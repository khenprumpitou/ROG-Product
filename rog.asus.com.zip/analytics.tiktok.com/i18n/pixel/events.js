window[window["TiktokAnalyticsObject"]]._env = {
    "env": "external",
    "key": ""
};
window[window["TiktokAnalyticsObject"]]._variation_id = 'traffic_1::default';
window[window["TiktokAnalyticsObject"]]._vids = '74172069,74539884,74813231';
window[window["TiktokAnalyticsObject"]]._cc = 'KH';
window[window.TiktokAnalyticsObject]._li || (window[window.TiktokAnalyticsObject]._li = {}), window[window.TiktokAnalyticsObject]._li["CVGIFO3C77U1H936GVN0"] = "0f1043fc-e4b8-11f0-b7be-1070fd686ae0";
window[window["TiktokAnalyticsObject"]]._cde = 390;;
if (!window[window["TiktokAnalyticsObject"]]._server_unique_id) window[window["TiktokAnalyticsObject"]]._server_unique_id = '0f105c87-e4b8-11f0-b7be-1070fd686ae0';
window[window["TiktokAnalyticsObject"]]._plugins = {
    "AdvancedMatching": true,
    "AutoAdvancedMatching": true,
    "AutoClick": true,
    "AutoConfig": true,
    "Callback": true,
    "DiagnosticsConsole": true,
    "EnableLPV": true,
    "EnrichIpv6": true,
    "EnrichIpv6V2": true,
    "EventBuilder": true,
    "EventBuilderRuleEngine": false,
    "HistoryObserver": true,
    "Identify": true,
    "JSBridge": false,
    "Metadata": true,
    "Monitor": false,
    "PageData": true,
    "PerformanceInteraction": false,
    "RuntimeMeasurement": false,
    "Shopify": true,
    "WebFL": false
};
window[window["TiktokAnalyticsObject"]]._csid_config = {
    "enable": true
};
window[window["TiktokAnalyticsObject"]]._ttls_config = {
    "key": "ttoclid"
};
window[window["TiktokAnalyticsObject"]]._auto_config = {
    "open_graph": ["audience"],
    "microdata": ["audience"],
    "json_ld": ["audience"],
    "meta": null
};
! function(e, n, i, d, o, t) {
    var u, l, a = g()._static_map || [{
            id: "MTc2YTgwMDRlMA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlNw",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlOA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlOQ",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !1
            }
        }, {
            id: "MTc2YTgwMDRlMTY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMTk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjI",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjM",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !1,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjQ",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjU",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjY",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjc",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !1,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjg",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMjk",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !1,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMzA",
            map: {
                AutoAdvancedMatching: !1,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }, {
            id: "MTc2YTgwMDRlMzE",
            map: {
                AutoAdvancedMatching: !0,
                Shopify: !0,
                JSBridge: !0,
                EventBuilderRuleEngine: !0,
                RemoveUnusedCode: !0
            }
        }],
        e = (g()._static_map = a, l = "https://analytics.tiktok.com/i18n/pixel/static/", null == (e = u = {
            "info": {
                "pixelCode": "CVGIFO3C77U1H936GVN0",
                "name": "ASUS Official TikTok Pixel",
                "status": 0,
                "setupMode": 0,
                "partner": "",
                "advertiserID": "0",
                "is_onsite": false,
                "firstPartyCookieEnabled": true
            },
            "plugins": {
                "Shopify": false,
                "AdvancedMatching": {
                    "email": true,
                    "phone_number": true,
                    "first_name": true,
                    "last_name": true,
                    "city": true,
                    "state": true,
                    "country": true,
                    "zip_code": true
                },
                "AutoAdvancedMatching": null,
                "Callback": true,
                "Identify": true,
                "Monitor": true,
                "PerformanceInteraction": true,
                "WebFL": true,
                "AutoConfig": {
                    "form_rules": null,
                    "vc_rules": {
                        "asus.com": [{
                            "version": "stable",
                            "rule_key": "asus.com",
                            "valueXpath": "//span[@class='price']",
                            "currency": {
                                "val": "$"
                            }
                        }],
                        "google.com": [{
                            "version": "stable",
                            "rule_key": "google.com",
                            "valueXpath": "//div[@class='ByJDCc ']",
                            "currency": {}
                        }]
                    }
                },
                "PageData": {
                    "performance": false,
                    "interaction": true
                },
                "DiagnosticsConsole": true,
                "CompetitorInsight": true,
                "EventBuilder": true,
                "EnrichIpv6": true,
                "HistoryObserver": {
                    "dynamic_web_pageview": true
                },
                "RuntimeMeasurement": true,
                "JSBridge": true,
                "EventBuilderRuleEngine": true,
                "RemoveUnusedCode": true,
                "EnableLPV": true,
                "AutoConfigV2": true
            },
            "rules": []
        }) || null == (n = e.info) ? void 0 : n.pixelCode);

    function c() {
        return window && window.TiktokAnalyticsObject || "ttq"
    }

    function g() {
        return window && window[c()]
    }

    function M(e, n) {
        n = g()[n];
        return n && n[e] || {}
    }
    var r, v, n = g();
    n || (n = [], window && (window[c()] = n)), Object.assign(u, {
        options: M(e, "_o")
    }), r = u, n._i || (n._i = {}), (v = r.info.pixelCode) && (n._i[v] || (n._i[v] = []), Object.assign(n._i[v], r), n._i[v]._load = +new Date), Object.assign(u.info, {
        loadStart: M(e, "_t"),
        loadEnd: M(e, "_i")._load,
        loadId: n._li && n._li[e] || ""
    }), null != (i = (d = n).instance) && null != (o = i.call(d, e)) && null != (t = o.setPixelInfo) && t.call(o, u.info), r = function(e, n, i) {
        var t = 0 < arguments.length && void 0 !== e ? e : {},
            u = 1 < arguments.length ? n : void 0,
            e = 2 < arguments.length ? i : void 0,
            n = function(e, n) {
                for (var i = 0; i < e.length; i++)
                    if (n.call(null, e[i], i)) return e[i]
            }(a, function(e) {
                for (var i = e.map, n = Object.keys(i), d = function(e) {
                        var n;
                        return "JSBridge" === e ? "external" !== (null == (n = g()._env) ? void 0 : n.env) === i[e] : !(!t[e] || !u[e]) === i[e]
                    }, o = 0; o < n.length; o++)
                    if (!d.call(null, n[o], o)) return !1;
                return !0
            });
        return n ? "".concat(e, "main.").concat(n.id, ".js") : "".concat(e, "main.").concat(a[0].id, ".js")
    }(n._plugins, u.plugins, l), v = e, (void 0 !== self.DedicatedWorkerGlobalScope ? self instanceof self.DedicatedWorkerGlobalScope : "DedicatedWorkerGlobalScope" === self.constructor.name) ? self.importScripts && self.importScripts(r) : ((i = document.createElement("script")).type = "text/javascript", i.async = !0, i.src = r, i.setAttribute("data-id", v), (r = document.getElementsByTagName("script")[0]) && r.parentNode && r.parentNode.insertBefore(i, r))
}();