(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [0], {
        1049: function(t, e, n) {
            "use strict";
            var r = n(779),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        1050: function(t, e, n) {
            "use strict";
            var r = n(780),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        1051: function(t, e, n) {
            "use strict";
            var r = n(781),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        1052: function(t, e, n) {
            "use strict";
            var r = n(782),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        1056: function(t, e, n) {
            "use strict";
            var r = n(786),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        1060: function(t, e, n) {
            "use strict";
            var r = n(790),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        },
        698: function(t, e, n) {
            t.exports = {
                areaContainer: "RegionItem__areaContainer__I-TCl",
                areaName: "RegionItem__areaName__383sp",
                areaButton: "RegionItem__areaButton__Zg1S+",
                arealink: "RegionItem__arealink__yzXTF",
                areaItemContent: "RegionItem__areaItemContent__z9noZ",
                active: "RegionItem__active__-r5Es",
                regionBlockTopContent: "RegionItem__regionBlockTopContent__gppVb"
            }
        },
        779: function(t, e, n) {
            t.exports = {
                searchItem: "SearchProductItem__searchItem__iorkL",
                searchProductItemContainer: "SearchProductItem__searchProductItemContainer__htj1B",
                title: "SearchProductItem__title__71ay-",
                noInch: "SearchProductItem__noInch__eem-s",
                productItemRatingContent: "SearchProductItem__productItemRatingContent__0V6gj",
                flexText: "SearchProductItem__flexText__ebvxU",
                slogan: "SearchProductItem__slogan__SQcci",
                searchProductImage: "SearchProductItem__searchProductImage__zWcDH",
                haveTag: "SearchProductItem__haveTag__RmRhB",
                imageBox: "SearchProductItem__imageBox__r2Ohb",
                mobileContent: "SearchProductItem__mobileContent__lb98+",
                content: "SearchProductItem__content__qP5Z3",
                mobileTextContent: "SearchProductItem__mobileTextContent__pLZpS",
                linkWrapper: "SearchProductItem__linkWrapper__g9YuH",
                linkItem: "SearchProductItem__linkItem__QiowQ",
                skuBlock: "SearchProductItem__skuBlock__uTlzH",
                skuLinkWrapper: "SearchProductItem__skuLinkWrapper__vmcaj",
                seeAllButton: "SearchProductItem__seeAllButton__ojINH",
                mobileUrlsContent: "SearchProductItem__mobileUrlsContent__w8J6d",
                last: "SearchProductItem__last__LEXhP"
            }
        },
        780: function(t, e, n) {
            t.exports = {
                searchItem: "SearchFAQItem__searchItem__ES-Dc",
                searchFAQItem: "SearchFAQItem__searchFAQItem__FFRys",
                title: "SearchFAQItem__title__X9ei4",
                description: "SearchFAQItem__description__VbU3E",
                last: "SearchFAQItem__last__M6jLm"
            }
        },
        781: function(t, e, n) {
            t.exports = {
                searchItem: "SearchArticleItem__searchItem__yDfB8",
                searchArticleItem: "SearchArticleItem__searchArticleItem__Aez1l",
                title: "SearchArticleItem__title__Be8+8",
                content: "SearchArticleItem__content__-Uyk0",
                last: "SearchArticleItem__last__6NvE7"
            }
        },
        782: function(t, e, n) {
            t.exports = {
                seeAllButton: "SeeAllButton__seeAllButton__YkDa4",
                isUppercase: "SeeAllButton__isUppercase__6LtIc"
            }
        },
        786: function(t, e, n) {
            t.exports = {
                searchPageTabContainer: "SearchPageTab__searchPageTabContainer__RG726",
                arrowIcon: "SearchPageTab__arrowIcon__BvadB",
                arrowButton: "SearchPageTab__arrowButton__ad6hB",
                arrowNextButton: "SearchPageTab__arrowNextButton__SET43",
                disabled: "SearchPageTab__disabled__f1ym7",
                pageList: "SearchPageTab__pageList__SXsmN",
                pageListItem: "SearchPageTab__pageListItem__CjK56",
                active: "SearchPageTab__active__F6Mr1",
                arrowPrevButton: "SearchPageTab__arrowPrevButton__YpQM-"
            }
        },
        790: function(t, e, n) {
            t.exports = {
                dropdownContainer: "FilterDropdown__dropdownContainer__slFWA",
                active: "FilterDropdown__active__+nXwN",
                selectedWrapper: "FilterDropdown__selectedWrapper__Mz97c",
                selectedAmount: "FilterDropdown__selectedAmount__MtAw6",
                slideUpDown: "FilterDropdown__slideUpDown__lvBz7",
                menuWrapper: "FilterDropdown__menuWrapper__loikj",
                option: "FilterDropdown__option__nj1gU",
                name: "FilterDropdown__name__+PSwa",
                checkbox: "FilterDropdown__checkbox__TAAtG",
                selected: "FilterDropdown__selected__6wL3R"
            }
        },
        925: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = (n(60), n(43), n(46), n(9)),
                l = (n(54), n(41), n(10), n(122), n(59), n(3)),
                d = n(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "searchFAQItemDescription", {
                        get: function() {
                            return this.data.highlightDescription ? this.data.highlightDescription.join("") : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.goLinkHandler = function() {
                        this.gaDataLayer(this.data.title)
                    }, e.prototype.gaDataLayer = function(title) {
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "internal-links",
                                event_action_DL: "clicked",
                                event_label_DL: "FAQ-".concat(title),
                                event_value_DL: 0
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "internal-links",
                                    event_action_DL: "clicked",
                                    event_label_DL: "FAQ-".concat(title),
                                    event_value_DL: 0
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!_hmt) return;
                            _hmt.push(["_trackEvent", "internal-links", "clicked", "FAQ-".concat(title)])
                        }
                    }, f([Object(d.Getter)("translation")], e.prototype, "translation", void 0), f([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "data", void 0), f([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "status", void 0), e = f([l.Component], e)
                }(l.Vue),
                v = h,
                y = n(1050),
                m = n(25);
            var component = Object(m.a)(v, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("a", {
                    class: [t.$style.searchItem, t.$style.searchFAQItem, Object(o.a)({}, t.$style.last, t.status)],
                    attrs: {
                        href: t.data.link,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    },
                    on: {
                        click: t.goLinkHandler
                    }
                }, [e("p", {
                    class: t.$style.title
                }, [t._v(t._s(t.data.title))]), t._v(" "), e("div", {
                    class: t.$style.description,
                    domProps: {
                        innerHTML: t._s(t.searchFAQItemDescription)
                    }
                })])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        926: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = n(9),
                l = (n(54), n(41), n(10), n(59), n(3)),
                d = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                f = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), e.prototype.goLinkHandler = function() {
                        this.gaDataLayer(this.data.title)
                    }, e.prototype.gaDataLayer = function(title) {
                        if ("undefined" != typeof window && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "internal-links",
                                event_action_DL: "clicked",
                                event_label_DL: "article-".concat(title),
                                event_value_DL: 0
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "internal-links",
                                    event_action_DL: "clicked",
                                    event_label_DL: "article-".concat(title),
                                    event_value_DL: 0
                                })
                            }), 200)), "rog.asus.com.cn" === window.location.host) {
                            if (!_hmt) return;
                            _hmt.push(["_trackEvent", "internal-links", "clicked", "article-".concat(title)])
                        }
                    }, _([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "data", void 0), _([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "status", void 0), e = _([l.Component], e)
                }(l.Vue),
                h = f,
                v = n(1051),
                y = n(25);
            var component = Object(y.a)(h, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("a", {
                    class: [t.$style.searchItem, t.$style.searchArticleItem, Object(o.a)({}, t.$style.last, t.status)],
                    attrs: {
                        href: t.data.url,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    },
                    on: {
                        click: t.goLinkHandler
                    }
                }, [e("p", {
                    class: t.$style.title
                }, [t._v(t._s(t.data.title))]), t._v(" "), e("div", {
                    class: t.$style.content,
                    domProps: {
                        innerHTML: t._s(t.data.previewContent)
                    }
                })])
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        927: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = n(9),
                l = (n(54), n(41), n(10), n(73), n(3)),
                d = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.currentTabListIndex = 0, e
                    }
                    return d(e, t), Object.defineProperty(e.prototype, "activePageInSplitArrayIndex", {
                        get: function() {
                            return Math.ceil(this.activePage / this.pageTabLimit) - 1
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "pageTabList", {
                        get: function() {
                            var t = Math.ceil(this.pageAmount / this.pageTabLimit),
                                e = [];
                            if ("undefined" != typeof window)
                                if (window.innerWidth <= 320)
                                    for (var n = Math.ceil(this.pageAmount / 4), r = 0; r < n; r++) {
                                        for (var o = [], c = 1 + 4 * r; c <= 4 * (r + 1); c++) c <= this.pageAmount && o.push(c);
                                        e.push(o)
                                    } else
                                        for (r = 0; r < t; r++) {
                                            for (o = [], c = 1 + r * this.pageTabLimit; c <= (r + 1) * this.pageTabLimit; c++) c <= this.pageAmount && o.push(c);
                                            r < t - 1 && o.push("..."), e.push(o)
                                        } else
                                            for (r = 0; r < t; r++) {
                                                for (o = [], c = 1 + r * this.pageTabLimit; c <= (r + 1) * this.pageTabLimit; c++) c <= this.pageAmount && o.push(c);
                                                r < t - 1 && o.push("..."), e.push(o)
                                            }
                            return e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "activePage", {
                        get: function() {
                            try {
                                var t = Number(this.$route.query.page);
                                return isNaN(t) ? 1 : t
                            } catch (t) {
                                return this.$route.query.page = "".concat(1), 1
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.created = function() {
                        this.currentTabListIndex = this.activePageInSplitArrayIndex
                    }, e.prototype.mounted = function() {}, e.prototype.switchPageHandler = function(t) {
                        var e = this.activePage;
                        if ("prev" === t) {
                            if (this.currentTabListIndex <= 0) return;
                            e--, this.$emit("switchPage", e)
                        } else if ("next" === t) {
                            if (this.currentTabListIndex >= this.pageTabList.length - 1) return;
                            e++, this.$emit("switchPage", e)
                        } else if ("..." === t) {
                            if (this.currentTabListIndex >= this.pageTabList.length) return;
                            this.$emit("switchPage", this.pageTabLimit * Math.ceil(this.activePage / 5) + 1)
                        } else this.$emit("switchPage", t)
                    }, _([Object(l.Prop)({
                        type: Number,
                        required: !0
                    })], e.prototype, "pageAmount", void 0), _([Object(l.Prop)({
                        type: Number,
                        default: 5
                    })], e.prototype, "pageTabLimit", void 0), e = _([Object(l.Component)({
                        components: {}
                    })], e)
                }(l.Vue),
                h = f,
                v = n(1056),
                y = n(25);
            var component = Object(y.a)(h, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.searchPageTabContainer
                }, [e("nav", {
                    attrs: {
                        role: "navigation",
                        "aria-label": "Pagination"
                    }
                }, [e("ul", {
                    class: t.$style.pageList
                }, [e("li", {
                    class: [t.$style.arrowButton, t.$style.arrowPrevButton, Object(o.a)({}, t.$style.disabled, t.currentTabListIndex <= 0)],
                    attrs: {
                        "aria-label": "prev page button",
                        tabindex: t.currentTabListIndex <= 0 ? -1 : 0
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.switchPageHandler("prev")
                        },
                        click: function(e) {
                            return t.switchPageHandler("prev")
                        }
                    }
                }, [e("svg", {
                    class: [t.$style.arrowIcon, t.$style.arrowLeft],
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        alt: "Previous Page Button"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M8.93 13.77L22.94 0v6.7l-9.18 8.94 9.18 9.66V32L8.93 17.51l-1.87-1.87 1.87-1.87z"
                    }
                })])]), t._v(" "), t._l(t.pageTabList[t.currentTabListIndex], (function(n) {
                    return e("li", {
                        key: n,
                        class: [t.$style.pageListItem, Object(o.a)({}, t.$style.active, n === t.activePage)]
                    }, [e("a", {
                        attrs: {
                            tabindex: "0",
                            "aria-label": n === t.activePage ? "Current Page, Page ".concat(t.activePage) : "Page ".concat(n),
                            "aria-current": n === t.activePage
                        },
                        on: {
                            keydown: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.switchPageHandler(n)
                            },
                            click: function(e) {
                                return e.preventDefault(), t.switchPageHandler(n)
                            }
                        }
                    }, [t._v(t._s(n))])])
                })), t._v(" "), e("li", {
                    class: [t.$style.arrowButton, t.$style.arrowNextButton, Object(o.a)({}, t.$style.disabled, t.currentTabListIndex >= t.pageTabList.length - 1)],
                    attrs: {
                        "aria-label": "next page button",
                        tabindex: t.currentTabListIndex >= t.pageTabList.length - 1 ? -1 : 0
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.switchPageHandler("next")
                        },
                        click: function(e) {
                            return t.switchPageHandler("next")
                        }
                    }
                }, [e("svg", {
                    class: [t.$style.arrowIcon, t.$style.arrowRight],
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        alt: "Next Page Button"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M23.07 13.77L9.06 0v6.7l9.18 8.94-9.18 9.66V32l14.01-14.49 1.87-1.87-1.87-1.87z"
                    }
                })])])], 2)])])
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        940: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = (n(26), n(20), n(9)),
                l = (n(54), n(41), n(10), n(18), n(29), n(3)),
                d = n(4),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                h = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isShow = !1, e
                    }
                    return _(e, t), e.prototype.watchRegionStatus = function(t, e) {
                        this.isShow = t
                    }, e.prototype.mounted = function() {
                        this.isShow = this.regionStatus
                    }, e.prototype.openAreaContent = function() {
                        this.nowOpenRegionNumber === this.regionNumber && (this.isShow = !this.isShow), this.$emit("clickOpen", this.regionNumber)
                    }, e.prototype.setCookieHandler = function(t, e) {
                        var n = t;
                        return this.isAccount && "undefined" != typeof window ? ("rogmars.asus.com" === window.location.host ? n = "cn" === e ? "https://accts-account.asus.com.cn/" : Object(d.b)("rog_account") ? t.replace("rogmars", "dev-account") + Object(d.b)("rog_account") : t.replace("rogmars", "dev-account") : "dev-rog.asus.com" === window.location.host ? n = "cn" === e ? "https://accts-account.asus.com.cn/" : Object(d.b)("rog_account") ? t.replace("dev-rog", "dev-account") + Object(d.b)("rog_account") : t.replace("dev-rog", "dev-account") : "rog.asus.com" === window.location.host ? n = Object(d.b)("rog_account") ? t.replace("rog", "account") + Object(d.b)("rog_account") : t.replace("rog", "account") : "localhost:8000" === window.location.host ? n = Object(d.b)("rog_account") ? t.replace("rog", "account") + Object(d.b)("rog_account") : t.replace("rogmars", "account") : "rog.asus.com.cn" === window.location.host && (n = "https://account.asus.com.cn/"), n) : n
                    }, f([Object(l.Prop)()], e.prototype, "areaItemsData", void 0), f([Object(l.Prop)()], e.prototype, "regionNumber", void 0), f([Object(l.Prop)()], e.prototype, "nowOpenRegionNumber", void 0), f([Object(l.Prop)()], e.prototype, "regionStatus", void 0), f([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isAccount", void 0), f([Object(l.Watch)("regionStatus")], e.prototype, "watchRegionStatus", null), e = f([l.Component], e)
                }(l.Vue),
                v = h,
                y = n(959),
                m = n(25);
            var component = Object(m.a)(v, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", [e("div", {
                    class: t.$style.areaName
                }, [t._v(t._s(t.areaItemsData.name) + "\n    "), e("div", {
                    class: t.$style.areaButton
                }, [e("svg", {
                    class: [Object(o.a)({}, t.$style.active, !t.isShow)],
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "plus",
                        role: "presentation",
                        focusable: "false"
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.openAreaContent()
                        },
                        click: function(e) {
                            return t.openAreaContent()
                        }
                    }
                }, [e("path", {
                    attrs: {
                        d: "M24 15h-7V8h-2v7H8v2h7v7h2v-7h7v-2z"
                    }
                })]), t._v(" "), e("svg", {
                    class: [Object(o.a)({}, t.$style.active, t.isShow)],
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "minus",
                        role: "presentation",
                        focusable: "false"
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.openAreaContent()
                        },
                        click: function(e) {
                            return t.openAreaContent()
                        }
                    }
                }, [e("path", {
                    attrs: {
                        d: "M8 15h16v2H8z"
                    }
                })])])]), t._v(" "), e("div", {
                    class: [t.$style.areaItemContent, Object(o.a)({}, t.$style.active, t.isShow)]
                }, [e("ClientOnly", t._l(t.areaItemsData.items, (function(n, r) {
                    return e("a", {
                        key: "".concat(n.websiteCode, "-").concat(r),
                        class: t.$style.arealink,
                        attrs: {
                            tabindex: "0",
                            target: n.target,
                            rel: "_blank" === n.target ? "noopener noreferrer" : "",
                            href: t.setCookieHandler(n.url, n.WebsiteCode)
                        }
                    }, [e("span", [t._v(t._s(n.region))])])
                })), 0)], 1)])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        945: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = (n(26), n(20), n(60), n(9)),
                l = (n(54), n(41), n(10), n(51), n(59), n(44), n(32), n(91), n(18), n(33), n(29), n(3)),
                d = n(7),
                _ = n(79),
                f = n(924),
                h = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                v = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                y = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.goToPageStatus = !0, e.skuListLimit = 6, e.imageWidth = "160", e.productPrice = 0, e.regularPrice = 0, e.amountOff = 0, e.buttonStatus = "", e.isRatingHide = !1, e
                    }
                    return h(e, t), Object.defineProperty(e.prototype, "skuAmount", {
                        get: function() {
                            return this.productData.skus.length
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "skuList", {
                        get: function() {
                            return this.productData.skus.slice(0, this.skuListLimit)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "overviewUrl", {
                        get: function() {
                            return this.productData.urls[0]
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.imageHandler = function(t, e) {
                        return t.indexOf(".jpg") > -1 || t.indexOf(".png") > -1 ? t : "".concat(t, "/w").concat(e)
                    }, Object.defineProperty(e.prototype, "tokenData", {
                        get: function() {
                            return localStorage.getItem("rog_ec_token")
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.beforeMount = function() {
                        this.initial()
                    }, e.prototype.mounted = function() {
                        var t = this;
                        Object(_.a)().width <= 768 && (this.imageWidth = "97"), this.$nextTick((function() {
                            setTimeout((function() {
                                var e, n, r, o;
                                (null === (e = t.$refs) || void 0 === e ? void 0 : e.review) && (null === (n = t.$refs) || void 0 === n ? void 0 : n.review).getElementsByClassName("bv_text") && (null === (r = t.$refs) || void 0 === r ? void 0 : r.review).getElementsByClassName("bv_text")[1] && "(0)" !== (null === (o = t.$refs) || void 0 === o ? void 0 : o.review).getElementsByClassName("bv_text")[1].innerText && (t.isRatingHide = !0)
                            }), 2e3)
                        }))
                    }, e.prototype.initial = function() {}, e.prototype.gaHandler = function(t, e) {
                        var n = "";
                        if ("global" === this.lang) {
                            var r = (o = t.url.split("/").filter((function(t) {
                                return t
                            }))).length - 1;
                            o.forEach((function(link, t) {
                                t >= 0 && t < r ? n = n + "/" + link : t >= 0 && (n += "/Undefined")
                            }))
                        } else {
                            var o, c = (o = t.url.split("/").filter((function(t) {
                                return t
                            }))).length - 1;
                            o.forEach((function(link, t) {
                                t > 0 && t < c ? n = n + "/" + link : t > 0 && (n += "/Undefined")
                            }))
                        }
                        window.dataLayer.push({
                            event: "productClick",
                            ecommerce: {
                                click: {
                                    actionField: {
                                        list: "search_product_list"
                                    },
                                    products: [{
                                        name: this.productData.name,
                                        id: t.partNo,
                                        price: this.productData.price,
                                        brand: "ROG",
                                        category: n,
                                        list: "search_product_list",
                                        position: e + 1
                                    }]
                                }
                            }
                        }), window.location.assign("/".concat(t.url, "spec/"))
                    }, e.prototype.skuLinkHandler = function(t) {
                        return new RegExp("supportonly", "ig").test(t.url) ? "/".concat(t.url) : "/".concat(t.url, "spec/")
                    }, e.prototype.link = function(t) {
                        var e = this.removeSlash(t);
                        return "Support" === t.id ? "/".concat(e.replace(/ /g, "_")) : "Store" === t.id ? t.url : "/".concat(e.replace(/ /g, "_")).toLowerCase()
                    }, e.prototype.removeSlash = function(t) {
                        return t.url.lastIndexOf("/") === t.url.length - 1 ? t.url.substring(0, t.url.length - 1) : ""
                    }, e.prototype.isSupportOnly = function(t) {
                        return new RegExp("supportonly", "ig").test(t.url) ? "Overview" !== t.id : t.url.length > 0
                    }, e.prototype.goToPage = function(t, e, n) {
                        var r = this;
                        if (this.goToPageStatus) {
                            if (this.goToPageStatus = !1, window.innerWidth > 1024 ? window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "buttons",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(e.name, "/").concat(t.name, "-").concat(t.name),
                                    event_value_DL: 0
                                }) : setTimeout((function() {
                                    window.dataLayer.push({
                                        event: "data_layer_event",
                                        event_category_DL: "buttons",
                                        event_action_DL: "clicked",
                                        event_label_DL: "".concat(e.name, "/").concat(t.name, "-").concat(t.name),
                                        event_value_DL: 0
                                    })
                                }), 200), "rog.asus.com.cn" === window.location.host) {
                                if (!_hmt) return;
                                _hmt.push(["_trackEvent", "buttons", "clicked", "".concat(e.name, "/").concat(t.name, "-").concat(t.name)])
                            }
                            var o = [],
                                c = "";
                            e.skus.forEach((function(t) {
                                if ("global" === r.lang) {
                                    var l = (d = t.url.split("/").filter((function(t) {
                                        return t
                                    }))).length - 1;
                                    d.forEach((function(link, t) {
                                        t >= 0 && t < l ? c = c + "/" + link : t >= 0 && (c += "/Undefined")
                                    }))
                                } else {
                                    var d, _ = (d = t.url.split("/").filter((function(t) {
                                        return t
                                    }))).length - 1;
                                    d.forEach((function(link, t) {
                                        t > 0 && t < _ ? c = c + "/" + link : t > 0 && (c += "/Undefined")
                                    }))
                                }
                                o.push({
                                    name: e.name,
                                    id: t.partNo,
                                    price: e.price,
                                    brand: "ROG",
                                    category: c,
                                    list: "search_product_list",
                                    position: n + 1
                                })
                            })), window.dataLayer.push({
                                event: "productClick",
                                ecommerce: {
                                    click: {
                                        actionField: {
                                            list: "search_product_list"
                                        },
                                        products: o
                                    }
                                }
                            });
                            var l = this.removeSlash(t);
                            "Support" === t.id ? window.location.assign("/".concat(l)) : "Store" === t.id ? window.location.assign(t.url) : window.location.assign("/".concat(l))
                        }
                    }, v([Object(d.Getter)("translation")], e.prototype, "translation", void 0), v([Object(d.Getter)("websiteId")], e.prototype, "websiteId", void 0), v([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), v([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "productData", void 0), v([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "searchProductItemStatus", void 0), e = v([Object(l.Component)({
                        components: {
                            ProductTag: f.a
                        }
                    })], e)
                }(l.Vue),
                m = y,
                w = n(1049),
                O = n(25);
            var component = Object(O.a)(m, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.searchItem, t.$style.searchProductItemContainer, Object(o.a)({}, t.$style.last, t.searchProductItemStatus)]
                }, [e("ProductTag", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.productData.isNew,
                        expression: "productData.isNew"
                    }],
                    attrs: {
                        isSearch: !0
                    }
                }), t._v(" "), e("div", {
                    class: [t.$style.searchProductImage, Object(o.a)({}, t.$style.haveTag, t.productData.isNew)]
                }, [e("div", {
                    attrs: {
                        "aria-label": t.productData.name
                    }
                }, [e("div", {
                    class: [t.$style.imageBox]
                }, [e("img", {
                    attrs: {
                        src: t.imageHandler(t.productData.imgUrl, t.imageWidth),
                        alt: ""
                    }
                })]), t._v(" "), e("div", {
                    class: t.$style.mobileContent
                }, [e("p", {
                    class: [t.$style.title, Object(o.a)({}, t.$style.noInch, "" === t.productData.inch)]
                }, [t._v(t._s(t.productData.name))]), t._v(" "), t.isRatingHide ? e("div", {
                    class: t.$style.productItemRatingContent
                }, [e("div", {
                    ref: "review",
                    attrs: {
                        "data-bv-show": "inline_rating",
                        "data-bv-product-id": "".concat(t.productData.externalId)
                    }
                })]) : t._e(), t._v(" "), t.productData.price ? e("p", {
                    class: t.$style.flexText
                }, [e("span", [t._v(t._s(t.productData.price))])]) : t._e(), t._v(" "), t.productData.slogan ? e("p", {
                    class: t.$style.slogan,
                    domProps: {
                        innerHTML: t._s(t.productData.slogan)
                    }
                }) : t._e()])])]), t._v(" "), e("div", {
                    class: t.$style.mobileUrlsContent
                }, [e("ul", {
                    class: t.$style.linkWrapper,
                    attrs: {
                        role: "list"
                    }
                }, t._l(t.productData.urls, (function(n, r) {
                    return e("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isSupportOnly(n),
                            expression: "isSupportOnly(item)"
                        }],
                        key: "".concat(r, "-").concat(n.id),
                        class: t.$style.linkItem,
                        attrs: {
                            role: "none"
                        }
                    }, [e("a", {
                        attrs: {
                            role: "listitem",
                            href: t.link(n)
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), t.goToPage(n, t.productData, r)
                            }
                        }
                    }, [t._v(t._s(n.name))])])
                })), 0)]), t._v(" "), e("div", {
                    class: t.$style.content
                }, [e("div", {
                    class: [t.$style.mobileTextContent]
                }, [e("a", {
                    attrs: {
                        href: t.link(t.overviewUrl)
                    },
                    on: {
                        click: function(e) {
                            return e.preventDefault(), t.goToPage(t.overviewUrl, t.productData, 0)
                        }
                    }
                }, [e("p", {
                    class: [t.$style.title, Object(o.a)({}, t.$style.noInch, "" === t.productData.inch)]
                }, [t._v(t._s(t.productData.name))]), t._v(" "), e("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.isRatingHide,
                        expression: "isRatingHide"
                    }],
                    class: t.$style.productItemRatingContent
                }, [e("div", {
                    ref: "review",
                    attrs: {
                        "data-bv-show": "inline_rating",
                        "data-bv-product-id": "".concat(t.productData.externalId)
                    }
                })]), t._v(" "), t.productData.price ? e("p", {
                    class: t.$style.flexText
                }, [e("span", [t._v(t._s(t.productData.price))])]) : t._e(), t._v(" "), t.productData.slogan ? e("p", {
                    class: t.$style.slogan,
                    domProps: {
                        innerHTML: t._s(t.productData.slogan)
                    }
                }) : t._e()]), t._v(" "), e("ul", {
                    class: t.$style.linkWrapper,
                    attrs: {
                        role: "list"
                    }
                }, t._l(t.productData.urls, (function(n, r) {
                    return e("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isSupportOnly(n),
                            expression: "isSupportOnly(item)"
                        }],
                        key: "".concat(r, "-").concat(n.id),
                        class: t.$style.linkItem,
                        attrs: {
                            role: "listitem"
                        }
                    }, [e("a", {
                        attrs: {
                            href: t.link(n)
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), t.goToPage(n, t.productData, r)
                            }
                        }
                    }, [t._v(t._s(n.name))])])
                })), 0)]), t._v(" "), t.skuAmount >= 1 ? e("div", {
                    class: t.$style.skuBlock
                }, [e("p", {
                    class: t.$style.title
                }, [t._v(t._s(t.translation.Search_Model_SKU))]), t._v(" "), e("div", {
                    class: t.$style.skuLinkWrapper
                }, t._l(t.skuList, (function(n, r) {
                    return e("a", {
                        key: "".concat(r, "-").concat(n.partNo),
                        class: t.$style.linkItem,
                        attrs: {
                            role: "link",
                            "aria-label": "go to spec page, ".concat(n.name),
                            href: t.skuLinkHandler(n)
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), e.stopPropagation(), t.gaHandler(n, r)
                            }
                        }
                    }, [e("span", [t._v(t._s(n.name))]), t._v(" "), e("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            "data-name": "圖層 1",
                            viewBox: "0 0 32 32",
                            "aria-hidden": "true",
                            "svg-inline": "",
                            alt: "arrow",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [e("path", {
                        attrs: {
                            d: "M23.07 13.77L9.06 0v6.7l9.18 8.94-9.18 9.66V32l14.01-14.49 1.87-1.87-1.87-1.87z"
                        }
                    })])])
                })), 0)]) : t._e()])], 1)
            }), [], !1, (function(t) {
                this.$style = w.default.locals || w.default
            }), null, null);
            e.a = component.exports
        },
        946: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = n(9),
                l = (n(54), n(41), n(10), n(3)),
                d = n(7),
                _ = n(925),
                f = n(926),
                h = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                v = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                y = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), e.prototype.clickHandler = function() {
                        this.$emit("click")
                    }, v([Object(d.Getter)("translation")], e.prototype, "translation", void 0), v([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isUppercase", void 0), e = v([Object(l.Component)({
                        components: {
                            SearchFAQItem: _.a,
                            SearchArticleItem: f.a
                        }
                    })], e)
                }(l.Vue),
                m = y,
                w = n(1052),
                O = n(25);
            var component = Object(O.a)(m, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.seeAllButton, Object(o.a)({}, t.$style.isUppercase, t.isUppercase)],
                    attrs: {
                        role: "button",
                        tabindex: "0"
                    },
                    on: {
                        click: t.clickHandler
                    }
                }, [e("span", [t._v(t._s(t.translation.Search_Extand))]), t._v(" "), e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M23.07 13.77L9.06 0v6.7l9.18 8.94-9.18 9.66V32l14.01-14.49 1.87-1.87-1.87-1.87z"
                    }
                })])])
            }), [], !1, (function(t) {
                this.$style = w.default.locals || w.default
            }), null, null);
            e.a = component.exports
        },
        956: function(t, e, n) {
            "use strict";
            var r, o = n(2),
                c = (n(26), n(9)),
                l = (n(54), n(41), n(10), n(51), n(20), n(78), n(59), n(47), n(70), n(690), n(205), n(3)),
                d = n(753),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, n, desc) {
                    var r, o = arguments.length,
                        l = o < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (o < 3 ? r(l) : o > 3 ? r(e, n, l) : r(e, n)) || l);
                    return o > 3 && l && Object.defineProperty(e, n, l), l
                },
                h = function(t, e, n) {
                    if (n || 2 === arguments.length)
                        for (var r, i = 0, o = e.length; i < o; i++) !r && i in e || (r || (r = Array.prototype.slice.call(e, 0, i)), r[i] = e[i]);
                    return t.concat(r || Array.prototype.slice.call(e))
                },
                v = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isMobile = !1, e
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "mapIdArray", {
                        get: function() {
                            return this.options.map((function(t) {
                                return t.id
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "selectedAmount", {
                        get: function() {
                            return this.value.length
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.openMenuHandler = function() {
                        this.options.length && !this.isMobile && (clearTimeout(this.timer), this.$emit("trigger", !0))
                    }, e.prototype.closeMenuHandler = function(t) {
                        var e = this;
                        t === this.options.length && (this.timer = setTimeout((function() {
                            e.$emit("trigger", !1)
                        }), 100)), this.options.length && !this.isMobile && (this.timer = setTimeout((function() {
                            e.$emit("trigger", !1)
                        }), 100))
                    }, e.prototype.toggleMenuHandler = function() {
                        this.options.length && this.$emit("trigger", !this.trigger)
                    }, e.prototype.isSelected = function(t) {
                        return this.value.includes(t)
                    }, e.prototype.selectHandler = function(t) {
                        var e = t.id;
                        if (this.gaDataLayer(t), this.isSelected(e)) {
                            var n = this.value.findIndex((function(t) {
                                    return t === e
                                })),
                                r = h([], this.value, !0);
                            r.splice(n, 1), this.$emit("input", r)
                        } else this.$emit("input", h(h([], this.value, !0), [e], !1))
                    }, e.prototype.mounted = function() {
                        var t = this;
                        "undefined" != typeof window && (window.innerWidth <= 1024 && (this.isMobile = !0), window.addEventListener("resize", (function() {
                            window.innerWidth <= 1024 ? t.isMobile = !0 : t.isMobile = !1
                        })))
                    }, e.prototype.gaDataLayer = function(t) {
                        var e = this;
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "filter",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(this.name, "/").concat(t.name),
                                event_value_DL: 0
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "filter",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(e.name, "/").concat(t.name),
                                    event_value_DL: 0
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!_hmt) return;
                            _hmt.push(["_trackEvent", "filter", "clicked", "".concat(this.name, "/").concat(t.name)])
                        }
                    }, f([Object(l.Prop)({
                        required: !0,
                        default: !1
                    })], e.prototype, "trigger", void 0), f([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "options", void 0), f([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "value", void 0), f([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "name", void 0), e = f([Object(l.Component)({
                        components: {
                            SlideUpDown: d.a
                        }
                    })], e)
                }(l.Vue),
                y = v,
                m = n(1060),
                w = n(25);
            var component = Object(w.a)(y, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.dropdownContainer, Object(o.a)({}, t.$style.active, t.trigger)],
                    attrs: {
                        tabindex: "0"
                    },
                    on: {
                        mouseenter: t.openMenuHandler,
                        mouseleave: t.closeMenuHandler,
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.toggleMenuHandler.apply(null, arguments)
                        }
                    }
                }, [e("div", {
                    class: t.$style.selectedWrapper,
                    on: {
                        click: t.toggleMenuHandler
                    }
                }, [e("span", [t._v(t._s(t.name))]), t._v(" "), t.selectedAmount > 0 ? e("span", {
                    class: t.$style.selectedAmount
                }, [t._v(t._s(t.selectedAmount))]) : t._e(), t._v(" "), e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "arrow",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M18.23 23.01L32 9h-6.7l-8.94 9.19L6.7 9H0l14.49 14.01 1.87 1.88 1.87-1.88z"
                    }
                })])]), t._v(" "), e("SlideUpDown", {
                    class: t.$style.slideUpDown,
                    attrs: {
                        active: t.trigger,
                        duration: 500
                    }
                }, [e("div", {
                    class: t.$style.menuWrapper,
                    attrs: {
                        tabindex: "-1"
                    }
                }, t._l(t.options, (function(option, n) {
                    return e("div", {
                        key: n,
                        class: t.$style.option,
                        attrs: {
                            tabindex: !0 === t.trigger ? 0 : -1
                        },
                        on: {
                            click: function(e) {
                                return t.selectHandler(option)
                            },
                            keydown: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.selectHandler(option)
                            }
                        }
                    }, [e("div", {
                        class: [t.$style.checkbox, Object(o.a)({}, t.$style.selected, t.isSelected(option.id))]
                    }), t._v(" "), e("span", {
                        class: t.$style.name
                    }, [t._v(t._s(option.name))])])
                })), 0)])], 1)
            }), [], !1, (function(t) {
                this.$style = m.default.locals || m.default
            }), null, null);
            e.a = component.exports
        },
        959: function(t, e, n) {
            "use strict";
            var r = n(698),
                o = n.n(r);
            n.d(e, "default", (function() {
                return o.a
            }))
        }
    }
]);