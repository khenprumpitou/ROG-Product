(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [5], {
        1022: function(t, e, o) {
            "use strict";
            var r = o(752),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1032: function(t, e, o) {
            "use strict";
            var r = o(763),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1034: function(t, e, o) {
            "use strict";
            var r = o(765),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1035: function(t, e, o) {
            "use strict";
            var r = o(766),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1037: function(t, e, o) {
            "use strict";
            var r = o(768),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1073: function(t, e, o) {
            "use strict";
            var r = o(800),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1087: function(t, e, o) {
            "use strict";
            var r = o(812),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1090: function(t, e, o) {
            "use strict";
            var r = o(815),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1091: function(t, e, o) {
            "use strict";
            var r = o(816),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1092: function(t, e, o) {
            "use strict";
            var r = o(817),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        1094: function(t, e, o) {
            "use strict";
            var r = o(819),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        686: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(3)),
                d = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), _([Object(l.Prop)({
                        default: !0
                    })], e.prototype, "isLoading", void 0), _([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isWhite", void 0), _([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSupport", void 0), e = _([l.Component], e)
                }(l.Vue),
                m = h,
                f = o(1022),
                y = o(25);
            var component = Object(y.a)(m, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.contentLoadingContainer, Object(n.a)({}, t.$style.isLeave, !t.isLoading), Object(n.a)({}, t.$style.isWhite, t.isWhite), Object(n.a)({}, t.$style.isSupport, t.isSupport)]
                }, [e("i", {
                    class: t.$style.loadingIcon
                })])
            }), [], !1, (function(t) {
                this.$style = f.default.locals || f.default
            }), null, null);
            e.a = component.exports
        },
        688: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(3)),
                d = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), _([Object(l.Prop)({
                        default: !0
                    })], e.prototype, "isLoading", void 0), _([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isContentLoading", void 0), e = _([l.Component], e)
                }(l.Vue),
                m = h,
                f = o(964),
                y = o(25);
            var component = Object(y.a)(m, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.loadingContainer, Object(n.a)({}, t.$style.isFullContentLoading, t.isContentLoading), Object(n.a)({}, t.$style.isLeave, !t.isLoading)]
                }, [e("i", {
                    class: t.$style.loadingIcon
                })])
            }), [], !1, (function(t) {
                this.$style = f.default.locals || f.default
            }), null, null);
            e.a = component.exports
        },
        689: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(28), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.list = ["global", "bd", "bn", "lk", "mm", "np", "latin", "pe", "py", "uy", "kz", "rs", "africa-fr", "ea", "ea-sw", "middleeast-fa", "eg", "eg-en", "me-ar", "me-en", "nafr-ar", "wa"], e
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "isShowHDMILogo", {
                        get: function() {
                            return !!(this.routeInfo && Object.keys(this.routeInfo).length > 0) && this.routeInfo.hdmiInfo.hdmiFlag
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "HDMIRegistration", {
                        get: function() {
                            return !!(this.routeInfo && Object.keys(this.routeInfo).length > 0) && this.routeInfo.hdmiInfo.hdmiRegistration
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getProductLine", {
                        get: function() {
                            if (this.routeInfo && Object.keys(this.routeInfo).length > 0) return this.routeInfo.webPathName
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "disclaimerNumber", {
                        get: function() {
                            var t, e;
                            return !!((null === (t = this.productDisclaimer) || void 0 === t ? void 0 : t.disclaimer) && Object.keys(null === (e = this.productDisclaimer) || void 0 === e ? void 0 : e.disclaimer).length > 0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), h([Object(d.Getter)("productDisclaimer")], e.prototype, "productDisclaimer", void 0), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "backgroundType", void 0), e = h([l.Component], e)
                }(l.Vue),
                f = m,
                y = o(1087),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t, e, r = this,
                    c = r._self._c;
                r._self._setupProxy;
                return r.disclaimerNumber || r.isShowHDMILogo ? c("div", {
                    class: [r.$style.productFooterContainer, (t = {}, Object(n.a)(t, r.$style.productBackgroundBlack, "black" === r.backgroundType), Object(n.a)(t, r.$style.productBackgroundDarkBlack, "darkBlack" === r.backgroundType), Object(n.a)(t, r.$style.productBackgroundArticleBlack, "articleBlack" === r.backgroundType), t)]
                }, [c("div", {
                    class: r.$style.productFooterContent
                }, [r.isShowHDMILogo && !r.HDMIRegistration ? c("div", {
                    class: r.$style.productFooterHDMI
                }, [c("img", {
                    attrs: {
                        src: o(1085),
                        alt: "Product has High-Definition Multimedia Interface"
                    }
                })]) : r._e(), r._v(" "), r.isShowHDMILogo && r.HDMIRegistration ? c("div", {
                    class: r.$style.productFooterHDMI
                }, [c("img", {
                    attrs: {
                        src: o(1086),
                        alt: "Product has High-Definition Multimedia Interface"
                    }
                })]) : r._e(), r._v(" "), c("p", {
                    staticClass: "sr-only"
                }, [r._v(r._s(r.translation.SEO_Disclaimer))]), r._v(" "), r.disclaimerNumber ? c("div", {
                    class: r.$style.productFooterList
                }, [null !== (e = r.productDisclaimer) && void 0 !== e && e.disclaimer ? c("ul", r._l(r.productDisclaimer.disclaimer, (function(t, e) {
                    return c("li", {
                        key: e
                    }, [c("div", {
                        domProps: {
                            innerHTML: r._s(t)
                        }
                    })])
                })), 0) : r._e()]) : r._e()])]) : r._e()
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        695: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "getProductStatus", {
                        get: function() {
                            return "buy" === this.getButtonStatus || "customize" === this.getButtonStatus ? 1 : "notify_me" === this.getButtonStatus ? 2 : 3
                        },
                        enumerable: !1,
                        configurable: !0
                    }), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "getButtonStatus", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "openAmountOff", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isCompare", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isNews", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSearch", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSpec", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isProductCard", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "single", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "lang", void 0), h([Object(l.Prop)({
                        default: 356
                    })], e.prototype, "productCardWidth", void 0), e = h([Object(l.Component)({})], e)
                }(l.Vue),
                f = m,
                y = o(1035),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t, e, o = this,
                    r = o._self._c;
                o._self._setupProxy;
                return r("div", {
                    class: [o.$style.tagContainer, (t = {}, Object(n.a)(t, o.$style.isCompare, o.isCompare), Object(n.a)(t, o.$style.isSearch, o.isSearch), Object(n.a)(t, o.$style.isSpec, o.isSpec), Object(n.a)(t, o.$style.single, o.single), Object(n.a)(t, o.$style.isProductCard, o.isProductCard), Object(n.a)(t, o.$style.col, o.productCardWidth < 280), t)]
                }, [3 !== o.getProductStatus ? r("div", {
                    class: o.$style.tagBox
                }, [1 === o.getProductStatus ? r("div", {
                    staticClass: "stockTag",
                    class: [o.$style.stock, {
                        jpFont: "jp" === o.lang
                    }]
                }, [r("span", {
                    class: [{
                        jpFont: "jp" === o.lang
                    }]
                }, [o._v(o._s(o.translation.PDList_Stock))])]) : 2 === o.getProductStatus ? r("div", {
                    staticClass: "stockTag",
                    class: o.$style.outStock
                }, [r("span", [o._v(o._s(o.translation.PDList_T_Out_of_Stock))])]) : o._e(), o._v(" "), r("div", {
                    class: [o.$style.tagName, (e = {}, Object(n.a)(e, o.$style.onStock, 1 === o.getProductStatus || 2 === o.getProductStatus), Object(n.a)(e, o.$style.noStock, 3 === o.getProductStatus), e)]
                }, [o.isNews ? r("div", {
                    class: o.$style.tagNameBorder
                }, [o.isNews ? r("span", [o._v(o._s(o.translation.Product_New))]) : o._e()]) : o._e(), o._v(" "), o.openAmountOff ? r("div", {
                    class: o.$style.tagNameBorder
                }, [o.openAmountOff ? r("span", [o._v(o._s(o.translation.eShop_Deals))]) : o._e()]) : o._e()])]) : o._e()])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        700: function(t, e, o) {
            t.exports = {
                loadingContainer: "fullLoading__loadingContainer__sy4Rg",
                isFullContentLoading: "fullLoading__isFullContentLoading__1LWxP",
                loadingIcon: "fullLoading__loadingIcon__g1tiM",
                "rotate-ltr": "fullLoading__rotate-ltr__8qKue",
                "rotate-rtl": "fullLoading__rotate-rtl__by1XC",
                isLeave: "fullLoading__isLeave__ZVDz5",
                fadeinout: "fullLoading__fadeinout__Tmef9"
            }
        },
        732: function(t, e, o) {
            t.exports = {
                tagContainer: "ProductStatus__tagContainer__p294a",
                isProductCard: "ProductStatus__isProductCard__D2l41",
                isRelated: "ProductStatus__isRelated__4tC5T",
                isHotProduct: "ProductStatus__isHotProduct__d0-a2",
                col: "ProductStatus__col__RzrlR",
                isCompare: "ProductStatus__isCompare__5UBDv",
                isSpec: "ProductStatus__isSpec__oesRy",
                single: "ProductStatus__single__SAxn8",
                stock: "ProductStatus__stock__voZSe",
                outStock: "ProductStatus__outStock__J0XeQ",
                tagBox: "ProductStatus__tagBox__ImV8V",
                tagName: "ProductStatus__tagName__aGXQy",
                onStock: "ProductStatus__onStock__No0bT",
                noStock: "ProductStatus__noStock__9lh7e",
                tagNameBorder: "ProductStatus__tagNameBorder__Ljm-m",
                flashSale: "ProductStatus__flashSale__Rzw74",
                needPaddingLeft: "ProductStatus__needPaddingLeft__ioefW",
                needLeft: "ProductStatus__needLeft__L8oUJ",
                full: "ProductStatus__full__3e7wa",
                isPadding: "ProductStatus__isPadding__72mr4",
                tagTriangle: "ProductStatus__tagTriangle__29XzI"
            }
        },
        752: function(t, e, o) {
            t.exports = {
                contentLoadingContainer: "contentLoading__contentLoadingContainer__2pjC2",
                loadingIcon: "contentLoading__loadingIcon__IrHI8",
                "rotate-ltr": "contentLoading__rotate-ltr__dVJRD",
                "rotate-rtl": "contentLoading__rotate-rtl__N0np7",
                isSupport: "contentLoading__isSupport__TnRz5",
                isLeave: "contentLoading__isLeave__LjvdG",
                fadeinout: "contentLoading__fadeinout__KypcP",
                isWhite: "contentLoading__isWhite__Xcvpg"
            }
        },
        763: function(t, e, o) {
            t.exports = {
                sortButton: "ProductResultSort__sortButton__CQ2ED",
                sortSwitch: "ProductResultSort__sortSwitch__fEvvM",
                active: "ProductResultSort__active__AP-+F",
                dropdownIcon: "ProductResultSort__dropdownIcon__EIJAp",
                desktop: "ProductResultSort__desktop__8qltP",
                mobile: "ProductResultSort__mobile__UGnI8",
                mobileSelect: "ProductResultSort__mobileSelect__2Ylq7",
                sortList: "ProductResultSort__sortList__cBS6q",
                open: "ProductResultSort__open__TWNFI",
                listSortItem: "ProductResultSort__listSortItem__P2DMn"
            }
        },
        765: function(t, e, o) {
            t.exports = {
                tagContainer: "ProductTag__tagContainer__FDv4L",
                isCompare: "ProductTag__isCompare__74Gj7",
                isSearch: "ProductTag__isSearch__1j6zk",
                tagBox: "ProductTag__tagBox__evJiZ",
                tagName: "ProductTag__tagName__ctfK4",
                tagTriangle: "ProductTag__tagTriangle__VyqfF"
            }
        },
        766: function(t, e, o) {
            t.exports = {
                tagContainer: "ProductStock__tagContainer__bgf0t",
                isProductCard: "ProductStock__isProductCard__l02FZ",
                col: "ProductStock__col__Fp-hE",
                isCompare: "ProductStock__isCompare__7wSoG",
                isSpec: "ProductStock__isSpec__zjWUK",
                single: "ProductStock__single__jHNeU",
                stock: "ProductStock__stock__CplSf",
                outStock: "ProductStock__outStock__uOyfJ",
                tagBox: "ProductStock__tagBox__Qq-62",
                tagName: "ProductStock__tagName__OY0RR",
                onStock: "ProductStock__onStock__71Tm6",
                noStock: "ProductStock__noStock__pW0Ee",
                tagNameBorder: "ProductStock__tagNameBorder__GfcGd",
                flashSale: "ProductStock__flashSale__xVkSP",
                full: "ProductStock__full__LXNA+",
                isPadding: "ProductStock__isPadding__DS9yl",
                tagTriangle: "ProductStock__tagTriangle__VYkBG"
            }
        },
        768: function(t, e, o) {
            t.exports = {
                productItem: "ProductResultItem__productItem__Wc51h",
                outStock: "ProductResultItem__outStock__7Bzid",
                productScreenWidth: "ProductResultItem__productScreenWidth__kYYSe",
                noData: "ProductResultItem__noData__8tfJ2",
                productNoImage: "ProductResultItem__productNoImage__1BAbq",
                productCheckBox: "ProductResultItem__productCheckBox__yqNsf",
                isCheck: "ProductResultItem__isCheck__YYlKd",
                jpCheckBox: "ProductResultItem__jpCheckBox__ibtqI",
                checkBoxIcon: "ProductResultItem__checkBoxIcon__zArFs",
                productItemImage: "ProductResultItem__productItemImage__ha34S",
                noNewTag: "ProductResultItem__noNewTag__QNjps",
                isECSite: "ProductResultItem__isECSite__jaAKc",
                productItemImageWrapper: "ProductResultItem__productItemImageWrapper__eeMJe",
                productBadge: "ProductResultItem__productBadge__R7+Nc",
                productBadgeLink: "ProductResultItem__productBadgeLink__UKxGu",
                productBadgeImage: "ProductResultItem__productBadgeImage__8zxdC",
                productItemTitle: "ProductResultItem__productItemTitle__75icn",
                subTitle: "ProductResultItem__subTitle__NpiB7",
                mktName: "ProductResultItem__mktName__bqftk",
                subName: "ProductResultItem__subName__Y3lzj",
                jpProductItemTitle: "ProductResultItem__jpProductItemTitle__NviPp",
                isHover: "ProductResultItem__isHover__JxclW",
                productItemRatingContent: "ProductResultItem__productItemRatingContent__XA7kv",
                show: "ProductResultItem__show__K8KZO",
                line: "ProductResultItem__line__1W-2U",
                productItemContent: "ProductResultItem__productItemContent__k1c74",
                productItemIntroduction: "ProductResultItem__productItemIntroduction__Mh6XZ",
                active: "ProductResultItem__active__q75dC",
                noSeeAllButton: "ProductResultItem__noSeeAllButton__+Pr+M",
                productStartingAt: "ProductResultItem__productStartingAt__vGbdH",
                productHowMuch: "ProductResultItem__productHowMuch__fwgpj",
                skuBase: "ProductResultItem__skuBase__dSiNX",
                tw: "ProductResultItem__tw__2ieba",
                finallyPriceValue: "ProductResultItem__finallyPriceValue__6sADl",
                originalPrice: "ProductResultItem__originalPrice__NZa0Y",
                savePriceValue: "ProductResultItem__savePriceValue__aDwIQ",
                originalPriceValue: "ProductResultItem__originalPriceValue__HVhh7",
                lowPriceValue: "ProductResultItem__lowPriceValue__MAmsw",
                groupNameDisplayRuleValue: "ProductResultItem__groupNameDisplayRuleValue__e5DNL",
                productBuyButton: "ProductResultItem__productBuyButton__43iX3",
                productLearnMoreButton: "ProductResultItem__productLearnMoreButton__4oNOn",
                marginTopAuto: "ProductResultItem__marginTopAuto__mIAoX",
                marginNoTopAuto: "ProductResultItem__marginNoTopAuto__PE6-N",
                productWhereToBuyButton: "ProductResultItem__productWhereToBuyButton__IMKWt",
                kspItems: "ProductResultItem__kspItems__kg16t",
                keySpecItems: "ProductResultItem__keySpecItems__wR8pI",
                productCardBottom: "ProductResultItem__productCardBottom__myM5C",
                productItemWrapper: "ProductResultItem__productItemWrapper__+TBGp",
                fpsWrapper: "ProductResultItem__fpsWrapper__4sIU3",
                fpsIcon: "ProductResultItem__fpsIcon__6en+3",
                fpsFont: "ProductResultItem__fpsFont__uZwKb",
                fpsGameName: "ProductResultItem__fpsGameName__GUmuM",
                fpsContent: "ProductResultItem__fpsContent__5pc0M",
                fpsValue: "ProductResultItem__fpsValue__hj8Im",
                fpsMoreButton: "ProductResultItem__fpsMoreButton__aK4v4",
                fpsArrow: "ProductResultItem__fpsArrow__PTEgZ",
                fpsMoreContent: "ProductResultItem__fpsMoreContent__6Y9-k",
                fpsClose: "ProductResultItem__fpsClose__hKX7h",
                fpsMoreContentTitle: "ProductResultItem__fpsMoreContentTitle__GUFyz",
                fpsMoreList: "ProductResultItem__fpsMoreList__Dpb3y",
                name: "ProductResultItem__name__kgTXi",
                toolTip: "ProductResultItem__toolTip__bA3QL",
                value: "ProductResultItem__value__rSLXj",
                tagLine: "ProductResultItem__tagLine__Q56Li",
                productItemLink: "ProductResultItem__productItemLink__mbXkd",
                buyContent: "ProductResultItem__buyContent__vf5xN",
                havePrice: "ProductResultItem__havePrice__0zGgI",
                BuyPrice: "ProductResultItem__BuyPrice__87qJ5",
                wtbType: "ProductResultItem__wtbType__+z7H-",
                modelType: "ProductResultItem__modelType__17AFm",
                customizeType: "ProductResultItem__customizeType__utNyt",
                noType: "ProductResultItem__noType__YiOvE",
                productStartingAtWrapper: "ProductResultItem__productStartingAtWrapper__KW1qL",
                productItemPriceContent: "ProductResultItem__productItemPriceContent__AKvn+"
            }
        },
        800: function(t, e, o) {
            t.exports = {
                rewardItem: "ProductAwardsMoreItem__rewardItem__qEqDb",
                rewardImageBox: "ProductAwardsMoreItem__rewardImageBox__gjZie",
                rewardItemUrlDate: "ProductAwardsMoreItem__rewardItemUrlDate__EFQ+R",
                rewardBottom: "ProductAwardsMoreItem__rewardBottom__fM75K"
            }
        },
        812: function(t, e, o) {
            t.exports = {
                productFooterContent: "ProductFooter__productFooterContent__mXPuo",
                productFooterList: "ProductFooter__productFooterList__J6HzI",
                productFooterHDMI: "ProductFooter__productFooterHDMI__watNS",
                productFooterContainer: "ProductFooter__productFooterContainer__Mu9vd",
                productBackgroundBlack: "ProductFooter__productBackgroundBlack__ZFDu8",
                productBackgroundDarkBlack: "ProductFooter__productBackgroundDarkBlack__NOol7",
                productBackgroundArticleBlack: "ProductFooter__productBackgroundArticleBlack__i8VE8"
            }
        },
        815: function(t, e, o) {
            t.exports = {
                productSpecCheckBox: "ProductSpecCheckBox__productSpecCheckBox__bkHgV",
                jp: "ProductSpecCheckBox__jp__hxdXE",
                isCheck: "ProductSpecCheckBox__isCheck__hemXk",
                jpCheckBox: "ProductSpecCheckBox__jpCheckBox__+PnOW",
                checkBoxIcon: "ProductSpecCheckBox__checkBoxIcon__y8rzH"
            }
        },
        816: function(t, e, o) {
            t.exports = {
                specPriceWrapper: "ProductSpecPrice__specPriceWrapper__BkpWT",
                single: "ProductSpecPrice__single__dupNG",
                specWtbInner: "ProductSpecPrice__specWtbInner__JedTJ",
                specPriceInner: "ProductSpecPrice__specPriceInner__rpa99",
                specNoRating: "ProductSpecPrice__specNoRating__3Szlp",
                specPriceInnerHeight: "ProductSpecPrice__specPriceInnerHeight__UrtGI",
                onlyWhereToBuy: "ProductSpecPrice__onlyWhereToBuy__P4d0c",
                skuProductRatingContent: "ProductSpecPrice__skuProductRatingContent__WFd5K",
                singleSpec: "ProductSpecPrice__singleSpec__ADsTq",
                hideRatingContent: "ProductSpecPrice__hideRatingContent__n3fjL",
                productStartingAt: "ProductSpecPrice__productStartingAt__5XWvg",
                compareProductStartingAt: "ProductSpecPrice__compareProductStartingAt__NRN7Z",
                finallyPriceValue: "ProductSpecPrice__finallyPriceValue__fUbBJ",
                specPrice: "ProductSpecPrice__specPrice__wCScg",
                jp: "ProductSpecPrice__jp__8-Hk1",
                originalPrice: "ProductSpecPrice__originalPrice__X7NPC",
                showSavePrice: "ProductSpecPrice__showSavePrice__-xLC-",
                savePriceValue: "ProductSpecPrice__savePriceValue__QHngG",
                originalPriceValue: "ProductSpecPrice__originalPriceValue__78gUo",
                productSpecLowPriceText: "ProductSpecPrice__productSpecLowPriceText__JfGqN",
                lowHistoryPrice: "ProductSpecPrice__lowHistoryPrice__PA-CE",
                groupNameDisplayRuleValue: "ProductSpecPrice__groupNameDisplayRuleValue__ayN4c",
                productHowMuch: "ProductSpecPrice__productHowMuch__mg0-r",
                noOriginPrice: "ProductSpecPrice__noOriginPrice__zDcF6",
                tw: "ProductSpecPrice__tw__AfD2-",
                specPriceBox: "ProductSpecPrice__specPriceBox__GCmd4"
            }
        },
        817: function(t, e, o) {
            t.exports = {
                productSpecItemRow: "ProductSpecItemRow__productSpecItemRow__hfhM9",
                productSpecItemTitle: "ProductSpecItemRow__productSpecItemTitle__0tfBr",
                hide: "ProductSpecItemRow__hide__MOZGi",
                specDescription: "ProductSpecItemRow__specDescription__IkQpQ"
            }
        },
        819: function(t, e, o) {
            t.exports = {
                compareTopContainer: "ProductSpecTopPanel__compareTopContainer__MxB2I",
                compareTopSingleItem: "ProductSpecTopPanel__compareTopSingleItem__2eX5Y",
                slideDown: "ProductSpecTopPanel__slideDown__c0+6e",
                showPrice: "ProductSpecTopPanel__showPrice__FtYEy",
                noPrice: "ProductSpecTopPanel__noPrice__+tZfb",
                scrolled: "ProductSpecTopPanel__scrolled__qQnD5",
                compareTopContainerScroll: "ProductSpecTopPanel__compareTopContainerScroll__9rBx0",
                mobile: "ProductSpecTopPanel__mobile__XEOMn",
                pagination: "ProductSpecTopPanel__pagination__NXyAG",
                pageBullets: "ProductSpecTopPanel__pageBullets__W3dOn",
                active: "ProductSpecTopPanel__active__uJKJp",
                paginationWrapper: "ProductSpecTopPanel__paginationWrapper__XRcYH",
                compareTopWrapper: "ProductSpecTopPanel__compareTopWrapper__wwUVC",
                rtl: "ProductSpecTopPanel__rtl__ravjU",
                lessProduct: "ProductSpecTopPanel__lessProduct__CJ6rv",
                showPriceAmountOff: "ProductSpecTopPanel__showPriceAmountOff__tD4tC",
                showPriceRatting: "ProductSpecTopPanel__showPriceRatting__6MT4Y",
                showLowPrice: "ProductSpecTopPanel__showLowPrice__lDS+E"
            }
        },
        900: function(t, e, o) {
            "use strict";
            var r, n = o(9),
                c = (o(54), o(41), o(10), o(3)),
                l = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                d = function(t, e, o, desc) {
                    var r, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(n.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (c < 3 ? r(l) : c > 3 ? r(e, o, l) : r(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                _ = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return l(e, t), d([Object(c.Prop)()], e.prototype, "awardMoreItemObject", void 0), e = d([Object(c.Component)({
                        components: {}
                    })], e)
                }(c.Vue),
                h = _,
                m = o(1073),
                f = o(25);
            var component = Object(f.a)(h, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.rewardItem
                }, [e("div", {
                    class: t.$style.rewardImageBox,
                    style: "background-image:url(".concat(t.awardMoreItemObject.AwardImg, ");"),
                    attrs: {
                        role: "img"
                    }
                }), t._v(" "), e("h3", [t._v(t._s(t.awardMoreItemObject.AwardName))]), t._v(" "), e("p", [t._v("\n    " + t._s(t.awardMoreItemObject.Description) + "\n  ")])])
            }), [], !1, (function(t) {
                this.$style = m.default.locals || m.default
            }), null, null);
            e.a = component.exports
        },
        901: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = (o(20), o(51), o(9)),
                l = (o(54), o(41), o(10), o(18), o(29), o(78), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.checked = !1, e
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "productLineName", {
                        get: function() {
                            if (this.routeInfo.fullPath) {
                                var t = this.routeInfo.fullPath;
                                return "global" === this.routeInfo.websitePath ? t.split("/")[0] : "cn" === this.routeInfo.websitePath ? t.indexOf("cn/") > -1 ? t.split("/")[1].replace("-group", "") : t.split("/")[0].replace("-group", "") : t.split("/")[1]
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareType", {
                        get: function() {
                            if (this.routeInfo && this.routeInfo.productLine) return this.routeInfo.productLine ? this.routeInfo.productLine.replace(/\s+/g, "-") : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareData", {
                        get: function() {
                            return this.productLineName ? this.compareSelect[this.productLineName] : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo && this.routeInfo.websitePath ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchCompareData = function() {
                        var t = this,
                            e = !0;
                        this.compareData.map((function(o) {
                            o.key === t.productId && (e = !1)
                        })), e && (this.checked = !1)
                    }, e.prototype.initialCheckBoxStatus = function() {
                        var t = this;
                        this.productLineName && this.compareSelect[this.productLineName] && this.compareSelect[this.productLineName].length && this.compareSelect[this.productLineName].map((function(e) {
                            e.key === t.productId && (t.checked = !0)
                        }))
                    }, e.prototype.checkBoxHandler = function() {
                        4 === this.compareSelect[this.productLineName].length && this.checked ? this.checked = !1 : this.onCheck(this.productId)
                    }, e.prototype.onTabCheckHandler = function(t) {
                        this.checked = !this.checked, 4 === this.compareSelect[this.productLineName].length && this.checked ? this.checked = !1 : this.onCheck(t)
                    }, e.prototype.onCheck = function(t) {
                        var e = {
                                key: t,
                                type: this.productLineName
                            },
                            o = Object.assign(this.specItemParam, e);
                        if (this.$emit("triggerComparePanel"), this.checkProductID(t)) return this.checked = !1, void this.CompareCancel(o);
                        this.checked ? this.getCompareSelect(o) : this.CompareCancel(o)
                    }, e.prototype.checkProductID = function(t) {
                        var e = !1;
                        return this.compareSelect[this.productLineName].map((function(o) {
                            o.key === t && (e = !0)
                        })), e
                    }, e.prototype.mounted = function() {
                        this.productLineName && this.initialCheckBoxStatus()
                    }, h([Object(d.Action)("getCompareSelect")], e.prototype, "getCompareSelect", void 0), h([Object(d.Action)("CompareCancel")], e.prototype, "CompareCancel", void 0), h([Object(d.Getter)("spec")], e.prototype, "spec", void 0), h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(d.Getter)("compareSelect")], e.prototype, "compareSelect", void 0), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(l.Prop)()], e.prototype, "productId", void 0), h([Object(l.Prop)()], e.prototype, "isDisable", void 0), h([Object(l.Prop)()], e.prototype, "isSingle", void 0), h([Object(l.Prop)()], e.prototype, "specItemParam", void 0), h([Object(l.Watch)("compareData")], e.prototype, "watchCompareData", null), e = h([l.Component], e)
                }(l.Vue),
                f = m,
                y = o(1090),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.isDisable ? t._e() : e("div", {
                    class: [t.$style.productSpecCheckBox, Object(n.a)({}, t.$style.jp, "jp" === t.lang)],
                    attrs: {
                        tabindex: "0"
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.onTabCheckHandler(t.productId)
                        }
                    }
                }, [e("label", {
                    staticClass: "checkBoxCompare",
                    class: [Object(n.a)({}, t.$style.isCheck, t.checked)],
                    attrs: {
                        for: "checkbox".concat(t.productId)
                    }
                }, [t._v(t._s(t.translation.Compare_Compare))]), t._v(" "), e("div", {
                    class: [t.$style.checkBoxIcon, Object(n.a)({}, t.$style.isCheck, t.checked)],
                    attrs: {
                        role: "checkbox",
                        "aria-label": "choose ".concat(t.productId),
                        "aria-checked": t.checked ? "true" : "false"
                    }
                }, [e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "check",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M32 5.96l-5.23-4.25-15.38 18.93-6.67-5.77L0 19.71l12.24 10.58 2.79-3.43L32 5.96z"
                    }
                }), e("path", {
                    attrs: {
                        d: "M0 0h32v32H0z",
                        fill: "none"
                    }
                })])]), t._v(" "), e("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: t.checked,
                        expression: "checked"
                    }],
                    attrs: {
                        tabindex: "-1",
                        type: "checkbox",
                        name: "productSpecCheckBox",
                        id: "checkbox".concat(t.productId)
                    },
                    domProps: {
                        checked: Array.isArray(t.checked) ? t._i(t.checked, null) > -1 : t.checked
                    },
                    on: {
                        change: [function(e) {
                            var o = t.checked,
                                r = e.target,
                                n = !!r.checked;
                            if (Array.isArray(o)) {
                                var c = t._i(o, null);
                                r.checked ? c < 0 && (t.checked = o.concat([null])) : c > -1 && (t.checked = o.slice(0, c).concat(o.slice(c + 1)))
                            } else t.checked = n
                        }, t.checkBoxHandler]
                    }
                })])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        902: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(18), o(29), o(44), o(59), o(145), o(73), o(47), o(20), o(3)),
                d = o(7),
                _ = o(4),
                h = o(204),
                m = o(144),
                f = o(685),
                y = o(695),
                v = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                P = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                w = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.productPrice = "", e.productUrl = "", e.regularPrice = "", e.amountOff = "", e.buttonStatus = "", e.isPrice = !1, e.haveStore = !1, e.isRatingShow = !0, e.ownRating = !0, e.singleSku = 0, e.displayHistoricLowPrice = "", e.historicLowPrice = "", e.isShow = !1, e.callPriceCheck = null, e.priceDouble = 0, e.displayRegularPrice = "", e.displayAmountOff = "", e.groupNameDisplayRule = "", e.specialPrice = "", e.groupLabelName = "ASUS Member Program_Default_US_ASUS_ASUS", e.modelBaseList = ["Gaming-Handhelds", "Motherboards", "Cooling", "Graphics-Cards", "Monitors", "Cooling", "Power-Supply-Units", "Networking", "Cases", "External-Graphic-Docks", "Keyboards", "Apparel-Bags-Gear", "Mice-Mouse-pads", "Headsets-Audio", "Streaming-Kits", "Controllers", "Storage", "Power-Protection-Gadgets"], e.productType = "", e
                    }
                    return v(e, t), Object.defineProperty(e.prototype, "isECSite", {
                        get: function() {
                            return null !== this.mappingWebsite.tagLang && "" !== this.mappingWebsite.tagLang
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "modelBaseName", {
                        get: function() {
                            return this.routeInfo.productLine
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "modelBaseStatus", {
                        get: function() {
                            return this.routeInfo.filterInfo && this.routeInfo.filterInfo.modelBaseFlag
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "tokenData", {
                        get: function() {
                            return localStorage.getItem("rog_ec_token")
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "productBuyType", {
                        get: function() {
                            var t = this.productUrl,
                                e = this.resultItemData.wtbLink;
                            return t ? "buy" : e ? "wtb" : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonName", {
                        get: function() {
                            return "" === this.productBuyType ? "" : "buy" === this.productBuyType ? "notify_me" === this.buttonStatus ? this.translation.eShop_Notify_Me : "pre_order" === this.buttonStatus ? this.translation.eShop_Pre_Order : "back_order" === this.buttonStatus ? this.translation.eShop_Back_Order : "customize" === this.buttonStatus ? this.translation.eShop_Buy_Customize : this.translation.eShop_Buy_Now : "wtb" === this.productBuyType ? this.translation.WTB_Where_to_Buy : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "setButtonData", {
                        get: function() {
                            return {
                                name: this.buttonName,
                                disabled: !1,
                                link: this.productUrl + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : "")
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isMcc1", {
                        get: function() {
                            var t, e;
                            return "MCC1" === (null === (t = this.mappingWebsite) || void 0 === t ? void 0 : t.mcc) || "MCC2" === (null === (e = this.mappingWebsite) || void 0 === e ? void 0 : e.mcc)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isTranslateStringNumber", {
                        get: function() {
                            if (this.amountOff) return this.$emit("showAmount", parseInt(this.amountOff.split(",")[0].replace(/[^0-9]/gi, ""), 10) > 0), parseInt(this.amountOff.split(",")[0].replace(/[^0-9]/gi, ""), 10) > 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "area", {
                        get: function() {
                            return "global" === this.lang ? "" : "/".concat(this.lang)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchAllObject = function(t, e) {
                        var o = this,
                            r = this.modelBaseList.filter((function(t) {
                                return t.toLowerCase() === o.productType
                            }));
                        this.isCompare && this.isNowCloseCompareStatus && this.isECSite && (this.modelBaseStatus || r.length > 0 ? setTimeout((function() {
                            Object(_.b)("aticket") ? o.callPriceCheck = setInterval((function() {
                                clearInterval(o.callPriceCheck), o.userProductIdGetModelPrice(o.resultItemData)
                            }), 200) : o.userProductIdGetModelPrice(o.resultItemData)
                        }), 500) : setTimeout((function() {
                            Object(_.b)("aticket") ? o.callPriceCheck = setInterval((function() {
                                clearInterval(o.callPriceCheck), o.userProductIdGetSkuPrice(o.resultItemData)
                            }), 200) : o.userProductIdGetSkuPrice(o.resultItemData)
                        }), 500), setTimeout((function() {
                            o.isChangeCompareStatusHandler(!1)
                        }), 3e3))
                    }, e.prototype.mounted = function() {
                        var t = this;
                        this.productType = this.parsePath("productline");
                        var e = this.modelBaseList.filter((function(e) {
                            return e.toLowerCase() === t.productType
                        }));
                        this.isECSite ? this.modelBaseStatus || e.length > 0 ? setTimeout((function() {
                            Object(_.b)("aticket") ? t.callPriceCheck = setInterval((function() {
                                clearInterval(t.callPriceCheck), t.userProductIdGetModelPrice(t.resultItemData)
                            }), 500) : t.userProductIdGetModelPrice(t.resultItemData)
                        }), 500) : setTimeout((function() {
                            Object(_.b)("aticket") ? t.callPriceCheck = setInterval((function() {
                                clearInterval(t.callPriceCheck), t.userProductIdGetSkuPrice(t.resultItemData)
                            }), 500) : t.userProductIdGetSkuPrice(t.resultItemData)
                        }), 500) : this.emitDataHandler(), this.$nextTick((function() {
                            t.getRatingHeight()
                        }))
                    }, e.prototype.getRatingHeight = function() {
                        var t = this;
                        setTimeout((function() {
                            var e, o;
                            if ("" !== t.resultItemData.externalId) {
                                var r = null === (o = null === (e = t.$refs) || void 0 === e ? void 0 : e.review) || void 0 === o ? void 0 : o.getElementsByClassName("bv_text");
                                r && r[1] && r[1].innerText && "(0)" === r[1].innerText ? (t.isRatingShow = !1, t.ownRating = !1, t.$emit("ratingStatus", t.isRatingShow)) : t.$emit("ratingStatus", t.isRatingShow)
                            } else t.isRatingShow = !1, t.ownRating = !1, t.$emit("ratingStatus", t.isRatingShow)
                        }), 2e3)
                    }, e.prototype.parsePath = function(t) {
                        var e, o;
                        return null === (o = null === (e = encodeURI(window.location.href)) || void 0 === e ? void 0 : e.split("".concat(t, "="))[1]) || void 0 === o ? void 0 : o.split("&")[0]
                    }, e.prototype.setButtonWTBData = function(t) {
                        return {
                            name: this.translation.WTB_Where_to_Buy,
                            disabled: !1,
                            link: t
                        }
                    }, e.prototype.setSessionStorage = function(t, e) {
                        sessionStorage.setItem(t, e)
                    }, e.prototype.getSessionStorage = function(t) {
                        return sessionStorage.getItem(t)
                    }, e.prototype.userProductIdGetSkuPrice = function(t) {
                        var e = this,
                            o = {
                                WebsiteCode: this.routeInfo.websitePath,
                                SkuWebPathName: t.partNo,
                                token: this.tokenData,
                                GroupId: Object(_.b)("groupid_rog_".concat(this.lang)) ? Object(_.b)("groupid_rog_".concat(this.lang)) : 0
                            };
                        h.a.getSkuPrice(o).then((function(t) {
                            var o, r;
                            t.data.status && 200 === t.data.status && t.data.result && t.data.result[0] ? (e.productUrl = t.data.result[0].storeLink, e.regularPrice = t.data.result[0].regularPrice, e.productPrice = t.data.result[0].price, e.amountOff = t.data.result[0].amountOff, e.buttonStatus = t.data.result[0].buttonStatus, e.singleSku = t.data.result[0].singleSku, e.displayHistoricLowPrice = t.data.result[0].displayHistoricLowPrice, e.historicLowPrice = t.data.result[0].historicLowPrice, e.priceDouble = t.data.result[0].priceDouble, e.displayRegularPrice = t.data.result[0].regularPrice, e.displayAmountOff = t.data.result[0].amountOff, e.specialPrice = (null === (o = t.data.result[0]) || void 0 === o ? void 0 : o.specialPrice) ? t.data.result[0].specialPrice : "", e.groupNameDisplayRule = t.data.result[0].groupNameDisplayRule, e.groupLabelName = (null === (r = t.data.result[0]) || void 0 === r ? void 0 : r.groupLabelName) ? t.data.result[0].groupLabelName : "ASUS Member Program_Default_US_ASUS_ASUS", e.setSessionStorage(e.resultItemData.partNo, JSON.stringify(t.data.result[0])), "" === e.productPrice ? (e.getRatingHeight(), e.emitDataHandler(), e.$emit("hidePrice", !0), e.isPrice = !1) : (e.isPrice = !0, e.isShow = !0, e.getProductPriceNumber(e.isPrice), e.getRatingHeight(), e.emitDataHandler(), e.$emit("modelPriceItems", t.data.result[0])), e.haveStore = !0) : ("" === e.productPrice && e.$emit("hidePrice", !0), e.getRatingHeight(), e.emitDataHandler(), e.isShow = !0, e.haveStore = !1)
                        })).catch((function(t) {
                            e.emitDataHandler(), console.error(t)
                        }))
                    }, e.prototype.userProductIdGetModelPrice = function(t) {
                        var e = this,
                            o = {
                                WebsiteCode: this.routeInfo.websitePath,
                                M1Id: this.routeInfo.m1Id ? this.routeInfo.m1Id : t.m1Id,
                                token: this.tokenData,
                                SimplePrice: 0,
                                GroupId: Object(_.b)("groupid_rog_".concat(this.lang)) ? Object(_.b)("groupid_rog_".concat(this.lang)) : 0
                            };
                        h.a.getModelPrice(o).then((function(t) {
                            var o, r;
                            t.data.status && 200 === t.data.status && t.data.result && t.data.result[0] ? (e.productUrl = t.data.result[0].storeLink, e.regularPrice = t.data.result[0].regularPrice, e.productPrice = t.data.result[0].price, e.amountOff = t.data.result[0].amountOff, e.buttonStatus = t.data.result[0].buttonStatus, e.singleSku = t.data.result[0].singleSku, e.displayHistoricLowPrice = t.data.result[0].displayHistoricLowPrice, e.historicLowPrice = t.data.result[0].historicLowPrice, e.priceDouble = t.data.result[0].priceDouble, e.displayRegularPrice = t.data.result[0].regularPrice, e.displayAmountOff = t.data.result[0].amountOff, e.specialPrice = (null === (o = t.data.result[0]) || void 0 === o ? void 0 : o.specialPrice) ? t.data.result[0].specialPrice : "", e.groupNameDisplayRule = t.data.result[0].groupNameDisplayRule, e.groupLabelName = (null === (r = t.data.result[0]) || void 0 === r ? void 0 : r.groupLabelName) ? t.data.result[0].groupLabelName : "ASUS Member Program_Default_US_ASUS_ASUS", e.setSessionStorage(e.resultItemData.partNo, JSON.stringify(t.data.result[0])), "" === e.productPrice ? (e.getRatingHeight(), e.emitDataHandler(), e.$emit("hidePrice", !0), e.isPrice = !1) : (e.isPrice = !0, e.haveStore = !0, e.isShow = !0, e.getProductPriceNumber(e.isPrice), e.getRatingHeight(), e.emitDataHandler(), e.$emit("modelPriceItems", t.data.result[0]))) : ("" === e.productPrice && e.$emit("hidePrice", !0), e.isShow = !0, e.getRatingHeight(), e.emitDataHandler(), e.haveStore = !1)
                        })).catch((function(t) {
                            e.emitDataHandler(), console.error(t)
                        }))
                    }, e.prototype.lowPriceRegion = function(t) {
                        return "pl" === t || "it" === t || "de" === t
                    }, e.prototype.priceCompareSpecialPrice = function() {
                        return this.priceDouble > Number(this.specialPrice) || (this.priceDouble < Number(this.specialPrice) || null === this.specialPrice)
                    }, e.prototype.getDisplayPriceHandler = function(t) {
                        for (var e, o = this, r = t.toLowerCase(), n = ["save", "with"], c = /\{(.*?)\}/g, l = []; null !== (e = c.exec(r));) {
                            var d = e[1];
                            n.includes(d) ? l.push({
                                type: "translation",
                                key: d
                            }) : l.push({
                                type: "param",
                                key: d
                            })
                        }
                        var _ = "";
                        return l.forEach((function(t, e) {
                            "translation" === t.type ? "save" === t.key ? _ += o.translation.eShop_Save : "with" === t.key && (_ += o.translation.PDList_GroupName) : "regularprice" === t.key ? _ += "<span>" + o.displayRegularPrice + "</span>" : "amountoff" === t.key ? _ += o.displayAmountOff : _ += o.groupLabelName, e < l.length - 1 && (_ += " ")
                        })), _
                    }, e.prototype.returnCurrency = function(t) {
                        var e = t,
                            o = this.mappingWebsite.currencySymbol;
                        Number(this.mappingWebsite.numberOfDecimal);
                        e = e.replace("".concat(o), "");
                        var r = this.mappingWebsite.decimalSeparator;
                        e = e.split("".concat(r))[0];
                        var n = this.mappingWebsite.thousandSeparators;
                        return e = e.replace("".concat(n), ""), Number(e)
                    }, e.prototype.emitDataHandler = function() {
                        var t = this;
                        setTimeout((function() {
                            setTimeout((function() {
                                t.$emit("closeLoading", !1)
                            }), 100)
                        }), 500)
                    }, e.prototype.currencyHandler = function(t) {
                        return t
                    }, e.prototype.gaTriggerHandler = function() {
                        var t, e = this;
                        t = "rog.asus.com.cn" === window.location.host ? this.resultItemData.skuUrl.toLowerCase().split("".concat(encodeURI(window.location.origin)))[1].split("/") : this.resultItemData.skuUrl.toLowerCase().split("".concat(encodeURI(window.location.origin)).concat(this.area))[1].split("/");
                        var o = "".concat(t[1], "/undefined/").concat(t[2], "/undefined");
                        window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "buttons",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/").concat(this.buttonStatus, "-").concat(this.buttonName),
                            event_value_DL: this.specItemIndex
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "buttons",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(e.resultItemData.mktName, "/").concat(e.buttonStatus, "-").concat(e.buttonName),
                                event_value_DL: e.specItemIndex
                            })
                        }), 200), window.dataLayer.push({
                            event: "productClick",
                            ecommerce: {
                                click: {
                                    actionField: {
                                        list: ""
                                    },
                                    products: [{
                                        name: "".concat(this.resultItemData.mktName),
                                        id: this.resultItemData.partNo,
                                        dimension10: this.resultItemData.partNo,
                                        price: "",
                                        brand: "ROG",
                                        category: o,
                                        list: "tech_specs",
                                        position: ""
                                    }]
                                }
                            }
                        }), window.location.assign(this.productUrl + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : ""))
                    }, P([Object(d.Action)("getProductPriceNumber")], e.prototype, "getProductPriceNumber", void 0), P([Object(d.Action)("isChangeCompareStatusHandler")], e.prototype, "isChangeCompareStatusHandler", void 0), P([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), P([Object(d.Getter)("translation")], e.prototype, "translation", void 0), P([Object(d.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), P([Object(d.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), P([Object(d.Getter)("isNowCloseCompareStatus")], e.prototype, "isNowCloseCompareStatus", void 0), P([Object(l.Prop)()], e.prototype, "resultItemData", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "specType", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "singleSpec", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "isCompare", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "showOriginStatus", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "showRatingHeight", void 0), P([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "specItemIndex", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "isSpecPage", void 0), P([Object(l.Prop)({
                        required: !1
                    })], e.prototype, "isSpecBottom", void 0), P([Object(l.Prop)({
                        default: 0,
                        type: Number
                    })], e.prototype, "index", void 0), P([Object(l.Prop)({
                        default: null
                    })], e.prototype, "allObject", void 0), P([Object(l.Watch)("allObject", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchAllObject", null), e = P([Object(l.Component)({
                        components: {
                            ButtonRed: m.a,
                            ButtonBorderRed: f.a,
                            ProductStock: y.a
                        }
                    })], e)
                }(l.Vue),
                S = w,
                I = o(1091),
                O = o(25);
            var component = Object(O.a)(S, (function() {
                var t, e, o, r, c, l, d = this,
                    _ = d._self._c;
                d._self._setupProxy;
                return _("div", {
                    ref: "specContentHeight",
                    class: [d.$style.specPriceWrapper, Object(n.a)({}, d.$style.single, d.singleSpec)],
                    attrs: {
                        "data-id": d.resultItemData.partNo
                    }
                }, [d.isSpecBottom ? d._e() : [d.isSpecPage ? _("div", [_("ProductStock", {
                    attrs: {
                        getButtonStatus: d.buttonStatus,
                        isSpec: !0
                    }
                })], 1) : d._e()], d._v(" "), _("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isShow,
                        expression: "isShow"
                    }],
                    staticClass: "specPriceContent"
                }, [_("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !d.isPrice && !d.haveStore,
                        expression: "!isPrice && !haveStore"
                    }],
                    class: [d.$style.specPriceInner, d.$style.specWtbInner, (t = {}, Object(n.a)(t, d.$style.specPriceInnerHeight, d.isRatingShow), Object(n.a)(t, d.$style.onlyWhereToBuy, "" === d.resultItemData.externalId), t)]
                }, [d.isSpecBottom ? d._e() : [_("div", {
                    class: [d.$style.skuProductRatingContent, (e = {}, Object(n.a)(e, d.$style.hideRatingContent, !d.isRatingShow), Object(n.a)(e, d.$style.singleSpec, d.singleSpec), e)]
                }, [_("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isRatingShow,
                        expression: "isRatingShow"
                    }]
                }, [_("div", {
                    ref: "review",
                    attrs: {
                        "data-bv-show": "inline_rating",
                        "data-bv-product-id": "".concat(d.resultItemData.externalId)
                    }
                })])])], d._v(" "), _("div"), d._v(" "), _("div"), d._v(" "), _("div", {
                    class: d.$style.specPriceBox
                }, [d.resultItemData.wtbLink && !d.haveStore ? _("ButtonBorderRed", {
                    attrs: {
                        isWTB: !0,
                        "is-max-width": !0,
                        isSpecButton: !0,
                        isComparePage: d.isCompare,
                        "button-data": d.setButtonWTBData((d.resultItemData.mktName, "".concat(d.resultItemData.wtbLink.toLowerCase())))
                    }
                }) : d._e()], 1)], 2), d._v(" "), _("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isPrice && d.haveStore,
                        expression: "isPrice && haveStore"
                    }],
                    class: [d.$style.specPriceInner, (o = {}, Object(n.a)(o, d.$style.specPriceInnerHeight, d.isRatingShow), Object(n.a)(o, d.$style.single, d.singleSpec), o)]
                }, [d.isSpecBottom ? d._e() : [_("div", {
                    class: [d.$style.skuProductRatingContent, (r = {}, Object(n.a)(r, d.$style.hideRatingContent, !d.isRatingShow), Object(n.a)(r, d.$style.singleSpec, d.singleSpec), r)]
                }, [_("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isRatingShow,
                        expression: "isRatingShow"
                    }]
                }, [_("div", {
                    ref: "review",
                    attrs: {
                        "data-bv-show": "inline_rating",
                        "data-bv-product-id": "".concat(d.resultItemData.externalId)
                    }
                })])])], d._v(" "), _("span", {
                    class: [d.$style.productStartingAt, Object(n.a)({}, d.$style.compareProductStartingAt, d.isCompare)]
                }, [d._v("\n        " + d._s(d.modelBaseStatus && 0 === d.singleSku || !d.modelBaseStatus && 0 === d.singleSku ? this.translation.eShop_Starting_at : this.translation.eShop_Price))]), d._v(" "), _("div", {
                    ref: "priceContent",
                    class: [d.$style.productHowMuch, (c = {}, Object(n.a)(c, d.$style.specPrice, d.specType), Object(n.a)(c, d.$style.noOriginPrice, !d.showOriginStatus), Object(n.a)(c, d.$style.tw, "tw" === d.lang), c)]
                }, [_("span", {
                    class: [d.$style.finallyPriceValue, (l = {}, Object(n.a)(l, d.$style.specPrice, d.specType), Object(n.a)(l, d.$style.jp, "jp" === d.lang), l)]
                }, [d._v(d._s(d.currencyHandler(d.productPrice)))]), d._v(" "), _("div", {
                    class: [d.$style.originalPrice, Object(n.a)({}, d.$style.showSavePrice, !d.showOriginStatus)]
                }, [_("span", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isTranslateStringNumber && !d.priceCompareSpecialPrice(),
                        expression: "isTranslateStringNumber && !priceCompareSpecialPrice()"
                    }],
                    class: d.$style.savePriceValue
                }, [d._v(d._s(d.translation.eShop_Save) + " " + d._s(d.currencyHandler(d.amountOff)))]), d._v(" "), _("span", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: d.isTranslateStringNumber && !d.priceCompareSpecialPrice(),
                        expression: "isTranslateStringNumber && !priceCompareSpecialPrice()"
                    }],
                    class: d.$style.originalPriceValue
                }, [d._v(d._s(d.currencyHandler(d.regularPrice)))])]), d._v(" "), _("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "" !== d.amountOff && 1 === d.mappingWebsite.priceReduction,
                        expression: "amountOff !== '' && mappingWebsite.priceReduction === 1"
                    }],
                    class: d.$style.productSpecLowPriceText
                }, [_("span", [d._v(d._s(this.translation.eshop_price_reduction))]), d._v(" \n            "), _("span", {
                    class: d.$style.lowHistoryPrice
                }, [d._v("\n              " + d._s(null !== d.displayHistoricLowPrice && "" !== d.displayHistoricLowPrice || null !== d.historicLowPrice && "" !== d.historicLowPrice ? d.displayHistoricLowPrice : d.regularPrice) + "\n            ")])]), d._v(" "), "" !== d.amountOff && "" !== d.groupLabelName && d.priceCompareSpecialPrice() ? _("div", {
                    class: d.$style.groupNameDisplayRuleValue
                }, [_("p", {
                    domProps: {
                        innerHTML: d._s(d.getDisplayPriceHandler(d.groupNameDisplayRule))
                    }
                })]) : d._e()]), d._v(" "), _("div", {
                    class: [d.$style.specPriceBox, Object(n.a)({}, d.$style.single, d.singleSpec)]
                }, [_("ButtonRed", {
                    attrs: {
                        "button-data": d.setButtonData,
                        "is-max-width": !0,
                        isSpecButton: !0,
                        isSpecStore: !0
                    },
                    on: {
                        gaTrigger: d.gaTriggerHandler
                    }
                })], 1)], 2)])], 2)
            }), [], !1, (function(t) {
                this.$style = I.default.locals || I.default
            }), null, null);
            e.a = component.exports
        },
        924: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return _(e, t), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isCompare", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSearch", void 0), e = h([Object(l.Component)({})], e)
                }(l.Vue),
                f = m,
                y = o(1034),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    class: [e.$style.tagContainer, (t = {}, Object(n.a)(t, e.$style.isCompare, e.isCompare), Object(n.a)(t, e.$style.isSearch, e.isSearch), t)]
                }, [o("div", {
                    class: e.$style.tagBox
                }, [o("div", {
                    class: e.$style.tagName
                }, [o("span", [e._v(e._s(e.translation.Product_New))])])]), e._v(" "), o("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !e.isCompare && !e.isSearch,
                        expression: "!isCompare && !isSearch"
                    }],
                    class: e.$style.tagTriangle
                })])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        929: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "getProductStatus", {
                        get: function() {
                            return "buy" === this.getButtonStatus || "customize" === this.getButtonStatus ? 1 : "notify_me" === this.getButtonStatus ? 2 : 3
                        },
                        enumerable: !1,
                        configurable: !0
                    }), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(l.Prop)({
                        default: function() {
                            return []
                        }
                    })], e.prototype, "statusList", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "customTag", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "getButtonStatus", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "openAmountOff", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isRelated", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isHotProduct", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isCompare", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isNews", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSearch", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSpec", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isProductCard", void 0), h([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "single", void 0), h([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "lang", void 0), h([Object(l.Prop)({
                        default: 356
                    })], e.prototype, "productCardWidth", void 0), e = h([Object(l.Component)({})], e)
                }(l.Vue),
                f = m,
                y = o(996),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t, e, o = this,
                    r = o._self._c;
                o._self._setupProxy;
                return r("div", {
                    class: [o.$style.tagContainer, (t = {}, Object(n.a)(t, o.$style.isCompare, o.isCompare), Object(n.a)(t, o.$style.isRelated, o.isRelated), Object(n.a)(t, o.$style.isHotProduct, o.isHotProduct), Object(n.a)(t, o.$style.isSearch, o.isSearch), Object(n.a)(t, o.$style.isSpec, o.isSpec), Object(n.a)(t, o.$style.single, o.single), Object(n.a)(t, o.$style.isProductCard, o.isProductCard), Object(n.a)(t, o.$style.col, o.productCardWidth < 268), t)]
                }, [o.isNews || o.openAmountOff || o.statusList.length > 0 || 3 !== o.getProductStatus ? r("div", {
                    class: o.$style.tagBox
                }, [1 === o.getProductStatus ? r("div", {
                    staticClass: "stockTag",
                    class: [o.$style.stock, {
                        jpFont: "jp" === o.lang
                    }]
                }, [r("span", {
                    class: [{
                        jpFont: "jp" === o.lang
                    }]
                }, [o._v(o._s(o.translation.PDList_Stock))])]) : 2 === o.getProductStatus ? r("div", {
                    staticClass: "stockTag",
                    class: o.$style.outStock
                }, [r("span", [o._v(o._s(o.translation.PDList_T_Out_of_Stock))])]) : o._e(), o._v(" "), r("div", {
                    class: [o.$style.tagName]
                }, [o.isNews ? r("div", {
                    class: o.$style.tagNameBorder
                }, [o.isNews ? r("span", [o._v(o._s(o.translation.Product_New))]) : o._e()]) : o._e(), o._v(" "), o.openAmountOff ? r("div", {
                    class: o.$style.tagNameBorder
                }, [o.openAmountOff ? r("span", [o._v(o._s(o.translation.eShop_Deals))]) : o._e()]) : o._e(), o._v(" "), o._l(o.statusList, (function(t, e) {
                    return r("div", {
                        key: e,
                        class: o.$style.tagNameBorder
                    }, [r("span", [o._v(o._s(t))])])
                }))], 2)]) : o._e(), o._v(" "), o.customTag ? r("div", {
                    class: [o.$style.flashSale, (e = {}, Object(n.a)(e, o.$style.col, o.productCardWidth < 268), Object(n.a)(e, o.$style.isPadding, o.productCardWidth >= 268), Object(n.a)(e, o.$style.needPaddingLeft, o.productCardWidth >= 268 && 0 === o.statusList.length && !o.isNews && !o.openAmountOff), Object(n.a)(e, o.$style.needLeft, o.productCardWidth < 268 && 0 === o.statusList.length && !o.isNews && !o.openAmountOff), e)]
                }, [r("p", [o._v(o._s(o.customTag))])]) : o._e()])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        931: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(18), o(29), o(3)),
                d = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), e.prototype.filterString = function(t) {
                        return "N/A" !== t && "N/A\r\n" !== t
                    }, e.prototype.dataIsNull = function(t) {
                        return !!t
                    }, e.prototype.removeStringNA = function(t) {
                        return t ? t.replace(/N\/A|\r\nN\/A/gim, "") : t
                    }, _([Object(l.Prop)()], e.prototype, "pdId", void 0), _([Object(l.Prop)()], e.prototype, "specData", void 0), e = _([l.Component], e)
                }(l.Vue),
                m = h,
                f = o(1092),
                y = o(25);
            var component = Object(y.a)(m, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.productSpecItemRow
                }, [e("div", {
                    class: t.$style.productSpecItemTitle
                }, [e("p", {
                    staticClass: "displayField",
                    class: [Object(n.a)({}, t.$style.hide, 0 !== t.pdId)]
                }, [t._v(t._s(t.specData.displayField))])]), t._v(" "), t._l(t.specData.descriptions, (function(o, r) {
                    return e("div", {
                        key: r,
                        class: t.$style.specDescription
                    }, [t.filterString(o.displayDescription) && t.dataIsNull(o.displayDescription) ? e("span", {
                        domProps: {
                            innerHTML: t._s(o.item)
                        }
                    }) : t._e(), t._v(" "), t.filterString(o.displayDescription) && t.dataIsNull(o.displayDescription) ? e("span", {
                        domProps: {
                            innerHTML: t._s(t.removeStringNA(o.displayDescription))
                        }
                    }) : t._e()])
                }))], 2)
            }), [], !1, (function(t) {
                this.$style = f.default.locals || f.default
            }), null, null);
            e.a = component.exports
        },
        943: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = (o(28), o(78), o(44), o(10), o(9)),
                l = (o(54), o(41), o(147), o(3)),
                d = o(7),
                _ = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isSortOpen = !1, e.isSortOpenMobile = !1, e.sortValue = "", e.nowName = "", e.sortValueMobile = "", e.isFirstLoading = !0, e
                    }
                    return _(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return Object.keys(this.routeInfo).length > 0 ? (this.routeInfo.websitePath, this.routeInfo.websitePath) : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "sortList", {
                        get: function() {
                            return this.filterDetail && Object.keys(this.filterDetail).length > 0 ? this.filterDetail[0].result.sort : null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchFilterDetail = function() {
                        this.filterDetail.length > 0 && this.filterDetail[0].result.sort.length > 0 && this.isFirstLoading && (this.sortValue = this.filterDetail[0].result.sort[0].sortType, this.nowName = this.filterDetail[0].result.sort[0].sortName, this.isFirstLoading = !1)
                    }, e.prototype.watchSortValue = function(t, e) {
                        t && (this.sortValueMobile = t)
                    }, e.prototype.sortOpen = function() {
                        this.isSortOpen = !this.isSortOpen
                    }, e.prototype.sortClose = function() {
                        this.isSortOpen = !1
                    }, e.prototype.sortOpenMobile = function() {
                        this.isSortOpenMobile = !this.isSortOpenMobile
                    }, e.prototype.sortCloseMobile = function() {
                        this.isSortOpenMobile = !1
                    }, e.prototype.onChange = function(t) {
                        this.sortValue = t.target[t.target.selectedIndex].value, this.nowName = t.target[t.target.selectedIndex].label, this.$emit("sortTrigger", t.target.value)
                    }, e.prototype.changeSort = function(t, text) {
                        this.sortValue = t, this.nowName = text, this.$emit("sortTrigger", t)
                    }, h([Object(d.Getter)("filterDetail")], e.prototype, "filterDetail", void 0), h([Object(d.Getter)("translation")], e.prototype, "translation", void 0), h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(l.Prop)({
                        default: "productListSort"
                    })], e.prototype, "idName", void 0), h([Object(l.Prop)({
                        default: !0
                    })], e.prototype, "closeID", void 0), h([Object(l.Watch)("filterDetail", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchFilterDetail", null), h([Object(l.Watch)("sortValue", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchSortValue", null), e = h([Object(l.Component)({
                        components: {}
                    })], e)
                }(l.Vue),
                f = m,
                y = o(1032),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.sortList && Object.keys(t.sortList).length > 0 ? e("div", {
                    class: [t.$style.sortButton, Object(n.a)({}, t.$style.active, t.isSortOpen), Object(n.a)({}, t.$style.active, t.isSortOpenMobile)],
                    on: {
                        mouseleave: t.sortClose
                    }
                }, [e("div", {
                    class: [t.$style.sortSwitch, Object(n.a)({}, t.$style.active, t.isSortOpen), Object(n.a)({}, t.$style.active, t.isSortOpenMobile)],
                    attrs: {
                        "aria-haspopup": "listbox",
                        tabindex: "0",
                        "aria-expanded": t.isSortOpen,
                        id: t.closeID ? "rogContent" : ""
                    },
                    on: {
                        click: t.sortOpen,
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.sortOpen.apply(null, arguments)
                        }
                    }
                }, [e("label", {
                    attrs: {
                        for: t.idName
                    }
                }, [t._v(t._s(t.nowName))]), t._v(" "), e("svg", {
                    class: [t.$style.dropdownIcon, t.$style.mobile],
                    attrs: {
                        "aria-hidden": "true",
                        role: "none",
                        alt: "down",
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M1 4L6 10L11 4H1Z",
                        fill: "black"
                    }
                })]), t._v(" "), e("svg", {
                    class: [t.$style.dropdownIcon, t.$style.desktop],
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "aria-hidden": "true",
                        role: "none",
                        "svg-inline": "",
                        alt: "down",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M18.23 23.01L32 9h-6.7l-8.94 9.19L6.7 9H0l14.49 14.01 1.87 1.88 1.87-1.88z"
                    }
                })])]), t._v(" "), e("select", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: t.sortValueMobile,
                        expression: "sortValueMobile"
                    }],
                    ref: "searchEl",
                    class: t.$style.mobileSelect,
                    attrs: {
                        name: t.idName,
                        id: t.idName,
                        "aria-label": "select sort at mobile"
                    },
                    on: {
                        change: [function(e) {
                            var o = Array.prototype.filter.call(e.target.options, (function(t) {
                                return t.selected
                            })).map((function(t) {
                                return "_value" in t ? t._value : t.value
                            }));
                            t.sortValueMobile = e.target.multiple ? o : o[0]
                        }, function(e) {
                            return t.onChange(e)
                        }],
                        click: t.sortOpenMobile,
                        blur: t.sortCloseMobile
                    }
                }, t._l(t.sortList, (function(o, r) {
                    return e("option", {
                        key: r,
                        class: [Object(n.a)({}, t.$style.active, t.sortValueMobile === o.sortType)],
                        domProps: {
                            value: o.sortType
                        }
                    }, [t._v("\n      " + t._s(o.sortName) + "\n    ")])
                })), 0), t._v(" "), e("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.sortList,
                        expression: "sortList"
                    }],
                    class: [t.$style.sortList, Object(n.a)({}, t.$style.open, t.isSortOpen)]
                }, [e("ul", {
                    attrs: {
                        role: "listbox"
                    }
                }, t._l(t.sortList, (function(o, r) {
                    return e("li", {
                        key: r,
                        staticClass: "listSort",
                        class: [t.$style.listSortItem, Object(n.a)({}, t.$style.active, o.sortType === t.sortValue)],
                        attrs: {
                            role: "none",
                            "aria-selected": o.sortType === t.sortValue
                        }
                    }, [e("button", {
                        attrs: {
                            role: "option",
                            tabindex: o.sortType === t.sortValue ? -1 : 0,
                            disabled: o.sortType === t.sortValue,
                            type: "button"
                        },
                        on: {
                            click: function(e) {
                                return t.changeSort(o.sortType, o.sortName)
                            }
                        }
                    }, [e("span", [t._v("\n              " + t._s(o.sortName) + "\n            ")])])])
                })), 0)])]) : t._e()
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        944: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = (o(20), o(51), o(26), o(28), o(9)),
                l = (o(54), o(41), o(10), o(44), o(18), o(29), o(59), o(73), o(78), o(145), o(47), o(91), o(33), o(103), o(37), o(38), o(146), o(121), o(3)),
                d = o(204),
                _ = o(144),
                h = o(685),
                m = o(7),
                f = o(79),
                y = o(4),
                v = o(924),
                P = o(695),
                w = o(929),
                S = o(696),
                I = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                O = function() {
                    return O = Object.assign || function(t) {
                        for (var s, i = 1, e = arguments.length; i < e; i++)
                            for (var p in s = arguments[i]) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
                        return t
                    }, O.apply(this, arguments)
                },
                k = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                L = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.imageHeight = 0, e.productPrice = "", e.checked = !1, e.isShowNew = !1, e.isHoverProductImage = !1, e.isPrice = !1, e.haveStore = !1, e.buttonStatus = "", e.regularPrice = "", e.amountOff = "", e.syncStoreLink = "", e.isRatingHide = !1, e.hide = !1, e.productBuyType = "buy", e.shopSaleStatus = !0, e.checkSkuPrice = null, e.singleSku = 0, e.showContentMore = !0, e.displayHistoricLowPrice = "", e.isShowSeeAllButton = !1, e.historicLowPrice = "", e.isDomReady = !1, e.isFPSMore = !1, e.priceDouble = 0, e.displayRegularPrice = "", e.displayAmountOff = "", e.groupNameDisplayRule = "", e.specialPrice = "", e.groupLabelName = "ASUS Member Program_Default_US_ASUS_ASUS", e.isTooltipVisible = !1, e.productCardWidth = 356, e.isTextHover = !1, e
                    }
                    return I(e, t), Object.defineProperty(e.prototype, "productSkuPrice", {
                        get: function() {
                            var t, e = this;
                            return 0 === Object.keys(this.getAllProductPrice).length ? null : this.routeInfo.filterInfo && this.routeInfo.filterInfo.modelBaseFlag ? (t = this.getAllProductPrice.filter((function(t) {
                                return t.productId === e.resultItemData.productId
                            }))).length > 0 ? t[0] : [] : (t = this.getAllProductPrice.filter((function(t) {
                                return t.sku === e.resultItemData.partNo
                            }))).length > 0 ? t[0] : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "learnMoreData", {
                        get: function() {
                            return {
                                name: this.buttonLearnMoreName,
                                disabled: !1,
                                link: this.resultItemData.skuLink.toLowerCase(),
                                ariaLabel: "Learn More ".concat(this.resultItemData.mktName)
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buyButtonData", {
                        get: function() {
                            return {
                                name: this.buttonName,
                                disabled: !1,
                                link: "buy" === this.productBuyType ? this.buttonLink ? this.buttonLink : "" : this.wtbButtonLink ? this.wtbButtonLink : "",
                                ariaLabel: "".concat(this.buttonAriaLabelName)
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "customizeButtonData", {
                        get: function() {
                            var t;
                            return {
                                name: this.customizeButtonName,
                                disabled: !1,
                                link: null === (t = this.getECCustomize) || void 0 === t ? void 0 : t.storeLink,
                                ariaLabel: "".concat(this.buttonAriaLabelName)
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isWtbButtonLink", {
                        get: function() {
                            var t;
                            return "" !== (null === (t = this.resultItemData) || void 0 === t ? void 0 : t.wtbLink)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "wtbButtonLink", {
                        get: function() {
                            return this.resultItemData.name || this.buttonLink ? "".concat(this.removeSlash(this.buttonLink), "/") : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "area", {
                        get: function() {
                            return "global" === this.lang ? "" : "/".concat(this.lang)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "modelBaseStatus", {
                        get: function() {
                            return this.routeInfo.filterInfo && this.routeInfo.filterInfo.modelBaseFlag
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonLink", {
                        get: function() {
                            switch (this.productBuyType) {
                                case "buy":
                                    return "" !== this.syncStoreLink ? this.syncStoreLink + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : "") : "".concat(this.resultItemData.storeLink) + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : "");
                                case "wtb":
                                    return "".concat(this.resultItemData.wtbLink);
                                default:
                                    return ""
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonLearnMoreName", {
                        get: function() {
                            return this.translation.Home_Learn_More
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonName", {
                        get: function() {
                            return "buy" === this.productBuyType ? "notify_me" === this.buttonStatus ? this.translation.eShop_Notify_Me : "pre_order" === this.buttonStatus ? this.translation.eShop_Pre_Order : "back_order" === this.buttonStatus ? this.translation.eShop_Back_Order : "customize" === this.buttonStatus ? this.translation.eShop_Buy_Customize : this.translation.eShop_Buy_Now : "wtb" === this.productBuyType ? this.translation.WTB_Where_to_Buy : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "customizeButtonName", {
                        get: function() {
                            var t, e, o, r, n, c;
                            return "notify_me" === (null === (t = this.getECCustomize) || void 0 === t ? void 0 : t.buttonStatus) ? this.translation.eShop_Notify_Me : "pre_order" === (null === (e = this.getECCustomize) || void 0 === e ? void 0 : e.buttonStatus) ? this.translation.eShop_Pre_Order : "back_order" === (null === (o = this.getECCustomize) || void 0 === o ? void 0 : o.buttonStatus) ? this.translation.eShop_Back_Order : "customize" === (null === (r = this.getECCustomize) || void 0 === r ? void 0 : r.buttonStatus) ? this.translation.eShop_Buy_Customize : "Coming Soon" === (null === (n = this.getECCustomize) || void 0 === n ? void 0 : n.buttonStatus) || "coming_soon" === (null === (c = this.getECCustomize) || void 0 === c ? void 0 : c.buttonStatus) ? this.translation.eShop_Coming_Soon : this.translation.eShop_Buy_Now
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonAriaLabelName", {
                        get: function() {
                            return "buy" === this.productBuyType ? "notify_me" === this.buttonStatus ? "".concat(this.translation.eShop_Notify_Me, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name, " ").concat(this.translation.Aria_back_in_stock) : "pre_order" === this.buttonStatus ? "".concat(this.translation.eShop_Pre_Order, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name) : "back_order" === this.buttonStatus ? "".concat(this.translation.eShop_Back_Order, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name) : "customize" === this.buttonStatus ? "".concat(this.translation.eShop_Buy_Customize, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name) : "".concat(this.translation.Aria_GoTOBuy, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name) : "wtb" === this.productBuyType ? "".concat(this.translation.WTB_Where_to_Buy, " ").concat(this.resultItemData.mktName, " ").concat(this.resultItemData.name) : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "productLineName", {
                        get: function() {
                            if (this.getQueryVariable("productline")) return this.getQueryVariable("productline");
                            if (this.routeInfo.fullPath) {
                                var t = this.routeInfo.fullPath;
                                return "global" === this.routeInfo.websitePath ? t.split("/")[0].replace("-group", "") : "cn" === this.routeInfo.websitePath ? t.indexOf("cn/") > -1 ? t.split("/")[1].replace("-group", "") : t.split("/")[0].replace("-group", "") : t.split("/")[1].replace("-group", "")
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareSelectList", {
                        get: function() {
                            return this.getQueryVariable("productline") ? this.compareSelect[this.getQueryVariable("productline")] : this.productLineName ? this.compareSelect[this.productLineName] : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "firstGameData", {
                        get: function() {
                            return this.resultItemData.games && this.resultItemData.games.length > 0 && this.resultItemData.gameTagline ? this.resultItemData.gameTagline : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.getProductModelPrice = function() {
                        var t = this;
                        if (this.isPrice);
                        else if (null === this.resultItemData.partNo && "buy" === this.productBuyType) {
                            var e = {
                                WebsiteCode: this.routeInfo.websitePath,
                                M1Id: this.resultItemData.id,
                                token: this.tokenData,
                                GroupId: Object(y.b)("groupid_rog_".concat(this.lang)) ? Object(y.b)("groupid_rog_".concat(this.lang)) : 0
                            };
                            try {
                                d.a.getModelPrice(e).then((function(e) {
                                    if (200 === e.data.status && e.data.result && e.data.result[0]) {
                                        var o = e.data.result[0];
                                        if (null === o || "null" === o) t.isPrice = !1, t.resultItemData.wtbLink && (t.productBuyType = "wtb");
                                        if (t.productPrice = o.price, t.buttonStatus = o.buttonStatus, t.regularPrice = o.regularPrice, t.amountOff = o.amountOff, t.syncStoreLink = o.storeLink, t.singleSku = o.singleSku, t.priceDouble = o.priceDouble, t.displayRegularPrice = o.regularPrice, t.displayAmountOff = o.amountOff, t.specialPrice = (null == o ? void 0 : o.specialPrice) ? o.specialPrice : "", t.groupNameDisplayRule = o.groupNameDisplayRule, t.groupLabelName = (null == o ? void 0 : o.groupLabelName) ? o.groupLabelName : "ASUS Member Program_Default_US_ASUS_ASUS", t.amountOff && parseInt(t.amountOff.split(",")[0].replace(/[^0-9]/gi, "")) > 0 && t.$emit("amountOffOpen", !0), 0 === t.stringTransformNumber(t.productPrice) || 0 === t.stringTransformNumber(t.regularPrice)) t.isPrice = !1, t.resultItemData.wtbLink && (t.productBuyType = "wtb");
                                        else t.isPrice = !0;
                                        setTimeout((function() {
                                            t.$emit("popHeight", t.$refs.content.clientHeight)
                                        }), 800), t.$emit("triggerItemContent")
                                    } else {
                                        console.dir("API getModelPrice Status:".concat(e.data.status)), t.isPrice = !1, t.resultItemData.wtbLink && (t.productBuyType = "wtb")
                                    }
                                })).catch((function(t) {
                                    console.error(t)
                                }))
                            } catch (t) {
                                console.error(t)
                            }
                        } else {
                            this.isPrice = !1, this.resultItemData.wtbLink && (this.productBuyType = "wtb")
                        }
                    }, Object.defineProperty(e.prototype, "isShow", {
                        get: function() {
                            return !this.hide && !(this.outStockStatus && (null === this.getStoreLink || "" === this.getStoreLink) && !this.isStockStatusHandler()) && this.shopSaleStatus
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "mainImageUrl", {
                        get: function() {
                            return this.resultItemData.productImgUrl ? this.resultItemData.productImgUrl : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "secondImageUrl", {
                        get: function() {
                            return this.resultItemData.secondProductImgUrl ? this.resultItemData.secondProductImgUrl : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "tokenData", {
                        get: function() {
                            return localStorage.getItem("rog_ec_token")
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isTranslateStringNumber", {
                        get: function() {
                            if (this.amountOff) {
                                var t = this.amountOff.split(",")[0];
                                return parseInt(t.replace(/[^0-9]/gi, ""), 10) > 0
                            }
                            return !1
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "logos", {
                        get: function() {
                            return this.resultItemData.logo && 0 !== this.resultItemData.logo.length ? this.resultItemData.logo : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getButtonStatus", {
                        get: function() {
                            return this.getProductPrice && this.getProductPrice.buttonStatus ? this.getProductPrice.buttonStatus : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getAmountOff", {
                        get: function() {
                            return this.getProductPrice && this.getProductPrice.amountOff ? Number(this.getProductPrice.amountOff.replace(/[^0-9]/gi, "")) : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getStoreLink", {
                        get: function() {
                            return this.getProductPrice && this.getProductPrice.storeLink ? this.getProductPrice.storeLink : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isECSite", {
                        get: function() {
                            return null !== this.mappingWebsite.tagLang && "" !== this.mappingWebsite.tagLang
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isMcc", {
                        get: function() {
                            var t, e;
                            return "MCC1" === (null === (t = this.mappingWebsite) || void 0 === t ? void 0 : t.mcc) || "MCC2" === (null === (e = this.mappingWebsite) || void 0 === e ? void 0 : e.mcc)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getECCustomize", {
                        get: function() {
                            var t;
                            return null !== (null === (t = this.resultItemData) || void 0 === t ? void 0 : t.ecCustomize) ? this.resultItemData.ecCustomize : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "itemContentHeight", {
                        get: function() {
                            return this.itemHeight - this.ratingHeightAndMarginHeight
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "ratingHeightAndMarginHeight", {
                        get: function() {
                            return this.ratingHeight > 0 ? 40 : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "productItemWrapperHeight", {
                        get: function() {
                            if (this.isDomReady) {
                                var t = this.$refs.resultItemWrapper.clientHeight + (this.isRatingHide ? 28 : 0);
                                return t > 0 && this.isSeeMore ? this.ratingHeight : t = (this.ratingHeight, 108), this.isSeeMore ? "" : (this.ratingHeight, "max-height:".concat(this.itemHeight > 0 && this.isSeeMore ? t + 30 + "px" : t + "px", ";height:").concat(this.itemHeight > 0 && this.isSeeMore ? t + 30 + "px" : t + "px", ";"))
                            }
                            return ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.checkShowSeeAllButton = function() {
                        var t = this.$refs.resultItemWrapper;
                        this.isShowSeeAllButton = (null == t ? void 0 : t.clientHeight) > 106, this.isDomReady = !0
                    }, e.prototype.watchGetProductPrice = function(t, e) {
                        var o = this,
                            r = 500;
                        "undefined" != typeof window && "rog.asus.com" === window.location.host && (r = 500), this.checkSkuPrice = setInterval((function() {
                            o.skuPriceHandler()
                        }), r)
                    }, e.prototype.watchOutStockStatus = function(t, e) {}, e.prototype.watchGetAmountOff = function(t, e) {
                        var o = this;
                        setTimeout((function() {
                            var t = "1" === o.getQueryVariable("sale");
                            t ? o.getAmountOff > 0 && t ? o.shopSaleStatus = !0 : o.shopSaleStatus = !1 : o.shopSaleStatus = !0
                        }), 500)
                    }, e.prototype.watchResultItemData = function() {
                        var t = this;
                        this.compareSelect[this.productLineName].length > 0 && this.compareSelect[this.productLineName].map((function(e) {
                            e.partNo === t.resultItemData.partNo && (t.checked = !0)
                        }))
                    }, e.prototype.watchCompareData = function(t, e) {
                        var o = this;
                        if (t) {
                            var r = !0,
                                line = this.productLineName;
                            this.getQueryVariable("productline") && (line = this.getQueryVariable("productline")), this.compareSelect[line].map((function(t) {
                                t.key === o.productId && (r = !1)
                            })), r && (this.checked = !1)
                        }
                    }, e.prototype.watchPriceValue = function(t, e) {
                        var o = t.filter((function(t) {
                            return !0 === t.trigger
                        }));
                        if (0 === o.length) this.hide = !1;
                        else if (null === this.getProductPrice) this.hide = !0;
                        else if (0 === Object.keys(this.getProductPrice).length) this.hide = !0;
                        else if (null !== t) {
                            var r = Number(this.getProductPrice.price.replace(/[^0-9]/gi, ""));
                            if (0 === o.length) this.hide = !1;
                            else
                                for (var i = 0; i < o.length; i++) {
                                    var n = o[i];
                                    if (n.trigger) {
                                        var c = Number(n.name.split(" ~ ")[0].replace(/[^0-9]/gi, "")),
                                            l = 99999999999999;
                                        if (l = n.name.split(" ~ ")[1] === this.translation.price_up ? 99999999999999 : Number(n.name.split(" ~ ")[1].replace(/[^0-9]/gi, "")), r >= c && l >= r) {
                                            this.hide = !1;
                                            break
                                        }
                                        this.hide = !0
                                    }
                                }
                        } else this.hide = !1
                    }, e.prototype.watchPriceChangeValue = function(t, e) {
                        var o, r;
                        if (null !== t && null !== this.getProductPrice) {
                            var n = Number(null === (r = null === (o = this.getProductPrice) || void 0 === o ? void 0 : o.price) || void 0 === r ? void 0 : r.replace(/[^0-9]/gi, "")),
                                c = Number(t.split(" ~ ")[0].replace(/[^0-9]/gi, "")),
                                l = Number(t.split(" ~ ")[1].replace(/[^0-9]/gi, ""));
                            this.hide = !(n >= c && l >= n)
                        } else this.hide = !0
                    }, e.prototype.isStockStatusHandler = function() {
                        return (!this.inStockStatus || !this.outStockStatus) && (!(!this.inStockStatus && this.outStockStatus) && !(!this.inStockStatus || this.outStockStatus))
                    }, e.prototype.priceHandler = function() {
                        var t = this.priceValue.filter((function(t) {
                            return !0 === t.trigger
                        }));
                        if (0 === t.length) this.hide = !1;
                        else if (null === this.getProductPrice) this.hide = !0;
                        else if (0 === Object.keys(this.getProductPrice).length) this.hide = !0;
                        else if (null !== this.priceValue) {
                            var e = Number(this.getProductPrice.price.replace(/[^0-9]/gi, ""));
                            if (0 === t.length) this.hide = !1;
                            else
                                for (var i = 0; i < t.length; i++) {
                                    var o = t[i];
                                    if (o.trigger) {
                                        var r = Number(o.name.split(" ~ ")[0].replace(/[^0-9]/gi, "")),
                                            n = 99999999999999;
                                        if (n = o.name.split(" ~ ")[1] === this.translation.price_up ? 99999999999999 : Number(o.name.split(" ~ ")[1].replace(/[^0-9]/gi, "")), e >= r && n >= e) {
                                            this.hide = !1;
                                            break
                                        }
                                        this.hide = !0
                                    }
                                }
                        } else this.hide = !1
                    }, e.prototype.updated = function() {
                        var t = this;
                        setTimeout((function() {
                            t.shopOnSaleStatus && (t.getAmountOff > 0 && t.shopOnSaleStatus ? t.shopSaleStatus = !0 : t.shopSaleStatus = !1)
                        }), 500)
                    }, e.prototype.mounted = function() {
                        var t = this;
                        this.imageHeight = this.$refs.productItemImage ? this.$refs.productItemImage.offsetWidth : 0, this.productCardWidth = this.$refs.productItem ? this.$refs.productItem.offsetWidth : 0, this.productLineName && this.initialCheckBoxStatus(), document.addEventListener("keydown", (function(e) {
                            49 === e.keyCode && (t.isShowNew = !t.isShowNew)
                        })), window.addEventListener("resize", (function() {
                            setTimeout((function() {
                                t.productCardWidth = t.$refs.productItem ? t.$refs.productItem.offsetWidth : 0, t.checkShowSeeAllButton()
                            }), 100)
                        }));
                        var e = setInterval((function() {
                            var o = t.$refs.review && t.$refs.review.getElementsByClassName("bv_text") ? t.$refs.review.getElementsByClassName("bv_text") : null;
                            o && o[1] && o[1].innerText && "(0)" !== o[1].innerText && (t.isRatingHide = !0, window.clearInterval(e))
                        }), 1e3);
                        setTimeout((function() {
                            window.clearInterval(e)
                        }), 5e3), this.$nextTick((function() {
                            setTimeout((function() {
                                t.checkShowSeeAllButton()
                            }), 1e3)
                        })), this.isECSite || (this.productBuyType = "wtb")
                    }, e.prototype.skuPriceHandler = function() {
                        var t = this;
                        if (this.getECCustomize && this.getECCustomize.status) return this.productBuyType = this.getECCustomize.buttonStatus, this.syncStoreLink = this.getECCustomize.storeLink, void clearInterval(this.checkSkuPrice);
                        var e = this.getProductPrice;
                        if (e && Object.keys(e).length > 0) {
                            var o = e;
                            if (this.productPrice = o.price, this.buttonStatus = o.buttonStatus, this.regularPrice = o.regularPrice, this.amountOff = o.amountOff, this.syncStoreLink = o.storeLink, this.displayHistoricLowPrice = o.displayHistoricLowPrice ? o.displayHistoricLowPrice : "", this.historicLowPrice = o.historicLowPrice ? o.historicLowPrice : "", this.priceDouble = o.priceDouble, this.displayRegularPrice = o.regularPrice, this.displayAmountOff = o.amountOff, this.specialPrice = (null == o ? void 0 : o.specialPrice) ? o.specialPrice : "", this.groupNameDisplayRule = o.groupNameDisplayRule, this.groupLabelName = (null == o ? void 0 : o.groupLabelName) ? o.groupLabelName : "ASUS Member Program_Default_US_ASUS_ASUS", this.amountOff && parseInt(this.amountOff.split(",")[0].replace(/[^0-9]/gi, "")) > 0 ? this.$emit("amountOffOpen", !0) : this.$emit("amountOffOpen", !1), 0 === this.stringTransformNumber(this.productPrice) || 0 === this.stringTransformNumber(this.regularPrice)) this.isPrice = !1, (n = this.resultItemData.wtbLink) && (this.productBuyType = "wtb");
                            else if (this.productPrice && this.regularPrice) this.productBuyType = "buy", this.isPrice = !0;
                            else {
                                this.isPrice = !1, (n = this.resultItemData.wtbLink) && (this.productBuyType = "wtb")
                            }
                            var r = setInterval((function() {
                                t.$refs.content && (t.$emit("popHeight", t.$refs.content.clientHeight), clearInterval(r))
                            }), 500);
                            clearInterval(this.checkSkuPrice), this.$emit("triggerItemContent")
                        } else {
                            this.isPrice = !1;
                            var n = this.resultItemData.wtbLink;
                            clearInterval(this.checkSkuPrice), n && (this.productBuyType = "wtb")
                        }
                    }, e.prototype.priceCompareSpecialPrice = function() {
                        return this.priceDouble > Number(this.specialPrice) || (this.priceDouble < Number(this.specialPrice) || null === this.specialPrice)
                    }, e.prototype.returnCurrency = function(t) {
                        var e = t,
                            o = this.mappingWebsite.currencySymbol;
                        Number(this.mappingWebsite.numberOfDecimal);
                        e = e.replace("".concat(o), "");
                        var r = this.mappingWebsite.decimalSeparator;
                        e = e.split("".concat(r))[0];
                        var n = this.mappingWebsite.thousandSeparators;
                        return e = e.replace("".concat(n), ""), Number(e)
                    }, e.prototype.getDisplayPriceHandler = function(t) {
                        for (var e, o = this, r = t.toLowerCase(), n = ["save", "with"], c = /\{(.*?)\}/g, l = []; null !== (e = c.exec(r));) {
                            var d = e[1];
                            n.includes(d) ? l.push({
                                type: "translation",
                                key: d
                            }) : l.push({
                                type: "param",
                                key: d
                            })
                        }
                        var _ = "";
                        return l.forEach((function(t, e) {
                            "translation" === t.type ? "save" === t.key ? _ += o.translation.eShop_Save : "with" === t.key && (_ += o.translation.PDList_GroupName) : "regularprice" === t.key ? _ += "<span>" + o.displayRegularPrice + "</span>" : "amountoff" === t.key ? _ += o.displayAmountOff : _ += o.groupLabelName, e < l.length - 1 && (_ += " ")
                        })), _
                    }, e.prototype.encodeHTML = function(t) {
                        return t ? t.replace(/®/gim, "<sup>®</sup>") : ""
                    }, e.prototype.stringTransformNumber = function(t) {
                        var e = t ? t.split(",")[0] : "";
                        return parseInt(e.replace(/[^0-9]/gi, ""), 10)
                    }, e.prototype.initialCheckBoxStatus = function() {
                        var t = this;
                        this.productLineName && this.compareSelect[this.productLineName] && this.compareSelect[this.productLineName].length > 0 && this.compareSelect[this.productLineName].map((function(e) {
                            e.partNo === t.resultItemData.partNo && (t.checked = !0)
                        }))
                    }, e.prototype.propContentHeight = function() {
                        this.$refs.resultItemNames && this.$refs.resultItemNames.clientHeight ? this.$emit("maxNamesHeight", {
                            height: this.$refs.resultItemNames.clientHeight,
                            num: this.gaId,
                            status: this.isShow
                        }) : this.$emit("maxNamesHeight", {
                            height: 0,
                            num: this.gaId,
                            status: this.isShow
                        }), this.$refs.productItemRating ? this.$emit("isRatingHide", {
                            height: this.$refs.productItemRating.clientHeight,
                            status: this.isShow,
                            num: this.gaId,
                            hide: this.isRatingHide
                        }) : this.$emit("isRatingHide", {
                            height: 0,
                            status: this.isShow,
                            num: this.gaId,
                            hide: this.isRatingHide
                        }), this.$refs.content && this.$refs.content.clientHeight && this.$emit("popHeight", this.$refs.content.clientHeight)
                    }, e.prototype.checkBoxHandler = function() {
                        var t = this;
                        4 === this.compareSelect[this.productLineName].length && this.checked ? this.checked = !1 : (this.checked ? window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "compare_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/compare/product_card"),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "compare_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.resultItemData.mktName, "/compare/product_card"),
                                event_value_DL: "0"
                            })
                        }), 200) : window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "compare_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/compare_cancel/product_card"),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "compare_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.resultItemData.mktName, "/compare_cancel/product_card"),
                                event_value_DL: "0"
                            })
                        }), 200), this.onCheck(this.productId))
                    }, e.prototype.onTabCheckHandler = function(t) {
                        this.checked = !this.checked, 4 === this.compareSelect[this.productLineName].length && this.checked ? this.checked = !1 : this.onCheck(t)
                    }, e.prototype.onCheck = function(t) {
                        var param = {
                                key: t,
                                type: this.productLineName
                            },
                            e = O(O({}, this.resultItemData), param);
                        if (1 === this.compareSelect[this.productLineName].length && this.checked || Object(f.a)().width > 1024 && this.$emit("triggerComparePanel"), this.checkProductID(t)) return this.checked = !1, void this.CompareCancel(e);
                        this.checked ? this.getCompareSelect(e) : this.CompareCancel(e)
                    }, e.prototype.showMoreHandler = function(t) {
                        var e = this;
                        t ? window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "see_more_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/see_more/product_card"),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "see_more_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(e.resultItemData.mktName, "/see_more/product_card"),
                                event_value_DL: "0"
                            })
                        }), 200) : window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "see_more_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/see_less/product_card"),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "see_more_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(e.resultItemData.mktName, "/see_less/product_card"),
                                event_value_DL: "0"
                            })
                        }), 200), this.showContentMore = t, this.$emit("changeSeeMore", {
                            status: t,
                            id: this.gaId
                        })
                    }, e.prototype.goToProductOverView = function(t, e) {
                        var o, r = "http://localhost:8000" === encodeURI(window.location.origin) ? "https://rogmars.asus.com" : encodeURI(window.location.origin);
                        if ("http://localhost:8000" !== encodeURI(window.location.origin)) {
                            o = "rog.asus.com.cn" === window.location.host ? t.skuLink.toLowerCase().split("".concat(encodeURI(window.location.origin)))[1].split("/") : t.skuLink.toLowerCase().split("".concat(r).concat(this.area))[1].split("/");
                            var n = "".concat(o[1], "/undefined/").concat(o[2], "/undefined");
                            window.innerWidth > 1024 ? "image" === e ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "images_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.mktName, "/images/product_card"),
                                event_value_DL: "0"
                            }) : "name" === e && window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "titles_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.mktName, "/titles/product_card"),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                "image" === e ? window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_name_ga4: "images_product_card",
                                    event_category_DL: "product_card",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t.mktName, "/images/product_card"),
                                    event_value_DL: "0"
                                }) : "name" === e && window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_name_ga4: "titles_product_card",
                                    event_category_DL: "product_card",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t.mktName, "/titles/product_card"),
                                    event_value_DL: "0"
                                })
                            }), 200), window.dataLayer.push({
                                event: "productClick",
                                ecommerce: {
                                    click: {
                                        actionField: {
                                            list: this.gaProductListName
                                        },
                                        products: [{
                                            name: "".concat(t.name || t.mktName),
                                            id: t.partNo,
                                            dimension10: t.partNo,
                                            price: "",
                                            brand: "ROG",
                                            category: n,
                                            list: this.gaProductListName,
                                            position: this.gaId
                                        }]
                                    }
                                }
                            }), "rating" === e && sessionStorage.setItem("rating", "true"), window.location.href = encodeURI("".concat(t.skuLink.toLowerCase().replace(r, "")))
                        } else window.location.href = encodeURI("".concat(t.skuLink.toLowerCase().replace(r, "")))
                    }, e.prototype.checkProductID = function(t) {
                        var e = !1;
                        return this.compareSelect[this.productLineName].map((function(o) {
                            parseInt(o.key) === t && (e = !0)
                        })), e
                    }, e.prototype.showSecondImage = function() {
                        this.secondImageUrl && (this.isHoverProductImage = !0)
                    }, e.prototype.hoverTextHandler = function() {
                        this.isTextHover = !0
                    }, e.prototype.leaveTextHandler = function() {
                        this.isTextHover = !1
                    }, e.prototype.hideSecondImage = function() {
                        this.isHoverProductImage = !1
                    }, e.prototype.checkString = function(t) {
                        return this.filterString(t.name)
                    }, e.prototype.filterString = function(t) {
                        return !(!this.hideNA(t) || !t)
                    }, e.prototype.hideNA = function(t) {
                        var e = new RegExp(/N\/A/gim);
                        return !t.match(e)
                    }, e.prototype.secondImageUrlHandler = function(t, e) {
                        return t && "" !== t ? "".concat(t, "/").concat(e) : ""
                    }, e.prototype.removeSlash = function(path) {
                        var t = "";
                        return path.length - 1 > 0 && path.lastIndexOf("/") === path.length - 1 && (t = path.substring(0, path.length - 1)), t
                    }, e.prototype.openTooltipHandler = function() {
                        this.isTooltipVisible = !this.isTooltipVisible
                    }, e.prototype.getQueryVariable = function(t) {
                        if ("undefined" != typeof window) return new URLSearchParams(window.location.search).get(t) || ""
                    }, e.prototype.currencyHandler = function(t) {
                        return t
                    }, e.prototype.fpsMoreClickGAHandler = function() {
                        var t = this;
                        this.isFPSMore = !this.isFPSMore, this.isFPSMore && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "fps_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.resultItemData.mktName, "/fps/product_card"),
                            event_value_DL: ""
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "fps_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.resultItemData.mktName, "/fps/product_card"),
                                event_value_DL: ""
                            })
                        }), 200))
                    }, e.prototype.goProductPage = function() {
                        var t, e = this,
                            o = this.resultItemData,
                            r = "http://localhost:8000" === encodeURI(window.location.origin) ? "https://dev-rog.asus.com" : encodeURI(window.location.origin);
                        t = "rog.asus.com.cn" === window.location.host ? o.skuLink.toLowerCase().split("".concat(encodeURI(window.location.origin)))[1].split("/") : o.skuLink.toLowerCase().split("".concat(r).concat(this.area))[1].split("/");
                        var n = "".concat(t[1], "/undefined/").concat(t[2], "/undefined");
                        window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "cta_btn_product_card",
                            event_category_DL: "product_card",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(o.mktName, "/learnmoreButton-").concat(this.translation.Home_Learn_More, "/product_card"),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "cta_btn_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(o.mktName, "/learnmoreButton-").concat(e.translation.Home_Learn_More, "/product_card"),
                                event_value_DL: "0"
                            })
                        }), 200), window.dataLayer.push({
                            event: "productClick",
                            ecommerce: {
                                click: {
                                    actionField: {
                                        list: this.gaProductListName
                                    },
                                    products: [{
                                        name: "".concat(o.name || o.mktName),
                                        id: o.partNo,
                                        dimension10: o.partNo,
                                        price: "",
                                        brand: "ROG",
                                        category: n,
                                        list: this.gaProductListName,
                                        position: this.gaId
                                    }]
                                }
                            }
                        }), window.location.href = encodeURI("".concat(o.skuLink.toLowerCase().replace(r, "")))
                    }, e.prototype.gaDataLayer = function(t, e) {
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "compare_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "/").concat(e, "-").concat(e),
                                event_value_DL: 0
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_name_ga4: "compare_product_card",
                                    event_category_DL: "product_card",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t, "/").concat(e, "-").concat(e),
                                    event_value_DL: 0
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "buttons", "clicked", "".concat(t, "/").concat(e, "-").concat(e)])
                        }
                    }, e.prototype.goBuyLink = function(t) {
                        var e, area = "global" === this.routeInfo.websitePath ? "" : this.routeInfo.websitePath,
                            o = "http://localhost:8000" === encodeURI(window.location.origin) ? "https://rogmars.asus.com" : encodeURI(window.location.origin);
                        e = "rog.asus.com.cn" === window.location.host ? t.skuLink.toLowerCase().split("".concat(encodeURI(window.location.origin)))[1].split("/") : t.skuLink.toLowerCase().split("".concat(encodeURI(o), "/").concat(area))[1].split("/");
                        var r = "".concat(encodeURI(e[1]), "/undefined/").concat(encodeURI(e[2]), "/undefined"),
                            n = this.buyButtonData.name,
                            c = this.buttonStatus;
                        if (this.getECCustomize && this.getECCustomize.status && (n = this.customizeButtonName, c = "customize"), window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "cta_btn_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.mktName, "/").concat(c.replace("_", ""), "Button-").concat(n, "/product_card"),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_name_ga4: "cta_btn_product_card",
                                    event_category_DL: "product_card",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t.mktName, "/").concat(c.replace("_", ""), "Button-").concat(n, "/product_card"),
                                    event_value_DL: "0"
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "buttons", "clicked", "".concat(t.mktName, "/buynow-").concat(this.buyButtonData.name)])
                        }
                        window.dataLayer.push({
                            event: "productClick",
                            ecommerce: {
                                click: {
                                    actionField: {
                                        list: this.gaProductListName
                                    },
                                    products: [{
                                        name: "".concat(t.name || t.mktName),
                                        id: t.partNo,
                                        dimension10: t.partNo,
                                        price: "",
                                        brand: "ROG",
                                        category: r,
                                        list: this.gaProductListName,
                                        position: this.gaId
                                    }]
                                }
                            }
                        }), this.getECCustomize && this.getECCustomize.status ? window.location.href = encodeURI(this.getECCustomize.storeLink) : window.location.href = encodeURI("" !== this.syncStoreLink ? this.syncStoreLink + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : "") : t.skuLink.toLowerCase() + ("cn" !== this.lang ? "?config=".concat(this.resultItemData.partNo) : ""))
                    }, e.prototype.goWTBLink = function(t) {
                        var e, o = this,
                            area = "global" === this.routeInfo.websitePath ? "" : this.routeInfo.websitePath,
                            r = "http://localhost:8000" === encodeURI(window.location.origin) ? "https://stage-rog.asus.com" : encodeURI(window.location.origin);
                        e = "rog.asus.com.cn" === window.location.host ? t.skuLink.toLowerCase().split("".concat(encodeURI(window.location.origin)))[0].split("/") : t.skuLink.toLowerCase().split("".concat(encodeURI(r), "/").concat(area))[0].split("/");
                        var n = "".concat(e[1], "/undefined/").concat(e[2], "/undefined");
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "cta_btn_product_card",
                                event_category_DL: "product_card",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.mktName, "/wheretobuyButton-").concat(this.buyButtonData.name, "/product_card"),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_name_ga4: "cta_btn_product_card",
                                    event_category_DL: "product_card",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t.mktName, "/wheretobuyButton-").concat(o.buyButtonData.name, "/product_card"),
                                    event_value_DL: "0"
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "buttons", "clicked", "".concat(t.name || t.mktName, "/wheretobuyButton-").concat(this.buyButtonData.name)])
                        }
                        window.dataLayer.push({
                            event: "productClick",
                            ecommerce: {
                                click: {
                                    actionField: {
                                        list: "where_to_buy"
                                    },
                                    products: [{
                                        name: "".concat(t.name || t.mktName),
                                        id: t.partNo,
                                        dimension10: t.partNo,
                                        price: "",
                                        brand: "ROG",
                                        category: n,
                                        list: this.gaProductListName,
                                        position: this.gaId
                                    }]
                                }
                            }
                        }), window.location.href = encodeURI("".concat(this.resultItemData.wtbLink.toLowerCase()))
                    }, k([Object(m.Action)("getCompareSelect")], e.prototype, "getCompareSelect", void 0), k([Object(m.Action)("CompareCancel")], e.prototype, "CompareCancel", void 0), k([Object(m.Action)("getSkuPrice")], e.prototype, "getSkuPrice", void 0), k([Object(m.Action)("getModelPrice")], e.prototype, "getModelPrice", void 0), k([Object(m.Getter)("compareSelect")], e.prototype, "compareSelect", void 0), k([Object(m.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), k([Object(m.Getter)("translation")], e.prototype, "translation", void 0), k([Object(m.Getter)("filterShop")], e.prototype, "filterShop", void 0), k([Object(m.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), k([Object(m.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), k([Object(m.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), k([Object(l.Prop)({
                        required: !0
                    })], e.prototype, "resultItemData", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "productId", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "gaId", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "itemHeight", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "ratingHeight", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "itemNameHeight", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isBuyStatus", void 0), k([Object(l.Prop)({
                        default: []
                    })], e.prototype, "routeDefault", void 0), k([Object(l.Prop)({
                        default: "product_list"
                    })], e.prototype, "gaProductListName", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "showRating", void 0), k([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "productResultItemPriceContentHeight", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "ratingHide", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "openAmountOff", void 0), k([Object(l.Prop)({
                        default: null
                    })], e.prototype, "getProductPrice", void 0), k([Object(l.Prop)({
                        default: null
                    })], e.prototype, "getAllProductPrice", void 0), k([Object(l.Prop)({
                        default: null
                    })], e.prototype, "priceValue", void 0), k([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "priceChangeValue", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "shopOnSaleStatus", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "inStockStatus", void 0), k([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "outStockStatus", void 0), k([Object(l.Prop)({
                        default: !0
                    })], e.prototype, "isSeeMore", void 0), k([Object(l.Watch)("getProductPrice", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchGetProductPrice", null), k([Object(l.Watch)("outStockStatus", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchOutStockStatus", null), k([Object(l.Watch)("getAmountOff", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchGetAmountOff", null), k([Object(l.Watch)("resultItemData", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchResultItemData", null), k([Object(l.Watch)("compareSelectList")], e.prototype, "watchCompareData", null), k([Object(l.Watch)("priceValue", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchPriceValue", null), k([Object(l.Watch)("priceChangeValue", {
                        immediate: !1,
                        deep: !0
                    })], e.prototype, "watchPriceChangeValue", null), e = k([Object(l.Component)({
                        components: {
                            ButtonRed: _.a,
                            ButtonBorderRed: h.a,
                            ProductTag: v.a,
                            seeAllButton: S.a,
                            ProductStock: P.a,
                            ProductStatus: w.a
                        }
                    })], e)
                }(l.Vue),
                j = L,
                D = o(1037),
                C = o(25);
            var component = Object(C.a)(j, (function() {
                var t, e, o, r, c, l, d, _, h, m, f, y = this,
                    v = y._self._c;
                y._self._setupProxy;
                return !y.hide && y.shopSaleStatus ? v("div", {
                    ref: "productItem",
                    staticClass: "productItem",
                    class: [y.$style.productItem],
                    attrs: {
                        "data-number": y.gaId
                    }
                }, [v("ClientOnly", [v("input", {
                    attrs: {
                        type: "hidden",
                        name: y.resultItemData.partNo || y.resultItemData.id
                    }
                }), y._v(" "), v("ProductStatus", {
                    attrs: {
                        getButtonStatus: y.getButtonStatus,
                        openAmountOff: "" !== y.amountOff,
                        isNews: null === (t = y.resultItemData) || void 0 === t || null === (t = t.productCardTag) || void 0 === t ? void 0 : t.newTag,
                        isProductCard: !0,
                        lang: y.lang,
                        productCardWidth: y.productCardWidth,
                        statusList: null === (e = y.resultItemData) || void 0 === e || null === (e = e.productCardTag) || void 0 === e ? void 0 : e.statusTag,
                        customTag: null === (o = y.resultItemData) || void 0 === o || null === (o = o.productCardTag) || void 0 === o ? void 0 : o.customTag
                    }
                })], 1), y._v(" "), v("div", {
                    ref: "productItemImage",
                    class: [y.$style.productItemImage, Object(n.a)({}, y.$style.isECSite, y.isECSite)],
                    on: {
                        click: function(t) {
                            return t.preventDefault(), y.goToProductOverView(y.resultItemData, "image")
                        }
                    }
                }, [v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.resultItemData.productImgUrl,
                        expression: "resultItemData.productImgUrl"
                    }],
                    class: y.$style.productItemImageWrapper,
                    on: {
                        mouseover: y.showSecondImage,
                        mouseleave: y.hideSecondImage
                    }
                }, [y.mainImageUrl ? v("a", {
                    class: y.$style.productItemLink,
                    attrs: {
                        "aria-label": "".concat(y.translation.WTB_VIEW, " ").concat(y.resultItemData.mktName),
                        href: y.resultItemData.skuLink.toLowerCase()
                    }
                }, [v("picture", {
                    class: [Object(n.a)({}, y.$style.show, !y.isHoverProductImage)],
                    attrs: {
                        "aria-hidden": !!y.isHoverProductImage
                    }
                }, [v("source", {
                    attrs: {
                        srcset: "".concat(y.mainImageUrl, "/w240/fwebp"),
                        media: "(max-width: 540px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: "".concat(y.mainImageUrl, "/w260/fwebp"),
                        media: "(max-width: 780px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: "".concat(y.mainImageUrl, "/w273/fwebp"),
                        media: "(max-width: 1235px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: "".concat(y.mainImageUrl, "/w273/fwebp"),
                        media: "(max-width: 1535px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: "".concat(y.mainImageUrl, "/w273/fwebp")
                    }
                }), y._v(" "), v("img", {
                    attrs: {
                        src: "".concat(y.mainImageUrl),
                        alt: "",
                        loading: 0 === y.gaId ? "eager" : "lazy",
                        fetchpriority: 0 === y.gaId ? "high" : "auto"
                    }
                })]), y._v(" "), v("picture", {
                    class: [Object(n.a)({}, y.$style.show, y.isHoverProductImage)],
                    attrs: {
                        "aria-hidden": !y.isHoverProductImage,
                        tabindex: y.isHoverProductImage ? "" : -1
                    }
                }, [v("source", {
                    attrs: {
                        srcset: y.secondImageUrlHandler("".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl, "/fwebp"), "w240"),
                        media: "(max-width: 540px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: y.secondImageUrlHandler("".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl, "/fwebp"), "w260"),
                        media: "(max-width: 780px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: y.secondImageUrlHandler("".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl, "/fwebp"), "w273"),
                        media: "(max-width: 1235px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: y.secondImageUrlHandler("".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl, "/fwebp"), "w273"),
                        media: "(max-width: 1535px)"
                    }
                }), y._v(" "), v("source", {
                    attrs: {
                        srcset: y.secondImageUrlHandler("".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl, "/fwebp"), "w273")
                    }
                }), y._v(" "), v("img", {
                    attrs: {
                        src: "".concat(y.secondImageUrl ? y.secondImageUrl : y.mainImageUrl),
                        alt: "",
                        loading: "lazy"
                    }
                })])]) : y._e(), y._v(" "), y.mainImageUrl ? y._e() : v("a", {
                    class: y.$style.productItemLink,
                    attrs: {
                        "aria-label": "".concat(y.translation.WTB_VIEW, " ").concat(y.resultItemData.mktName),
                        href: y.resultItemData.skuLink.toLowerCase()
                    }
                }, [v("div", {
                    class: y.$style.productNoImage
                }, [v("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        role: "img",
                        "svg-inline": "",
                        alt: "no image",
                        loading: "lazy",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        d: "M0 5.3v21.4h32V5.3zm13.9 12.12l4.34 3.11 6.86-7.27L29.86 18v6.6H7.41zm4.07.3l-4.37-3.14-9.07 10h-2.4V7.43h27.74V15L25 10.21z"
                    }
                }), v("path", {
                    attrs: {
                        d: "M6.85 8.19a4 4 0 104 4 4 4 0 00-4-4zm0 2.13A1.83 1.83 0 115 12.15a1.83 1.83 0 011.85-1.83z"
                    }
                })])])])])]), y._v(" "), v("div", {
                    ref: "badge",
                    class: [y.$style.productBadge, Object(n.a)({}, y.$style.noData, 0 === y.logos.length)]
                }, y._l(y.logos.slice(0, 2), (function(t, e) {
                    return v("div", {
                        key: e,
                        class: y.$style.productBadgeLink
                    }, ["" !== t.logoLink ? v("a", {
                        attrs: {
                            href: t.logoLink,
                            target: y.getAIStatus ? "_blank" : "_self",
                            rel: y.getAIStatus ? "noopener noreferrer" : "",
                            tabindex: "1"
                        }
                    }, [v("img", {
                        class: y.$style.productBadgeImage,
                        attrs: {
                            srcset: "".concat("" !== t.x1MediaUrl ? t.x1MediaUrl + " 1x" : t.x2MediaUrl + " 2x", ", ").concat("" !== t.x2MediaUrl ? t.x2MediaUrl + " 2x" : ""),
                            alt: t.alt || t.name,
                            loading: "lazy"
                        }
                    })]) : v("div", [v("img", {
                        class: y.$style.productBadgeImage,
                        attrs: {
                            srcset: "".concat("" !== t.x1MediaUrl ? t.x1MediaUrl + " 1x" : t.x2MediaUrl + " 2x", ", ").concat("" !== t.x2MediaUrl ? t.x2MediaUrl + " 2x" : ""),
                            alt: t.alt || t.name,
                            loading: "lazy"
                        }
                    })])])
                })), 0), y._v(" "), v("div", {
                    ref: "resultItemInch",
                    class: [y.$style.productScreenWidth, Object(n.a)({}, y.$style.noData, "" === y.resultItemData.inch)]
                }, [v("span", [y._v(y._s(y.resultItemData.inch))])]), y._v(" "), v("div", {
                    class: [y.$style.productItemTitle, (c = {}, Object(n.a)(c, y.$style.isHover, y.isTextHover), Object(n.a)(c, y.$style.jpProductItemTitle, "jp" === y.lang), Object(n.a)(c, y.$style.subTitle, (null === (r = y.resultItemData) || void 0 === r ? void 0 : r.name) && "" !== y.resultItemData.name), c)],
                    on: {
                        mouseover: y.hoverTextHandler,
                        mouseleave: y.leaveTextHandler,
                        click: function(t) {
                            return t.preventDefault(), y.goToProductOverView(y.resultItemData, "name")
                        }
                    }
                }, [v("a", {
                    ref: "resultItemNames",
                    attrs: {
                        href: y.resultItemData.skuLink.toLowerCase()
                    }
                }, [v("span", {
                    class: y.$style.mktName,
                    domProps: {
                        innerHTML: y._s(y.encodeHTML(y.resultItemData.mktName))
                    }
                })])]), y._v(" "), null !== (l = y.resultItemData) && void 0 !== l && l.name && "" !== y.resultItemData.name ? v("div", {
                    class: [y.$style.productItemTitle, (d = {}, Object(n.a)(d, y.$style.isHover, y.isTextHover), Object(n.a)(d, y.$style.jpProductItemTitle, "jp" === y.lang), d)],
                    on: {
                        mouseover: y.hoverTextHandler,
                        mouseleave: y.leaveTextHandler,
                        click: function(t) {
                            return t.preventDefault(), y.goToProductOverView(y.resultItemData, "name")
                        }
                    }
                }, [v("a", {
                    attrs: {
                        href: y.resultItemData.skuLink.toLowerCase()
                    }
                }, [v("span", {
                    class: y.$style.subName,
                    domProps: {
                        innerHTML: y._s(y.encodeHTML(y.resultItemData.name))
                    }
                })])]) : y._e(), y._v(" "), v("div", {
                    ref: "productItemRating",
                    class: [y.$style.productItemRatingContent, Object(n.a)({}, y.$style.show, y.isRatingHide)],
                    on: {
                        click: function(t) {
                            return y.goToProductOverView(y.resultItemData, "rating")
                        }
                    }
                }, [v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.isRatingHide,
                        expression: "isRatingHide"
                    }],
                    staticClass: "rogRating"
                }, [v("div", {
                    ref: "review",
                    attrs: {
                        "data-bv-show": "inline_rating",
                        "data-bv-set": "false",
                        "data-bv-product-id": "".concat(y.resultItemData.externalId)
                    }
                })])]), y._v(" "), v("div", {
                    class: y.$style.fpsWrapper
                }, [y.resultItemData.games.length > 0 ? [v("svg", {
                    class: y.$style.fpsIcon,
                    attrs: {
                        width: "28",
                        height: "28",
                        viewBox: "0 0 28 28",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "img",
                        "svg-inline": "",
                        alt: "fps icon",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M28 15.375l-5.6 5.5h-6.3v2.75h7L24.5 25h-21l1.4-1.375h7v-2.75H0V8.5L5.6 3H28v12.375zm-21.819-11L1.4 9.071V19.5h20.419l4.781-4.696V4.375H6.181z",
                        fill: "#000"
                    }
                }), v("path", {
                    attrs: {
                        d: "M8.806 12.313H4.859v2.854H3v-6h6.89l-.802.883H4.86v1.38h4.767l-.82.883zM17.14 13.041h-5.15v2.126h-1.914v-6h7.064v3.874zm-1.915-2.991h-3.253v2.108h3.254V10.05zM24.781 11.721v2.537l-.83.909h-5.75l-.82-.883h5.13l.338-.369v-1.311h-5.222v-2.486l.866-.951H25l-.802.883h-4.256l-.41.437v1.234h5.25z",
                        fill: "#000"
                    }
                })]), y._v(" "), v("div", [v("p", {
                    class: y.$style.fpsGameName
                }, [y._v(y._s(y.firstGameData.name))]), y._v(" "), v("div", {
                    class: y.$style.fpsContent
                }, [v("div", [v("span", {
                    class: y.$style.fpsValue
                }, [y._v(y._s(y.firstGameData.fhd))]), y._v(" "), v("span", {
                    class: [y.$style.fpsValue, y.$style.fpsFont]
                }, [y._v(y._s(y.translation.PDList_unit ? y.translation.PDList_unit : "FPS"))])]), y._v(" "), v("button", {
                    class: y.$style.fpsMoreButton,
                    on: {
                        click: y.fpsMoreClickGAHandler
                    }
                }, [y._v(y._s(y.translation.PDList_more ? y.translation.PDList_more : "MORE") + "\n            "), v("svg", {
                    class: [y.$style.fpsArrow, Object(n.a)({}, y.$style.active, y.isFPSMore)],
                    attrs: {
                        width: "12",
                        height: "13",
                        viewBox: "0 0 12 13",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "img",
                        "svg-inline": "",
                        alt: "fps icon",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        d: "M6 10.05l-5-5V3l5 5 5-5v2.05l-5 5z",
                        fill: "#181818"
                    }
                })])])]), y._v(" "), v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.isFPSMore,
                        expression: "isFPSMore"
                    }],
                    class: y.$style.fpsMoreContent
                }, [v("svg", {
                    class: y.$style.fpsClose,
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "search",
                        role: "presentation",
                        focusable: "false"
                    },
                    on: {
                        click: function(t) {
                            y.isFPSMore = !1
                        }
                    }
                }, [v("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M4.647 5.353l.707-.707L12 11.293l6.646-6.647.708.707L12.708 12l6.647 6.647-.708.707-6.646-6.647-6.647 6.647-.707-.707L11.293 12 4.647 5.353z",
                        fill: "#fff"
                    }
                })]), y._v(" "), v("div", {
                    class: y.$style.fpsMoreContentTitle
                }, [v("span", [y._v(y._s(y.translation.PDList_gameFPS))]), y._v(" "), v("span", [y._v(y._s(y.translation.PDList_fullHD))]), y._v(" "), v("span", [y._v(y._s(y.translation.PDList_quadHD))])]), y._v(" "), v("ul", {
                    class: y.$style.fpsMoreList
                }, y._l(y.resultItemData.games, (function(t, e) {
                    return v("li", {
                        key: e
                    }, [v("div", {
                        class: y.$style.name
                    }, [v("span", [y._v(y._s(t.name))]), y._v(" "), v("span", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.name.length > 19,
                            expression: "game.name.length > 19"
                        }],
                        class: y.$style.toolTip
                    }, [y._v(y._s(t.name))])]), y._v(" "), v("span", {
                        class: y.$style.value
                    }, [y._v(y._s(t.fhd) + y._s(y.translation.PDList_unit))]), y._v(" "), v("span", [y._v(y._s(t.qhd) + y._s(y.translation.PDList_unit))])])
                })), 0)])])] : y._e()], 2), y._v(" "), v("div", {
                    class: y.$style.tagLine
                }, [v("p", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.resultItemData.subTagLine,
                        expression: "resultItemData.subTagLine"
                    }]
                }, [y._v(y._s(y.resultItemData.subTagLine))])]), y._v(" "), v("div", {
                    class: y.$style.productItemWrapper,
                    style: "".concat(y.productItemWrapperHeight)
                }, [v("div", {
                    class: y.$style.productItemContent
                }, [v("div", {
                    class: [y.$style.productItemIntroduction, (_ = {}, Object(n.a)(_, y.$style.active, y.isSeeMore), Object(n.a)(_, y.$style.noSeeAllButton, !y.isShowSeeAllButton), _)]
                }, [v("div", {
                    ref: "resultItemWrapper"
                }, [1 === y.resultItemData.displayKeySpec ? v("div", {
                    class: y.$style.kspItems,
                    domProps: {
                        innerHTML: y._s(y.encodeHTML(y.resultItemData.ksp))
                    }
                }) : y._e(), y._v(" "), 0 === y.resultItemData.displayKeySpec ? [v("ul", {
                    class: y.$style.keySpecItems
                }, y._l(y.resultItemData.keySpec, (function(t, e) {
                    return v("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: y.checkString(t) && t && Object.keys(t).length > 0 && "" !== t.name,
                            expression: "checkString(spec)  && spec && Object.keys(spec).length > 0 && spec.name !== ''"
                        }],
                        key: e
                    }, [v("p", {
                        domProps: {
                            innerHTML: y._s(y.encodeHTML(t.name))
                        }
                    })])
                })), 0)] : y._e()], 2)]), y._v(" "), v("seeAllButton", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.isShowSeeAllButton,
                        expression: "isShowSeeAllButton"
                    }],
                    attrs: {
                        moreName: "".concat(y.isSeeMore ? y.translation.PDList_See_Less : y.translation.PDList_See_More),
                        horizontal: !0,
                        isProductCard: !0,
                        seeMoreActive: y.isSeeMore,
                        isShowSeeAllButton: y.isShowSeeAllButton
                    },
                    on: {
                        clickMore: y.showMoreHandler
                    }
                })], 1)]), y._v(" "), v("div", {
                    staticClass: "productContent"
                }, [v("div", {
                    ref: "content",
                    class: [(h = {}, Object(n.a)(h, y.$style.buyContent, "global" !== y.lang), Object(n.a)(h, y.$style.BuyPrice, y.isBuyStatus && y.isPrice), Object(n.a)(h, y.$style.wtbType, "wtb" === y.productBuyType && y.isWtbButtonLink), Object(n.a)(h, y.$style.modelType, y.modelBaseStatus && y.isBuyStatus), Object(n.a)(h, y.$style.customizeType, y.getECCustomize && y.getECCustomize.status), Object(n.a)(h, y.$style.noType, !(y.isBuyStatus && y.isPrice || "wtb" === y.productBuyType && y.isWtbButtonLink)), h)]
                }, [y.getECCustomize && y.getECCustomize.status ? [v("div", {
                    class: [y.$style.line]
                }), y._v(" "), v("div", {
                    class: [y.$style.productBuyButton, y.$style.marginTopAuto]
                }, [v("ButtonRed", {
                    attrs: {
                        buttonData: y.customizeButtonData,
                        isMaxWidth: !0,
                        isFilter: !0,
                        isStore: !0,
                        isECCustomize: !0,
                        isProductListButton: !0
                    },
                    on: {
                        gaTrigger: function(t) {
                            return y.goBuyLink(y.resultItemData)
                        }
                    }
                })], 1)] : y._e(), y._v(" "), "buy" === y.productBuyType && y.isPrice ? [v("div", {
                    class: y.$style.productItemPriceContent
                }, [v("div", {
                    class: [y.$style.line]
                }), y._v(" "), " " !== this.translation.eShop_Starting_at || " " !== this.translation.eShop_Price ? v("div", {
                    class: y.$style.productStartingAtWrapper
                }, [v("span", {
                    class: [y.$style.productStartingAt, Object(n.a)({}, "eShop", !(y.modelBaseStatus && 0 === y.getProductPrice.SingleSku || !y.modelBaseStatus && 0 === y.getProductPrice.SingleSku))]
                }, [y._v(y._s(y.modelBaseStatus && 0 === y.getProductPrice.SingleSku || !y.modelBaseStatus && 0 === y.getProductPrice.SingleSku ? this.translation.eShop_Starting_at : this.translation.eShop_Price))]), y._v(" "), v("div", {
                    staticClass: "tooltip",
                    class: [Object(n.a)({}, "active", y.isTooltipVisible)],
                    attrs: {
                        role: "button",
                        tabindex: "0",
                        "aria-describedby": "tooltip-".concat(y.productId)
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && y._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : y.openTooltipHandler.apply(null, arguments)
                        }
                    }
                }, [v("span", {
                    staticClass: "sr-only"
                }, [y._v("tooltip")]), y._v(" "), v("svg", {
                    attrs: {
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "info",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        d: "M0 6a6 6 0 116 6 6.007 6.007 0 01-6-6zm1.2 0a4.8 4.8 0 109.6 0 4.8 4.8 0 00-9.6 0zm4.2 3.6V4.8h1.2v4.8H5.4zm0-6V2.4h1.2v1.2H5.4z",
                        fill: "#666"
                    }
                })])]), y._v(" "), v("div", {
                    staticClass: "tooltipText",
                    class: [Object(n.a)({}, "active", y.isTooltipVisible)],
                    attrs: {
                        id: "tooltip-".concat(y.productId)
                    }
                }, [v("span", [y._v(y._s(this.translation.eShop_B_Model))])])]) : y._e(), y._v(" "), "" !== y.productPrice ? v("div", {
                    class: [y.$style.productHowMuch, (m = {}, Object(n.a)(m, y.$style.skuBase, !y.modelBaseStatus), Object(n.a)(m, y.$style.tw, "tw" === y.lang), m)]
                }, [v("span", {
                    class: [y.$style.finallyPriceValue, Object(n.a)({}, y.$style.tw, "tw" === y.lang)]
                }, [y._v(y._s(y.currencyHandler(y.productPrice)))]), y._v(" "), v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.openAmountOff && !y.priceCompareSpecialPrice(),
                        expression: "openAmountOff && !priceCompareSpecialPrice()"
                    }],
                    class: y.$style.originalPrice
                }, [v("span", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.isTranslateStringNumber,
                        expression: "isTranslateStringNumber"
                    }],
                    class: y.$style.savePriceValue
                }, [y._v(y._s(this.translation.eShop_Save) + " " + y._s(y.currencyHandler(y.amountOff)))]), y._v(" "), v("span", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: y.isTranslateStringNumber,
                        expression: "isTranslateStringNumber"
                    }],
                    class: y.$style.originalPriceValue
                }, [y._v(y._s(y.currencyHandler(y.regularPrice)))])]), y._v(" "), v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: 1 === y.mappingWebsite.priceReduction && "" !== y.amountOff,
                        expression: "mappingWebsite.priceReduction === 1 && amountOff !== ''"
                    }],
                    class: y.$style.lowPriceValue
                }, [y._v("\n              " + y._s(this.translation.eshop_price_reduction) + "\n              "), v("p", [y._v(y._s(null !== y.displayHistoricLowPrice && "" !== y.displayHistoricLowPrice || null !== y.historicLowPrice && "" !== y.historicLowPrice ? y.displayHistoricLowPrice : y.productPrice))])]), y._v(" "), v("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "" !== y.amountOff && "" !== y.groupLabelName && y.priceCompareSpecialPrice(),
                        expression: " amountOff !== '' && groupLabelName !== '' && priceCompareSpecialPrice()"
                    }],
                    class: y.$style.groupNameDisplayRuleValue
                }, [v("p", {
                    domProps: {
                        innerHTML: y._s(y.getDisplayPriceHandler(y.groupNameDisplayRule))
                    }
                })])]) : y._e()]), y._v(" "), "" !== y.productPrice && "" !== y.buttonName ? v("div", {
                    class: y.$style.productBuyButton
                }, [v("ButtonRed", {
                    attrs: {
                        buttonData: y.buyButtonData,
                        isMaxWidth: !0,
                        isFilter: !0,
                        isStore: !0,
                        isProductListButton: !0
                    },
                    on: {
                        gaTrigger: function(t) {
                            return y.goBuyLink(y.resultItemData)
                        }
                    }
                })], 1) : y._e()] : y._e(), y._v(" "), v("div", {
                    class: [y.$style.productBuyButton, y.$style.marginTopAuto, y.$style.productLearnMoreButton, Object(n.a)({}, y.$style.marginNoTopAuto, y.getECCustomize && y.getECCustomize.status)]
                }, [v("ButtonBorderRed", {
                    attrs: {
                        buttonData: y.learnMoreData,
                        isMaxWidth: !0,
                        isFilter: !0,
                        isLearnMore: !0,
                        otherName: y.resultItemData.mktName
                    },
                    on: {
                        click: y.goProductPage
                    }
                })], 1)], 2)]), y._v(" "), v("div", {
                    class: y.$style.line
                }), y._v(" "), v("div", {
                    class: y.$style.productCardBottom
                }, [v("div", {
                    class: y.$style.productCheckBox
                }, [v("label", {
                    staticClass: "checkBoxCompare",
                    class: [(f = {}, Object(n.a)(f, y.$style.isCheck, y.checked), Object(n.a)(f, y.$style.jpCheckBox, "jp" === y.lang), f)],
                    attrs: {
                        for: "checkbox-".concat(y.resultItemData.partNo || y.resultItemData.id)
                    }
                }, [y._v(y._s(y.translation.Compare_Compare) + "\n      ")]), y._v(" "), v("div", {
                    class: [y.$style.checkBoxIcon, Object(n.a)({}, y.$style.isCheck, y.checked)],
                    attrs: {
                        tabindex: "-1",
                        "aria-hidden": "false"
                    }
                }, [v("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "check",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        d: "M32 5.96l-5.23-4.25-15.38 18.93-6.67-5.77L0 19.71l12.24 10.58 2.79-3.43L32 5.96z"
                    }
                }), v("path", {
                    attrs: {
                        d: "M0 0h32v32H0z",
                        fill: "none"
                    }
                })])]), y._v(" "), v("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: y.checked,
                        expression: "checked"
                    }],
                    attrs: {
                        tabindex: "0",
                        type: "checkbox",
                        name: "productCheckBox",
                        "aria-hidden": "false",
                        "aria-label": "".concat(y.translation.Aria_Choose, " ").concat(y.resultItemData.mktName, " ").concat(y.resultItemData.name, " ").concat(y.translation.Aria_Compare_Checkbox),
                        id: "checkbox-".concat(y.resultItemData.partNo || y.resultItemData.id)
                    },
                    domProps: {
                        checked: Array.isArray(y.checked) ? y._i(y.checked, null) > -1 : y.checked
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && y._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : y.onTabCheckHandler(y.resultItemData.partNo || y.resultItemData.id)
                        },
                        change: [function(t) {
                            var e = y.checked,
                                o = t.target,
                                r = !!o.checked;
                            if (Array.isArray(e)) {
                                var n = y._i(e, null);
                                o.checked ? n < 0 && (y.checked = e.concat([null])) : n > -1 && (y.checked = e.slice(0, n).concat(e.slice(n + 1)))
                            } else y.checked = r
                        }, y.checkBoxHandler]
                    }
                })]), y._v(" "), y.isWtbButtonLink ? [v("a", {
                    class: y.$style.productWhereToBuyButton,
                    attrs: {
                        href: this.resultItemData.wtbLink
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), y.goWTBLink(y.resultItemData)
                        }
                    }
                }, [v("svg", {
                    attrs: {
                        width: "25",
                        height: "24",
                        viewBox: "0 0 25 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "landmark",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [v("path", {
                    attrs: {
                        d: "M19.03 13.817a7.941 7.941 0 00-1.23-9.51 7.736 7.736 0 00-11.022 0 7.94 7.94 0 00-1.23 9.51L12.288 22l6.741-8.182z",
                        stroke: "#181818",
                        "stroke-width": "1.5",
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round"
                    }
                }), v("path", {
                    attrs: {
                        d: "M12.201 12.706a3.146 3.146 0 100-6.292 3.146 3.146 0 000 6.292z",
                        stroke: "#181818",
                        "stroke-width": "1.5",
                        "stroke-linecap": "round",
                        "stroke-linejoin": "round"
                    }
                })]), y._v(" "), v("span", [y._v(y._s(y.translation.WTB_Where_to_Buy))])])] : y._e()], 2)], 1) : y._e()
            }), [], !1, (function(t) {
                this.$style = D.default.locals || D.default
            }), null, null);
            e.a = component.exports
        },
        948: function(t, e, o) {
            "use strict";
            var r, n = o(2),
                c = (o(20), o(9)),
                l = (o(54), o(41), o(10), o(28), o(59), o(3)),
                d = o(7),
                _ = o(4),
                h = (r = function(t, b) {
                    return r = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, r(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    r(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, o, desc) {
                    var r, n = arguments.length,
                        l = n < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(r = t[i]) && (l = (n < 3 ? r(l) : n > 3 ? r(e, o, l) : r(e, o)) || l);
                    return n > 3 && l && Object.defineProperty(e, o, l), l
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isShow = !1, e.productType = "", e.panelDOM = null, e.isScrolled = !1, e.lastPosition = 0, e.showItemsNumber = 3, e.moveTime = 0, e.touchStartX = 0, e.touchStartY = 0, e.touchEndX = 0, e.touchEndY = 0, e.currentPage = 0, e.isRatingShow = !1, e.topValue = 0, e
                    }
                    return h(e, t), e.prototype.watchScrollValue = function(t, e) {
                        t && (this.panelDOM.scrollLeft = t)
                    }, e.prototype.watchSpecMoveTime = function(t, e) {
                        this.moveTime = t, this.goToItems(t)
                    }, Object.defineProperty(e.prototype, "pageCount", {
                        get: function() {
                            return this.specObjects ? Math.ceil(this.specObjects.length / this.showItemsNumber) : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "cookieBannerHeight", {
                        get: function() {
                            return "undefined" != typeof window && "Yes" !== Object(_.b)("isReadCookiePolicyDNT") && document.getElementById("cookie-policy-info") && window.innerWidth > 1024 ? document.getElementById("cookie-policy-info").offsetHeight : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "localSwitcherHeight", {
                        get: function() {
                            var t = JSON.parse(localStorage.getItem("reminderClose".concat(this.mappingWebsiteId)));
                            return "undefined" != typeof window && !t && document.getElementById("localChange") && window.innerWidth > 1024 ? document.getElementById("localChange").offsetHeight : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "dirType", {
                        get: function() {
                            var t, e, o, r;
                            if (this.$route && (null === (t = this.$route.params) || void 0 === t ? void 0 : t.area)) switch (null === (e = this.$route.params) || void 0 === e ? void 0 : e.area.toLowerCase()) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return "rtl";
                                default:
                                    return "ltr"
                            } else if (this.$route && this.$route.fullPath) {
                                switch (null === (r = null === (o = this.$route) || void 0 === o ? void 0 : o.fullPath) || void 0 === r ? void 0 : r.split("/")[1].toLowerCase()) {
                                    case "il":
                                    case "me-ar":
                                    case "sa-ar":
                                    case "eg":
                                    case "nafr-ar":
                                        return "rtl";
                                    default:
                                        return "ltr"
                                }
                            }
                            return "ltr"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.mounted = function() {
                        var t = this;
                        this.panelDOM = document.querySelector(".compareTopPanel"), window.addEventListener("scroll", (function() {
                            window.pageYOffset > t.cookieBannerHeight + t.localSwitcherHeight ? (t.isShow = !0, t.isScrolled = !0) : t.isShow = !1, t.lastPosition > window.scrollY && (t.isScrolled = !1), t.lastPosition = window.scrollY
                        }));
                        var e = this,
                            o = setInterval((function() {
                                var t = document.getElementById("ratingText");
                                t && t.innerText && -1 === t.innerText.indexOf("(0)") && (e.isRatingShow = !0, window.clearInterval(o))
                            }), 1e3);
                        window.innerWidth <= 768 ? this.showItemsNumber = 2 : this.showItemsNumber = 3;
                        var r = setInterval((function() {
                            t.topValue = document.querySelector("#productTabBarContainer").clientHeight - 1
                        }), 500);
                        setTimeout((function() {
                            clearInterval(r)
                        }), 5e3), window.addEventListener("resize", (function() {
                            t.topValue = document.querySelector("#productTabBarContainer").clientHeight - 1, window.innerWidth <= 768 ? t.showItemsNumber = 2 : t.showItemsNumber = 3
                        }))
                    }, e.prototype.touchStart = function(t) {
                        window.innerWidth <= 1024 && (this.touchStartX = t.touches[0].clientX, this.touchStartY = t.touches[0].clientY)
                    }, e.prototype.touchEnd = function(t) {
                        if (window.innerWidth <= 1024) {
                            this.touchEndX = t.changedTouches[0].clientX, this.touchEndY = t.changedTouches[0].clientY;
                            var e = this.touchStartX - this.touchEndX,
                                o = this.touchStartY - this.touchEndY;
                            if (Math.abs(o) > Math.abs(e)) return;
                            if (e > 10) {
                                var r = (this.currentPage + 1) % this.pageCount;
                                this.goToItems(r), this.$emit("goToItems", this.currentPage)
                            } else if (e < -10) {
                                r = (this.currentPage - 1 + this.pageCount) % this.pageCount;
                                this.goToItems(r), this.$emit("goToItems", this.currentPage)
                            }
                        }
                    }, e.prototype.goToItems = function(t) {
                        this.moveTime = t;
                        var e = document.querySelector(".specContent");
                        if (e) {
                            var o = 390;
                            o = window.innerWidth > 1024 ? window.innerWidth - 40 : window.innerWidth <= 1024 && window.innerWidth > 768 ? (window.innerWidth - 32 - 40) / 3 + 20 : (this.specObjects.length, 2 * ((window.innerWidth - 32 - 20) / 2 + 20)), 0 === t ? ("ltr" === this.dirType ? e.scrollTo({
                                left: -10,
                                behavior: "smooth"
                            }) : e.scrollTo({
                                left: 10,
                                behavior: "smooth"
                            }), this.currentPage = t, this.$emit("goToItems", this.currentPage)) : (this.specObjects.length % 2 == 1 && t === Math.floor(this.specObjects.length / 2) ? "ltr" === this.dirType ? e.scrollTo({
                                left: this.moveTime * o - o / 2,
                                behavior: "smooth"
                            }) : e.scrollTo({
                                left: -1 * (this.moveTime * o - o / 2),
                                behavior: "smooth"
                            }) : "ltr" === this.dirType ? e.scrollTo({
                                left: this.moveTime * o,
                                behavior: "smooth"
                            }) : e.scrollTo({
                                left: this.moveTime * o * -1,
                                behavior: "smooth"
                            }), this.currentPage = t, this.$emit("goToItems", this.currentPage))
                        }
                    }, e.prototype.noPriceStatus = function(t) {
                        return !(Object.keys(t).length > 0) && !(t.price > 0)
                    }, m([Object(d.Getter)("modelPrice")], e.prototype, "modelPrice", void 0), m([Object(d.Getter)("websiteId")], e.prototype, "websiteId", void 0), m([Object(d.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), m([Object(d.Getter)("info")], e.prototype, "productInfo", void 0), m([Object(l.Prop)()], e.prototype, "itemMaxWidth", void 0), m([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "contentWidth", void 0), m([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "scrollValue", void 0), m([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "delta", void 0), m([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "specMoveTime", void 0), m([Object(l.Prop)({
                        default: []
                    })], e.prototype, "specObjects", void 0), m([Object(l.Watch)("scrollValue")], e.prototype, "watchScrollValue", null), m([Object(l.Watch)("specMoveTime")], e.prototype, "watchSpecMoveTime", null), e = m([l.Component], e)
                }(l.Vue),
                y = f,
                v = o(1094),
                P = o(25);
            var component = Object(P.a)(y, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return e.specObjects.length > 0 ? o("div", {
                    class: [e.$style.compareTopContainer, (t = {}, Object(n.a)(t, e.$style.slideDown, e.isShow), Object(n.a)(t, e.$style.noPrice, e.noPriceStatus(e.modelPrice)), Object(n.a)(t, e.$style.showPrice, !e.noPriceStatus(e.modelPrice)), Object(n.a)(t, e.$style.showPriceRatting, !e.noPriceStatus(e.modelPrice) && this.isRatingShow), Object(n.a)(t, e.$style.showPriceAmountOff, !e.noPriceStatus(e.modelPrice) && "" !== e.modelPrice.amountOff), Object(n.a)(t, e.$style.showLowPrice, !e.noPriceStatus(e.modelPrice) && "" !== e.modelPrice.historicLowPrice), Object(n.a)(t, e.$style.lessProduct, e.specObjects.length <= 2), t)],
                    style: {
                        top: e.isShow ? "".concat(e.topValue, "px") : "0"
                    }
                }, [o("div", {
                    staticClass: "compareTopPanel",
                    class: [e.$style.compareTopContainerScroll, e.$style.compareTopWrapper],
                    on: {
                        touchstart: e.touchStart,
                        touchend: e.touchEnd
                    }
                }, [o("ul", {
                    style: "width:".concat(e.contentWidth, "px;transform: translateX(").concat(e.delta, "px);"),
                    attrs: {
                        role: "list"
                    }
                }, e._l(e.specObjects, (function(t, r) {
                    return o("li", {
                        key: r,
                        class: Object(n.a)({}, e.$style.compareTopSingleItem, 1 === e.specObjects.length),
                        attrs: {
                            role: "listitem",
                            tabindex: "0"
                        }
                    }, [o("span", [e._v(e._s(t.skuName || t.mktName))])])
                })), 0), e._v(" "), o("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.pageCount > 1,
                        expression: "pageCount > 1"
                    }],
                    class: [e.$style.rowShowDiff, e.$style.mobile, Object(n.a)({}, e.$style.rtl, "rtl" === e.dirType)]
                }, [o("div", {
                    class: e.$style.paginationWrapper
                }, [o("div", {
                    class: e.$style.pagination
                }, e._l(e.pageCount, (function(t, r) {
                    return o("button", {
                        key: r,
                        class: [e.$style.pageBullets, Object(n.a)({}, e.$style.active, r === e.moveTime)],
                        attrs: {
                            "aria-label": "click item ".concat(r),
                            type: "button"
                        },
                        on: {
                            click: function(t) {
                                return e.goToItems(r)
                            }
                        }
                    })
                })), 0)])])])]) : e._e()
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        964: function(t, e, o) {
            "use strict";
            var r = o(700),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        },
        996: function(t, e, o) {
            "use strict";
            var r = o(732),
                n = o.n(r);
            o.d(e, "default", (function() {
                return n.a
            }))
        }
    }
]);