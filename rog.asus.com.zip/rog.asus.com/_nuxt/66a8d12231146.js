(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [10], {
        1: function(e, t, r) {
            "use strict";
            r(10), r(43), r(46), r(52), r(37), r(38), r(47), r(70), r(18), r(29), r(20);
            var n, o, c, d = r(6),
                l = r.n(d),
                h = r(478),
                m = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, c) {
                        function d(e) {
                            try {
                                h(n.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(n.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((n = n.apply(e, t || [])).next())
                    }))
                },
                f = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & c[0] ? r.return : c[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, c[1])).done) return n;
                                    switch (r = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                o.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && o.label < n[1]) {
                                                o.label = n[1], n = c;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(c);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, o)
                                } catch (e) {
                                    c = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                },
                _ = "stage-nomos.asus.com",
                v = "cdnta.asus.com",
                P = !!(null === (n = "api-rog.asus.com") ? void 0 : n.includes(".cn")),
                w = "api-rog.asus.com",
                y = "rog.asus.com",
                I = "odinapi.asus.com";
            c = Object(h.a)(w);
            try {
                if (-1 !== w.indexOf("dev-api-rog.asus.com") ? (v = "dev-cdnta.asus.com", _ = "dev-nomos.asus.com", I = "dev-asgardapi.asus.com") : -1 !== w.indexOf("stage-api-rog.asus.com") && (v = "stage-cdnta.asus.com", _ = "stage-nomos.asus.com", I = "stage-asgardapi.asus.com"), P) {
                    if (P) {
                        var C = -1 !== window.location.origin.indexOf("rog.asus.com.cn");
                        y = C ? "rog.asus.com.cn" : "rog-bacchus.asus.com", _ = C ? "nomos.asus.com.cn" : _, v = C ? "cdnta.asus.com.cn" : v
                    }
                } else {
                    var T = "api-rog.asus.com" === w;
                    y = T ? "rog.asus.com" : "rog-bacchus.asus.com", T ? "estore.asus.com" : "estorestage.asus.com", _ = T ? "nomos.asus.com" : _, v = T ? "cdnta.asus.com" : v
                }
            } catch (e) {}
            var S = function(e, t) {
                return void 0 === t && (t = {}), Promise.reject(e)
            };
            t.a = {
                getRouteInfo: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Route?WebURL=").concat(param.url),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getRouteRedirect: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/RouteRedirect?WebURL=").concat(param.url),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getCanonical: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e, t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), e = "", e = "" === param.itemId ? "?WebURL=".concat(param.url) : "?WebURL=".concat(param.url, "&ItemId=").concat(param.itemId), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v1/Canonical").concat(e)
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWebsiteID: function() {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Website"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getHeader: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Header"),
                                        params: e,
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getBanners: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Common/Banners"),
                                        params: e,
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getFooter: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Footer?WebsiteCode=").concat(e.WebsiteCode),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getTranslation: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Translation"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getRegion: function() {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Common/Region"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getTermCategory: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Terms/Category"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: param.params
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getTerms: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Terms/Content"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: param
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                rogProductArticle: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Common/ArticleTag?LevelTagId=").concat(param.LevelTagId),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                rogProductDisclaimer: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Disclaimer?Url=").concat(e.Url),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                rogHomeDisclaimer: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Common/Disclaimer/homepage?WebsiteCode=").concat(e.WebsiteCode),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getProductLine: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/ProductLine"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSection: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/Section"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getRogStory: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/RogStory"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getPLVideo: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/PLVideo"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getFilters: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v8/Filters"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getFiltersResults: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v8/Filters"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getFiltersResultsClient: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t, r;
                        return f(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    o && o.cancel && o.cancel("User navigated to different filter"), t = l.a.CancelToken, o = t.source(), n.label = 1;
                                case 1:
                                    return n.trys.push([1, 3, , 4]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v8/Filters"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e,
                                        cancelToken: o.token
                                    })];
                                case 2:
                                    return [2, n.sent()];
                                case 3:
                                    return r = n.sent(), S(r, "error message"), [3, 4];
                                case 4:
                                    return [2]
                            }
                        }))
                    }))
                },
                filterResultsAPINoToken: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v8/Filters"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                filterSEO: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v1/Filters/SEO"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                ctoPromotionBar: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/PromotionBar"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                levelHotProduct: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Template/HotProducts"),
                                        params: {
                                            WebsiteCode: e.WebsiteCode,
                                            LevelTagId: e.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                templateLevel: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Template/Level"),
                                        params: {
                                            WebsiteCode: e.WebsiteCode,
                                            LevelTagId: e.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSpotLight: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Template/SpotLight"),
                                        params: {
                                            WebsiteCode: e.WebsiteCode,
                                            LevelTagId: e.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                levelRelatedProduct: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/RelatedProduct"),
                                        params: {
                                            WebsiteCode: e.WebsiteCode,
                                            LevelTagId: e.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, "error message"), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                popUpAds: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Level/PopUPAds"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: {
                                            WebsiteCode: e.WebsiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                accountStatus: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "post",
                                        url: "https://".concat(w, "/recent-data/api/v4/Account/Status"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        data: {
                                            websiteCode: param.websiteCode,
                                            aticket: param.aticket
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                accountLinkMenu: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Account/Menu"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: {
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductInfo: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return param.Authorization && "" !== param.Authorization && "api-rogmars.asus.com" === w ? (e = {
                                        m1Id: param.m1Id,
                                        WebsiteCode: param.WebsiteCode
                                    }, param.DataId && (e.DataId = param.DataId, e.DataRowId = param.DataRowId), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Info"),
                                        params: e,
                                        headers: {
                                            Authorization: param.Authorization
                                        }
                                    })]) : [3, 2];
                                case 1:
                                case 3:
                                    return [2, t.sent()];
                                case 2:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Info"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })]
                            }
                        }))
                    }))
                },
                getProductTabs: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Tabs"),
                                        params: param
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getGallery: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Gallery"),
                                        params: param
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getSpec: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return param.Authorization && "" !== param.Authorization && "api-rogmars.asus.com" === w ? [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Product/Spec"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        },
                                        headers: {
                                            Authorization: param.Authorization
                                        }
                                    })] : [3, 2];
                                case 1:
                                case 3:
                                    return [2, e.sent()];
                                case 2:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Product/Spec"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })]
                            }
                        }))
                    }))
                },
                getModelSpec: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return param.Authorization && "" !== param.Authorization && "api-rogmars.asus.com" === w ? [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Product/ModelSpec"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        },
                                        headers: {
                                            Authorization: param.Authorization
                                        }
                                    })] : [3, 2];
                                case 1:
                                case 3:
                                    return [2, e.sent()];
                                case 2:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v5/Product/ModelSpec"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })]
                            }
                        }))
                    }))
                },
                getSingleSpec: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Common/Spec"),
                                        params: {
                                            WebsiteCode: param.WebsiteCode,
                                            PartNo: param.PartNo
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductWTB: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/WTB"),
                                        params: {
                                            WebsiteCode: param.WebsiteCode,
                                            PartNo: param.PartNo
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductAward: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Award"),
                                        params: {
                                            PageSize: param.PageSize,
                                            Page: param.Page,
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getRecommendedPostType: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "post",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Recommend"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        data: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode,
                                            aticket: param.aticket,
                                            clientid: param.clientid
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getRecommended: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Product/Recommend"),
                                        params: {
                                            m1Id: param.m1Id,
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                contentTemplate: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Content"),
                                        params: e
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportHeaderWording: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return origin = "https://www.asus.com", origin = "9" === param.WebsiteId ? origin + ".cn" : origin, [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/OfficialSiteAPI.asmx/GetWording"),
                                        params: {
                                            WebsiteId: param.WebsiteId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportContentWording: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/Common/GetWording"),
                                        params: {
                                            website: param.WebSitePath,
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportRegisterPd: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/CheckRegisterByPD"),
                                        params: {
                                            website: param.WebSitePath,
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            aticket: param.Aticket ? param.Aticket : "",
                                            model: param.ModelName ? param.ModelName : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportTabs: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDSupportTab"),
                                        params: {
                                            website: param.WebSitePath,
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            model: param.ModelName ? param.ModelName : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportNeedHelp: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/service/GetNeedHelp"),
                                        params: {
                                            website: param.WebSitePath,
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportCPU: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDCPUList"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportCPUQVL: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLCPU"),
                                        params: param
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportCPUCol: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLCPUCOL"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: param
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getProductSupportCPUGroupList: function(param) {
                    return m(this, void 0, Promise, (function() {
                        var e;
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLCPUGroupList"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: param
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return e = t.sent(), S(e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getProductSupportQVL: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDQVL"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportFAQ: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDFaq"),
                                        params: {
                                            website: param.WebSitePath,
                                            typeId: param.TypeId,
                                            categoryId: param.CategoryId,
                                            keyword: param.Keyword,
                                            pdlevelId: param.LevelTagId,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            pagesize: "10",
                                            pageNumber: param.PageNumber,
                                            sort: "latest",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportManual: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDManual"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId,
                                            country: param.Country,
                                            region: param.Region
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportDeclaration: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDDeclaration"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportEMI: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDEMI"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportServiceGuide: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDGuide"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdhashedid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId,
                                            region: "",
                                            country: param.WebSitePath
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportCPUName: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDCPUName"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportOS: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDOS"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            cpu: param.cpu ? param.cpu : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportDriver: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDDrivers"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            cpu: param.cpu ? param.cpu : "",
                                            osid: param.osid ? param.osid : "",
                                            active: param.active ? param.active : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportBIOS: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/ProductV2/GetPDBIOS"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            cpu: param.cpu ? param.cpu : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportMechanical: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/productv2/GetPDMechanical"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.routePath), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getProductSupportWarranty: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDWarranty"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportService: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetMoreService"),
                                        params: {
                                            systemCode: "rog",
                                            websiteCode: param.WebSitePath,
                                            typeId: 1
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportMemory: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLMemory"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            PageSize: param.PageSize ? param.PageSize : "20",
                                            PageIndex: param.PageIndex ? param.PageIndex : "1",
                                            Vendors: param.Vendors ? param.Vendors : "",
                                            Size: param.Size ? param.Size : "",
                                            RAMSpeed: param.RAMSpeed ? param.RAMSpeed : "",
                                            DIMM: param.DIMM ? param.DIMM : "",
                                            ECCDIMM: param.ECCDIMM ? param.ECCDIMM : "",
                                            keyword: param.keyword ? param.keyword : "",
                                            XMPEXPO: param.XMPEXPO ? param.XMPEXPO : "",
                                            CPUSeries: param.CPUSeries ? param.CPUSeries : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportMemoryCol: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLMemoryCOL"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportMemoryGroupList: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLMemoryGroupList"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportDevice: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLDevice"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            PageSize: param.PageSize ? param.PageSize : "20",
                                            PageIndex: param.PageIndex ? param.PageIndex : "1",
                                            keyword: param.keyword ? param.keyword : "",
                                            Series: param.Series ? param.Series : "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportDeviceCol: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLDeviceCOL"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportDeviceGroupList: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetPDQVLDeviceGroupList"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : "",
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            mode: "",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportGetSupportURL: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/Service/GetSupportURL"),
                                        params: {
                                            website: param.WebSitePath,
                                            pdid: param.ProductId ? param.ProductId : "0",
                                            m1id: param.M1Id ? param.M1Id : "0",
                                            LevelTagId: param.LevelTagId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getProductSupportCheckModelExists: function(param) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/CheckModelExists"),
                                        params: {
                                            website: param.WebSitePath,
                                            model: param.ModelName ? param.ModelName : ""
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                rogGeo: function() {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://rog.asus.com/geo",
                                        data: {},
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                rogCNGeo: function() {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, c({
                                        method: "get",
                                        url: "https://geo.asus.com/rogcngeo/",
                                        data: {},
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getWallpaperFolderList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Wallpaper/FolderList"),
                                        params: e.params,
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWallpaperPhotoList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Wallpaper/PhotoList"),
                                        params: e.params,
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWallpaperDownload: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(w, "/api/nc/v4/NoCache/wallpaper/download/").concat(e.wId),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                postWallpaperDownloadTimes: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(w, "/api/nc/v3/NoCache/Wallpapers/Download/").concat(e.id),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWallpaperHome: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/wallpaper/home"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWallpaperFilterList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/wallpaper/Filter"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getWallpaperFilterSEO: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/wallpaper/Filter/seo"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticleList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Article/List"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticleContent: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v3/Article/Content"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticleHomeContent: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Article/Home"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticlePopularList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v1/Article/PopularList"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticleRecommend: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v1/Article/Recommend"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getArticleCategoryList: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(w, "/recent-data/api/v4/Article/CategoryList"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                postStar: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(w, "/api/nc/v3/NoCache/Wallpapers/Star"),
                                        data: e.params,
                                        headers: {
                                            "Content-Type": "application/json"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getAiAssistantToken: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "".concat(e.baseUrl, "/api/v1/authorization"),
                                        data: e.params,
                                        headers: {
                                            "X-Request-ID": "chatbot",
                                            "Content-Type": "application/json"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getAiAssistantStatus: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "".concat(e.baseUrl, "/api/v0/regions/").concat(e.websiteCode, "/aiAssistant/").concat(e.systemId),
                                        headers: {
                                            "X-Request-ID": "chatbot"
                                        },
                                        data: {
                                            websiteCode: e.websiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e.frontendUse), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSystemInfo: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/MachineStatus/GetSystemInfo"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getOneClickDiagnosis: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(y, "/support/webapi/product/GetOneclickDiagnosisInfo"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getServiceStatus: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/MachineStatus/GetServiceStatus"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSystemStatus: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/MachineStatus/GetSystemStatus"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getStartScan: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Update/StartScan"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: {
                                            expires: e.expires,
                                            signature: e.signature,
                                            version: e.version
                                        },
                                        data: {
                                            website: e.website,
                                            domain: e.domain
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getScanResult: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Update/GetScanResult"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getStartInstall: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Update/StartInstall"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: {
                                            expires: e.expires,
                                            signature: e.signature,
                                            version: e.version
                                        },
                                        data: {
                                            InstallItems: e.InstallItems
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getInstallResult: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Update/GetInstallResult"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getStartReboot: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Update/StartReboot"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t, e), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getScenarios: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "POST",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Diagnosis/Inspect"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        params: {
                                            expires: e.expires,
                                            signature: e.signature,
                                            version: e.version
                                        },
                                        data: {
                                            Method: e.action
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getStopTest: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Diagnosis/Inspect"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        data: e.data,
                                        params: e.params
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getStartTest: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "POST",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Diagnosis/Inspect"),
                                        headers: {
                                            "Content-Type": "application/json; charset=utf-8"
                                        },
                                        params: {
                                            expires: e.expires,
                                            signature: e.signature,
                                            version: e.version
                                        },
                                        data: {
                                            Method: "StartTest",
                                            Scenario: e.scenario,
                                            TestItems: e.testItems,
                                            website: e.websiteCode,
                                            domain: "cn" === e.websiteCode ? "CN" : "Global"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                GetTestResult: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "POST",
                                        url: "http://127.0.0.1:".concat(e.apiPort, "/web/Diagnosis/Inspect"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        params: {
                                            expires: e.expires,
                                            signature: e.signature,
                                            version: e.version
                                        },
                                        data: {
                                            Method: "GetTestResult"
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSupportToken: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return e.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(_, "/api/v1/Token/Get"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: {
                                            api_key: "S2uAp1p8ort"
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()];
                                case 2:
                                    return e.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSupportCDNHQToken: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(v, "/api/v1/TokenHQ"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        params: e.params
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getSupportCDNCNToken: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "post",
                                        url: "https://".concat(v, "/api/v1/Token"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        params: e.params
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getRSA: function(e) {
                    return m(this, void 0, Promise, (function() {
                        return f(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return t.trys.push([0, 2, , 3]), [4, c({
                                        method: "POST",
                                        url: "https://".concat(y, "/support/webapi/service/sign"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        data: JSON.stringify(e.data)
                                    })];
                                case 1:
                                    return [2, t.sent()];
                                case 2:
                                    return t.sent(), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                },
                getMiniCartInfo: function(e) {
                    return m(this, void 0, Promise, (function() {
                        var t;
                        return f(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return r.trys.push([0, 2, , 3]), [4, c({
                                        method: "get",
                                        url: "https://".concat(I, "/recent-data/apiv2/WebsiteInfo"),
                                        headers: {
                                            "Content-Type": "text/plain"
                                        },
                                        params: e
                                    })];
                                case 1:
                                    return [2, r.sent()];
                                case 2:
                                    return t = r.sent(), S(t), [3, 3];
                                case 3:
                                    return [2]
                            }
                        }))
                    }))
                }
            }
        },
        204: function(module, __webpack_exports__, __webpack_require__) {
            "use strict";
            var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10),
                core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__),
                core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43),
                core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_1__),
                core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46),
                core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_2__),
                core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52),
                core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__),
                core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(37),
                core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = __webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__),
                core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38),
                core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = __webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__),
                core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(47),
                core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6___default = __webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__),
                core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(70),
                core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7___default = __webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7__),
                axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6),
                axios__WEBPACK_IMPORTED_MODULE_8___default = __webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_8__),
                https__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(118),
                https__WEBPACK_IMPORTED_MODULE_9___default = __webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_9__),
                __awaiter = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, c) {
                        function d(e) {
                            try {
                                h(n.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(n.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((n = n.apply(e, t || [])).next())
                    }))
                },
                __generator = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & c[0] ? r.return : c[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, c[1])).done) return n;
                                    switch (r = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                o.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && o.label < n[1]) {
                                                o.label = n[1], n = c;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(c);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, o)
                                } catch (e) {
                                    c = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                },
                _a, isCN = !!(null === (_a = "api-rog.asus.com") || void 0 === _a ? void 0 : _a.includes(".cn")),
                baseUrl = "api-rog.asus.com",
                baseECUrl = "estorestage.asus.com",
                axiosInstance = axios__WEBPACK_IMPORTED_MODULE_8___default.a.create({
                    httpsAgent: new https__WEBPACK_IMPORTED_MODULE_9___default.a.Agent({
                        rejectUnauthorized: !1,
                        keepAlive: !0,
                        maxSockets: 200
                    }),
                    timeout: 15e3
                });
            axiosInstance.interceptors.response.use((function(res) {
                try {
                    if ("undefined" != typeof window && "stage-api-rog.asus.com" !== baseUrl && "stage-api-rog.asus.com.cn" !== baseUrl && "api-rog.asus.com " !== baseUrl && "api-rog.asus.com.cn" !== baseUrl) {
                        var NDATA = eval('window["__NUXT__"].state.Config');
                        NDATA.APIList += "," + res.request.responseURL
                    }
                } catch (e) {}
                return res
            })), __webpack_exports__.a = {
                getModelPrice: function(param) {
                    return __awaiter(this, void 0, Promise, (function() {
                        return __generator(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, axiosInstance({
                                        method: "get",
                                        url: "https://".concat(baseUrl, "/api/nc/v1/NoCache/Model1Price"),
                                        params: {
                                            WebsiteCode: param.WebsiteCode,
                                            M1Id: param.M1Id,
                                            GroupId: param.GroupId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getModelOneListPrice: function(param) {
                    return __awaiter(this, void 0, Promise, (function() {
                        return __generator(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, axiosInstance({
                                        method: "post",
                                        url: "https://".concat(baseUrl, "/api/nc/v1/NoCache/Model1Price"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        data: {
                                            websiteCode: param.WebsiteCode,
                                            m1Id: param.M1Id,
                                            simplePrice: param.SimplePrice,
                                            groupId: param.GroupId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getModelListPrice: function(param) {
                    return __awaiter(this, void 0, Promise, (function() {
                        return __generator(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, axiosInstance({
                                        method: "post",
                                        url: "https://".concat(baseUrl, "/api/nc/v4/NoCache/ModelListPrice"),
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        data: {
                                            websiteCode: param.WebsiteCode,
                                            productId: param.ProductId,
                                            simplePrice: param.SimplePrice,
                                            groupId: param.GroupId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getSkuPrice: function(param) {
                    return __awaiter(this, void 0, Promise, (function() {
                        return __generator(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, axiosInstance({
                                        method: "get",
                                        url: "https://".concat(baseUrl, "/api/nc/v4/NoCache/SkuPrice"),
                                        params: {
                                            WebsiteCode: param.WebsiteCode,
                                            SkuWebPathName: param.SkuWebPathName,
                                            SimplePrice: param.SimplePrice,
                                            GroupId: param.GroupId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                postSkuPrice: function(param) {
                    return __awaiter(this, void 0, Promise, (function() {
                        return __generator(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, axiosInstance({
                                        method: "post",
                                        url: "https://".concat(baseUrl, "/api/nc/v4/NoCache/SkuPrice"),
                                        data: {
                                            websiteCode: param.WebsiteCode,
                                            skuWebPathName: param.SkuWebPathName,
                                            simplePrice: param.SimplePrice,
                                            groupId: param.GroupId
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                }
            }
        },
        484: function(e, t, r) {
            "use strict";
            r(10), r(43), r(46), r(52), r(37), r(38), r(20);
            var n = r(6),
                o = r.n(n),
                c = r(485),
                d = r(36),
                l = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, c) {
                        function d(e) {
                            try {
                                h(n.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(n.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((n = n.apply(e, t || [])).next())
                    }))
                },
                h = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & c[0] ? r.return : c[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, c[1])).done) return n;
                                    switch (r = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                o.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && o.label < n[1]) {
                                                o.label = n[1], n = c;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(c);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, o)
                                } catch (e) {
                                    c = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                };
            t.a = {
                rogGeo: function() {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "https://rog.asus.com/geo"
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                checkGeo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v1/GeoCheck"),
                                        params: {
                                            ISOCode: param.ISOCode,
                                            Url: param.Url
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getWebsiteInfo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/route/info?weburl=").concat(param.weburl)
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                postToken: function() {
                    return l(this, void 0, Promise, (function() {
                        var e, t;
                        return h(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return e = "", t = Object(c.a)(), e = Object(d.c)() ? "https://nomos.asus.com/api/v1/Token/Get" : "https://sowoverload.asus.com/APIToken/api/v1/Token/Get", [4, o()({
                                        method: "post",
                                        url: e,
                                        params: {
                                            api_key: t
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                usersProfile: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/elite/api/v1/users/Users_Profile"),
                                        params: {
                                            WebSiteCode: param.WebSiteCode,
                                            aticket: param.aticket
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getEliteBanner: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/Banner"),
                                        params: {
                                            WebSiteCode: param.WebSiteCode,
                                            BannerType: param.BannerType
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getTranslation: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/Translation"),
                                        params: {
                                            WebsiteId: param.WebsiteId,
                                            PageTypeId: param.PageTypeId,
                                            Str_key: ""
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                RedirectCheck: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v1/RedirectCheck"),
                                        params: {
                                            aticket: param.aticket,
                                            url: param.url
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getHeaderFooter: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/HeaderFooter"),
                                        params: {
                                            WebsiteCode: param.WebsiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getGuideInfo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/GuideInfo"),
                                        params: {
                                            WebsiteCode: param.websiteCode,
                                            Type: param.type
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getSystemList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/SystemList"),
                                        params: {
                                            WebSiteCode: param.WebSiteCode,
                                            Type: param.Type
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getFaqList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v1/FaqList"),
                                        params: {
                                            WebsiteId: param.WebsiteId,
                                            SearchKey: param.SearchKey
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getTierList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/cth/TierList"),
                                        params: {
                                            WebsiteId: param.WebsiteId
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getWidget: function(e, t) {
                    return new Promise((function(r, n) {
                        o.a.get("".concat(e, "/elite/api/cth/Widgets"), {
                            params: t
                        }).then((function(e) {
                            r(e.data)
                        })).catch((function(e) {
                            n(e)
                        }))
                    }))
                },
                getActivityList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/ActivityList"),
                                        params: {
                                            aticket: param.aticket,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getRewardList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/RewardList"),
                                        params: {
                                            aticket: param.aticket,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getUserProfile: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/elite/api/v2/users/UserProfile"),
                                        params: {
                                            aticket: param.aticket,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getV2TierList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/cth/TierList"),
                                        params: {
                                            WebsiteCode: param.WebSiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getNewGuideInfo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/GuideInfo"),
                                        params: {
                                            WebsiteCode: param.WebSiteCode,
                                            Type: param.type
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getRegisterPointCheck: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/RegisterPointCheck"),
                                        params: {
                                            DisplayName: param.DisplayName
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getActivityInfo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/ActivityInfo"),
                                        params: {
                                            aticket: param.aticket,
                                            activityId: param.activityId,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getRewardInfo: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/RewardInfo"),
                                        params: {
                                            aticket: param.aticket,
                                            rewardId: param.rewardId,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getActivityUpdate: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/elite/api/v2/ActivityUpdate"),
                                        data: {
                                            qRecordItemObj: param.qRecordItemObj,
                                            codes: param.codes,
                                            aticket: param.aticket,
                                            activityId: param.activityId,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getRewardUpdate: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/elite/api/v2/RewardUpdate"),
                                        data: {
                                            aticket: param.aticket,
                                            rewardId: param.rewardId,
                                            quantity: param.quantity,
                                            physicalItemObj: param.physicalItemObj,
                                            personalObj: param.personalObj,
                                            terms: param.terms,
                                            WebsiteCode: param.WebSiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getTranslateList: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(e, "/elite/api/v2/TranslateList"),
                                        params: {
                                            WebsiteCode: param.WebSiteCode
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                productRegister: function(e, param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/elite/api/v2/ProductRegister"),
                                        data: {
                                            aticket: param.aticket,
                                            purchaseTime: param.purchaseTime,
                                            purchasePlace: param.purchasePlace,
                                            serialNumber: param.serialNumber,
                                            checkNumber: param.checkNumber,
                                            registerTime: param.registerTime,
                                            invoicePath: param.invoicePath,
                                            WebsiteCode: param.WebsiteCode
                                        },
                                        headers: {
                                            api_key: param.api_key,
                                            Token: param.Token
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getRegion: function(param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(param.param.origin, "/api/RegionApi")
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getUserInfo: function(param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(param.param.origin, "/api/EliteApi/Get"),
                                        data: {
                                            TokenCaller: param.param.api_key,
                                            Token: param.param.Token,
                                            Ticket: param.param.aticket
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getUserInitialize: function(param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(param.param.origin, "/api/EliteApi/Initialize"),
                                        data: {
                                            TokenCaller: param.param.api_key,
                                            Token: param.param.Token,
                                            Ticket: param.param.aticket,
                                            IsAgreeTermsAndCondition: param.param.agreeTermsAndCondition,
                                            IsAgreePrivacyPolicy: param.param.agreePrivacyPolicy
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getTranslationApi: function(param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(param.param.origin, "/api/TranslationApi"),
                                        params: {
                                            pageId: param.param.pageId,
                                            WebsiteCode: param.param.WebSiteCode,
                                            systemCode: param.param.systemCode
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                },
                getPrivacyApi: function(param) {
                    return l(this, void 0, Promise, (function() {
                        return h(this, (function(e) {
                            switch (e.label) {
                                case 0:
                                    return [4, o()({
                                        method: "get",
                                        url: "".concat(param.param.origin, "/api/PrivacyApi/Get"),
                                        params: {
                                            WebsiteCode: param.param.WebsiteCode,
                                            SystemCode: param.param.systemCode,
                                            TranslationKey: param.param.translationKey
                                        }
                                    })];
                                case 1:
                                    return [2, e.sent()]
                            }
                        }))
                    }))
                }
            }
        },
        50: function(e, t, r) {
            "use strict";
            r(10), r(43), r(46), r(52), r(37), r(38), r(400), r(20);
            var n = r(6),
                o = r.n(n),
                c = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, c) {
                        function d(e) {
                            try {
                                h(n.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(n.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((n = n.apply(e, t || [])).next())
                    }))
                },
                d = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & c[0] ? r.return : c[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, c[1])).done) return n;
                                    switch (r = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                o.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && o.label < n[1]) {
                                                o.label = n[1], n = c;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(c);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, o)
                                } catch (e) {
                                    c = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                };
            "https://".concat("estore", ".asus.com/graphql");

            function l(param) {
                return {
                    Store: param.store,
                    Authorization: "Bearer ".concat(param.token)
                }
            }

            function h(param) {
                return {
                    Store: param.store
                }
            }
            t.a = {
                usersEcToken: function(e, t, r) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        data: {
                                            query: '\n          mutation {\n            getAuthorizationToken(id:"'.concat(e, '", type:"aTicket"){\n              token\n            }\n          }\n          ')
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                usersEcShopToken: function(e, t, r) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        data: {
                                            query: '\n          mutation {\n            getAuthorizationToken(id:"'.concat(e, '", type:"aTicket"){\n              token\n            }\n          }\n          ')
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                usersEcTokenGroupId: function(e, t, param) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        headers: h(param),
                                        data: {
                                            query: '\n          mutation {\n            getAuthorizationToken(id:"'.concat(e, '", type:"aTicket"){\n              token\n              group_id\n            }\n          }\n          ')
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                visitorEcToken: function(e, t, r) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(n) {
                            switch (n.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        data: {
                                            query: '\n          mutation {\n            getAuthorizationToken(id:"'.concat(e, '", type:"session", ').concat(r, "){\n              token\n            }\n          }\n          ")
                                        }
                                    })];
                                case 1:
                                    return [2, n.sent()]
                            }
                        }))
                    }))
                },
                miniCartVisitorNumber: function(e, t, param) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: '{miniCartQty(type:SESSION, id:"'.concat(e, '"){qty}}')
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                miniCartMemberNumber: function(e, t, param) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(t, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: '{miniCartQty(type:ATICKET, id:"'.concat(e, '"){qty}}')
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                getEcCustomer: function(param, e) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: "\n          {\n            customer {\n              firstname\n              lastname\n              email\n              group_id\n            }\n          }\n            "
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getEcCartId: function(param, e) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: "\n        {\n          customerCart {\n            id\n          }\n        }\n          "
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getVisitorEcCartId: function(param, e) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: "\n        mutation {\n          createEmptyCart\n        }\n          "
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getEcCartItems: function(param, e) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: '\n        {\n          cart(cart_id: "'.concat(param.cartID, '") {\n            id\n            total_quantity\n            translate {\n              items_in_cart\n              more_items\n              cart_subtotal\n              checkout\n            }\n            items {\n              quantity\n              prices {\n                row_total_including_tax {\n                  value\n                  currency\n                }\n              }\n              product {\n                sku\n                name\n                price_range {\n                  maximum_price {\n                    final_price {\n                      currency\n                      value\n                    }\n                  }\n                }\n                small_image {\n                  url\n                  label\n                }\n              }\n              buy_page_url\n            }\n            prices {\n              subtotal_including_tax {\n                value\n                currency\n              }\n            }\n            checkout_url\n          }\n        }\n\n          ')
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                },
                getShopComEcCartItems: function(param, e) {
                    return c(this, void 0, Promise, (function() {
                        return d(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, o()({
                                        method: "post",
                                        url: "".concat(e, "/graphql"),
                                        headers: l(param),
                                        data: {
                                            query: '\n        {\n          cart(cart_id: "'.concat(param.cartID, '") {\n            id\n            total_quantity\n            translate {\n              items_in_cart\n              more_items\n              cart_subtotal\n              checkout\n            }\n            items {\n              quantity\n              prices {\n                row_total_including_tax {\n                  value\n                  currency\n                }\n\n                row_total{\n                  value\n                  currency\n                }\n\n              }\n              product {\n                sku\n                name\n                price_range {\n                  maximum_price {\n                    final_price {\n                      currency\n                      value\n                    }\n                  }\n                }\n                small_image {\n                  url\n                  label\n                }\n              }\n              buy_page_url\n              additional_message\n            }\n            prices {\n              subtotal_including_tax {\n                value\n                currency\n              }\n              subtotal_excluding_tax{\n                value\n                currency\n              }\n            }\n            checkout_url\n          }\n        }\n\n          ')
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                }
            }
        },
        650: function(e, t, r) {
            e.exports = r.p + "img/vn-logo-footer.9837dce.png"
        },
        72: function(e, t, r) {
            "use strict";
            r(10), r(43), r(46), r(52), r(37), r(38), r(18), r(29), r(20);
            var n, o = r(6),
                c = r.n(o),
                d = r(118),
                l = r.n(d),
                h = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, c) {
                        function d(e) {
                            try {
                                h(n.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(n.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((n = n.apply(e, t || [])).next())
                    }))
                },
                m = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & c[0] ? r.return : c[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, c[1])).done) return n;
                                    switch (r = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                o.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && o.label < n[1]) {
                                                o.label = n[1], n = c;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(c);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, o)
                                } catch (e) {
                                    c = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                },
                f = "api-rog.asus.com";
            (n = c.a.create({
                httpsAgent: new l.a.Agent({
                    rejectUnauthorized: !1,
                    keepAlive: !0,
                    maxSockets: 200
                }),
                timeout: 25e3
            })).interceptors.request.use((function(e) {
                var t = e.params || {};
                return t.systemCode = _(), e.params = t, e
            }));
            var _ = function() {
                var e = window.location.host,
                    t = window.location.href;
                if (t.indexOf("/event") > -1 || t.indexOf("/microsite") > -1 || t.indexOf("/campaign") > -1) return t.indexOf("/event") > -1 ? "rogevent" : t.indexOf("/microsite") > -1 ? "rogmicrosite" : t.indexOf("/campaign") > -1 ? "rogcampaign" : "";
                switch (e) {
                    case "localhost:8000":
                        return "localrog";
                    case "dev-rog.asus.com":
                        return "devrog";
                    case "rogmars.asus.com":
                        return "rogmars";
                    case "stage-rog.asus.com":
                        return "stage-rog";
                    case "rog.asus.com":
                        return "rog";
                    case "sowoverload.asus.com":
                        return "sowoverload";
                    case "www.asus.com":
                        return "asus";
                    case "account.asus.com":
                        return "account";
                    case "dev-account.asus.com":
                        return "devaccount";
                    case "nomos.asus.com":
                        return "nomos";
                    case "rog.asus.com.cn":
                        return "rogcn";
                    case "rog-bacchus.asus.com":
                        return "devsupport";
                    default:
                        var r = window.location.host.replace(".asus.com", "").replace(".", "");
                        return "rog".concat(r)
                }
            };
            t.a = {
                getSearchSuggestion: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r, o;
                        return m(this, (function(c) {
                            switch (c.label) {
                                case 0:
                                    return e = param.Website, t = param.Source, r = param.RowLimit, o = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/SuggestionV1/").concat(e, "/").concat(t, "/").concat(r),
                                        params: {
                                            SearchKey: o
                                        }
                                    })];
                                case 1:
                                    return [2, c.sent()]
                            }
                        }))
                    }))
                },
                getSearchExplore: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r;
                        return m(this, (function(o) {
                            switch (o.label) {
                                case 0:
                                    return e = param.Website, t = param.Count, r = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/Explore/ExploreV1/").concat(e, "/").concat(t),
                                        params: {
                                            SearchKey: r
                                        }
                                    })];
                                case 1:
                                    return [2, o.sent()]
                            }
                        }))
                    }))
                },
                getSearchProductResult: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r, o, c, d;
                        return m(this, (function(l) {
                            switch (l.label) {
                                case 0:
                                    return e = param.Website, t = param.PageSize, r = param.Page, o = param.Sort, c = param.ProductCategory, d = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/ResultV1/").concat(e, "/Product/").concat(t, "/").concat(r, "/").concat(c, "/").concat(o),
                                        params: {
                                            SearchKey: d
                                        }
                                    })];
                                case 1:
                                    return [2, l.sent()]
                            }
                        }))
                    }))
                },
                getSearchCampaignResult: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r, o, c;
                        return m(this, (function(d) {
                            switch (d.label) {
                                case 0:
                                    return e = param.Website, t = param.PageSize, r = param.Page, o = param.Sort, c = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/ResultV1/").concat(e, "/Campaign/").concat(t, "/").concat(r, "/").concat(o),
                                        params: {
                                            SearchKey: c
                                        }
                                    })];
                                case 1:
                                    return [2, d.sent()]
                            }
                        }))
                    }))
                },
                getSearchFAQResult: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r, o, c, d, l, h, _, v;
                        return m(this, (function(m) {
                            switch (m.label) {
                                case 0:
                                    return e = param.Website, t = param.PageSize, r = param.Page, o = param.Sort, c = param.FAQTopic, d = param.FAQCategory, l = param.FAQProductLine, h = param.LocalFlag, _ = param.SearchKey, v = param.Callback, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/ResultV1/").concat(e, "/Faq/").concat(t, "/").concat(r, "/").concat(o, "/").concat(c, "/").concat(d, "/").concat(l, "/").concat(h),
                                        params: {
                                            SearchKey: _,
                                            Callback: v
                                        }
                                    })];
                                case 1:
                                    return [2, m.sent()]
                            }
                        }))
                    }))
                },
                getSearchArticleResult: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t, r, o, c, d, l;
                        return m(this, (function(h) {
                            switch (h.label) {
                                case 0:
                                    return e = param.Website, t = param.PageSize, r = param.Page, o = param.Sort, c = param.ArticleDateRange, d = param.ArticleCategory, l = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/ResultV1/").concat(e, "/Article/").concat(t, "/").concat(r, "/").concat(o),
                                        params: {
                                            SearchKey: l,
                                            ArticleDateRange: c,
                                            ArticleCategory: d
                                        }
                                    })];
                                case 1:
                                    return [2, h.sent()]
                            }
                        }))
                    }))
                },
                getSearchArticleFilter: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t;
                        return m(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return e = param.Website, t = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/FiltersV1/").concat(e, "/article"),
                                        params: {
                                            SearchKey: t
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                getSearchProductFilter: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t;
                        return m(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return e = param.Website, t = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/FiltersV1/").concat(e, "/product"),
                                        params: {
                                            SearchKey: t
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                getSearchFAQFilter: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e, t;
                        return m(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return e = param.Website, t = param.SearchKey, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/FiltersV1/").concat(e, "/faq"),
                                        params: {
                                            SearchKey: t
                                        }
                                    })];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }))
                },
                getSearchQuick: function(e, param) {
                    return h(this, void 0, Promise, (function() {
                        var e;
                        return m(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return e = param.websiteId, [4, n({
                                        method: "get",
                                        url: "https://".concat(f, "/recent-data/search-api/v1/SuggestionV1/QuickSearch"),
                                        params: {
                                            websiteId: e
                                        }
                                    })];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }))
                }
            }
        }
    }
]);