(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [20], {
        175: function(t, e, n) {
            t.exports = {
                loadingContainer: "PageLoading__loadingContainer__LnxUq",
                isFullContentLoading: "PageLoading__isFullContentLoading__fRlHp",
                loadingIcon: "PageLoading__loadingIcon__Rr9iJ",
                "rotate-ltr": "PageLoading__rotate-ltr__xkfjM",
                "rotate-rtl": "PageLoading__rotate-rtl__LAdPw",
                isLeave: "PageLoading__isLeave__YZea2",
                fadeinout: "PageLoading__fadeinout__b1hV6"
            }
        },
        179: function(t, e, n) {
            t.exports = {
                searchHeaderPanel: "SearchHeaderPanel__searchHeaderPanel__WSEdM",
                panelContainer: "SearchHeaderPanel__panelContainer__ReqkH",
                container: "SearchHeaderPanel__container__2QudB",
                searchInputContainer: "SearchHeaderPanel__searchInputContainer__scpcF",
                fadeIn: "SearchHeaderPanel__fadeIn__SejVW",
                inputWrapper: "SearchHeaderPanel__inputWrapper__4HU1Q",
                searchTyping: "SearchHeaderPanel__searchTyping__XM5Z8",
                searchIcon: "SearchHeaderPanel__searchIcon__DrTZg",
                closeButton: "SearchHeaderPanel__closeButton__7XL2B",
                exploreContainer: "SearchHeaderPanel__exploreContainer__SNbCz",
                exploreResultBlock: "SearchHeaderPanel__exploreResultBlock__gLg9J",
                title: "SearchHeaderPanel__title__wb2c2",
                searchResultItem: "SearchHeaderPanel__searchResultItem__wTTlb",
                searchSuggestedItem: "SearchHeaderPanel__searchSuggestedItem__yHVD2",
                mask: "SearchHeaderPanel__mask__x2kfj"
            }
        },
        181: function(t, e, n) {
            t.exports = {
                bagWrapper: "MiniCart__bagWrapper__gKdgC",
                bagButton: "MiniCart__bagButton__21a47",
                isActivity: "MiniCart__isActivity__Eo-2B",
                isRed: "MiniCart__isRed__EdcuZ",
                bagItemNum: "MiniCart__bagItemNum__tA3yY",
                bagDropdownMenu: "MiniCart__bagDropdownMenu__nOEHD",
                desktopBagDropdownMenu: "MiniCart__desktopBagDropdownMenu__EsRdY",
                mobileBagDropdownMenu: "MiniCart__mobileBagDropdownMenu__DVJE2",
                isMenuShow: "MiniCart__isMenuShow__dI1nv",
                closeButton: "MiniCart__closeButton__U43ii",
                miniCartButton: "MiniCart__miniCartButton__XeaAI",
                bagContent: "MiniCart__bagContent__jGc2x",
                bagTitle: "MiniCart__bagTitle__O5vnH",
                scrollbarContent: "MiniCart__scrollbarContent__1fj6j",
                bagItemList: "MiniCart__bagItemList__vpWvx",
                bagItemContent: "MiniCart__bagItemContent__IbYyW",
                bagItemLink: "MiniCart__bagItemLink__xjKzK",
                bagItemImg: "MiniCart__bagItemImg__aPeO8",
                bagItemData: "MiniCart__bagItemData__g5xXL",
                bagItemName: "MiniCart__bagItemName__2RCTP",
                bagItemPlusSaleName: "MiniCart__bagItemPlusSaleName__Hnqdl",
                bagItmInfo: "MiniCart__bagItmInfo__cqGQa",
                bagItemCount: "MiniCart__bagItemCount__2SP2r",
                bagItemPrice: "MiniCart__bagItemPrice__o4JYS",
                moreItemText: "MiniCart__moreItemText__sSasR",
                subTotalText: "MiniCart__subTotalText__HD0AL",
                miniCartButtons: "MiniCart__miniCartButtons__ldJTX",
                viewAndEditText: "MiniCart__viewAndEditText__89eD8",
                emptyText: "MiniCart__emptyText__luCEA",
                title: "MiniCart__title__+qNaA"
            }
        },
        184: function(t, e, n) {
            t.exports = {
                breadcrumbContainer: "Breadcrumb__breadcrumbContainer__1YPg6",
                homeLinkIcon: "Breadcrumb__homeLinkIcon__HXqz1",
                breadcrumbList: "Breadcrumb__breadcrumbList__qVeH2",
                breadcrumbSubList: "Breadcrumb__breadcrumbSubList__Mwlb7",
                linkFont: "Breadcrumb__linkFont__r2rvL",
                breadcrumbHome: "Breadcrumb__breadcrumbHome__p4M2t",
                breadcrumbItem: "Breadcrumb__breadcrumbItem__JOFwJ",
                breadcrumbHomeList: "Breadcrumb__breadcrumbHomeList__7VIjI"
            }
        },
        200: function(t, e, n) {
            "use strict";
            var o, r = n(2),
                c = n(9),
                l = (n(54), n(41), n(10), n(3)),
                h = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                d = function(t, e, n, desc) {
                    var o, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (l = (r < 3 ? o(l) : r > 3 ? o(e, n, l) : o(e, n)) || l);
                    return r > 3 && l && Object.defineProperty(e, n, l), l
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.loading = !1, e
                    }
                    return h(e, t), e.prototype.start = function() {
                        "support" !== this.$route.meta.type ? this.loading = !0 : this.loading = !1
                    }, e.prototype.finish = function() {
                        this.loading = !1
                    }, e.prototype.updated = function() {}, e.prototype.mounted = function() {
                        this.$nextTick((function() {}))
                    }, e = d([l.Component], e)
                }(l.Vue),
                _ = f,
                y = n(384),
                m = n(25);
            var component = Object(m.a)(_, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.loadingContainer, Object(r.a)({}, t.$style.isLeave, !t.loading)]
                }, [e("i", {
                    class: t.$style.loadingIcon
                })])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        384: function(t, e, n) {
            "use strict";
            var o = n(175),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        388: function(t, e, n) {
            "use strict";
            var o = n(179),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        390: function(t, e, n) {
            "use strict";
            var o = n(181),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        393: function(t, e, n) {
            "use strict";
            var o = n(184),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        476: function(t, e, n) {
            "use strict";
            n(28), n(20);
            var o, r = n(9),
                c = (n(54), n(41), n(10), n(26), n(18), n(121), n(51), n(44), n(29), n(205), n(32), n(122), n(60), n(59), n(22)),
                l = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, n, desc) {
                    var o, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (l = (c < 3 ? o(l) : c > 3 ? o(e, n, l) : o(e, n)) || l);
                    return c > 3 && l && Object.defineProperty(e, n, l), l
                },
                d = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.parsedBreadList = "", e
                    }
                    return l(e, t), Object.defineProperty(e.prototype, "breadcrumbs", {
                        get: function() {
                            var t, e, n = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.breadcrumbs;
                            return "Compare" === (null === (e = this.$route) || void 0 === e ? void 0 : e.name) && "undefined" != typeof window && (n[1] = {
                                title: n[1].title,
                                url: window.location.pathname + window.location.search
                            }), n || null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "breadcrumbLinks", {
                        get: function() {
                            var t;
                            return null === (t = this.breadcrumbs) || void 0 === t ? void 0 : t.slice(1)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isRogSite", {
                        get: function() {
                            return !!this.$route
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "productPageStructure", {
                        get: function() {
                            var t, e, n, o, r, c = [];
                            return "spec" === (null === (t = this.$route) || void 0 === t ? void 0 : t.meta.type) ? c.push({
                                title: "Spec",
                                url: window.location.pathname
                            }) : "gallery" === (null === (e = this.$route) || void 0 === e ? void 0 : e.meta.type) ? c.push({
                                title: "Gallery",
                                url: window.location.pathname
                            }) : "award" === (null === (n = this.$route) || void 0 === n ? void 0 : n.meta.type) ? c.push({
                                title: "Award",
                                url: window.location.pathname
                            }) : "wtb" === (null === (o = this.$route) || void 0 === o ? void 0 : o.meta.type) ? c.push({
                                title: "WTB",
                                url: window.location.pathname
                            }) : "support" === (null === (r = this.$route) || void 0 === r ? void 0 : r.meta.type) && c.push({
                                title: "Support",
                                url: window.location.pathname
                            }), c
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "pageLevel", {
                        get: function() {
                            if (this.routeInfo && this.routeInfo.type) switch (this.routeInfo.type) {
                                case 1:
                                    return 1;
                                case 2:
                                    return 2
                            }
                            return 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "routeName", {
                        get: function() {
                            var t;
                            return this.$route ? null === (t = this.$route) || void 0 === t ? void 0 : t.name : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isShow", {
                        get: function() {
                            var t;
                            return "search" !== (null === (t = this.$route) || void 0 === t ? void 0 : t.meta.layout)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "area", {
                        get: function() {
                            if (this.routeInfo && this.routeInfo.websitePath) {
                                var t = this.routeInfo.websitePath;
                                return "global" === t ? "/" : "/".concat(t, "/")
                            }
                            return ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "newList", {
                        get: function() {
                            if (this.parsedBreadList.indexOf("helpdesk") > -1) {
                                var t = this.routeInfo.bread.split(" > ");
                                return t[t.length - 1] = "help desk", t
                            }
                            var e = [];
                            if (this.routeInfo.bread)
                                if ((e = this.routeInfo.bread.split(" > "))[e.length - 1] === e[e.length - 2] && (e[e.length - 1] = ""), "/" === this.area) {
                                    var n = this.parsedBreadList.split("/").filter((function(t) {
                                        return "" !== t
                                    }));
                                    2 === e.length && n.length > e.length && (e[2] = n[2]), 3 === e.length && n.length > e.length && (e[3] = n[3]), 4 === e.length && n.length > e.length && (e[4] = n[4]), 5 === e.length && n.length > e.length && (e[5] = n[5])
                                } else {
                                    n = this.parsedBreadList.split("/").filter((function(t) {
                                        return "" !== t
                                    }));
                                    2 === e.length && (e[2] = n[n.length - 1]), 3 === e.length && (e[3] = n[n.length - 1]), 4 === e.length && (e[4] = n[n.length - 1]), 5 === e.length && (e[5] = n[n.length - 1])
                                }
                            else if (17 === this.routeInfo.type && (e[0] = "articles"), 10 === this.routeInfo.type) e[0] = "".concat(this.list[0].replace(/-/g, " "));
                            else if (8 === this.routeInfo.type) e[0] = "articles", e[1] = "".concat(this.list[1].replace(/-/g, " "));
                            else if (12 === this.routeInfo.type) e[0] = "wallpapers";
                            else if (13 === this.routeInfo.type) e[0] = "wallpapers", e[1] = "".concat(this.list[1].replace(/-/g, " "));
                            else if (4 === this.routeInfo.type) {
                                e = n = this.parsedBreadList.split("/").filter((function(t) {
                                    return "" !== t.replace(/-/g, " ")
                                }))
                            }
                            return e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "list", {
                        get: function() {
                            if (this.routeInfo && this.routeInfo.websitePath && "undefined" != typeof window && this.parsedBreadList) {
                                var area = this.routeInfo.websitePath.toLowerCase(),
                                    t = this.parsedBreadList.toLowerCase();
                                if (t = window.location.pathname) {
                                    if ("/" === t[t.length - 1]) {
                                        var e = t.split("/");
                                        if (8 === this.routeInfo.type) {
                                            var n = [];
                                            return n[0] = "articles", n[1] = this.routeInfo.brandingName, n
                                        }
                                        if (10 === this.routeInfo.type) {
                                            var o = [];
                                            return o[0] = "tag " + this.routeInfo.brandingName.toLowerCase(), o
                                        }
                                        if ("global" !== area) {
                                            var r = this.listFilter(e);
                                            return "rog.asus.com.cn" !== window.location.host && r.shift(), r
                                        }
                                        return this.listFilter(e)
                                    }
                                    if ("global" !== area) {
                                        var c = t.split("/");
                                        r = this.listFilter(c);
                                        return "rog.asus.com.cn" !== window.location.host && r.shift(), r
                                    }
                                    var l = t.split("/");
                                    return this.listFilter(l)
                                }
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "paths", {
                        get: function() {
                            var t = this;
                            if ("undefined" != typeof window) {
                                var e = this.$root ? this.$root.$data : null,
                                    n = "",
                                    o = "";
                                e && Object.keys(e).length > 0 && (n = e.websitePath ? "".concat(e.websitePath) : "", o = "global" === n ? "/" : "/".concat(n, "/"));
                                var r = [],
                                    c = window.location.pathname.split("/"),
                                    l = Object.assign([], c),
                                    h = 0;
                                "about-rog" === c[1] || "articles" === c[1] || "wallpapers" === c[1] ? h = 1 : "terms-of-notice" === c[1] || "about-rog" === c[2] || "articles" === c[2] || "wallpapers" === c[2] ? h = 2 : "terms-of-notice" === c[2] && (h = 3);
                                var d = c.splice(h),
                                    f = encodeURI(window.location.origin);
                                if ("terms-of-notice" === l[1] || "terms-of-notice" === l[2]) d.forEach((function(e) {
                                    if ("" !== e)
                                        if ("Official-Site" === e) {
                                            var n = "terms-of-notice",
                                                o = "".concat(f).concat(t.area, "/").concat(n).concat(e);
                                            r.push({
                                                name: n.toUpperCase(),
                                                link: o
                                            })
                                        } else {
                                            o = "".concat(f).concat(t.area).concat(e);
                                            r.push({
                                                name: e.toUpperCase(),
                                                link: o
                                            })
                                        }
                                }));
                                else if ("about-rog" === l[1] || "about-rog" === l[2]) d.forEach((function(e) {
                                    if ("" !== e) {
                                        var n = "".concat(f).concat(t.area).concat(e);
                                        r.push({
                                            name: e.toUpperCase(),
                                            link: n
                                        })
                                    }
                                }));
                                else if ("team-rog" === l[1] || "team-rog" === l[2]) d.forEach((function(e) {
                                    if ("" !== e) {
                                        var n = "".concat(f).concat(t.area).concat(e);
                                        r.push({
                                            name: e.toUpperCase(),
                                            link: n
                                        })
                                    }
                                }));
                                else if ("rog-intelligent-cooling" === l[1] || "rog-intelligent-cooling" === l[2]) d.forEach((function(e) {
                                    if ("" !== e) {
                                        var n = "".concat(f).concat(t.area).concat(e);
                                        r.push({
                                            name: e.toUpperCase(),
                                            link: n
                                        })
                                    }
                                }));
                                else if ("articles" !== l[1] && "articles" !== l[2] || !o) {
                                    if (("wallpapers" === l[1] || "wallpapers" === l[2]) && o) {
                                        var _ = [];
                                        d.forEach((function(t) {
                                            if ("" !== t) {
                                                _.push(t);
                                                var e = _.join("/"),
                                                    n = "".concat(f).concat(o).concat(e);
                                                r.push({
                                                    name: t.toUpperCase(),
                                                    link: n
                                                })
                                            }
                                        }))
                                    }
                                } else {
                                    var y = [];
                                    d.forEach((function(t) {
                                        if ("" !== t) {
                                            y.push(t);
                                            var e = y.join("/"),
                                                n = "".concat(f).concat(o).concat(e);
                                            r.push({
                                                name: t.toUpperCase(),
                                                link: n
                                            })
                                        }
                                    }))
                                }
                                return r
                            }
                            return []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchRoute = function(t, e) {
                        t && (this.parsedBreadList = t.fullPath.split("?")[0])
                    }, e.prototype.listFilter = function(t) {
                        return t.filter((function(t) {
                            return t.length > 0
                        }))
                    }, e.prototype.parsePhoneBreadCrumb = function(t) {
                        var e = /group/gi,
                            area = this.routeInfo.websitePath.toLowerCase();
                        if ("global" !== area)
                            if ("rog.asus.com.cn" === window.location.host) switch (t) {
                                case 0:
                                    return e.test(this.list[0]) ? "/".concat(this.list[0], "/") : "/".concat(this.list[0], "-group/");
                                case 1:
                                    return "/".concat(this.list[0], "/").concat(this.list[1], "/");
                                case 2:
                                    return "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/")
                            } else switch (t) {
                                case 0:
                                    return 1 === this.routeInfo.layoutTemplate ? e.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/") : "/".concat(area, "/").concat(this.list[0], "-group/") : e.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/") : "/".concat(area, "/").concat(this.list[0], "-group/allmodels/");
                                case 1:
                                    return "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/");
                                case 2:
                                    return "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/")
                            } else switch (t) {
                                case 0:
                                    return 1 === this.routeInfo.layoutTemplate ? e.test(this.list[0]) ? "/".concat(this.list[0], "/") : "/".concat(this.list[0], "-group/") : e.test(this.list[0]) ? "/".concat(this.list[0], "/") : "/".concat(this.list[0], "-group/allmodels/");
                                case 1:
                                    return "/".concat(this.list[0], "/").concat(this.list[1], "/");
                                case 2:
                                    return "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/")
                            }
                        return ""
                    }, e.prototype.link = function(t) {
                        var e, n, o, r, c, l, h, d, f, _, y, m, v, w, I = /group/gi;
                        if (this.routeInfo && "Phones" === this.routeInfo.productLine) return this.parsePhoneBreadCrumb(t);
                        if (this.routeInfo && this.routeInfo.websitePath) {
                            var area = this.routeInfo.websitePath.toLowerCase(),
                                S = this.routeInfo.type;
                            if ("global" !== area)
                                if ("rog.asus.com.cn" === window.location.host) switch (t) {
                                    case 0:
                                        return 8 === this.routeInfo.type || (10 === this.routeInfo.type || 12 === this.routeInfo.type || 13 === this.routeInfo.type || 17 === this.routeInfo.type || I.test(this.list[0])) ? this.handlerUrl(0) : "".concat(this.handlerUrl(0), "-group/");
                                    case 1:
                                        return encodeURI(window.location.pathname).toLowerCase().indexOf("allmodels") > 0 ? "".concat(this.handlerUrl(1)) : this.list[1].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? "".concat(this.handlerUrl(1), "-series/").concat(window.location.search) : "".concat(this.handlerUrl(1), "-series/") : this.list[2] && this.list[2].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? "".concat(this.handlerUrl(0), "-group/") : "".concat(this.handlerUrl(1), "-series/") : 3 === this.list.length ? "".concat(this.handlerUrl(0), "-group/") : "".concat(this.handlerUrl(1), "-series/");
                                    case 2:
                                        return this.list[2].toLowerCase().indexOf("series") > 0 && 2 === this.routeInfo.type ? "".concat(this.handlerUrl(2)).concat(window.location.search) : "".concat(this.handlerUrl(2), "/");
                                    case 3:
                                        return "".concat(this.handlerUrl(3), "/");
                                    case 4:
                                        return "".concat(this.handlerUrl(4), "/").concat(window.location.search)
                                } else switch (t) {
                                    case 0:
                                        var L = this.routeInfo.type;
                                        return 8 === L ? (I.test(this.list[0]), "/".concat(area, "/").concat(this.list[0], "/")) : 10 === L ? I.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/") : "/".concat(area, "/").concat(this.list[0].replace(/ /g, "/"), "/") : 12 === L || 13 === L || 17 === L ? (I.test(this.list[0]), "/".concat(area, "/").concat(this.list[0], "/")) : L >= 1 ? I.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/") : "/".concat(area, "/").concat(this.list[0], "-group/") : I.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/allmodels") : "/".concat(area, "/").concat(this.list[0], "-group/allmodels");
                                    case 1:
                                        return encodeURI(window.location.pathname).toLowerCase().indexOf("allmodels") > 0 ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1]) : this.list[1].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? 3 === this.list.length ? "/".concat(area, "/").concat(this.list[0], "-group") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1]).concat(window.location.search) : this.list[1].toLowerCase().indexOf("series") > 0 ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/") : 4 === this.list.length && this.$route && (null === (n = null === (e = this.$route) || void 0 === e ? void 0 : e.name) || void 0 === n ? void 0 : n.indexOf("Features")) > -1 ? "/".concat(area, "/").concat(this.list[0], "-group/") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "-series/") : this.list[2] && this.list[2].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? "/".concat(area, "/").concat(this.list[0], "-group/") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "-series/") : 2 === this.list.length ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/") : 3 === this.list.length ? "Motherboards" === this.routeInfo.productLine ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "-series/") : this.$route && -1 === (null === (r = null === (o = this.$route) || void 0 === o ? void 0 : o.name) || void 0 === r ? void 0 : r.indexOf("Features")) ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/") : 4 === this.routeInfo.layoutTemplate ? I.test(this.list[0]) ? "/".concat(area, "/").concat(this.list[0], "/allmodels") : "/".concat(area, "/").concat(this.list[0], "-group/allmodels") : "/".concat(area, "/").concat(this.list[0], "-group/") : 4 === this.list.length ? this.$route && (null === (l = null === (c = this.$route) || void 0 === c ? void 0 : c.name) || void 0 === l ? void 0 : l.indexOf("Features")) > -1 ? "/".concat(area, "/").concat(this.list[0], "-group/") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "-series/") : this.$route && (null === (d = null === (h = this.$route) || void 0 === h ? void 0 : h.name) || void 0 === d ? void 0 : d.indexOf("Features")) > -1 ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "-series/") : "/".concat(area, "/").concat(this.list[0], "-group/");
                                    case 2:
                                        return this.list[2].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2]).concat(window.location.search) : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/") : 3 === this.list.length ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/") : 4 === this.list.length ? this.$route && (null === (_ = null === (f = this.$route) || void 0 === f ? void 0 : f.name) || void 0 === _ ? void 0 : _.indexOf("Features")) > -1 ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "-series/") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/") : this.list.length >= 5 ? "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "-series/") : "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/");
                                    case 3:
                                        return "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/").concat(this.list[3], "/");
                                    case 4:
                                        return "/".concat(area, "/").concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/").concat(this.list[3], "/").concat(this.list[4], "/")
                                } else switch (t) {
                                    case 0:
                                        return 8 === S ? (I.test(this.list[0]), "/".concat(this.list[0], "/")) : 10 === S ? "/".concat(this.list[0].replace(/ /g, "/")) : 12 === S || 13 === S || 17 === S ? (I.test(this.list[0]), "/".concat(this.list[0], "/")) : S >= 1 ? I.test(this.list[0]) ? "/".concat(this.list[0], "/") : "/".concat(this.list[0], "-group/") : I.test(this.list[0]) ? "/".concat(this.list[0], "/allmodels") : "/".concat(this.list[0], "-group/allmodels");
                                    case 1:
                                        return encodeURI(window.location.pathname).toLowerCase().indexOf("allmodels") > 0 ? "/".concat(this.list[0], "/").concat(this.list[1]) : this.list[1].toLowerCase().indexOf("series") > 0 ? "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(window.location.search) : this.list[2] && this.list[2].toLowerCase().indexOf("series") > 0 ? "/".concat(this.list[0], "-group") : 2 === this.list.length ? 8 === S ? "".concat(window.location.pathname) : "/".concat(this.list[0], "/").concat(this.list[1], "/") : 3 === this.list.length ? "Motherboards" === this.routeInfo.productLine ? "/".concat(this.list[0], "/").concat(this.list[1], "-series/") : this.$route && -1 === (null === (m = null === (y = this.$route) || void 0 === y ? void 0 : y.name) || void 0 === m ? void 0 : m.indexOf("Features")) ? "/".concat(this.list[0], "/").concat(this.list[1], "/") : 4 === this.routeInfo.layoutTemplate ? I.test(this.list[0]) ? "/".concat(this.list[0], "/allmodels") : "/".concat(this.list[0], "-group/allmodels") : "/".concat(this.list[0], "-group/") : 4 === this.list.length || this.list.length >= 5 ? "/".concat(this.list[0], "-group/") : "/".concat(this.list[0], "/").concat(this.list[1], "-series/");
                                    case 2:
                                        return this.list[2].toLowerCase().indexOf("series") > 0 ? 2 === this.routeInfo.type ? "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2]).concat(window.location.search) : "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/") : 4 === this.list.length ? this.$route && (null === (w = null === (v = this.$route) || void 0 === v ? void 0 : v.name) || void 0 === w ? void 0 : w.indexOf("Features")) > -1 ? "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "-series/") : "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/") : this.list.length >= 5 ? "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "-series/") : "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/");
                                    case 3:
                                        return this.list[3].toLowerCase().indexOf("series") > 0 && 2 === this.routeInfo.type ? "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/").concat(this.list[3]).concat(window.location.search) : "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/").concat(this.list[3], "/");
                                    case 4:
                                        return "/".concat(this.list[0], "/").concat(this.list[1], "/").concat(this.list[2], "/").concat(this.list[3], "/").concat(this.list[4], "/")
                                }
                        }
                        return ""
                    }, e.prototype.handlerUrl = function(t) {
                        var e = "";
                        return this.list.forEach((function(n, o) {
                            o <= t && (e = "".concat(e, "/").concat(n))
                        })), e
                    }, e.prototype.getBreadName = function(t, e) {
                        return this.routeInfo && 16 === this.routeInfo.type ? (encodeURI(window.location.pathname).indexOf("AllModels") > 0 || encodeURI(window.location.pathname).indexOf("allmodels") > 0) && 1 === e ? "".concat(this.translation.Common_Breadcrumbs_Result) : this.newList[e] : this.routeInfo && 2 === this.routeInfo.type && t.indexOf("Series") > 0 && 1 === e ? this.newList[e] : this.routeInfo && 4 === this.routeInfo.type ? this.newList[e].replace(/-/g, " ") : -1 !== this.list[e].indexOf("wtb") ? this.translation.WTB_Find_Stire : this.newList[e]
                    }, e.prototype.gaDataLayer = function(t) {
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "internal-links",
                                event_action_DL: "clicked",
                                event_label_DL: t,
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "internal-links",
                                    event_action_DL: "clicked",
                                    event_label_DL: t,
                                    event_value_DL: "0"
                                })
                            }), 200), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "internal-links", "clicked", t])
                        }
                    }, h([Object(c.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(c.Getter)("translation")], e.prototype, "translation", void 0), h([Object(c.Prop)()], e.prototype, "breadList", void 0), h([Object(c.Watch)("$route", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchRoute", null), e = h([c.Component], e)
                }(c.Vue),
                f = d,
                _ = n(393),
                y = n(25);
            var component = Object(y.a)(f, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.isShow,
                        expression: "isShow"
                    }],
                    class: t.$style.breadcrumbContainer,
                    attrs: {
                        "aria-label": "breadcrumbs",
                        role: "navigation"
                    }
                }, [e("ul", {
                    class: t.$style.breadcrumbList
                }, [t.breadcrumbs && t.breadcrumbs.length > 0 ? e("li", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "HomePage" !== t.routeName,
                        expression: "routeName !== 'HomePage'"
                    }],
                    class: [t.$style.breadcrumbHomeList, t.$style.breadcrumbItem]
                }, [e("p", {
                    class: t.$style.homeLinkIcon
                }, [e("a", {
                    attrs: {
                        "aria-label": "".concat(t.breadcrumbs[0].title),
                        href: t.breadcrumbs[0].url,
                        "aria-current": 1 === Object.keys(t.breadcrumbs).length ? "page" : "false"
                    },
                    on: {
                        click: function(e) {
                            return t.gaDataLayer("home")
                        }
                    }
                }, [e("svg", {
                    attrs: {
                        width: "32",
                        height: "18",
                        viewBox: "0 0 32 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M12.143 11.094c-2.552 1.888-2.936 2.676-2.627 3.273a20.501 20.501 0 002.58 3.2v.023a11.358 11.358 0 01-4.046-3.097c-.935-1.264-3.596-5.474-3.596-5.474.297.142.634.314.992.495 1.573.799 3.54 1.796 4.173 1.443 5.736-5.593 8.835-8.558 10.954-9.222C26.517-.139 30.677.54 30.677.54 23.67 2.194 16.384 7.825 13.19 10.294c-.425.328-.777.6-1.046.8zm-.445 3.575a8.9 8.9 0 01-1.158-.645s8.482-6.043 13.5-8.429A24.683 24.683 0 0132 3.292a2.404 2.404 0 01-.949 1.622h-.047c-11.95 4.874-16.992 8.657-17.395 8.966 0 .007 4.862 1.918 7.59 1.37 2.727-.547 4.824-5.469 4.824-5.469l1.758-.54-9.578 2.893.525-.266.033-.011c.797-.409 2.504-1.253 5.313-2.567 3.348-1.575 6.669-2.893 6.669-2.893-1.11 3.083-4.653 9.767-7.789 10.791-1.167.375-7.158-.72-11.256-2.519zm7.03-2.8l.009-.005-.142.052.133-.048zm9.975-6.217zM1.812 11.596A17.537 17.537 0 010 7.996s4.478 4.178 6.662 5.703l-.059-.028c-.484-.112-3.928-.956-4.791-2.075z",
                        fill: "#B3B3B3"
                    }
                })])])])]) : t._e(), t._v(" "), e("li", [e("ul", {
                    class: t.$style.breadcrumbSubList
                }, [t._l(t.breadcrumbLinks, (function(n, o) {
                    return e("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "HomePage" !== t.routeName,
                            expression: "routeName !== 'HomePage'"
                        }],
                        key: o
                    }, [e("p", [0 === o ? e("a", {
                        attrs: {
                            "aria-label": "".concat(t.translation.SEO_Gaming, " ").concat(n.title),
                            href: n.url,
                            "aria-current": 0 === Object.keys(t.breadcrumbs).length ? "page" : "false"
                        },
                        on: {
                            click: function(e) {
                                return t.gaDataLayer(n.title)
                            }
                        }
                    }, [e("span", [t._v(t._s(t.translation.SEO_Gaming) + " " + t._s(n.title))])]) : e("a", {
                        attrs: {
                            "aria-label": "".concat(n.title),
                            href: n.url,
                            "aria-current": 1 === Object.keys(t.breadcrumbs).length ? "page" : "false"
                        },
                        on: {
                            click: function(e) {
                                return t.gaDataLayer(n.title)
                            }
                        }
                    }, [e("span", [t._v(t._s(n.title))])])])])
                })), t._v(" "), t.isRogSite ? [e("ClientOnly", [t.productPageStructure.length > 0 ? e("li", [e("a", {
                    attrs: {
                        "aria-label": "".concat(t.productPageStructure[0].title),
                        href: t.productPageStructure[0].url,
                        "aria-current": 1 === Object.keys(t.breadcrumbs).length ? "page" : "false"
                    },
                    on: {
                        click: function(e) {
                            return t.gaDataLayer(t.productPageStructure[0].title)
                        }
                    }
                }, [e("span", [t._v(t._s(t.productPageStructure[0].title))])])]) : t._e()])] : t._e()], 2)])])])
            }), [], !1, (function(t) {
                this.$style = _.default.locals || _.default
            }), null, null);
            e.a = component.exports
        },
        488: function(t, e, n) {
            "use strict";
            var o, r;
            n.d(e, "a", (function() {
                    return r
                })),
                function(t) {
                    t.es = "es-ES", t.it = "it-IT", t.fr = "fr-FR", t.se = "sv-SE", t.dk = "da-DK", t.fi = "fi-FI", t.cz = "cs-CZ", t.pl = "pl-PL", t.hu = "hu-HU", t.de = "de-DE", t.nl = "nl-NL", t.pt = "pt-PT", t.in = "en-IN", t.kr = "ko-KR", t.id = "id-ID", t.uk = "en-UK", t.au = "en-AU", t.tw = "zh-TW", t.us = "en-US", t["be-nl"] = "nl-BE", t["be-fr"] = "fr-BE", t["ca-en"] = "en-CA", t["ca-fr"] = "fr-CA", t.cl = "es-CL", t.co = "es-CO", t.br = "pt-BR", t.pe = "es-PE", t.jp = "jp-JP", t.vn = "vi-VN", t.th = "th-TH", t.ro = "ro-RO", t["ua-ua"] = "ua-UA", t["me-en"] = "en-ME", t["me-ar"] = "ar-ME", t.ru = "ru-RU", t.za = "en-ZA"
                }(o || (o = {})),
                function(t) {
                    t.global = "en-us", t["be-nl"] = "en-us", t.bt = "en-us", t["ca-en"] = "en-us", t.cz = "cs-cz", t.de = "de-de", t.dk = "da-dk", t.fi = "fi-fi", t.fr = "fr-fr", t["me-en"] = "en-us", t.nl = "nl-nl", t.no = "no", t.pl = "pl-pl", t.ro = "ro-ro", t.ru = "ru-ru", t.se = "sv-se", t.tw = "zh-tw", t.uk = "en-us", t.us = "en-us", t.au = "en-us", t["ch-de"] = "de-de", t["ch-en"] = "en-us", t["ch-fr"] = "fr-fr", t.hk = "zh-tw", t.hu = "hu-hu", t.id = "id-id", t.in = "en-us", t.it = "it-it", t.jp = "ja-jp", t.kr = "ko-kr", t.latin = "es-ar", t.lk = "en-us", t.mx = "es-es", t.my = "en-us", t.ph = "en-us", t["sa-en"] = "en-us", t.sg = "en-us", t.sk = "sk-sk", t.th = "th-th", t.tr = "tr-tr", t.vn = "vi-vn", t.za = "en-us", t.cn = "zh-cn", t["me-ar"] = "en-us", t.il = "he-il", t["sa-ar"] = "sa-ar", t["ua-ua"] = "uk-ua", t["be-fr"] = "fr-fr", t["africa-fr"] = "en-us", t.ar = "es-ar", t.bd = "en-us", t.bn = "en-us", t.br = "pt-br", t["ca-fr"] = "fr-fr", t.cl = "es-ar", t.co = "es-ar", t.ea = "en-us", t["ea-sw"] = "sw-ea", t.ec = "es-ar", t.eg = "ar-eg", t["eg-en"] = "en-eg", t.es = "es-es", t["hk-en"] = "en-us", t.ie = "en-us", t.mm = "mm", t["nafr-ar"] = "en-us", t.np = "en-us", t.nz = "en-us", t.pe = "es-ar", t.pk = "", t.pt = "pt-pt", t.py = "es-ar", t.uy = "es-ar", t.wa = "en-us"
                }(r || (r = {}))
        },
        494: function(t, e, n) {
            "use strict";
            var o, r = n(2),
                c = (n(26), n(147), n(20), n(9)),
                l = (n(54), n(41), n(10), n(18), n(29), n(28), n(32), n(59), n(73), n(91), n(33), n(103), n(498), n(37), n(499), n(500), n(501), n(502), n(503), n(504), n(505), n(506), n(507), n(508), n(509), n(510), n(511), n(512), n(513), n(514), n(38), n(44), n(3)),
                h = n(7),
                d = n(151),
                f = n.n(d),
                _ = n(79),
                y = n(102),
                m = n(0),
                v = n(1),
                w = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                I = function(t, e, n, desc) {
                    var o, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (l = (r < 3 ? o(l) : r > 3 ? o(e, n, l) : o(e, n)) || l);
                    return r > 3 && l && Object.defineProperty(e, n, l), l
                },
                S = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.windowInnerSize = _.a, e.getWebsiteInfoMetas = new y.a, e.searchKeyword = "", e.suggestionCount = 5, e.panelHeight = 0, e.firstAnimationDone = !1, e.resultAnimationDone = !1, e.exportWebsiteID = 1, e.exportWebsitePath = "global", e.showSearchSuggested = !0, e.searchTyping = !1, e
                    }
                    return w(e, t), Object.defineProperty(e.prototype, "searchSuggestionResult", {
                        get: function() {
                            var t;
                            return null === (t = this.searchSuggestion) || void 0 === t ? void 0 : t.obj
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.searchSuggestionHandler = function(t) {
                        t && (this.searchTyping = !0), this.debounceSearchTypingResetHandler(), this.debounceSearchSuggestedHandler(), this.debounceSearchHandler()
                    }, e.prototype.animationHandler = function(t, e) {
                        t > e ? requestAnimationFrame(this.expandAnimationStep.bind(this, !1)) : requestAnimationFrame(this.expandAnimationStep.bind(this, !0))
                    }, e.prototype.closeHandler = function() {
                        this.clearSearchSuggestionResult(), this.setSearchKeyword(""), this.firstAnimationDone = !1, this.panelHeight = 0
                    }, e.prototype.clearSearchSuggestionResult = function() {
                        this.clearSearchSuggestionMutation(), this.resultAnimationDone = !1
                    }, e.prototype.debounceSearchTypingResetHandler = function() {
                        this.searchTyping = !1
                    }, e.prototype.debounceSearchSuggestedHandler = function() {
                        this.searchQuick && "" === this.searchKeyword ? this.showSearchSuggested = !0 : this.showSearchSuggested = !1
                    }, e.prototype.debounceSearchHandler = function() {
                        this.clearSearchSuggestionResult(), this.searchHandler()
                    }, e.prototype.searchHandler = function() {
                        var t = this;
                        if (!this.searchKeyword) return this.clearSearchSuggestionResult(), void this.$nextTick((function() {
                            t.calculateHeight()
                        }));
                        this.$route ? this.getWebsiteInfoMetas.originVal() : "https://rog-bacchus.asus.com" === this.getWebsiteInfoMetas.originVal() || ("https://rog.asus.com.cn" === this.getWebsiteInfoMetas.originVal() || ("https://stage-rog.asus.com" === this.getWebsiteInfoMetas.originVal() || window.location.host.indexOf("stage")));
                        var e = {
                            SearchKey: this.searchKeyword.replace(/\s+/g, "-"),
                            Website: this.getWebsite(),
                            Source: "",
                            RowLimit: ""
                        };
                        e.Source = "product,campaign,faq,article", e.RowLimit = "".concat(this.suggestionCount, ",").concat(this.suggestionCount, ",").concat(this.suggestionCount, ",").concat(this.suggestionCount), this.getSearchSuggestion({
                            url: this.getWebsiteInfoMetas.originVal(),
                            datas: e
                        }).then((function() {
                            t.calculateHeight() && (t.resultAnimationDone = !0)
                        })).catch((function(t) {
                            console.error(t)
                        }))
                    }, e.prototype.getWebsite = function() {
                        var t = this;
                        if (this.$route) return this.routeInfo.websitePath;
                        var e = this.$root ? this.$root.$data : null;
                        if (e && Object.keys(e).length > 0) {
                            this.exportWebsiteID = e.websiteID;
                            return "rog.asus.com.cn" === encodeURI(window.location.host) ? "https://rog.asus.com.cn" : "rogmars.asus.com" === encodeURI(window.location.host) ? "https://rogmars.asus.com" : "https://rog.asus.com", v.a.getWebsiteID().then((function(e) {
                                var n = e.data.result;
                                n && n.forEach((function(element) {
                                    element.websiteId === t.exportWebsiteID && (t.exportWebsitePath = element.webPath)
                                }))
                            })).catch((function(t) {
                                console.error(t)
                            })), e.websitePath ? e.websitePath : this.exportWebsitePath
                        }
                    }, e.prototype.directToSearchPage = function() {
                        if ("" !== this.searchKeyword) {
                            this.setSearchKeyword(this.searchKeyword), localStorage.setItem("searchKeyWords", this.searchKeyword), this.$emit("close");
                            var area = "",
                                t = "";
                            if (this.$route) {
                                var e = this.routeInfo.websitePath;
                                area = "global" !== e ? e : "", "rog.asus.com.cn" === window.location.host && (area = ""), t = encodeURI(area ? "/".concat(area, "/search/explore/") : "/search/explore/"), "object" === ("undefined" == typeof _satellite ? "undefined" : Object(c.a)(_satellite)) && _satellite.track("spa-pageview"), "undefined" != typeof _hmt && _hmt && _hmt.push(["_requirePlugin", "UrlChangeTracker", {
                                    shouldTrackUrlChange: function(t, e) {
                                        return t && e
                                    }
                                }]), setTimeout((function() {
                                    document.getElementById("searchButton").blur()
                                }), 100), this.$router.push({
                                    path: "".concat(t, "?searchkeyword=").concat(encodeURI(this.searchKeyword))
                                })
                            } else {
                                area = "global" === this.getWebsite() ? "" : this.getWebsite();
                                var n = "",
                                    o = "";
                                o = "api-rog.asus.com".indexOf("dev") > -1 ? "dev-rog.asus.com" : "api-rog.asus.com".indexOf("stage") > -1 ? "stage-rog.asus.com" : "api-rog.asus.com".indexOf("mars") > -1 ? "rogmars.asus.com" : "rog.asus.com", n = "cn" === area ? "https://rog.asus.com.cn/search/explore/" : encodeURI(area ? "https://".concat(o, "/").concat(area, "/search/explore/") : "https://".concat(o, "/search/explore/")), window.location.assign(encodeURI("".concat(n, "?searchkeyword=").concat(this.searchKeyword)))
                            }
                        }
                    }, e.prototype.maskHeightHandler = function() {
                        try {
                            return {
                                height: "".concat(document.body.clientHeight, "px")
                            }
                        } catch (t) {
                            return {
                                height: "0"
                            }
                        }
                    }, e.prototype.expandAnimationStep = function(t) {
                        var e = this.$refs.searchHeaderPanel,
                            n = 0;
                        e && (n = "auto" === e.style.height.split("px")[0] ? this.panelHeight : Number(e.style.height.split("px")[0])), t ? (n -= 30) < this.panelHeight && (n = this.panelHeight) : (n += 30) > this.panelHeight && (n = this.panelHeight), e && (e.style.height = "".concat(n, "px"));
                        var o = this.expandAnimationStep.bind(this, t);
                        if (t) {
                            if (n <= 30) return void this.$emit("close");
                            n > this.panelHeight ? requestAnimationFrame(o) : this.firstAnimationDone && (this.resultAnimationDone = !0)
                        } else n < this.panelHeight ? requestAnimationFrame(o) : this.animationStepFlagHandler(t)
                    }, e.prototype.animationStepFlagHandler = function(t) {
                        t ? this.resultAnimationDone ? this.resultAnimationDone = !1 : this.firstAnimationDone = !1 : this.firstAnimationDone ? this.resultAnimationDone = !0 : this.firstAnimationDone = !0
                    }, e.prototype.calculateHeight = function() {
                        var t = this.$refs.searchHeaderPanel,
                            e = this.panelHeight;
                        t.style.height = "auto";
                        var n = t.clientHeight;
                        return t.style.height = "".concat(e, "px"), this.panelHeight = n, n === e
                    }, e.prototype.isOuterLink = function(t) {
                        return /^((ht|f)tps?):\/\/([\w-]+(\.[\w-]+)*\/?)+(\?([\w\-.,@?^=%&:/~+#]*)+)?$/.test(t)
                    }, e.prototype.highlightHandler = function(t) {
                        var e = new RegExp(this.searchKeyword, "gi");
                        if (t.match(e)) {
                            var n = t;
                            return n = n.replace(e, (function(t) {
                                return '<span class="highlightText">'.concat(t, "</span>")
                            }))
                        }
                        return t
                    }, e.prototype.sort = function(t) {
                        var e = new Set;
                        return t.filter((function(t) {
                            return !e.has(t.name) && e.add(t.name)
                        }))
                    }, e.prototype.rightClick = function(t, e) {
                        3 === t.which && (t.target.href = e.replace(/script|java|applet|iframe|meta|CONCAT|CHAR|<|>|'/g, ""))
                    }, e.prototype.openLink = function(t, title) {
                        var e = this;
                        window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "site search dynamic list",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.searchKeyword, "-").concat(title, "-").concat(t.name)
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "site search dynamic list",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(e.searchKeyword, "-").concat(title, "-").concat(t.name)
                            })
                        }), 200));
                        var n = t.url.replace(/script|java|applet|iframe|meta|CONCAT|CHAR|<|>|'/g, "");
                        window.open(n, "_blank")
                    }, e.prototype.getSearchQuickList = function() {
                        var t = this;
                        this.getSearchQuick({
                            url: this.getWebsiteInfoMetas.originVal(),
                            datas: {
                                websiteId: this.mappingWebsiteId
                            }
                        }).then((function() {
                            t.calculateHeight()
                        }))
                    }, e.prototype.created = function() {
                        this.clearSearchSuggestionResult(), this.getSearchQuickList()
                    }, e.prototype.mounted = function() {
                        this.calculateHeight()
                    }, I([Object(h.Getter)("searchSuggestion")], e.prototype, "searchSuggestion", void 0), I([Object(h.Getter)("searchKeyword")], e.prototype, "stageSearchKeyword", void 0), I([Object(h.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), I([Object(h.Getter)("translation")], e.prototype, "translation", void 0), I([Object(h.Getter)("searchQuick")], e.prototype, "searchQuick", void 0), I([Object(h.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), I([Object(h.Action)("getSearchSuggestion")], e.prototype, "getSearchSuggestion", void 0), I([Object(h.Action)("getSearchQuick")], e.prototype, "getSearchQuick", void 0), I([Object(h.Action)("setSearchKeyword")], e.prototype, "setSearchKeyword", void 0), I([Object(h.Mutation)(m.CLEAR_SEARCH_SUGGESTION)], e.prototype, "clearSearchSuggestionMutation", void 0), I([Object(l.Prop)({
                        default: 1
                    })], e.prototype, "websiteId", void 0), I([Object(l.Watch)("searchKeyword")], e.prototype, "searchSuggestionHandler", null), I([Object(l.Watch)("panelHeight")], e.prototype, "animationHandler", null), I([f()(600)], e.prototype, "debounceSearchTypingResetHandler", null), I([f()(600)], e.prototype, "debounceSearchSuggestedHandler", null), I([f()(600)], e.prototype, "debounceSearchHandler", null), e = I([l.Component], e)
                }(l.Vue),
                L = S,
                C = n(388),
                O = n(25);
            var component = Object(O.a)(L, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    ref: "searchHeaderPanel",
                    class: t.$style.searchHeaderPanel
                }, [e("div", {
                    class: t.$style.panelContainer
                }, [e("div", {
                    class: [t.$style.container, t.$style.searchInputContainer, Object(r.a)({}, t.$style.searchTyping, t.searchTyping), Object(r.a)({}, t.$style.fadeIn, t.firstAnimationDone)]
                }, [e("div", {
                    class: t.$style.inputWrapper
                }, [e("div", {
                    class: t.$style.searchIcon
                }, [e("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "presentation",
                        "svg-inline": "",
                        alt: "search",
                        focusable: "false"
                    }
                }, [e("g", {
                    attrs: {
                        "clip-path": "url(#clip0_248_126)"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M16.045 16.645a7.5 7.5 0 11.707-.707l4.254 4.254-.707.707-4.254-4.254zm-.342-1.049A6.5 6.5 0 106.51 6.404a6.5 6.5 0 009.193 9.192z",
                        fill: "#fff"
                    }
                })]), e("defs", [e("clipPath", {
                    attrs: {
                        id: "clip0_248_126"
                    }
                }, [e("path", {
                    attrs: {
                        fill: "#fff",
                        d: "M0 0h24v24H0z"
                    }
                })])])])]), t._v(" "), e("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: t.searchKeyword,
                        expression: "searchKeyword"
                    }],
                    class: Object(r.a)({}, t.$style.searchTyping, t.searchTyping),
                    attrs: {
                        name: "search",
                        id: "search",
                        type: "text",
                        size: "20",
                        placeholder: "",
                        "aria-label": t.translation.Aria_SearchBar
                    },
                    domProps: {
                        value: t.searchKeyword
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.directToSearchPage.apply(null, arguments)
                        },
                        input: function(e) {
                            e.target.composing || (t.searchKeyword = e.target.value)
                        }
                    }
                }), t._v(" "), e("label", {
                    staticClass: "sr-only",
                    attrs: {
                        for: "search"
                    }
                }, [t._v("\n          " + t._s(t.translation.Aria_SearchBar) + "\n        ")])]), t._v(" "), e("button", {
                    class: t.$style.closeButton,
                    attrs: {
                        tabindex: "0",
                        type: "button",
                        "aria-label": t.translation.Aria_CancelSearch
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.closeHandler.apply(null, arguments)
                        },
                        click: t.closeHandler
                    }
                }, [e("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "presentation",
                        "svg-inline": "",
                        alt: "search",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M4.647 5.353l.707-.707L12 11.293l6.646-6.647.708.707L12.708 12l6.647 6.647-.708.707-6.646-6.647-6.647 6.647-.707-.707L11.293 12 4.647 5.353z",
                        fill: "#fff"
                    }
                })])])]), t._v(" "), e("div", {
                    class: [t.$style.container, t.$style.exploreContainer, Object(r.a)({}, t.$style.fadeIn, t.firstAnimationDone)]
                }, [t.searchQuick && t.searchQuick && 0 !== t.searchQuick.length ? [t.showSearchSuggested ? e("ul", {
                    attrs: {
                        role: "listbox"
                    }
                }, t._l(t.searchQuick, (function(n, o) {
                    return e("li", {
                        key: "suggested_".concat(o),
                        attrs: {
                            role: "presentation"
                        }
                    }, [e("a", {
                        class: [t.$style.searchSuggestedItem, t.$style.fadeIn],
                        attrs: {
                            role: "option",
                            "aria-label": "".concat(n.name),
                            href: n.url
                        }
                    }, [t._v(t._s(n.name))])])
                })), 0) : t._e()] : t._e(), t._v(" "), t.searchSuggestionResult && t.searchSuggestionResult.length > 0 ? t._l(t.searchSuggestionResult, (function(n) {
                    return n.items.length > 0 ? e("div", {
                        key: n.type,
                        class: t.$style.exploreResultBlock,
                        attrs: {
                            role: n.items.length ? "listbox" : "none",
                            "aria-label": n.items.length ? n.type : ""
                        }
                    }, [e("p", {
                        class: t.$style.title,
                        attrs: {
                            role: "presentation"
                        }
                    }, [t._v(t._s(n.type))]), t._v(" "), t._l(t.sort(n.items), (function(o, r) {
                        return [e("a", {
                            key: "".concat(r, "-").concat(o.id),
                            class: t.$style.searchResultItem,
                            attrs: {
                                role: "option",
                                "aria-label": "".concat(o.name),
                                href: o.url
                            },
                            domProps: {
                                innerHTML: t._s(t.highlightHandler(o.name))
                            },
                            on: {
                                mousedown: function(e) {
                                    return t.rightClick(e, o.url)
                                },
                                click: function(e) {
                                    return e.preventDefault(), t.openLink(o, n.type)
                                }
                            }
                        })]
                    }))], 2) : t._e()
                })) : t._e()], 2)]), t._v(" "), e("div", {
                    class: [t.$style.mask, Object(r.a)({}, t.$style.fadeIn, t.firstAnimationDone)],
                    style: t.maskHeightHandler()
                })])
            }), [], !1, (function(t) {
                this.$style = C.default.locals || C.default
            }), null, null);
            e.a = component.exports
        },
        495: function(t, e, n) {
            "use strict";
            var o, r = n(2),
                c = (n(20), n(26), n(9)),
                l = (n(54), n(41), n(10), n(28), n(18), n(29), n(59), n(73), n(33), n(517), n(3)),
                h = n(7),
                d = n(144),
                f = n(1),
                _ = n(36),
                y = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, n, desc) {
                    var o, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (l = (r < 3 ? o(l) : r > 3 ? o(e, n, l) : o(e, n)) || l);
                    return r > 3 && l && Object.defineProperty(e, n, l), l
                },
                v = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.rightWidth = 20, e.isDropDownActived = !1, e.websiteResult = [], e.callWebsite = !1, e.shopStore = "", e.storeLink = "", e
                    }
                    return y(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo && Object.keys(this.routeInfo).length > 0 ? this.routeInfo.websitePath : window.AsusAPIConfig ? window.AsusAPIConfig.websitePath : void 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isECSite", {
                        get: function() {
                            var t;
                            return null === (t = this.mappingWebsite) || void 0 === t ? void 0 : t.ecStatus
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "i18AccountLang", {
                        get: function() {
                            var t, e, n;
                            return (null === (t = this.mappingWebsite) || void 0 === t ? void 0 : t.tagLang) && null !== (null === (e = this.mappingWebsite) || void 0 === e ? void 0 : e.tagLang) ? null === (n = this.mappingWebsite) || void 0 === n ? void 0 : n.tagLang.replace(/rog_/g, "").replace("_", "-") : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "displayedItems", {
                        get: function() {
                            return this.cartList.items ? this.cartList.items : []
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "cartButtonData", {
                        get: function() {
                            return {
                                name: this.getWording("checkout"),
                                link: this.cartList.checkout_url,
                                disabled: !1
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "bagItemsQuantity", {
                        get: function() {
                            var t;
                            if (this.cartList) return (null === (t = this.cartList) || void 0 === t ? void 0 : t.total_quantity) ? this.cartList.total_quantity : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "displayedQuantity", {
                        get: function() {
                            return this.bagItemsQuantity || 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "itemsMoreThanThree", {
                        get: function() {
                            var t;
                            if (this.cartList && (null === (t = this.cartList) || void 0 === t ? void 0 : t.items)) return this.cartList.items.length > 3
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isRtlArea", {
                        get: function() {
                            return "eg" === this.lang || "me-ar" === this.lang || "il" === this.lang || "sa-ar" === this.lang
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.mounted = function() {
                        var t = this;
                        "cn" !== this.lang && f.a.getMiniCartInfo({
                            WebsiteCode: this.lang
                        }).then((function(e) {
                            if (200 === e.status && e.data) {
                                var n = e.data.Result;
                                t.shopStore = n.ShoponASUSstore, t.storeLink = n.StoreURL
                            }
                        })).catch((function(t) {
                            console.error(t)
                        })), this.checkDropMenuRightPosition(), document.body.addEventListener("click", (function(e) {
                            -1 !== navigator.userAgent.indexOf("MSIE") || navigator.appVersion.indexOf("Trident/"), e.target.closest(".bagDropdownMenu") || e.target.closest(".bagButton") || (t.isDropDownActived = !1)
                        })), window.addEventListener("resize", (function() {
                            t.checkDropMenuRightPosition()
                        })), setTimeout((function() {
                            t.websiteResult = t.mappingWebsite
                        }), 0)
                    }, e.prototype.checkDropMenuRightPosition = function() {
                        var t = document.body.clientWidth;
                        t > 1890 || t <= 1890 && t > 1600 ? this.rightWidth = 32 : t <= 1600 && t > 1024 ? this.rightWidth = 20 : t <= 1024 && (this.rightWidth = 0)
                    }, e.prototype.bagIconClick = function() {
                        this.isDropDownActived = !this.isDropDownActived, document.body.clientWidth <= 540 && (this.isDropDownActived ? document.body.classList.add("hiddenScroll") : document.body.classList.remove("hiddenScroll"))
                    }, e.prototype.closeMenu = function() {
                        window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "header_close_mini_cart",
                            event_category_DL: "header-mini_cart-L2",
                            event_action_DL: "clicked",
                            event_label_DL: "close",
                            event_value_DL: "0"
                        }), this.isDropDownActived = !1, document.body.classList.remove("hiddenScroll")
                    }, e.prototype.isFloat = function(t) {
                        return t == t && t !== (0 | t)
                    }, e.prototype.thousandSeparatorHandler = function(t, e) {
                        var n = "";
                        return "" !== e ? "IN" === this.websiteResult.isoCode || "PE" === this.websiteResult.isoCode ? (n = Number(t).toLocaleString(this.i18AccountLang, {
                            maximumFractionDigits: this.websiteResult.numberOfDecimal,
                            style: "currency",
                            currency: this.websiteResult.currencyCode
                        }), "PE" === this.websiteResult.isoCode && (n = n.replace("S/", "S/."))) : n = t.toString().replace(/\B(?=(\d{3})+(?!\d))/g, this.websiteResult.thousandSeparators) : n = t, n
                    }, e.prototype.currencyHandler = function(t) {
                        if (!this.callWebsite && 0 === this.websiteResult.length) {
                            this.callWebsite = !0;
                            Object(_.a)() && encodeURI(window.location.origin), this.$root && this.$root.$data;
                            var e = encodeURI(window.location.host);
                            e.replace(".asus.com", "");
                            return e.indexOf("dev") > -1 ? "dev-api-rog.asus.com" : e.indexOf("stage") > -1 ? "stage-api-rog.asus.com" : e.indexOf("rogmars") > -1 && "api-rogmars.asus.com", this.websiteResult = this.mappingWebsite, this.currencyHandler(t), ""
                        }
                        var n = t,
                            o = Number(this.websiteResult.numberOfDecimal);
                        return this.isFloat(Number(n)) && o > 0 ? n = n.toFixed(2).replace(".", this.websiteResult.decimalSeparator) : o > 0 && (n = n.toString() + this.websiteResult.decimalSeparator + "00"), n = this.thousandSeparatorHandler(n, this.websiteResult.thousandSeparators), "IN" === this.websiteResult.isoCode || "PE" === this.websiteResult.isoCode ? n : "LEFT" === this.websiteResult.currencyPosition ? "".concat(this.websiteResult.currencySymbol).concat(n) : "".concat(n).concat(this.websiteResult.currencySymbol)
                    }, e.prototype.splitWord = function(t) {
                        return t.split(";")
                    }, e.prototype.getWording = function(t) {
                        var e = this.cartList;
                        return e && e.translate && e.translate[t] ? e.translate[t] : t
                    }, m([Object(h.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), m([Object(h.Getter)("translation")], e.prototype, "translation", void 0), m([Object(h.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), m([Object(h.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), m([Object(l.Prop)()], e.prototype, "cartList", void 0), m([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "miniCartNumber", void 0), m([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "getMiniCartStatus", void 0), e = m([Object(l.Component)({
                        components: {
                            ButtonRed: d.a
                        }
                    })], e)
                }(l.Vue),
                w = v,
                I = n(390),
                S = n(25);
            var component = Object(S.a)(w, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.isECSite && "cn" !== t.lang ? e("div", {
                    class: t.$style.bagWrapper
                }, [e("button", {
                    class: ["bagButton", t.$style.bagButton, Object(r.a)({}, t.$style.isActivity, t.isDropDownActived)],
                    attrs: {
                        "aria-label": "".concat(t.miniCartNumber, " ").concat(t.translation.Aria_cart),
                        tabindex: "0",
                        "aria-haspopup": "true",
                        "aria-expanded": t.isDropDownActived
                    },
                    on: {
                        click: t.bagIconClick
                    }
                }, [e("svg", {
                    class: ["svg-icon", Object(r.a)({}, t.$style.isRed, t.isDropDownActived)],
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "bag",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M4.22 5.79l1.57 11.06h.806A2.078 2.078 0 008.38 20a2.078 2.078 0 001.783-3.153l7.428-.006A2.078 2.078 0 0019.37 20c1.149 0 2.079-.93 2.079-2.08 0-1.113-.871-2.02-1.97-2.077v-.003h-.124l-10.787.008a2.114 2.114 0 00-.381 0l-1.528.002L5.09 4.79H1.5v1h2.72zm14.07 12.13c0-.597.485-1.075 1.071-1.08h.017a1.075 1.075 0 011.072 1.08c0 .6-.48 1.08-1.08 1.08-.6 0-1.08-.48-1.08-1.08zM8.247 16.848h.266c.536.065.947.517.947 1.072 0 .6-.48 1.08-1.08 1.08-.6 0-1.08-.48-1.08-1.08 0-.554.418-1.006.947-1.072zM19.56 13.24l.77-5.37H7.89l.77 5.37h10.9zM6.74 6.87h14.73l-1.05 7.37H7.79L6.74 6.87z",
                        fill: "#F2F2F2"
                    }
                })]), t._v(" "), t.miniCartNumber ? e("span", {
                    class: t.$style.bagItemNum,
                    attrs: {
                        "aria-hidden": "true"
                    }
                }, [t._v(t._s(t.miniCartNumber))]) : t._e()]), t._v(" "), e("div", {
                    class: ["bagDropdownMenu", t.$style.bagDropdownMenu, t.$style.desktopBagDropdownMenu, Object(r.a)({}, t.$style.isMenuShow, t.isDropDownActived)],
                    style: "left: ".concat(t.isRtlArea ? "-" + t.rightWidth + "px" : "auto", "; right: ").concat(t.isRtlArea ? "auto" : "-" + t.rightWidth + "px")
                }, [e("button", {
                    class: t.$style.closeButton,
                    attrs: {
                        "aria-label": "close button",
                        tabindex: "0",
                        type: "button"
                    },
                    on: {
                        click: t.closeMenu,
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.closeMenu.apply(null, arguments)
                        }
                    }
                }, [e("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "close",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M4.647 5.353l.707-.707L12 11.293l6.646-6.647.708.707L12.708 12l6.647 6.647-.708.707-6.646-6.647-6.647 6.647-.707-.707L11.293 12 4.647 5.353z",
                        fill: "#181818"
                    }
                })])]), t._v(" "), t.bagItemsQuantity > 0 ? e("div", {
                    class: t.$style.bagContent
                }, [e("p", {
                    class: t.$style.bagTitle
                }, [e("span", [t._v(t._s(t.splitWord(t.getWording("items_in_cart"))[0]))]), t._v("\n        " + t._s(t.splitWord(t.getWording("items_in_cart"))[1]) + "\n      ")]), t._v(" "), e("div", {
                    class: t.$style.scrollbarContent
                }, [e("ul", {
                    class: t.$style.bagItemList
                }, t._l(t.displayedItems, (function(n, o) {
                    return e("li", {
                        key: o,
                        class: t.$style.bagItemContent
                    }, [e("a", {
                        class: t.$style.bagItemLink,
                        attrs: {
                            href: n.buy_page_url
                        }
                    }, [e("div", {
                        class: t.$style.bagItemImg,
                        style: {
                            backgroundImage: "url(".concat(n.product.small_image.url, ")")
                        }
                    })]), t._v(" "), e("div", {
                        class: t.$style.bagItemData
                    }, [e("a", {
                        class: t.$style.bagItemLink,
                        attrs: {
                            href: n.buy_page_url
                        }
                    }, [e("p", {
                        class: t.$style.bagItemName
                    }, [t._v(t._s(n.product.name))])]), t._v(" "), n.additional_message ? e("p", {
                        class: t.$style.bagItemPlusSaleName
                    }, [t._v("\n                " + t._s(n.additional_message) + "\n              ")]) : t._e(), t._v(" "), e("div", {
                        class: t.$style.bagItmInfo
                    }, [e("p", {
                        class: t.$style.bagItemCount
                    }, [t._v("X " + t._s(n.quantity))]), t._v(" "), "us" === t.lang && "ca-en" === t.lang && "ca-fr" === t.lang ? e("p", {
                        class: t.$style.bagItemPrice
                    }, [t._v("\n                  " + t._s(t.currencyHandler(n.prices.row_total.value)) + "\n                ")]) : e("p", {
                        class: t.$style.bagItemPrice
                    }, [t._v("\n                  " + t._s(t.currencyHandler(n.prices.row_total_including_tax.value)) + "\n                ")])])])])
                })), 0)]), t._v(" "), e("div", {
                    class: t.$style.miniCartButtons
                }, [e("p", {
                    class: t.$style.subTotalText
                }, [t._v("\n          " + t._s(t.getWording("cart_subtotal")) + " \n          "), "us" === t.lang && "ca-en" === t.lang && "ca-fr" === t.lang ? e("span", [t._v(t._s(t.currencyHandler(t.cartList.prices.subtotal_excluding_tax.value)))]) : e("span", [t._v(t._s(t.currencyHandler(t.cartList.prices.subtotal_including_tax.value)))])]), t._v(" "), e("ButtonRed", {
                    class: t.$style.miniCartButton,
                    attrs: {
                        buttonData: t.cartButtonData,
                        isMaxWidth: !0,
                        isRogSite: !1,
                        isGA: !0,
                        isMiniCartButton: !0
                    }
                })], 1)]) : e("div", {
                    class: t.$style.emptyText
                }, [e("p", {
                    class: t.$style.title
                }, [t._v(t._s(t.translation.Header_Bag_Empty))]), t._v(" "), "" !== t.storeLink ? e("p", [e("a", {
                    attrs: {
                        href: t.storeLink
                    }
                }, [t._v(" " + t._s(this.shopStore) + " ")])]) : t._e()])]), t._v(" "), e("div", {
                    class: ["bagDropdownMenu", t.$style.bagDropdownMenu, t.$style.mobileBagDropdownMenu, Object(r.a)({}, t.$style.isMenuShow, t.isDropDownActived)],
                    style: "left: ".concat(t.isRtlArea ? "-" + t.rightWidth + "px" : "auto", "; right: ").concat(t.isRtlArea ? "auto" : "-" + t.rightWidth + "px")
                }, [e("button", {
                    class: t.$style.closeButton,
                    attrs: {
                        "aria-label": "close button",
                        tabindex: "0",
                        type: "button"
                    },
                    on: {
                        click: t.closeMenu,
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.closeMenu.apply(null, arguments)
                        }
                    }
                }, [e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "close",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M28 5.41L26.59 4 16 14.59 5.41 4 4 5.41 14.59 16 4 26.59 5.41 28 16 17.41 26.59 28 28 26.59 17.41 16 28 5.41z"
                    }
                })])]), t._v(" "), t.bagItemsQuantity > 0 ? e("div", {
                    class: t.$style.bagContent
                }, [e("p", {
                    class: t.$style.bagTitle
                }, [e("span", [t._v(t._s(t.splitWord(t.getWording("items_in_cart"))[0]))]), t._v("\n        " + t._s(t.splitWord(t.getWording("items_in_cart"))[1]) + "\n      ")]), t._v(" "), e("div", {
                    class: t.$style.scrollbarContent
                }, [e("ul", {
                    class: t.$style.bagItemList
                }, t._l(t.displayedItems, (function(n, o) {
                    return e("li", {
                        key: o,
                        class: t.$style.bagItemContent
                    }, [e("a", {
                        class: t.$style.bagItemLink,
                        attrs: {
                            href: n.buy_page_url
                        }
                    }, [e("div", {
                        class: t.$style.bagItemImg,
                        style: {
                            backgroundImage: "url(".concat(n.product.small_image.url, ")")
                        }
                    })]), t._v(" "), e("div", {
                        class: t.$style.bagItemData
                    }, [e("a", {
                        class: t.$style.bagItemLink,
                        attrs: {
                            href: n.buy_page_url
                        }
                    }, [e("p", {
                        class: t.$style.bagItemName
                    }, [t._v(t._s(n.product.name))])]), t._v(" "), n.additional_message ? e("p", {
                        class: t.$style.bagItemPlusSaleName
                    }, [t._v("\n                " + t._s(n.additional_message) + "\n              ")]) : t._e(), t._v(" "), e("div", {
                        class: t.$style.bagItmInfo
                    }, [e("p", {
                        class: t.$style.bagItemCount
                    }, [t._v("X " + t._s(n.quantity))]), t._v(" "), "us" === t.lang && "ca-en" === t.lang && "ca-fr" === t.lang ? e("p", {
                        class: t.$style.bagItemPrice
                    }, [t._v("\n                  " + t._s(t.currencyHandler(n.prices.row_total.value)) + "\n                ")]) : e("p", {
                        class: t.$style.bagItemPrice
                    }, [t._v("\n                  " + t._s(t.currencyHandler(n.prices.row_total_including_tax.value)) + "\n                ")])])])])
                })), 0)]), t._v(" "), e("div", {
                    class: t.$style.miniCartButtons
                }, [e("p", {
                    class: t.$style.subTotalText
                }, [t._v("\n          " + t._s(t.getWording("cart_subtotal")) + " \n          "), "us" === t.lang && "ca-en" === t.lang && "ca-fr" === t.lang ? e("span", [t._v(t._s(t.currencyHandler(t.cartList.prices.subtotal_excluding_tax.value)))]) : e("span", [t._v(t._s(t.currencyHandler(t.cartList.prices.subtotal_including_tax.value)))])]), t._v(" "), e("ButtonRed", {
                    attrs: {
                        buttonData: t.cartButtonData,
                        isMaxWidth: !0,
                        isRogSite: !1,
                        isGA: !0,
                        isMiniCartButton: !0
                    }
                })], 1)]) : e("div", {
                    class: t.$style.emptyText
                }, [e("p", {
                    class: t.$style.title
                }, [t._v(t._s(t.translation.Header_Bag_Empty))]), t._v(" "), e("p", [e("a", {
                    attrs: {
                        href: t.storeLink
                    }
                }, [t._v(" " + t._s(this.shopStore) + " ")])])])])]) : t._e()
            }), [], !1, (function(t) {
                this.$style = I.default.locals || I.default
            }), null, null);
            e.a = component.exports
        }
    }
]);