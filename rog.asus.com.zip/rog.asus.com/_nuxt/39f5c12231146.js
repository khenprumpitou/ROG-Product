(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [4], {
        1006: function(t, e, n) {
            var o = n(742);
            t.exports = function() {
                return o.Date.now()
            }
        },
        1007: function(t, e, n) {
            (function(e) {
                var n = "object" == typeof e && e && e.Object === Object && e;
                t.exports = n
            }).call(this, n(45))
        },
        1008: function(t, e, n) {
            var o = n(1009),
                r = n(692),
                l = n(1011),
                c = /^[-+]0x[0-9a-f]+$/i,
                _ = /^0b[01]+$/i,
                d = /^0o[0-7]+$/i,
                f = parseInt;
            t.exports = function(t) {
                if ("number" == typeof t) return t;
                if (l(t)) return NaN;
                if (r(t)) {
                    var e = "function" == typeof t.valueOf ? t.valueOf() : t;
                    t = r(e) ? e + "" : e
                }
                if ("string" != typeof t) return 0 === t ? t : +t;
                t = o(t);
                var n = _.test(t);
                return n || d.test(t) ? f(t.slice(2), n ? 2 : 8) : c.test(t) ? NaN : +t
            }
        },
        1009: function(t, e, n) {
            var o = n(1010),
                r = /^\s+/;
            t.exports = function(t) {
                return t ? t.slice(0, o(t) + 1).replace(r, "") : t
            }
        },
        1010: function(t, e) {
            var n = /\s/;
            t.exports = function(t) {
                for (var e = t.length; e-- && n.test(t.charAt(e)););
                return e
            }
        },
        1011: function(t, e, n) {
            var o = n(909),
                r = n(743);
            t.exports = function(t) {
                return "symbol" == typeof t || r(t) && "[object Symbol]" == o(t)
            }
        },
        1012: function(t, e, n) {
            var o = n(910),
                r = Object.prototype,
                l = r.hasOwnProperty,
                c = r.toString,
                _ = o ? o.toStringTag : void 0;
            t.exports = function(t) {
                var e = l.call(t, _),
                    n = t[_];
                try {
                    t[_] = void 0;
                    var o = !0
                } catch (t) {}
                var r = c.call(t);
                return o && (e ? t[_] = n : delete t[_]), r
            }
        },
        1013: function(t, e) {
            var n = Object.prototype.toString;
            t.exports = function(t) {
                return n.call(t)
            }
        },
        1205: function(t, e, n) {
            "use strict";
            var o = n(874),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        1206: function(t, e, n) {
            "use strict";
            var o = n(875),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        1207: function(t, e, n) {
            "use strict";
            var o = n(876),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        },
        690: function(t, e, n) {
            "use strict";
            var o = n(5),
                r = n(123).findIndex,
                l = n(149),
                c = "findIndex",
                _ = !0;
            c in [] && Array(1)[c]((function() {
                _ = !1
            })), o({
                target: "Array",
                proto: !0,
                forced: _
            }, {
                findIndex: function(t) {
                    return r(this, t, arguments.length > 1 ? arguments[1] : void 0)
                }
            }), l(c)
        },
        692: function(t, e) {
            t.exports = function(t) {
                var e = typeof t;
                return null != t && ("object" == e || "function" == e)
            }
        },
        705: function(t, e, n) {
            t.exports = {
                tagContainer: "TagEventRed__tagContainer__f6eFK",
                isBlack: "TagEventRed__isBlack__yQnTO",
                tagValue: "TagEventRed__tagValue__RRGWi"
            }
        },
        707: function(t, e, n) {
            "use strict";

            function o() {
                var t = 0;
                return void 0 !== window.pageYOffset ? t = window.pageYOffset : void 0 !== document.body && (t = document.body.scrollTop), t
            }
            n.d(e, "a", (function() {
                return o
            }))
        },
        742: function(t, e, n) {
            var o = n(1007),
                r = "object" == typeof self && self && self.Object === Object && self,
                l = o || r || Function("return this")();
            t.exports = l
        },
        743: function(t, e) {
            t.exports = function(t) {
                return null != t && "object" == typeof t
            }
        },
        753: function(t, e, n) {
            "use strict";
            e.a = {
                name: "SlideUpDown",
                props: {
                    active: Boolean,
                    duration: {
                        type: Number,
                        default: 500
                    },
                    tag: {
                        type: String,
                        default: "div"
                    }
                },
                data: function() {
                    return {
                        style: {},
                        initial: !1
                    }
                },
                watch: {
                    active: function() {
                        this.layout()
                    }
                },
                render: function(t) {
                    return t(this.tag, {
                        style: this.style,
                        ref: "container",
                        attrs: {
                            "aria-hidden": !this.active
                        },
                        on: {
                            transitionend: this.onTransitionEnd
                        }
                    }, this.$slots.default)
                },
                mounted: function() {
                    this.layout(), this.initial = !0
                },
                computed: {
                    el: function() {
                        return this.$refs.container
                    }
                },
                methods: {
                    layout: function() {
                        var t = this;
                        this.active ? (this.$emit("open-start"), this.initial && this.setHeight("0px", (function() {
                            return t.el.scrollHeight + "px"
                        }))) : (this.$emit("close-start"), this.setHeight(this.el.scrollHeight + "px", (function() {
                            return "0px"
                        })))
                    },
                    asap: function(t) {
                        this.initial ? this.$nextTick(t) : t()
                    },
                    setHeight: function(t, i) {
                        var e = this;
                        this.style = {
                            height: t
                        }, this.asap((function() {
                            e.__ = e.el.scrollHeight, e.style = {
                                height: i(),
                                overflow: "hidden",
                                "transition-property": "height",
                                "transition-duration": e.duration + "ms"
                            }
                        }))
                    },
                    onTransitionEnd: function() {
                        this.active ? (this.style = {}, this.$emit("open-end")) : (this.style = {
                            height: "0",
                            overflow: "hidden"
                        }, this.$emit("close-end"))
                    }
                }
            }
        },
        874: function(t, e, n) {
            t.exports = {
                breakPointMedium: "1279px",
                breakPointHeaderTablet: "1023px",
                breakPointSmall: "730px",
                starRating: "StarRating__starRating__rnnA0",
                starWrapper: "StarRating__starWrapper__444uP",
                starImg: "StarRating__starImg__y9vZ+"
            }
        },
        875: function(t, e, n) {
            t.exports = {
                breakPointMedium: "1279px",
                breakPointHeaderTablet: "1023px",
                breakPointSmall: "730px",
                downloadButtonWrapper: "WallpaperDownloadButton__downloadButtonWrapper__CCO4z",
                downloadButton: "WallpaperDownloadButton__downloadButton__ZQmzR",
                open: "WallpaperDownloadButton__open__LI5BY",
                deviceDropMenu: "WallpaperDownloadButton__deviceDropMenu__JoxTA",
                deviceTabs: "WallpaperDownloadButton__deviceTabs__ogZ6P",
                active: "WallpaperDownloadButton__active__T-SAl",
                deviceTabContent: "WallpaperDownloadButton__deviceTabContent__9XKj2"
            }
        },
        876: function(t, e, n) {
            t.exports = {
                breakPointMedium: "1279px",
                breakPointHeaderTablet: "1023px",
                breakPointSmall: "730px",
                wpListItem: "WallpaperItem__wpListItem__0Xo-8",
                wpImage: "WallpaperItem__wpImage__sLH0T",
                wpItemImageIcon: "WallpaperItem__wpItemImageIcon__aBZBn",
                wpItemContent: "WallpaperItem__wpItemContent__2S2+e",
                categoryName: "WallpaperItem__categoryName__31WG-",
                wpItemName: "WallpaperItem__wpItemName__gOF2t",
                wpItemDeviceList: "WallpaperItem__wpItemDeviceList__Z2Zf-",
                wpItemDownloadContent: "WallpaperItem__wpItemDownloadContent__3blWV",
                downloadTimes: "WallpaperItem__downloadTimes__jYE-C",
                downloadButton: "WallpaperItem__downloadButton__5oU0h",
                open: "WallpaperItem__open__IQian",
                downloadButtonWrapper: "WallpaperItem__downloadButtonWrapper__s+i2U",
                deviceDropMenu: "WallpaperItem__deviceDropMenu__kJiUP",
                deviceTabs: "WallpaperItem__deviceTabs__TqeQu",
                active: "WallpaperItem__active__kWJoC",
                deviceTabContent: "WallpaperItem__deviceTabContent__9CTXL",
                corner1: "WallpaperItem__corner1__TvWnq",
                corner2: "WallpaperItem__corner2__yNSaj",
                corner3: "WallpaperItem__corner3__btHlI",
                corner4: "WallpaperItem__corner4__6ORqS",
                wpListBlock: "WallpaperItem__wpListBlock__tBcIh",
                shareButton: "WallpaperItem__shareButton__SHeZm",
                shareIcon: "WallpaperItem__shareIcon__akH+I",
                shareMenu: "WallpaperItem__shareMenu__bc3p3",
                shareLink: "WallpaperItem__shareLink__7EcO6",
                icon: "WallpaperItem__icon__WxoET",
                wpImg: "WallpaperItem__wpImg__FT40L",
                img: "WallpaperItem__img__hms7k",
                wpInfo: "WallpaperItem__wpInfo__D150l",
                wpInfoTitle: "WallpaperItem__wpInfoTitle__rLqs4",
                wpContent: "WallpaperItem__wpContent__fV5Xo",
                wpContentHidden: "WallpaperItem__wpContentHidden__wGU8t",
                wpRate: "WallpaperItem__wpRate__vN-SN",
                startWrapper: "WallpaperItem__startWrapper__oyoVc",
                iconStarWrapper: "WallpaperItem__iconStarWrapper__1qIDx",
                iconStar: "WallpaperItem__iconStar__odmel",
                iconStarOn: "WallpaperItem__iconStarOn__TpIuE",
                startQuantity: "WallpaperItem__startQuantity__up42c",
                btnRate: "WallpaperItem__btnRate__S42Px",
                rateIcon: "WallpaperItem__rateIcon__Cf5nc",
                wpSize: "WallpaperItem__wpSize__N+Ooz",
                sizeSelect: "WallpaperItem__sizeSelect__0lOpo",
                sizeOption: "WallpaperItem__sizeOption__HMGgU",
                wpDownload: "WallpaperItem__wpDownload__hf6vn",
                downloadIcon: "WallpaperItem__downloadIcon__TXrNy",
                downloadText: "WallpaperItem__downloadText__fQ18R",
                starRatingWrapper: "WallpaperItem__starRatingWrapper__p30-b",
                ratingBackButton: "WallpaperItem__ratingBackButton__nkrsC"
            }
        },
        903: function(t, e, n) {
            "use strict";
            var o, r = n(2),
                l = n(9),
                c = (n(54), n(41), n(10), n(3)),
                _ = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                d = function(t, e, n, desc) {
                    var o, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (c = (r < 3 ? o(c) : r > 3 ? o(e, n, c) : o(e, n)) || c);
                    return r > 3 && c && Object.defineProperty(e, n, c), c
                },
                f = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return _(e, t), d([Object(c.Prop)()], e.prototype, "tagData", void 0), d([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isBlack", void 0), e = d([c.Component], e)
                }(c.Vue),
                v = f,
                h = n(970),
                w = n(25);
            var component = Object(w.a)(v, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("i", {
                    class: [t.$style.tagContainer, Object(r.a)({}, t.$style.isBlack, t.isBlack)]
                }, [e("span", {
                    class: t.$style.tagValue
                }, [t._v(t._s(t.tagData))])])
            }), [], !1, (function(t) {
                this.$style = h.default.locals || h.default
            }), null, null);
            e.a = component.exports
        },
        908: function(t, e, n) {
            var o = n(692),
                r = n(1006),
                l = n(1008),
                c = Math.max,
                _ = Math.min;
            t.exports = function(t, e, n) {
                var d, f, v, h, w, y, m = 0,
                    I = !1,
                    O = !1,
                    L = !0;
                if ("function" != typeof t) throw new TypeError("Expected a function");

                function j(time) {
                    var e = d,
                        n = f;
                    return d = f = void 0, m = time, h = t.apply(n, e)
                }

                function W(time) {
                    var t = time - y;
                    return void 0 === y || t >= e || t < 0 || O && time - m >= v
                }

                function x() {
                    var time = r();
                    if (W(time)) return D(time);
                    w = setTimeout(x, function(time) {
                        var t = e - (time - y);
                        return O ? _(t, v - (time - m)) : t
                    }(time))
                }

                function D(time) {
                    return w = void 0, L && d ? j(time) : (d = f = void 0, h)
                }

                function T() {
                    var time = r(),
                        t = W(time);
                    if (d = arguments, f = this, y = time, t) {
                        if (void 0 === w) return function(time) {
                            return m = time, w = setTimeout(x, e), I ? j(time) : h
                        }(y);
                        if (O) return clearTimeout(w), w = setTimeout(x, e), j(y)
                    }
                    return void 0 === w && (w = setTimeout(x, e)), h
                }
                return e = l(e) || 0, o(n) && (I = !!n.leading, v = (O = "maxWait" in n) ? c(l(n.maxWait) || 0, e) : v, L = "trailing" in n ? !!n.trailing : L), T.cancel = function() {
                    void 0 !== w && clearTimeout(w), m = 0, d = y = f = w = void 0
                }, T.flush = function() {
                    return void 0 === w ? h : D(r())
                }, T
            }
        },
        909: function(t, e, n) {
            var o = n(910),
                r = n(1012),
                l = n(1013),
                c = o ? o.toStringTag : void 0;
            t.exports = function(t) {
                return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : c && c in Object(t) ? r(t) : l(t)
            }
        },
        910: function(t, e, n) {
            var o = n(742).Symbol;
            t.exports = o
        },
        913: function(t, e, n) {
            "use strict";
            var o, r = n(9),
                l = (n(54), n(41), n(10), n(8)),
                c = n(3),
                _ = n(7),
                d = n(0),
                f = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                v = function(t, e, n, desc) {
                    var o, l = arguments.length,
                        c = l < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (c = (l < 3 ? o(c) : l > 3 ? o(e, n, c) : o(e, n)) || c);
                    return l > 3 && c && Object.defineProperty(e, n, c), c
                };
            e.a = function(param) {
                var t = param.pageSize,
                    e = function(e) {
                        function n() {
                            var n = null !== e && e.apply(this, arguments) || this;
                            return n.pageSize = t, n
                        }
                        return f(n, e), v([Object(_.Getter)("websitePath")], n.prototype, "websitePath", void 0), v([Object(_.Mutation)(d.SEARCH_KEYWORD)], n.prototype, "searchKeywordMutation", void 0), n = v([Object(c.Component)({})], n)
                    }(l.default);
                return e
            }
        },
        951: function(t, e, n) {
            "use strict";
            n(26);
            var o, r = n(9),
                l = (n(54), n(41), n(10), n(59), n(18), n(121), n(22)),
                c = n(957),
                _ = n(952),
                d = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, n, desc) {
                    var o, l = arguments.length,
                        c = l < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (c = (l < 3 ? o(c) : l > 3 ? o(e, n, c) : o(e, n)) || c);
                    return l > 3 && c && Object.defineProperty(e, n, c), c
                },
                v = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.tabType = "desktop", e.isOpen = !1, e
                    }
                    return d(e, t), Object.defineProperty(e.prototype, "getIsDesktop", {
                        get: function() {
                            return this.photoItem.devices.some((function(t) {
                                return 1 === t.type
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getIsDuo", {
                        get: function() {
                            return this.photoItem.devices.some((function(t) {
                                return 3 === t.type
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getIsMobile", {
                        get: function() {
                            return this.photoItem.devices.some((function(t) {
                                return 2 === t.type
                            }))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.showModal = function() {
                        var t = this;
                        setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "card_wallpaper_rog",
                                event_category_DL: "card/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.photoItem.name, "/sorting/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200), this.setWallpaperModal(this.photoItem), this.$emit("showModal", this.photoItem)
                    }, e.prototype.getQueryVariable = function(t) {
                        var e = "";
                        if ("undefined" != typeof window)
                            for (var n = 0, o = window.location.search.substring(1).toLowerCase().split("&"); n < o.length; n++) {
                                var r = o[n].split("=");
                                if (decodeURIComponent(r[0]).toLowerCase() === t.toLowerCase()) {
                                    e = decodeURIComponent(r[1]);
                                    break
                                }
                            }
                        return e
                    }, e.prototype.mounted = function() {
                        "" !== this.getQueryVariable("wId") && this.showModal()
                    }, f([Object(l.Action)("setWallpaperModal")], e.prototype, "setWallpaperModal", void 0), f([Object(l.Getter)("translation")], e.prototype, "translation", void 0), f([Object(l.Prop)({
                        default: []
                    })], e.prototype, "photoItem", void 0), f([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "photoIndex", void 0), e = f([Object(l.Component)({
                        components: {
                            StarRating: c.a,
                            WallpaperDownloadButton: _.a
                        }
                    })], e)
                }(l.Vue),
                h = v,
                w = n(1207),
                y = n(25);
            var component = Object(y.a)(h, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("li", {
                    class: t.$style.wpListItem,
                    on: {
                        mouseenter: function(e) {
                            t.isOpen = !0
                        },
                        mouseleave: function(e) {
                            t.isOpen = !1
                        }
                    }
                }, [e("div", {
                    class: t.$style.wpItemImageIcon
                }, [e("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M21 17.01V4H3V20H18.01L21 17.01ZM2 3H22V17.42L18.42 21H2V3ZM11 8C11 9.10457 10.1046 10 9 10C7.89543 10 7 9.10457 7 8C7 6.89543 7.89543 6 9 6C10.1046 6 11 6.89543 11 8ZM7.57 18H4L8.58 12.3L10.37 14.52L7.82 17.69L7.57 18ZM19 15.88V13.6L15.6 9.37L8.64001 18H16.88L19 15.88Z",
                        fill: "white"
                    }
                })]), t._v(" "), t._e()]), t._v(" "), e("img", {
                    class: t.$style.wpImage,
                    attrs: {
                        src: t.photoItem.thumbnail,
                        alt: ""
                    },
                    on: {
                        click: function(e) {
                            return t.showModal()
                        }
                    }
                }), t._v(" "), e("div", {
                    class: t.$style.wpItemContent
                }, [e("div", {
                    class: t.$style.categoryName
                }, [e("svg", {
                    attrs: {
                        width: "14",
                        height: "14",
                        viewBox: "0 0 14 14",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M4 2H6L2 12H0L4 2Z",
                        fill: "#FF1929"
                    }
                }), t._v(" "), e("path", {
                    attrs: {
                        d: "M8 2H10L6 12H4L8 2Z",
                        fill: "#FF1929"
                    }
                }), t._v(" "), e("path", {
                    attrs: {
                        d: "M12 2H14L10 12H8L12 2Z",
                        fill: "#FF1929"
                    }
                })]), t._v(" "), e("p", [t._v(t._s(t.photoItem.category))]), t._v(" "), e("ul", {
                    class: t.$style.wpItemDeviceList
                }, [t.getIsDesktop ? e("li", [e("svg", {
                    attrs: {
                        width: "20",
                        height: "20",
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M1.00034 5.66683L4.48775 2L19.0006 2L19.0002 11.6667L16.0002 15H11.25L11.2502 17H15.4168L16.2502 18H10.0002H3.75017L4.58351 17H8.75017L8.75001 15H1L1.00034 5.66683ZM15.4877 14L18.0002 11.1542L18.0005 3H5.00034L2.0005 6.01266L2.00016 14H15.4877Z",
                        fill: "white"
                    }
                })])]) : t._e(), t._v(" "), t.getIsMobile ? e("li", [e("svg", {
                    attrs: {
                        width: "20",
                        height: "20",
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M7.5 1L5 3.5V19H13L15 16.5V1H7.5ZM7.33333 18V17.0833H11.5V18H7.33333ZM14 15.6542L13.6542 16H6V4L8.0125 2H14V15.6542Z",
                        fill: "white"
                    }
                })])]) : t._e(), t._v(" "), t.getIsDuo ? e("li", [e("svg", {
                    attrs: {
                        width: "20",
                        height: "20",
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M17.5 2.5V10.8818L17.1914 11.5H4.5V5.20703L7.20703 2.5H17.5Z",
                        stroke: "white"
                    }
                }), t._v(" "), e("path", {
                    attrs: {
                        d: "M17.251 11.5L14.7568 17.5H1.75879L4.33008 11.5H17.251Z",
                        stroke: "white"
                    }
                }), t._v(" "), e("rect", {
                    attrs: {
                        x: "2",
                        y: "16",
                        width: "13",
                        height: "1",
                        fill: "white"
                    }
                })])]) : t._e()])]), t._v(" "), e("div", {
                    class: t.$style.wpItemName
                }, [e("p", [t._v(t._s(t.photoItem.name))])]), t._v(" "), e("div", {
                    class: t.$style.wpItemDownloadContent
                }, [e("div", [e("span", {
                    class: t.$style.downloadTimes
                }, [t._v(t._s(t.photoItem.download))]), t._v(" "), e("span", {
                    class: t.$style.downloadTimes
                }, [t._v("Downloads")])]), t._v(" "), e("WallpaperDownloadButton", {
                    attrs: {
                        photoObj: t.photoItem,
                        deviceItem: t.photoItem.devices
                    }
                })], 1)]), t._v(" "), e("div", {
                    class: t.$style.corner1
                }), t._v(" "), e("div", {
                    class: t.$style.corner2
                }), t._v(" "), e("div", {
                    class: t.$style.corner3
                }), t._v(" "), e("div", {
                    class: t.$style.corner4
                })])
            }), [], !1, (function(t) {
                this.$style = w.default.locals || w.default
            }), null, null);
            e.a = component.exports
        },
        952: function(t, e, n) {
            "use strict";
            var o, r = n(2),
                l = (n(26), n(9)),
                c = (n(54), n(41), n(10), n(32), n(59), n(20), n(22)),
                _ = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                d = function(t, e, n, desc) {
                    var o, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (c = (r < 3 ? o(c) : r > 3 ? o(e, n, c) : o(e, n)) || c);
                    return r > 3 && c && Object.defineProperty(e, n, c), c
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.tabType = "desktop", e.tabNumber = 1, e.isOpen = !1, e.deviceList = [], e
                    }
                    return _(e, t), e.prototype.deviceListHandler = function(t) {
                        var e = this;
                        this.deviceItem.forEach((function(n) {
                            n.type === t && (e.deviceList = n.images, e.tabNumber = t)
                        }))
                    }, e.prototype.downloadHandler = function(t) {
                        var e = this,
                            n = [];
                        t.dlUrl && n.push(t.dlUrl), t.ddlUrl && n.push(t.ddlUrl), 0 !== n.length && (n.forEach((function(t, n) {
                            setTimeout((function() {
                                var link = document.createElement("a");
                                link.href = t, link.target = "_blank", link.rel = "noopener noreferrer", link.download = e.photoObj.name, link.style.display = "none", document.body.appendChild(link), link.click(), document.body.removeChild(link)
                            }), 1e3 * n)
                        })), "modal" === this.type ? setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "resolution_download_lightbox_wallpaper_rog",
                                event_category_DL: "download/lightbox/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.width, " x ").concat(t.high, "/download/").concat(e.photoObj.name, "/lightbox/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "resolution_download_card_wallpaper_rog",
                                event_category_DL: "download/card/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t.width, " x ").concat(t.high, "/download/").concat(e.photoObj.name, "/card/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200), this.getWallpaperDownload({
                            wId: this.photoObj.wId
                        }))
                    }, e.prototype.openMobileHandler = function() {
                        var t = this;
                        window.innerWidth > 1024 || (this.isOpen = !this.isOpen, this.isOpen && ("modal" === this.type ? setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "download_lightbox_wallpaper_rog",
                                event_category_DL: "download/lightbox/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "download/".concat(t.photoObj.name, "/lightbox/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "download_card_wallpaper_rog",
                                event_category_DL: "download/card/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "download/".concat(t.photoObj.name, "/card/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200)))
                    }, e.prototype.openHandler = function() {
                        var t = this;
                        window.innerWidth <= 1024 || (this.isOpen = !this.isOpen, this.isOpen && ("modal" === this.type ? setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "download_lightbox_wallpaper_rog",
                                event_category_DL: "download/lightbox/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "download/".concat(t.photoObj.name, "/lightbox/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_name_ga4: "download_card_wallpaper_rog",
                                event_category_DL: "download/card/wallpaper/rog",
                                event_action_DL: "clicked",
                                event_label_DL: "download/".concat(t.photoObj.name, "/card/wallpaper/rog"),
                                event_value_DL: 0
                            })
                        }), 200)))
                    }, e.prototype.mounted = function() {
                        this.deviceListHandler(this.tabNumber), 1 === this.deviceItem.length && (this.tabNumber = this.deviceItem[0].type, this.deviceList = this.deviceItem[0].images)
                    }, d([Object(c.Action)("getWallpaperDownload")], e.prototype, "getWallpaperDownload", void 0), d([Object(c.Getter)("translation")], e.prototype, "translation", void 0), d([Object(c.Prop)()], e.prototype, "photoObj", void 0), d([Object(c.Prop)()], e.prototype, "deviceItem", void 0), d([Object(c.Prop)({
                        default: "card"
                    })], e.prototype, "type", void 0), e = d([Object(c.Component)({
                        components: {}
                    })], e)
                }(c.Vue),
                v = f,
                h = n(1206),
                w = n(25);
            var component = Object(w.a)(v, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.downloadButtonWrapper,
                    on: {
                        mouseenter: function(e) {
                            return t.openHandler()
                        },
                        mouseleave: function(e) {
                            return t.openHandler()
                        },
                        click: function(e) {
                            return e.preventDefault(), t.openMobileHandler()
                        }
                    }
                }, [e("button", {
                    class: [t.$style.downloadButton, Object(r.a)({}, t.$style.open, !0 === t.isOpen)],
                    attrs: {
                        type: "button"
                    }
                }, [e("span", [t._v(t._s(t.translation.Downlaod))]), t._v(" "), e("svg", {
                    attrs: {
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M6 9.55L1 4.55V2.5L6 7.5L11 2.5V4.55L6 9.55Z",
                        fill: "white"
                    }
                })])]), t._v(" "), e("div", {
                    class: [t.$style.deviceDropMenu, Object(r.a)({}, t.$style.open, !0 === t.isOpen)]
                }, [e("ul", {
                    class: t.$style.deviceTabs
                }, t._l(t.deviceItem, (function(n, o) {
                    return e("li", {
                        key: o,
                        class: [Object(r.a)({}, t.$style.active, t.tabNumber === n.type)],
                        style: "order:".concat(n.type, ";"),
                        on: {
                            click: function(e) {
                                return t.deviceListHandler(n.type)
                            }
                        }
                    }, [e("span", [t._v("\n             " + t._s(n.name) + "\n          ")])])
                })), 0), t._v(" "), e("div", {
                    class: t.$style.deviceTabContent
                }, [e("ul", t._l(t.deviceList, (function(n, o) {
                    return e("li", {
                        key: o,
                        on: {
                            click: function(e) {
                                return t.downloadHandler(n)
                            }
                        }
                    }, [e("p", [t._v(t._s(n.width) + ", " + t._s(n.high) + " (" + t._s(n.ratio) + ")")])])
                })), 0)])])])
            }), [], !1, (function(t) {
                this.$style = h.default.locals || h.default
            }), null, null);
            e.a = component.exports
        },
        957: function(t, e, n) {
            "use strict";
            var o, r = n(9),
                l = (n(54), n(41), n(10), n(22)),
                c = (o = function(t, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, o(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    o(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, n, desc) {
                    var o, l = arguments.length,
                        c = l < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, n, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(o = t[i]) && (c = (l < 3 ? o(c) : l > 3 ? o(e, n, c) : o(e, n)) || c);
                    return l > 3 && c && Object.defineProperty(e, n, c), c
                },
                d = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.hoverValue = 0, e.selectedRating = 0, e.starImages = {
                            default: n(1202),
                            half: n(1203),
                            filled: n(1204)
                        }, e
                    }
                    return c(e, t), e.prototype.mounted = function() {}, e.prototype.updateStarStatus = function() {
                        this.$emit("updateStarStatus", !1)
                    }, e.prototype.selectRating = function() {
                        this.selectedRating = this.hoverValue, this.hoverValue = 0, this.$emit("ratingStar", this.selectedRating), this.updateStarStatus()
                    }, e.prototype.getStarImage = function(t) {
                        var e = this.hoverValue,
                            n = "filled",
                            o = "half",
                            r = "default",
                            l = e ? e >= t ? n : e >= t - .5 ? o : r : this.selectedRating >= t ? n : this.selectedRating >= t - .5 ? o : r;
                        return this.starImages[l]
                    }, e.prototype.updateHoverValue = function(t, e) {
                        var rect = t.target.getBoundingClientRect(),
                            n = (t.clientX - rect.left) / rect.width;
                        this.hoverValue = n >= .5 ? e : e - .5
                    }, e.prototype.clearHoverValue = function() {
                        this.hoverValue = 0
                    }, e = _([Object(l.Component)({
                        components: {}
                    })], e)
                }(l.Vue),
                f = d,
                v = n(1205),
                h = n(25);
            var component = Object(h.a)(f, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.starRating
                }, t._l(5, (function(n) {
                    return e("div", {
                        key: n,
                        class: t.$style.starWrapper,
                        on: {
                            mousemove: function(e) {
                                return t.updateHoverValue(e, n)
                            },
                            mouseleave: t.clearHoverValue,
                            click: t.selectRating
                        }
                    }, [e("img", {
                        class: t.$style.starImg,
                        attrs: {
                            src: t.getStarImage(n),
                            alt: ""
                        }
                    })])
                })), 0)
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        970: function(t, e, n) {
            "use strict";
            var o = n(705),
                r = n.n(o);
            n.d(e, "default", (function() {
                return r.a
            }))
        }
    }
]);