(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [16], {
        144: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(26), o(9)),
                l = (o(54), o(41), o(10), o(60), o(20), o(3)),
                d = o(7),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                w = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                _ = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            if (this.routeInfo) return this.routeInfo.websitePath, this.routeInfo.websitePath
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "buttonLink", {
                        get: function() {
                            return this.buttonData.link ? this.buttonData.link : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "linkTarget", {
                        get: function() {
                            return this.isDownload ? "_blank" : "_self"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getBrandAssistantGetStatusExpend", {
                        get: function() {
                            if ("undefined" != typeof window) return "function" == typeof(null === window || void 0 === window ? void 0 : window.brandAssistantGetStatus) && window.brandAssistantGetStatus().expand
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "goToSpecUrl", {
                        get: function() {
                            if (this.isProductLineStatus || this.isProductPage) return this.isProductPage, "".concat(this.productLink, "spec/");
                            if (this.isArticle) return "".concat(this.productLink, "spec/");
                            var t = "",
                                area = this.$route.params.area ? this.$route.params.area : "",
                                e = area ? "/".concat(area) : "";
                            return this.$route.params.modelPath ? t = "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.modelPath, "-model/spec/") : this.$route.params.noModelPath ? t = this.$route.params.groupSeries && this.$route.params.productSeries ? "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.groupSeries, "/").concat(this.$route.params.productSeries, "/").concat(this.$route.params.noModelPath, "/spec/") : this.$route.params.groupSeries ? "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.groupSeries, "/").concat(this.$route.params.noModelPath, "/spec/") : this.$route.params.productSeries ? "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.productSeries, "/").concat(this.$route.params.noModelPath, "/spec/") : "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.noModelPath, "/spec/") : this.$route.params.seriesPath && (t = "".concat(e, "/").concat(this.$route.params.productLine, "/").concat(this.$route.params.groupSeries, "/").concat(this.$route.params.seriesPath, "-series/spec/")), "" !== t ? t : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.seriesPage = function() {
                        return this.$route.params.series ? "/".concat(this.$route.params.series, "-series") : ""
                    }, e.prototype.buttonRedCallEvent = function(t) {
                        var e = this.buttonData.disabled ? "disabled" : "default";
                        if (this.buttonData.isExternalLink) - 1 === this.buttonLink.indexOf(".asus.com") ? (t.preventDefault(), this.$emit("click", e)) : this.isDownload && window.open(this.buttonLink, "_blank");
                        else if (this.getAIStatus && this.buttonLink && !this.isViewMyProduct && !this.isGoToSpec) window.open(this.buttonLink, "_blank");
                        else if (!this.isDownload && this.buttonLink) {
                            if (this.updateDownButton) return void this.$emit("click", this.buttonData.link);
                            if (this.isWhereToBuy && window.open(this.buttonLink, "_blank"), this.isGoToSpec) return void(this.isL2 || this.isArticle ? window.location.assign("".concat(this.goToSpecUrl)) : (this.isProductPage ? window.location.assign("".concat(this.goToSpecUrl)) : -1 !== window.location.href.indexOf("spec") ? window.location.reload() : this.$router.push({
                                path: "".concat(this.goToSpecUrl)
                            }), this.$emit("click", e)));
                            if (!this.isGoToSpec && this.isModel) return this.$emit("click", e), void window.location.assign(this.buttonLink);
                            if (this.isStore && this.isModel) return void this.$emit("click", e);
                            if (this.isECCustomize) return void this.$emit("gaTrigger");
                            this.isStore && this.$emit("gaTrigger"), this.isSpecStore && this.$emit("gaTrigger"), this.isRogSite || this.isWhereToBuy || (this.isNewTab ? window.open(this.buttonLink) : (this.isGA && this.gaHandler(), window.location.assign(this.buttonLink)))
                        } else if (this.isDownload) return void this.$emit("click");
                        this.$emit("click", e)
                    }, e.prototype.gaHandler = function() {
                        window.dataLayer && window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "header-mini_cart-L2",
                            event_action_DL: "clicked",
                            event_label_DL: this.buttonData.name,
                            event_value_DL: "0"
                        })
                    }, w([Object(d.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), w([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), w([Object(l.Prop)()], e.prototype, "buttonData", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isFullWidthStatus", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isMaxWidth", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isFilter", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isShort", void 0), w([Object(l.Prop)({
                        default: !0
                    })], e.prototype, "isRogSite", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isModel", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isNewTab", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isDownload", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isWhereToBuy", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isStore", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSpecStore", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isBuy", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isMiniCartButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isEliteButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSearchButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isGA", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isSpecButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isGoToSpec", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isProductListButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isPassPortCard", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isEliteModelButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isFilterPrice", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "updateDownButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isBlackBackground", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isECCustomize", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isCrmButton", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isProductLineStatus", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isL2", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isProductPage", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isArticle", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isViewMyProduct", void 0), w([Object(l.Prop)({
                        default: ""
                    })], e.prototype, "productLink", void 0), w([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "noLink", void 0), e = w([Object(l.Component)({})], e)
                }(l.Vue),
                f = _,
                y = o(389),
                v = o(25);
            var component = Object(v.a)(f, (function() {
                var t, e, o, n = this,
                    c = n._self._c;
                n._self._setupProxy;
                return c("div", {
                    class: [n.$style.redFullButton, (t = {}, Object(r.a)(t, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(t, n.$style.isProductListButton, n.isProductListButton), Object(r.a)(t, n.$style.isFilterPrice, n.isFilterPrice), Object(r.a)(t, n.$style.isProductBarButton, n.isModel), Object(r.a)(t, n.$style.isProductLineStatus, n.isProductLineStatus), t)]
                }, ["" === n.buttonLink || n.noLink ? [c("div", {
                    staticClass: "btn",
                    class: [n.$style.btnRed, n.$style.isFull, (o = {}, Object(r.a)(o, n.$style.disabled, n.buttonData.disabled), Object(r.a)(o, n.$style.isFullWidth, n.isFullWidthStatus), Object(r.a)(o, n.$style.maxWidth, n.isMaxWidth), Object(r.a)(o, n.$style.isFilter, n.isFilter), Object(r.a)(o, n.$style.updateDownButton, n.updateDownButton), Object(r.a)(o, n.$style.isShort, n.isShort), Object(r.a)(o, n.$style.modelButton, n.isModel), Object(r.a)(o, n.$style.isWTB, n.isWhereToBuy), Object(r.a)(o, n.$style.storeButton, n.isStore), Object(r.a)(o, n.$style.specStoreButton, n.isSpecStore), Object(r.a)(o, n.$style.miniCartButton, n.isMiniCartButton), Object(r.a)(o, n.$style.isEliteButton, n.isEliteButton), Object(r.a)(o, n.$style.isSearchButton, n.isSearchButton), Object(r.a)(o, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(o, n.$style.isGoToSpec, n.isGoToSpec), Object(r.a)(o, n.$style.isFilterPrice, n.isFilterPrice), Object(r.a)(o, n.$style.isECCustomize, n.isECCustomize), Object(r.a)(o, n.$style.isProductLineStatus, n.isProductLineStatus), Object(r.a)(o, n.$style.isBlackBackground, n.isBlackBackground), Object(r.a)(o, n.$style.isCrmButton, n.isCrmButton), o)],
                    attrs: {
                        role: n.buttonData.role ? n.buttonData.role : "button",
                        "aria-label": n.buttonData.ariaLabel,
                        tabindex: n.buttonData.disabled ? -1 : 0
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && n._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : n.buttonRedCallEvent.apply(null, arguments)
                        },
                        click: n.buttonRedCallEvent
                    }
                }, [c("div", {
                    staticClass: "buttonClick",
                    class: n.$style.inner
                }, [c("span", {
                    staticClass: "buttonClick"
                }, [n.buttonData.isVideo ? c("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "icon-triangle-right",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [c("path", {
                    attrs: {
                        d: "M26.7 15.24L6 3v26l20.7-12.23L28 16l-1.3-.76z"
                    }
                })]) : n._e(), n._v(" "), n.buttonData.isExternalLink ? c("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "icon-external-link",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [c("path", {
                    attrs: {
                        d: "M16 23.9H1c-.5 0-.9-.4-.9-.9V8c0-.5.4-.9.9-.9h8c.5 0 .9.4.9.9s-.4.9-.9.9H1.9v13.3h13.3V15c0-.5.4-.9.9-.9s.9.4.9.9v8c-.1.5-.5.9-1 .9z"
                    }
                }), c("path", {
                    attrs: {
                        d: "M8 16.9c-.2 0-.4-.1-.6-.3-.3-.3-.3-.9 0-1.2l11-11c.3-.3.9-.3 1.2 0 .3.3.3.9 0 1.2l-11 11c-.2.2-.4.3-.6.3z"
                    }
                }), c("path", {
                    attrs: {
                        d: "M19 11.9c-.5 0-.9-.4-.9-.9V5.9H13c-.5 0-.9-.4-.9-.9s.4-.9.9-.9h6c.5 0 .9.4.9.9v6c0 .5-.4.9-.9.9z"
                    }
                })]) : n._e(), n._v("\n          " + n._s(n.buttonData.name) + "\n        ")])]), n._v(" "), c("div", {
                    staticClass: "buttonClick",
                    class: n.$style.hoverColor
                })])] : [c("a", {
                    staticClass: "btn",
                    class: [n.$style.btnRed, n.$style.isFull, (e = {}, Object(r.a)(e, n.$style.disabled, n.buttonData.disabled), Object(r.a)(e, n.$style.isFullWidth, n.isFullWidthStatus), Object(r.a)(e, n.$style.maxWidth, n.isMaxWidth), Object(r.a)(e, n.$style.isFilter, n.isFilter), Object(r.a)(e, n.$style.updateDownButton, n.updateDownButton), Object(r.a)(e, n.$style.isShort, n.isShort), Object(r.a)(e, n.$style.modelButton, n.isModel), Object(r.a)(e, n.$style.isWTB, n.isWhereToBuy), Object(r.a)(e, n.$style.storeButton, n.isStore), Object(r.a)(e, n.$style.specStoreButton, n.isSpecStore), Object(r.a)(e, n.$style.miniCartButton, n.isMiniCartButton), Object(r.a)(e, n.$style.isEliteButton, n.isEliteButton), Object(r.a)(e, n.$style.isSearchButton, n.isSearchButton), Object(r.a)(e, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(e, n.$style.isGoToSpec, n.isGoToSpec), Object(r.a)(e, n.$style.isDownload, n.isDownload), Object(r.a)(e, n.$style.isPassPortCard, n.isPassPortCard), Object(r.a)(e, n.$style.isFilterPrice, n.isFilterPrice), Object(r.a)(e, n.$style.isECCustomize, n.isECCustomize), Object(r.a)(e, n.$style.isProductLineStatus, n.isProductLineStatus), Object(r.a)(e, n.$style.isBlackBackground, n.isBlackBackground), Object(r.a)(e, n.$style.isCrmButton, n.isCrmButton), e)],
                    attrs: {
                        tabindex: n.buttonData.disabled ? -1 : 0,
                        href: n.isGoToSpec ? "".concat(n.goToSpecUrl) : n.buttonLink,
                        target: n.getAIStatus ? "_blank" : n.linkTarget,
                        rel: n.getAIStatus ? "noopener noreferrer" : ""
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), n.buttonRedCallEvent.apply(null, arguments)
                        }
                    }
                }, [c("div", {
                    class: n.$style.inner
                }, [n.buttonData && n.buttonData.name ? c("span", {
                    staticClass: "buttonName",
                    class: [Object(r.a)({}, n.$style.smallFont, n.buttonData.name.length > 16)]
                }, [n.buttonData.isVideo ? c("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "icon-triangle-right",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [c("path", {
                    attrs: {
                        d: "M26.7 15.24L6 3v26l20.7-12.23L28 16l-1.3-.76z"
                    }
                })]) : n._e(), n._v("\n          " + n._s(n.buttonData.name) + "\n          "), n.buttonData.isExternalLink ? c("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 24 24",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "icon-external-link",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [c("path", {
                    attrs: {
                        d: "M16 23.9H1c-.5 0-.9-.4-.9-.9V8c0-.5.4-.9.9-.9h8c.5 0 .9.4.9.9s-.4.9-.9.9H1.9v13.3h13.3V15c0-.5.4-.9.9-.9s.9.4.9.9v8c-.1.5-.5.9-1 .9z"
                    }
                }), c("path", {
                    attrs: {
                        d: "M8 16.9c-.2 0-.4-.1-.6-.3-.3-.3-.3-.9 0-1.2l11-11c.3-.3.9-.3 1.2 0 .3.3.3.9 0 1.2l-11 11c-.2.2-.4.3-.6.3z"
                    }
                }), c("path", {
                    attrs: {
                        d: "M19 11.9c-.5 0-.9-.4-.9-.9V5.9H13c-.5 0-.9-.4-.9-.9s.4-.9.9-.9h6c.5 0 .9.4.9.9v6c0 .5-.4.9-.9.9z"
                    }
                })]) : n._e()]) : n._e()]), n._v(" "), c("div", {
                    class: n.$style.hoverColor
                })])]], 2)
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        176: function(t, e, o) {
            t.exports = {
                dropDownMenuContainer: "headerDropDownMenuList__dropDownMenuContainer__YLTOW",
                dropDownContent: "headerDropDownMenuList__dropDownContent__ST5-y",
                secondDropDownContent: "headerDropDownMenuList__secondDropDownContent__d3MH4",
                dropDownOList: "headerDropDownMenuList__dropDownOList__fhuH4",
                dropDownOListProduct: "headerDropDownMenuList__dropDownOListProduct__BBZkj",
                listItem: "headerDropDownMenuList__listItem__oI1sA",
                menuLink: "headerDropDownMenuList__menuLink__rP4dY",
                otherMenuList: "headerDropDownMenuList__otherMenuList__PC7GC",
                listCategory: "headerDropDownMenuList__listCategory__fXSm4",
                subDetailLink: "headerDropDownMenuList__subDetailLink__LTgQS",
                headerItemName: "headerDropDownMenuList__headerItemName__4QDPV",
                subDetailLinkItem: "headerDropDownMenuList__subDetailLinkItem__Ua73j",
                subDetailBlock: "headerDropDownMenuList__subDetailBlock__Ig+kU",
                mobileMenuList: "headerDropDownMenuList__mobileMenuList__ViGBt",
                mobileActived: "headerDropDownMenuList__mobileActived__A1Jik",
                show: "headerDropDownMenuList__show__V8x2d",
                dropDownBack: "headerDropDownMenuList__dropDownBack__ooso9"
            }
        },
        177: function(t, e, o) {
            t.exports = {
                dropDownMenuContainer: "headerMobileDropDownMenuList__dropDownMenuContainer__j-c+y",
                dropDownContent: "headerMobileDropDownMenuList__dropDownContent__R2khZ",
                secondDropDownContent: "headerMobileDropDownMenuList__secondDropDownContent__hkn87",
                dropDownOList: "headerMobileDropDownMenuList__dropDownOList__2dFCN",
                dropDownOListProduct: "headerMobileDropDownMenuList__dropDownOListProduct__lD1AA",
                listItem: "headerMobileDropDownMenuList__listItem__HcMbT",
                menuLink: "headerMobileDropDownMenuList__menuLink__Lp44r",
                otherMenuList: "headerMobileDropDownMenuList__otherMenuList__d9v6x",
                listCategory: "headerMobileDropDownMenuList__listCategory__Dqwzs",
                subDetailLink: "headerMobileDropDownMenuList__subDetailLink__wdKCe",
                headerItemName: "headerMobileDropDownMenuList__headerItemName__OKUms",
                subDetailLinkItem: "headerMobileDropDownMenuList__subDetailLinkItem__Yg5mw",
                subDetailBlock: "headerMobileDropDownMenuList__subDetailBlock__8Hwru",
                mobileMenuList: "headerMobileDropDownMenuList__mobileMenuList__JdbNn",
                mobileActived: "headerMobileDropDownMenuList__mobileActived__zLHeT",
                show: "headerMobileDropDownMenuList__show__faezu",
                dropDownBack: "headerMobileDropDownMenuList__dropDownBack__Zd2YE"
            }
        },
        178: function(t, e, o) {
            t.exports = {
                personalWrapper: "headerPersonalBlock__personalWrapper__N2xAS",
                accountButton: "headerPersonalBlock__accountButton__y2X2l",
                isLogin: "headerPersonalBlock__isLogin__zviqO",
                isActivity: "headerPersonalBlock__isActivity__vT9CI",
                isRed: "headerPersonalBlock__isRed__pfks7",
                personalDropDownMenu: "headerPersonalBlock__personalDropDownMenu__2qxFK",
                accountLinkSection: "headerPersonalBlock__accountLinkSection__oPr3f",
                isMenuShow: "headerPersonalBlock__isMenuShow__yyrxX",
                dropDownLink: "headerPersonalBlock__dropDownLink__-s275",
                wishlist: "headerPersonalBlock__wishlist__68ycq",
                lastItem: "headerPersonalBlock__lastItem__IgpHb",
                isLoginStatus: "headerPersonalBlock__isLoginStatus__IzTlz",
                accountInfo: "headerPersonalBlock__accountInfo__U6dZZ",
                accountName: "headerPersonalBlock__accountName__lfMMX",
                accountPoints: "headerPersonalBlock__accountPoints__m2ChJ",
                dropDownBar: "headerPersonalBlock__dropDownBar__kOTGs",
                linkSectionLink: "headerPersonalBlock__linkSectionLink__6GeaP",
                accountIcon: "headerPersonalBlock__accountIcon__9OEDW"
            }
        },
        180: function(t, e, o) {
            t.exports = {
                redFullButton: "ButtonRed__redFullButton__0lMzl",
                isProductListButton: "ButtonRed__isProductListButton__1rCeF",
                isSpecButton: "ButtonRed__isSpecButton__yraDR",
                isFilterPrice: "ButtonRed__isFilterPrice__-fvAf",
                isProductBarButton: "ButtonRed__isProductBarButton__qIAJB",
                isProductLineStatus: "ButtonRed__isProductLineStatus__yNgyK",
                btnRed: "ButtonRed__btnRed__SXGza",
                maxWidth: "ButtonRed__maxWidth__D1j8R",
                hoverColor: "ButtonRed__hoverColor__0DIt8",
                isFilter: "ButtonRed__isFilter__EzHBw",
                inner: "ButtonRed__inner__U++OE",
                updateDownButton: "ButtonRed__updateDownButton__38MtC",
                miniCartButton: "ButtonRed__miniCartButton__9xdbF",
                disabled: "ButtonRed__disabled__Q+k5e",
                isFull: "ButtonRed__isFull__6Glcz",
                isBlackBackground: "ButtonRed__isBlackBackground__DYvJe",
                isCrmButton: "ButtonRed__isCrmButton__-qqmC",
                isFullWidth: "ButtonRed__isFullWidth__T36mv",
                modelButton: "ButtonRed__modelButton__tDIKt",
                isECCustomize: "ButtonRed__isECCustomize__ockGJ",
                isWTB: "ButtonRed__isWTB__7HuK9",
                isBuy: "ButtonRed__isBuy__gmq8Z",
                isEliteButton: "ButtonRed__isEliteButton__wCkD1",
                isSearchButton: "ButtonRed__isSearchButton__NOBd1",
                storeButton: "ButtonRed__storeButton__KCNOS",
                isShort: "ButtonRed__isShort__sbOeL",
                specStoreButton: "ButtonRed__specStoreButton__crNM+",
                isDownload: "ButtonRed__isDownload__Y0O2W",
                smallFont: "ButtonRed__smallFont__LQtGu",
                isPassPortCard: "ButtonRed__isPassPortCard__fbx2I"
            }
        },
        182: function(t, e, o) {
            t.exports = {
                closeLightBox: "Advertising__closeLightBox__JBDmh",
                AdvertisingActivityWrapper: "Advertising__AdvertisingActivityWrapper__HnaJt",
                AdvertisingActivityContent: "Advertising__AdvertisingActivityContent__u2sHr",
                youtubeContent: "Advertising__youtubeContent__Z5Fuk",
                AdsWrapper: "Advertising__AdsWrapper__ghBXB",
                active: "Advertising__active__ynQY8",
                desktopSize: "Advertising__desktopSize__eCuBD",
                mobileSize: "Advertising__mobileSize__6Cv6l"
            }
        },
        385: function(t, e, o) {
            "use strict";
            var n = o(176),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        386: function(t, e, o) {
            "use strict";
            var n = o(177),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        387: function(t, e, o) {
            "use strict";
            var n = o(178),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        389: function(t, e, o) {
            "use strict";
            var n = o(180),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        391: function(t, e, o) {
            "use strict";
            var n = o(182),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        491: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(20), o(26), o(51), o(60), o(9)),
                l = (o(54), o(41), o(10), o(28), o(44), o(91), o(18), o(33), o(145), o(32), o(59), o(73), o(3)),
                d = o(7),
                h = o(16),
                w = o.n(h),
                _ = o(102),
                f = o(36),
                y = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                v = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.navSubNestedItemSplitNum = 9, e.websiteInfo = new _.a, e
                    }
                    return y(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t, e = "";
                            return Object.keys(this.routeInfo).length > 0 ? e = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.websitePath : "undefined" != typeof window && (null === window || void 0 === window ? void 0 : window.AsusAPIConfig) && (e = window.AsusAPIConfig.websitePath), e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "bottomMenu", {
                        get: function() {
                            var t = this.dropDownVal.items.filter((function(t) {
                                return "bottom" === t.class
                            }));
                            return t.length > 0 ? t[0] : null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.urlReplace = function(t) {
                        for (var e = [], o = "localhost:8000" === window.location.host ? "https://dev-rog.asus.com" : encodeURI(window.location.origin), n = 0, r = f.b; n < r.length; n++) {
                            var c = r[n];
                            new RegExp(c).test(t) && (e = t.split(o))
                        }
                        return e.length > 1 ? e[1] : null
                    }, e.prototype.linkClick = function(t) {
                        var e, o, n = Object(f.a)(),
                            r = this.urlReplace(t.link);
                        if (t || t.link)
                            if (n && r && this.$route) {
                                if (this.gaSetting(t.class, t.name), "object" === Object(c.a)(window._satellite) && window._satellite.track("spa-pageview"), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                                        shouldTrackUrlChange: function(t, e) {
                                            return t && e
                                        }
                                    }]), "product" === (null === (o = null === (e = this.$route) || void 0 === e ? void 0 : e.meta) || void 0 === o ? void 0 : o.layout)) return void window.open(t.link, t.linkTarget);
                                if (-1 === t.link.indexOf("group")) return void window.open(t.link, t.linkTarget);
                                window.location.href = t.link, this.$emit("closeAction")
                            } else this.gaSetting(t.class, t.name), window.location = t.link
                    }, e.prototype.changeUrl = function(t) {
                        var e = t.split("/"),
                            o = "";
                        return e.forEach((function(t) {
                            t.length > 0 && (o = o + "/" + t)
                        })), o.toLowerCase()
                    }, e.prototype.linkClickNoRouterPush = function(t) {
                        (t || t.link) && (this.gaNoRoutePushSetting(t.name), window.open(t.link, t.linkTarget))
                    }, e.prototype.createLink = function(t) {
                        if (t || t.link) return t.link
                    }, e.prototype.menuMouseLeave = function() {
                        this.$emit("leaveSubMenu", {
                            leave: !0
                        })
                    }, e.prototype.menuMouseOver = function() {
                        this.$emit("enterSubMenu", {
                            leave: !1
                        })
                    }, e.prototype.mobilePrev = function() {
                        this.$emit("mobileSubMenu")
                    }, e.prototype.splitSubNestedItemSplitVal = function(t) {
                        return w.a.chunk(t, this.navSubNestedItemSplitNum)
                    }, e.prototype.gaSetting = function(t, e) {
                        var o = this;
                        setTimeout((function() {
                            if ("rog.asus.com.cn" === window.location.host) {
                                if (!window._hmt) return;
                                window._hmt.push(["_trackEvent", "header-".concat(o.dropDownVal.Class, "-L2"), "clicked", "".concat(t, "-").concat(e)])
                            } else window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-".concat(o.dropDownVal.Class, "-L2"),
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "-").concat(e),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "header-".concat(o.dropDownVal.Class, "-L2"),
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t, "-").concat(e),
                                    event_value_DL: "0"
                                })
                            }), 200))
                        }), 200)
                    }, e.prototype.gaNoRoutePushSetting = function(t) {
                        var e = this;
                        if ("rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "header-".concat(this.dropDownVal.Class, "-L2"), "clicked", t])
                        } else window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "header-".concat(this.dropDownVal.Class, "-L2"),
                            event_action_DL: "clicked",
                            event_label_DL: t,
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-".concat(e.dropDownVal.Class, "-L2"),
                                event_action_DL: "clicked",
                                event_label_DL: t,
                                event_value_DL: "0"
                            })
                        }), 200))
                    }, v([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), v([Object(l.Prop)({
                        default: null
                    })], e.prototype, "dropDownVal", void 0), v([Object(l.Prop)({
                        type: String,
                        default: "default"
                    })], e.prototype, "dropDownType", void 0), v([Object(l.Prop)({
                        default: null
                    })], e.prototype, "headerBlockPosition", void 0), v([Object(l.Prop)({
                        default: null
                    })], e.prototype, "headerListBlockPosition", void 0), v([Object(l.Prop)({
                        type: Boolean,
                        default: !1
                    })], e.prototype, "isMobile", void 0), v([Object(l.Prop)({
                        type: Number,
                        default: 286
                    })], e.prototype, "menuWidth", void 0), e = v([l.Component], e)
                }(l.Vue),
                k = m,
                D = o(385),
                O = o(25);
            var component = Object(O.a)(k, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.dropDownVal && t.dropDownVal.items && t.dropDownVal.items.length > 0 ? e("div", {
                    class: [t.$style.dropDownMenuContainer, Object(r.a)({}, t.$style.mobileActived, t.isMobile)],
                    style: "width:".concat(t.menuWidth, "px;\n  top:").concat(t.headerBlockPosition, "px;\n  left:").concat(0 === t.headerListBlockPosition.left ? "auto" : t.headerListBlockPosition.left + "px", ";\n  right:").concat(0 === t.headerListBlockPosition.right ? "auto" : t.headerListBlockPosition.right + "px"),
                    attrs: {
                        role: "list"
                    },
                    on: {
                        mouseover: t.menuMouseOver,
                        mouseleave: t.menuMouseLeave
                    }
                }, [!t.dropDownType || t.dropDownType && "default" === t.dropDownType ? e("div", {
                    class: t.$style.dropDownContent
                }, [t.isMobile ? e("p", {
                    class: t.$style.dropDownBack,
                    on: {
                        click: t.mobilePrev
                    }
                }, [t._v(t._s(t.dropDownVal.name))]) : t._e(), t._v(" "), t._l(t.dropDownVal.items.slice(0, 3), (function(o, n) {
                    return e("ol", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: o.subItem.length > 0,
                            expression: "items.subItem.length > 0"
                        }],
                        key: n,
                        class: [t.$style.dropDownOList, Object(r.a)({}, t.$style.dropDownOListProduct, "product" === t.dropDownVal.class)]
                    }, ["product" !== t.dropDownVal.class && o.name ? e("li", {
                        class: t.$style.listCategory
                    }, [e("p", {
                        class: t.$style.listCategory
                    }, [t._v(t._s(o.name))])]) : t._e(), t._v(" "), o.subItem && o.subItem.length > 0 && "product" !== t.dropDownVal.class ? e("li", {
                        class: [Object(r.a)({}, t.$style.otherMenuList, "product" !== t.dropDownVal.class)]
                    }, [e("ol", {
                        attrs: {
                            role: "list"
                        }
                    }, t._l(o.subItem, (function(o, n) {
                        return e("li", {
                            key: n,
                            staticClass: "dropMenuItem",
                            class: [t.$style.menuLink],
                            attrs: {
                                role: "listitem"
                            }
                        }, [e("a", {
                            class: [t.$style.headerItemName, t.$style.subDetailLinkItem, {
                                jpFont: "jp" === t.lang
                            }],
                            attrs: {
                                tabindex: "0",
                                href: t.createLink(o),
                                target: o.linkTarget,
                                rel: "_blank" === o.linkTarget ? "noopener noreferrer" : ""
                            },
                            on: {
                                keydown: function(e) {
                                    return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.linkClickNoRouterPush(o)
                                },
                                click: function(e) {
                                    return e.preventDefault(), t.linkClickNoRouterPush(o)
                                }
                            }
                        }, [t._v("\n              " + t._s(o.name) + "\n            ")])])
                    })), 0)]) : t._e(), t._v(" "), o.subItem && o.subItem.length > 0 && "product" === t.dropDownVal.class ? e("li", {
                        class: [t.$style.listItem]
                    }, t._l(t.splitSubNestedItemSplitVal(o.subItem), (function(c, l) {
                        return e("ol", {
                            key: l,
                            class: [t.$style.subDetailLink, Object(r.a)({}, "test", n === (4 === t.dropDownVal.items.length && t.dropDownVal.items.length - 2) || n === (t.dropDownVal.items.length <= 3 && t.dropDownVal.items.length - 1))],
                            attrs: {
                                role: "list"
                            }
                        }, t._l(c, (function(n, r) {
                            return e("li", {
                                key: r,
                                staticClass: "dropMenuItem",
                                class: [t.$style.menuLink],
                                attrs: {
                                    role: "listitem"
                                }
                            }, [e("a", {
                                class: [t.$style.headerItemName, t.$style.subDetailLinkItem, {
                                    jpFont: "jp" === t.lang
                                }],
                                attrs: {
                                    tabindex: "0",
                                    id: "".concat(o.name).concat(r),
                                    href: t.createLink(n)
                                },
                                on: {
                                    keydown: function(e) {
                                        return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.linkClick(n)
                                    },
                                    click: function(e) {
                                        return e.preventDefault(), t.linkClick(n)
                                    }
                                }
                            }, [t._v("\n              " + t._s(n.name) + "\n            ")])])
                        })), 0)
                    })), 0) : t._e()])
                }))], 2) : t._e(), t._v(" "), t.bottomMenu && t.bottomMenu.subItem.length > 0 || t.dropDownVal.productItems && t.dropDownVal.productItems.length > 0 ? [e("div", {
                    class: [t.$style.dropDownContent, t.$style.secondDropDownContent]
                }, [t.bottomMenu && t.bottomMenu.subItem.length > 0 ? e("ol", {
                    class: t.$style.dropDownOList,
                    attrs: {
                        role: "list"
                    }
                }, t._l(t.bottomMenu.subItem, (function(o, n) {
                    return e("li", {
                        key: n,
                        class: [t.$style.subDetailLink, t.$style.subDetailBlock],
                        attrs: {
                            role: "listitem"
                        }
                    }, [e("a", {
                        class: [t.$style.headerItemName, t.$style.subDetailLinkItem, {
                            jpFont: "jp" === t.lang
                        }],
                        attrs: {
                            tabindex: "0",
                            href: o.link,
                            target: o.linkTarget
                        },
                        on: {
                            keydown: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.linkClick(o)
                            },
                            click: function(e) {
                                return e.preventDefault(), t.linkClick(o)
                            }
                        }
                    }, [t._v(t._s(o.name))])])
                })), 0) : t._e(), t._v(" "), e("ol", {
                    class: t.$style.dropDownOList,
                    attrs: {
                        role: "list"
                    }
                }, [t.dropDownVal.productItems && t.dropDownVal.productItems.length > 0 && t.dropDownVal.productItems[0].subItem.length > 0 ? e("li", {
                    class: [t.$style.subDetailLink, t.$style.subDetailBlock],
                    attrs: {
                        role: "listitem"
                    }
                }, [t.dropDownVal.productItems[0].subItem.length > 0 ? e("a", {
                    class: [t.$style.headerItemName, t.$style.subDetailLinkItem, {
                        jpFont: "jp" === t.lang
                    }],
                    attrs: {
                        tabindex: "0",
                        href: t.createLink(t.dropDownVal.productItems[0].subItem[0])
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.linkClick(t.dropDownVal.productItems[0].subItem[0])
                        },
                        click: function(e) {
                            return e.preventDefault(), t.linkClick(t.dropDownVal.productItems[0].subItem[0])
                        }
                    }
                }, [e("svg", {
                    attrs: {
                        width: "16",
                        height: "16",
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        loading: "lazy",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M15 1.71l-.02-.03v-.66h-.66L14.3 1l-.03.02H9.48l-1 1h4.79L7 8.52l.71.71 6.31-6.54v4.79l.96-.96V1.73l.02-.02zm-2.98 12.31V8.04h1v6.98H1v-12h7.02v1H2v10h10.02z",
                        fill: "#181818"
                    }
                })]), t._v(t._s(t.dropDownVal.productItems[0].subItem[0].name) + "\n            ")]) : t._e()]) : t._e()])])] : t._e()], 2) : t._e()
            }), [], !1, (function(t) {
                this.$style = D.default.locals || D.default
            }), null, null);
            e.a = component.exports
        },
        492: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(26), o(51), o(60), o(9)),
                l = (o(54), o(41), o(10), o(28), o(44), o(59), o(91), o(18), o(33), o(145), o(3)),
                d = o(7),
                h = o(16),
                w = o.n(h),
                _ = o(102),
                f = o(36),
                y = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                v = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.showMenu = !1, e.navSubNestedItemSpliteNum = 20, e.websiteInfo = new _.a, e
                    }
                    return y(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t, e = "";
                            return Object.keys(this.routeInfo).length > 0 ? e = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.websitePath : "undefined" != typeof window && (null === window || void 0 === window ? void 0 : window.AsusAPIConfig) && (e = window.AsusAPIConfig.websitePath), e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "bottomMenu", {
                        get: function() {
                            var t = this.dropDownVal.items.filter((function(t) {
                                return "bottom" === t.class
                            }));
                            return t.length > 0 ? t[0] : null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchIsMobile = function(t, e) {
                        var o = this;
                        t && (this.showMenu = !0), t || (this.isBurgerActived ? this.showMenu = !1 : setTimeout((function() {
                            o.showMenu = !1
                        }), 500))
                    }, e.prototype.createLink = function(t) {
                        if (t || t.link) return t.link
                    }, e.prototype.urlReplace = function(t) {
                        for (var e = [], o = 0, n = f.b; o < n.length; o++) {
                            var r = n[o];
                            new RegExp(r).test(t) && (e = t.split(encodeURI(window.location.origin)))
                        }
                        return e.length > 1 ? e[1] : null
                    }, e.prototype.linkClick = function(t) {
                        event.preventDefault();
                        var e = Object(f.a)(),
                            o = this.urlReplace(t.link);
                        (t || t.link) && (e && o && this.$route ? (this.gaSetting(t.name), "object" === Object(c.a)(window._satellite) && window._satellite.track("spa-pageview"), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                            shouldTrackUrlChange: function(t, e) {
                                return t && e
                            }
                        }]), window.location = t.link, this.$emit("closeAction")) : (this.gaSetting(t.name), window.location = t.link))
                    }, e.prototype.linkClickOldPage = function(t) {
                        event.preventDefault(), (t || t.link) && (this.$emit("closeAction"), window.location = t.link)
                    }, e.prototype.menuMouseLeave = function() {
                        this.$emit("leaveSubMenu", {
                            leave: !0
                        })
                    }, e.prototype.menuMouseOver = function() {
                        this.$emit("leaveSubMenu", {
                            leave: !1
                        })
                    }, e.prototype.mobilePrev = function() {
                        this.$emit("mobileSubMenu")
                    }, e.prototype.spliteSubNestedItemSpliteVal = function(t) {
                        return w.a.chunk(t, this.navSubNestedItemSpliteNum)
                    }, e.prototype.closeMobileMenuList = function() {
                        this.showMenu = !1, this.$emit("closeMobileMenuList")
                    }, e.prototype.gaSetting = function(t) {
                        if ("rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "header-L1", "clicked", "Products-".concat(t)])
                        } else window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "header-L1",
                            event_action_DL: "clicked",
                            event_label_DL: "Products-".concat(t),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-L1",
                                event_action_DL: "clicked",
                                event_label_DL: "Products-".concat(t),
                                event_value_DL: "0"
                            })
                        }), 200))
                    }, e.prototype.mounted = function() {}, v([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), v([Object(l.Prop)({
                        default: null
                    })], e.prototype, "dropDownVal", void 0), v([Object(l.Prop)({
                        type: String,
                        default: "default"
                    })], e.prototype, "dropDownType", void 0), v([Object(l.Prop)({
                        default: {
                            top: 0,
                            left: 0
                        }
                    })], e.prototype, "headerBlockPosition", void 0), v([Object(l.Prop)({
                        default: {
                            top: 0,
                            left: 0
                        }
                    })], e.prototype, "headerListBlockPosition", void 0), v([Object(l.Prop)({
                        type: Boolean,
                        default: !1
                    })], e.prototype, "isMobile", void 0), v([Object(l.Prop)({
                        type: Boolean,
                        default: !1
                    })], e.prototype, "isBurgerActived", void 0), v([Object(l.Watch)("isMobile")], e.prototype, "watchIsMobile", null), e = v([l.Component], e)
                }(l.Vue),
                k = m,
                D = o(386),
                O = o(25);
            var component = Object(O.a)(k, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    class: [e.$style.dropDownMenuContainer, e.$style.mobileMenuList, (t = {}, Object(r.a)(t, e.$style.mobileActived, e.isBurgerActived), Object(r.a)(t, e.$style.show, e.showMenu), Object(r.a)(t, e.$style.isBurgerActived, e.isBurgerActived), t)],
                    style: "top: ".concat(e.headerBlockPosition, "px;"),
                    on: {
                        mouseover: e.menuMouseOver,
                        mouseleave: e.menuMouseLeave
                    }
                }, [e.dropDownVal && e.dropDownVal.items && e.dropDownVal.items.length > 0 ? o("div", [!e.dropDownType || e.dropDownType && "default" === e.dropDownType ? o("div", {
                    class: [e.$style.dropDownContent, Object(r.a)({}, e.$style.dropDownProductContent, "product" === e.dropDownVal.class)]
                }, [o("div", {
                    class: e.$style.dropDownBack,
                    attrs: {
                        role: "button",
                        "aria-label": "go back"
                    },
                    on: {
                        click: e.mobilePrev
                    }
                }, [o("svg", {
                    attrs: {
                        width: "16",
                        height: "16",
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "back",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M12.733 8l-6.666 6.667H3.333L10 8 3.333 1.333h2.734L12.733 8z",
                        fill: "#181818"
                    }
                })]), e._v(" "), o("p", [e._v(e._s(e.dropDownVal.name))])]), e._v(" "), e._l(e.dropDownVal.items.slice(0, 3), (function(t, n) {
                    return o("ol", {
                        key: n,
                        class: [e.$style.dropDownOList, Object(r.a)({}, e.$style.dropDownOListProduct, "product" === e.dropDownVal.class)],
                        attrs: {
                            role: "menu"
                        }
                    }, ["product" !== e.dropDownVal.class ? o("li", {
                        class: e.$style.listCategory,
                        attrs: {
                            role: "presentation"
                        }
                    }, [o("p", {
                        class: e.$style.listCategory,
                        on: {
                            click: e.closeMobileMenuList
                        }
                    }, [e._v(e._s(t.name))])]) : e._e(), e._v(" "), t.subItem && t.subItem.length > 0 && "product" !== e.dropDownVal.class ? o("li", {
                        class: e.$style.listItem,
                        attrs: {
                            role: "presentation"
                        }
                    }, e._l(t.subItem, (function(t, n) {
                        return o("a", {
                            key: n,
                            attrs: {
                                href: t.link
                            },
                            on: {
                                click: function(o) {
                                    return o.preventDefault(), e.linkClickOldPage(t)
                                }
                            }
                        }, [e._v("\n          " + e._s(t.name) + "\n        ")])
                    })), 0) : e._e(), e._v(" "), t.subItem && t.subItem.length > 0 && "product" === e.dropDownVal.class ? o("li", {
                        class: e.$style.listItem,
                        attrs: {
                            role: "presentation"
                        }
                    }, e._l(e.spliteSubNestedItemSpliteVal(t.subItem), (function(t, n) {
                        return o("div", {
                            key: n,
                            class: e.$style.subDetailLink
                        }, e._l(t, (function(t, n) {
                            return o("div", {
                                key: n,
                                class: [e.$style.subDetailLinkItem, {
                                    jpFont: "jp" === e.lang
                                }],
                                attrs: {
                                    role: "link"
                                },
                                on: {
                                    click: function(o) {
                                        return o.preventDefault(), e.linkClick(t)
                                    }
                                }
                            }, [e._v("\n            " + e._s(t.name) + "\n          ")])
                        })), 0)
                    })), 0) : e._e()])
                }))], 2) : e._e(), e._v(" "), e.bottomMenu && e.bottomMenu.subItem.length > 0 || e.dropDownVal.productItems && e.dropDownVal.productItems.length > 0 ? [o("div", {
                    class: [e.$style.dropDownContent, e.$style.secondDropDownContent]
                }, [o("ol", {
                    class: e.$style.dropDownOList,
                    attrs: {
                        role: "list"
                    }
                }, e._l(e.bottomMenu.subItem, (function(t, n) {
                    return o("li", {
                        key: n,
                        class: [e.$style.subDetailLink, e.$style.subDetailBlock],
                        attrs: {
                            role: "listitem"
                        }
                    }, [o("a", {
                        class: [e.$style.headerItemName, e.$style.subDetailLinkItem, {
                            jpFont: "jp" === e.lang
                        }],
                        attrs: {
                            tabindex: "0",
                            href: t.link,
                            target: t.linkTarget
                        }
                    }, [e._v(e._s(t.name))])])
                })), 0), e._v(" "), o("ol", {
                    class: e.$style.dropDownOList,
                    attrs: {
                        role: "list"
                    }
                }, [e.dropDownVal.productItems && e.dropDownVal.productItems.length > 0 && e.dropDownVal.productItems[0].subItem.length > 0 ? o("li", {
                    class: [e.$style.subDetailLink, e.$style.subDetailBlock],
                    attrs: {
                        role: "listitem"
                    }
                }, [e.dropDownVal.productItems[0].subItem.length > 0 ? o("a", {
                    class: [e.$style.headerItemName, e.$style.subDetailLinkItem, {
                        jpFont: "jp" === e.lang
                    }],
                    attrs: {
                        tabindex: "0",
                        href: e.createLink(e.dropDownVal.productItems[0].subItem[0])
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && e._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : e.linkClick(e.dropDownVal.productItems[0].subItem[0])
                        },
                        click: function(t) {
                            return t.preventDefault(), e.linkClick(e.dropDownVal.productItems[0].subItem[0])
                        }
                    }
                }, [o("svg", {
                    attrs: {
                        width: "16",
                        height: "16",
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        loading: "lazy",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M15 1.71l-.02-.03v-.66h-.66L14.3 1l-.03.02H9.48l-1 1h4.79L7 8.52l.71.71 6.31-6.54v4.79l.96-.96V1.73l.02-.02zm-2.98 12.31V8.04h1v6.98H1v-12h7.02v1H2v10h10.02z",
                        fill: "#181818"
                    }
                })]), e._v("\n            \n              " + e._s(e.dropDownVal.productItems[0].subItem[0].name) + "\n            ")]) : e._e()]) : e._e()])])] : e._e()], 2) : e._e()])
            }), [], !1, (function(t) {
                this.$style = D.default.locals || D.default
            }), null, null);
            e.a = component.exports
        },
        493: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(20), o(26), o(60), o(636), o(9)),
                l = (o(54), o(41), o(10), o(28), o(47), o(91), o(18), o(33), o(145), o(59), o(29), o(3)),
                d = o(7),
                h = o(6),
                w = o.n(h),
                _ = o(4),
                f = o(235),
                y = o(36),
                v = o(0),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                k = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                D = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.rightWidth = 20, e.messageNum = 1, e.isDropDownActived = !1, e.aticketValue = "null", e.accountLanguage = "", e.exportAccountWebsitePath = "global", e.exportWebsitePath = "global", e.exportWebsiteID = 0, e.exportStatus = !1, e
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t;
                            if (this.routeInfo && (null === (t = this.routeInfo) || void 0 === t ? void 0 : t.websitePath)) return this.routeInfo.websitePath;
                            var e = this.$root ? this.$root.$data : null;
                            return e && Object.keys(e).length > 0 ? e.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isUserLogin", {
                        get: function() {
                            return "undefined" != typeof window && ("cn" === this.lang ? null !== Object(_.b)("aticket_cn") : null !== Object(_.b)("aticket"))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isRtlArea", {
                        get: function() {
                            return ["eg", "me-ar", "il", "sa-ar"].includes(this.lang)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "createUrl", {
                        get: function() {
                            return this.accountStatus && this.accountStatus.userInfo && this.accountStatus.userInfo.mediaUrl ? this.accountStatus.userInfo.mediaUrl.indexOf("rog_avator") > -1 ? "" : this.accountStatus.userInfo.mediaUrl : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "filteredAccountMenu", {
                        get: function() {
                            if (this.accountMenu) return this.aticketValue, this.accountMenu
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "userName", {
                        get: function() {
                            if (this.accountStatus && this.accountStatus.userInfo && this.accountStatus.userInfo.name) return this.accountStatus.userInfo.name
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "cnReturnUrl", {
                        get: function() {
                            return "undefined" != typeof window ? encodeURI(window.location.href) : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.urlReplace = function(t) {
                        for (var e = [], o = 0, n = y.b; o < n.length; o++) {
                            var r = n[o],
                                c = new RegExp(r);
                            c.test(t) && "" !== t && (e = null == t ? void 0 : t.split(c))
                        }
                        return e.length > 1 ? e[1] : null
                    }, e.prototype.blurMenu = function(t) {
                        t && (this.isDropDownActived = !this.isDropDownActived)
                    }, e.prototype.accountIconClick = function(t) {
                        t.preventDefault(), this.gaSetting("member"), this.isDropDownActived = !this.isDropDownActived, this.isDropDownActived && setTimeout((function() {
                            var t = document.getElementById("personMenu").children[0].children[0];
                            t instanceof HTMLElement && t.focus()
                        }), 100)
                    }, e.prototype.accountName = function(t) {
                        return t.link.indexOf("signin") > -1 ? this.translation.Header_Login : t.link.indexOf("logout") > -1 ? this.translation.Header_Logout : this.translation.Header_Sign_up
                    }, e.prototype.accountLinkActived = function(t) {
                        if ("post" === (t.type ? t.type : null)) {
                            this.accountLanguage = this.mappingWebsite.accountLang;
                            var e = this.routeInfo.websitePath;
                            if (this.exportStatus) {
                                var o = this.$root ? this.$root.$data : null;
                                o && Object.keys(o).length > 0 && (this.accountLanguage = o.language, e = o.websitePath, this.exportAccountWebsitePath = o.websitePath)
                            }
                            "cn" === e ? "rog.asus.com.cn" === window.location.host || "rogmars.asus.com" === window.location.host ? sessionStorage.getItem("oidc.user:https://account.asus.com.cn:c3df97ef67b2022e") ? window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=logout" : window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=login" : sessionStorage.getItem("oidc.user:https://accts-account.asus.com.cn:63825193b2ed32d0") ? window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=logout" : window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=login" : this.accountActive(t)
                        }
                    }, e.prototype.accountActive = function(t) {
                        var e = (window.location.host, encodeURI(t.link)),
                            o = new RegExp("logout", "ig");
                        if (e.indexOf("logout") > -1 && (Object(_.a)("groupid_rog_".concat(this.lang)), sessionStorage.removeItem("rog_ec_cartList_".concat(this.lang)), sessionStorage.removeItem("rog_ec_member_token_".concat(this.lang)), sessionStorage.removeItem("rog_ec_cartID_".concat(this.lang)), sessionStorage.removeItem("rog_ec_token_".concat(this.lang))), this.accountMappingWebsite(), e && Object.keys(this.accountLanguage).length > 0) try {
                            if (window) {
                                var n = encodeURI(window.location.href);
                                n.indexOf("wishlist") > -1 && (n = encodeURI(window.location.origin).indexOf("stage") ? encodeURI(window.location.origin + "/rog/") : encodeURI(window.location.origin));
                                var r = {
                                        lang: this.accountLanguage,
                                        site: this.exportStatus ? this.exportAccountWebsitePath : this.routeInfo.websitePath,
                                        AppID: this.checkAppID(),
                                        login_background: "general_black",
                                        login_panel: "simply",
                                        ReturnURL: encodeURI(window.location.href)
                                    },
                                    form = document.createElement("form");
                                for (var c in form.setAttribute("method", "post"), (this.getAIStatus || window.AsusAPIConfig.brandAssistantDefaultDisplay || "tw" === window.AsusAPIConfig.websitePath) && form.setAttribute("target", "_top"), form.setAttribute("action", o.test(e) ? "".concat(e).concat(encodeURI(window.location.href)) : "".concat(e)), r)
                                    if (r.hasOwnProperty(c)) {
                                        var element = r[c],
                                            l = document.createElement("input");
                                        l.setAttribute("type", "hidden"), l.setAttribute("name", c), l.setAttribute("value", element), form.appendChild(l)
                                    }
                                document.body.appendChild(form), form.submit()
                            }
                        } catch (t) {
                            console.error(t)
                        }
                    }, e.prototype.accountLogOutActive = function() {
                        var t = "dev-rog.asus.com" === window.location.host ? "dev-" : "";
                        if (Object(_.a)("groupid_rog_".concat(this.lang)), this.accountMappingWebsite(), Object.keys(this.accountLanguage).length > 0) try {
                            if (window) {
                                var e = encodeURI(window.location.href);
                                e.indexOf("wishlist") > -1 && (e = encodeURI(window.location.origin).indexOf("stage") ? encodeURI(window.location.origin + "/rog/") : encodeURI(window.location.origin));
                                var o = {
                                        lang: this.accountLanguage,
                                        site: this.exportStatus ? this.exportAccountWebsitePath : this.routeInfo.websitePath,
                                        AppID: this.checkAppID(),
                                        login_background: "general_black",
                                        login_panel: "simply",
                                        ReturnURL: encodeURI(window.location.href)
                                    },
                                    form = document.createElement("form");
                                for (var n in form.setAttribute("method", "post"), form.setAttribute("action", "https://".concat(t, "account.asus.com/logout.aspx?ReturnUrl=").concat(e)), o)
                                    if (o.hasOwnProperty(n)) {
                                        var element = o[n],
                                            r = document.createElement("input");
                                        r.setAttribute("type", "hidden"), r.setAttribute("name", n), r.setAttribute("value", element), form.appendChild(r)
                                    }
                                document.body.appendChild(form), form.submit()
                            }
                        } catch (t) {
                            console.error(t)
                        }
                    }, e.prototype.accountMappingWebsite = function() {
                        if (0 === Object.keys(this.accountLanguage).length) {
                            var t = this.websiteMapping.value ? this.websiteMapping.value : this.routeInfo.websiteMapping;
                            this.accountLanguage = Object(f.a)(t, this.routeInfo.websitePath)
                        }
                    }, e.prototype.accountStatusWashActived = function(t, link) {
                        var e = (window.location.host, encodeURI(t.link)),
                            o = new RegExp("logout", "ig");
                        if (this.exportStatus && 0 === Object.keys(this.accountLanguage).length && (this.accountLanguage = window.AsusAPIConfig.language, this.exportAccountWebsitePath = window.AsusAPIConfig.websitePath), 0 === Object.keys(this.accountLanguage).length && (this.accountLanguage = Object(f.a)(this.websiteMapping.value ? this.websiteMapping.value : this.routeInfo.websiteMapping, this.routeInfo.websitePath)), Object.keys(this.accountLanguage).length > 0) try {
                            if (window) {
                                var n = this.exportStatus ? encodeURI(link) : encodeURI(window.location.href),
                                    r = {
                                        lang: this.accountLanguage,
                                        site: this.exportStatus ? this.exportAccountWebsitePath : this.routeInfo.websitePath,
                                        AppID: this.checkAppID(),
                                        login_background: "general_black",
                                        login_panel: "simply",
                                        ReturnURL: n
                                    };
                                Object(_.c)("gowish", encodeURI(link), "");
                                var form = document.createElement("form");
                                for (var c in form.setAttribute("method", "post"), form.setAttribute("action", o.test(e) ? "".concat(e).concat(encodeURI(window.location.href)) : "".concat(e)), r)
                                    if (r.hasOwnProperty(c)) {
                                        var element = r[c],
                                            l = document.createElement("input");
                                        l.setAttribute("type", "hidden"), l.setAttribute("name", c), l.setAttribute("value", element), form.appendChild(l)
                                    }
                                document.body.appendChild(form), form.submit()
                            }
                        } catch (t) {
                            console.error(t)
                        }
                    }, e.prototype.accountStatusActived = function(t) {
                        var e = Object(y.a)(),
                            o = this.urlReplace(t.link);
                        (t || t.link) && (o ? e && ("object" === Object(c.a)(window._satellite) && window._satellite.track("spa-pageview"), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                            shouldTrackUrlChange: function(t, e) {
                                return t && e
                            }
                        }]), window.location = t.link) : (this.gaSubMenuSetting(t.name, t.name), this.accountLinkActived(t)))
                    }, e.prototype.accountDropDownLinkClick = function(t) {
                        var e = Object(y.a)(),
                            o = this.urlReplace(t.link);
                        (t || t.link) && (e && o ? ("object" === Object(c.a)(window._satellite) && window._satellite.track("spa-pageview"), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                            shouldTrackUrlChange: function(t, e) {
                                return t && e
                            }
                        }]), window.location = t.link) : window.location = t.link)
                    }, e.prototype.checkAppID = function() {
                        return encodeURI(window.location.origin).indexOf("store") > -1 || encodeURI(window.location.origin).indexOf("shop") > -1 ? window.AsusAPIConfig ? window.AsusAPIConfig.appID : void 0 : "0000000003"
                    }, e.prototype.getAccountMenuMetas = function() {
                        var t = this;
                        if (0 === Object.keys(this.accountMenu).length) {
                            var e = encodeURI(window.location.host),
                                o = e.replace(".asus.com", ""),
                                n = new RegExp(/stage/gim).test(e) ? "stage-api-rog.asus.com" : "api-rog.asus.com";
                            "cn" === this.lang && (n = "api-rog.asus.com.cn");
                            var r = {
                                WebsiteCode: this.exportStatus ? this.exportWebsitePath : this.routeInfo.websitePath,
                                systemCode: o
                            };
                            this.exportStatus ? w()({
                                method: "get",
                                url: "https://".concat(n, "/recent-data/api/v4/Account/Menu?WebsiteCode=").concat(this.exportWebsitePath, "&systemCode=").concat(o)
                            }).then((function(e) {
                                t.rogExportAccountMenu(e.data)
                            })).catch((function(t) {
                                console.error(t)
                            })) : this.getAccountMenu(r)
                        }
                    }, e.prototype.getAccountStatusMetas = function() {
                        var t = this;
                        if (0 === Object.keys(this.accountStatus).length) {
                            "cn" === this.lang ? this.aticketValue = Object(_.b)("aticket_cn") ? Object(_.b)("aticket_cn") : "" : this.aticketValue = Object(_.b)("aticket") ? Object(_.b)("aticket") : "";
                            var e = encodeURI(window.location.host),
                                o = e.replace(".asus.com", ""),
                                n = new RegExp(/stage/gim).test(e) ? "stage-api-rog.asus.com" : "api-rog.asus.com";
                            "cn" === this.lang && (n = "api-rog.asus.com.cn");
                            var r = {
                                websiteCode: this.exportStatus ? this.exportWebsitePath : this.routeInfo.websitePath,
                                aticket: this.aticketValue,
                                systemCode: o
                            };
                            this.exportStatus ? w()({
                                method: "post",
                                url: "https://".concat(n, "/recent-data/api/v4/Account/Status"),
                                data: r
                            }).then((function(e) {
                                t.rogExportAccountStatus(e.data)
                            })).catch((function(t) {
                                console.error(t)
                            })) : this.getAccountStatus(r)
                        }
                    }, e.prototype.checkRouteInfo = function() {
                        this.getAccountStatusMetas()
                    }, e.prototype.checkIsExport = function() {
                        if (this.$route) this.checkRouteInfo();
                        else {
                            var t = this.$root ? this.$root.$data : null;
                            this.exportStatus = !0, t && Object.keys(t).length > 0 && (this.exportWebsiteID = t.websiteID, this.exportWebsitePath = t.websitePath, this.getAccountMenuMetas(), this.getAccountStatusMetas())
                        }
                    }, e.prototype.checkDropMenuRightPosition = function() {
                        var t = this;
                        document.body.clientWidth >= 1890 ? t.rightWidth = 135 : document.body.clientWidth < 1890 && document.body.clientWidth > 1600 ? t.rightWidth = (document.body.clientWidth - 1600) / 2 : document.body.clientWidth <= 1600 && (t.rightWidth = 20)
                    }, e.prototype.regexEliteName = function(t) {
                        return !!new RegExp("elite", "ig").test(t)
                    }, e.prototype.accountLinkHandler = function(t) {
                        if ("undefined" != typeof window) {
                            if (new RegExp("account", "ig").test(t)) {
                                var e = "dev-rog.asus.com" === window.location.host ? encodeURI(t.replace("https://account", "https://dev-account")) : encodeURI(t);
                                return "cn" === this.routeInfo.websitePath && (e = "rog.asus.com.cn" === window.location.host || "rogmars.asus.com" === window.location.host ? "https://account.asus.com.cn" : "https://accts-account.asus.com.cn"), e
                            }
                            return t
                        }
                    }, e.prototype.accountGaHandler = function(t) {
                        var e = t.link,
                            o = new RegExp("elite", "ig"),
                            n = new RegExp("account", "ig");
                        o.test(e) ? this.gaSubMenuSetting("elite_rewards", t.name) : n.test(e) && this.gaSubMenuSetting("my_account", t.name)
                    }, e.prototype.mounted = function() {
                        var t = this,
                            e = this;
                        if ("undefined" != typeof window && ("cn" === this.lang ? this.aticketValue = Object(_.b)("aticket_cn") ? Object(_.b)("aticket_cn") : "null" : this.aticketValue = Object(_.b)("aticket") ? Object(_.b)("aticket") : "null"), Object(_.b)("gowish") && "" !== Object(_.b)("gowish")) {
                            var o = Object(_.b)("gowish");
                            Object(_.c)("gowish", "", ""), window.location.assign(o)
                        }
                        this.checkIsExport(), this.checkDropMenuRightPosition(), document.body.addEventListener("click", (function(t) {
                            var o; - 1 !== navigator.userAgent.indexOf("MSIE") || navigator.appVersion.indexOf("Trident/") > 0 ? (o = t.target).closest(".personalMenu") || o.closest(".userButton") || (e.isDropDownActived = !1) : (o = t.target).closest(".personalMenu") || o.closest(".userButton") || (e.isDropDownActived = !1)
                        })), window.addEventListener("resize", (function() {
                            t.checkDropMenuRightPosition()
                        }))
                    }, e.prototype.gaSetting = function(t) {
                        if (window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-L1",
                                event_action_DL: "clicked",
                                event_label_DL: t,
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "header-L1",
                                    event_action_DL: "clicked",
                                    event_label_DL: t,
                                    event_value_DL: "0"
                                })
                            }), 200)), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "header-L1", "clicked", t])
                        }
                    }, e.prototype.gaSubMenuSetting = function(t, e) {
                        if (window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-member-L2",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "-").concat(e),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "header-member-L2",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t, "-").concat(e),
                                    event_value_DL: "0"
                                })
                            }), 200)), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "header-member-L2", "clicked", "".concat(t, "-").concat(e), , ])
                        }
                    }, k([Object(d.Getter)("accountMenu")], e.prototype, "accountMenu", void 0), k([Object(d.Getter)("accountStatus")], e.prototype, "accountStatus", void 0), k([Object(d.Getter)("websiteMapping")], e.prototype, "websiteMapping", void 0), k([Object(d.Getter)("websitePath")], e.prototype, "websitePath", void 0), k([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), k([Object(d.Getter)("translation")], e.prototype, "translation", void 0), k([Object(d.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), k([Object(d.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), k([Object(d.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), k([Object(d.Action)("getAccountStatus")], e.prototype, "getAccountStatus", void 0), k([Object(d.Action)("getAccountMenu")], e.prototype, "getAccountMenu", void 0), k([Object(d.Mutation)(v.ROG_ACCOUNT_STATUS)], e.prototype, "rogExportAccountStatus", void 0), k([Object(d.Mutation)(v.ROG_ACCOUNT_MENU)], e.prototype, "rogExportAccountMenu", void 0), e = k([l.Component], e)
                }(l.Vue),
                O = D,
                L = o(387),
                P = o(25);
            var component = Object(P.a)(O, (function() {
                var t, e, o = this,
                    n = o._self._c;
                o._self._setupProxy;
                return n("div", {
                    ref: "personalWrapper",
                    class: o.$style.personalWrapper
                }, [n("button", {
                    class: ["userButton", o.$style.accountButton, (t = {}, Object(r.a)(t, o.$style.isActivity, o.isDropDownActived && o.accountMenu), Object(r.a)(t, o.$style.isLogin, o.aticketValue), t)],
                    attrs: {
                        id: "personMenuButton",
                        "aria-haspopup": "true",
                        "aria-controls": "personMenu",
                        type: "button",
                        "aria-label": o.aticketValue ? "".concat(o.translation.Aria_MyAccount).concat(o.userName) : o.translation.Aria_SignIn,
                        "aria-expanded": !(!o.isDropDownActived || !o.accountMenu),
                        tabindex: "0"
                    },
                    on: {
                        click: function(t) {
                            return o.accountIconClick(t)
                        },
                        keydown: function(t) {
                            return !t.type.indexOf("key") && o._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : o.accountIconClick(t)
                        }
                    }
                }, ["null" !== o.aticketValue && o.aticketValue && "" !== o.aticketValue ? n("svg", {
                    class: ["svg-icon", (e = {}, Object(r.a)(e, o.$style.isRed, o.accountMenu && o.isDropDownActived && o.accountStatus), Object(r.a)(e, o.$style.isLogin, "null" !== o.aticketValue), e)],
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "user",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm0 1c6.07 0 11 4.93 11 11 0 2.64-.93 5.06-2.49 6.95l-2.52-2.52.7-3.98v-.1c-.48-1.44-2.1-6.2-2.78-6.85a18.36 18.36 0 00-3.7-1.87L12 3.56l-.17.07c-1.3.48-2.54 1.11-3.7 1.87-.69.65-2.89 5.85-3.32 6.88l-.06.14 1.23 3.94-2.5 2.5a10.97 10.97 0 01-2.49-6.95C1 5.93 5.93 1 12 1zm-1.11 21.94v-4.36l-2.87-1.72-.44.74 2.45 1.45v3.74c-.09 0-.18-.03-.27-.04-1.99-.42-3.77-1.38-5.21-2.71-.15-.16-.3-.32-.44-.49l2.8-3.12-1.22-4.12c.84-2.22 1.83-4.37 2.97-6.45.97-.65 2.01-1.19 3.11-1.61v6.1l3.33-.87c.63.85 1.17 1.77 1.6 2.73l-1.59 4.42-2.48 1.69v4.63c-.2.01-.41.03-.61.03-.38 0-.75-.02-1.11-.06l-.02.02z",
                        fill: "#fff"
                    }
                })]) : n("svg", {
                    class: ["svg-icon", Object(r.a)({}, o.$style.isRed, o.accountMenu && o.isDropDownActived && o.accountStatus)],
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "user",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M12.613 18.28v2.1H22l-4.009-4.009.7-3.982v-.1c-.484-1.44-2.1-6.195-2.783-6.846a18.386 18.386 0 00-3.701-1.874L12 3.5l-.17.069A18.393 18.393 0 008.13 5.443c-.69.651-2.89 5.848-3.32 6.88l-.063.139 1.235 3.939L2 20.383h8.886V18.53l-2.873-1.718-.442.739 2.448 1.452v.507H4.094l2.795-3.123-1.215-4.121a50.59 50.59 0 012.97-6.447 15.671 15.671 0 013.107-1.614V10.304l3.332-.868c.633.85 1.17 1.766 1.6 2.733l-1.587 4.425-2.483 1.686z",
                        fill: "#F7F7F7"
                    }
                })]), o._v(" "), n("img", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: o.createUrl && "" !== o.createUrl,
                        expression: "(createUrl && createUrl !== '')"
                    }],
                    attrs: {
                        "aria-hidden": o.createUrl && "" !== o.createUrl,
                        src: o.createUrl,
                        alt: "user"
                    }
                })]), o._v(" "), n("ClientOnly", [n("ul", {
                    class: [o.$style.personalDropDownMenu, Object(r.a)({}, o.$style.isMenuShow, o.accountMenu && o.isDropDownActived && o.accountStatus), "personalMenu"],
                    style: "left: ".concat(o.isRtlArea ? "-" + o.rightWidth + "px" : "auto", "; right: ").concat(o.isRtlArea ? "auto" : "-" + o.rightWidth + "px"),
                    attrs: {
                        role: "menu",
                        "aria-labelledby": "personMenuButton"
                    }
                }, ["cn" !== o.lang && "it" !== o.lang && o.accountStatus && o.accountStatus.userInfo && o.accountStatus.userInfo.name ? n("li", {
                    class: o.$style.accountInfo,
                    attrs: {
                        role: "menuitem"
                    }
                }, [n("p", {
                    class: o.$style.accountName
                }, [o._v(o._s(o.accountStatus.userInfo.name))]), o._v(" "), n("p", {
                    class: o.$style.accountPoints
                }, [o._v("\n        " + o._s(o.accountStatus.userInfo.points) + " \n        " + o._s(o.translation.Points))])]) : o._e(), o._v(" "), n("li", {
                    attrs: {
                        role: "menuitem"
                    }
                }, [n("ul", {
                    class: o.$style.accountLinkSection,
                    attrs: {
                        role: "group",
                        id: "personMenu"
                    }
                }, [o.accountStatus.linkSection && o.accountStatus.linkSection.length > 0 ? n("li", {
                    attrs: {
                        role: "menuitem"
                    }
                }, o._l(o.accountStatus.linkSection, (function(t, e) {
                    return n("a", {
                        key: e,
                        class: [o.$style.linkSectionLink, Object(r.a)({}, o.$style.isLoginStatus, "null" !== o.aticketValue)],
                        attrs: {
                            tabindex: "0",
                            "aria-label": "".concat(t.name),
                            href: t.link
                        },
                        on: {
                            keydown: function(e) {
                                return !e.type.indexOf("key") && o._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : o.accountStatusActived(t)
                            }
                        }
                    }, ["cn" !== o.lang ? n("span", {
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.accountStatusActived(t)
                            }
                        }
                    }, [o._v(o._s(o.accountName(t)))]) : o._e(), o._v(" "), "cn" === o.lang ? n("span", {
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.accountStatusActived(t)
                            }
                        }
                    }, [o._v(o._s(t.name))]) : o._e()])
                })), 0) : o._e(), o._v(" "), o._l(o.filteredAccountMenu, (function(t, e) {
                    var c;
                    return n("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !("cn" === o.lang && o.regexEliteName(t.link)),
                            expression: "!((lang === 'cn') && regexEliteName(accountInfo.link))"
                        }],
                        key: e,
                        class: [o.$style.dropDownLink, (c = {}, Object(r.a)(c, o.$style.isLoginStatus, "null" !== o.aticketValue), Object(r.a)(c, o.$style.lastItem, o.filteredAccountMenu.length - 1 === e && "null" === o.aticketValue), c)],
                        attrs: {
                            role: "menuitem"
                        }
                    }, [t && t.link && t.link.indexOf("wishlist") > -1 && t.link.indexOf("info") > -1 && !o.isUserLogin ? n("div", {
                        staticClass: "wishlist",
                        class: o.$style.wishlist,
                        attrs: {
                            target: t.linkTarget,
                            rel: "_blank" === t.linkTarget ? "noopener noreferrer" : ""
                        },
                        on: {
                            click: function(e) {
                                return o.accountStatusWashActived(o.accountStatus.linkSection[0], t.link)
                            }
                        }
                    }, [o._v("\n          " + o._s(t.name))]) : n("a", {
                        attrs: {
                            href: o.accountLinkHandler(t.link),
                            target: t.linkTarget,
                            rel: "_blank" === t.linkTarget ? "noopener noreferrer" : "",
                            "aria-label": "".concat(t.name)
                        },
                        on: {
                            click: function(e) {
                                return o.accountGaHandler(t)
                            }
                        }
                    }, [o._v("\n          " + o._s(t.name))])])
                }))], 2)])])])], 1)
            }), [], !1, (function(t) {
                this.$style = L.default.locals || L.default
            }), null, null);
            e.a = component.exports
        },
        496: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(28), o(9)),
                l = (o(54), o(41), o(10), o(59), o(3)),
                d = o(7),
                h = o(4),
                w = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isEnd = !1, e
                    }
                    return w(e, t), Object.defineProperty(e.prototype, "isYoutube", {
                        get: function() {
                            return !(!this.adsUrl || !(this.adsUrl.indexOf("https://youtu.be/") > -1 || this.adsUrl.indexOf("https://www.youtube.com/") > -1 || this.adsUrl.indexOf("https://www.youtube-nocookie.com/") > -1))
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isFB", {
                        get: function() {
                            return !!(this.adsUrl && this.adsUrl.indexOf("facebook") > -1)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "adsImgUrl", {
                        get: function() {
                            return "undefined" != typeof window && this.popUpAds && "" !== this.popUpAds.mediaPC ? this.popUpAds.mediaPC : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "adsMobileImgUrl", {
                        get: function() {
                            return "undefined" != typeof window && this.popUpAds && "" !== this.popUpAds.mediaMobile ? this.popUpAds.mediaMobile : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "adsAltPC", {
                        get: function() {
                            return "undefined" != typeof window && this.popUpAds && this.popUpAds.altPC && "" !== this.popUpAds.altPC ? this.popUpAds.altPC : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "adsAltMobile", {
                        get: function() {
                            return "undefined" != typeof window && this.popUpAds && this.popUpAds.altMobile && "" !== this.popUpAds.altMobile ? this.popUpAds.altMobile : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "adsUrl", {
                        get: function() {
                            return this.popUpAds && "" !== this.popUpAds.url ? this.popUpAds.url : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.fbHandler = function(t) {
                        var e = "";
                        return t.split("?v=").length > 1 && (e = t.split("?v=")[1].split("&")[0]), "https://www.facebook.com/plugins/video.php?height=518&href=https://www.facebook.com/asusrogmalaysia/videos/".concat(e, "/&show_text=false&width=1345&t=0")
                    }, e.prototype.youtubeHandler = function(t) {
                        var e = "";
                        return t ? (t.split("?v=").length > 1 ? e = t.split("?v=")[1].split("&")[0] : t.indexOf("https://www.youtube-nocookie.com/embed/") > -1 && t.split("https://www.youtube-nocookie.com/embed/").length > 1 ? e = t.split("?")[0].split("https://www.youtube-nocookie.com/embed/")[1] : t.indexOf("https://www.youtube.com/embed/") > -1 && t.split("https://www.youtube.com/embed/").length > 1 ? e = t.split("?")[0].split("https://www.youtube.com/embed/")[1] : t.indexOf("https://youtu.be/") > -1 && t.split("https://youtu.be/").length > 1 && (e = t.split("?")[0].split("https://youtu.be/")[1]), "https://www.youtube-nocookie.com/embed/".concat(e)) : ""
                    }, e.prototype.closeLightBox = function() {
                        this.$emit("closeBox", !1)
                    }, e.prototype.closeDate = function() {
                        var t = new Date,
                            e = t.getUTCFullYear(),
                            o = t.getUTCMonth() + 1,
                            n = t.getUTCDate(),
                            r = t.getUTCHours() + 8,
                            c = t.getUTCMinutes(),
                            s = t.getUTCSeconds();
                        new Date(e, o, n, r, c, s).getTime() > new Date(2020, 9, 16, 23, 59, 59).getTime() && (this.isEnd = !0)
                    }, e.prototype.isShowHandler = function() {
                        this.$emit("update:isShow", !1)
                    }, e.prototype.closeHandler = function(t) {
                        return "rog.asus.com.cn" !== window.location.host && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "buttons",
                            event_action_DL: "clicked",
                            event_label_DL: "close_Pop-up"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "buttons",
                                event_action_DL: "clicked",
                                event_label_DL: "close_Pop-up"
                            })
                        }), 200)), document.getElementsByTagName("html")[0].classList.remove("fixScroll"), t.target.className.baseVal && t.target.className.baseVal.indexOf("closeLightBox") > -1 || t.target.tagName && "path" === t.target.tagName || t.target.className && t.target.className.indexOf("AdvertisingActivityWrapper") > -1 ? (this.isShowHandler(), void Object(h.c)("rog_close_advert", encodeURI("1"), "")) : void 0
                    }, e.prototype.focusOnAdvertise = function() {
                        var t = this;
                        this.$nextTick((function() {
                            setTimeout((function() {
                                var e = t.$refs.advertiseWrapper;
                                e && e.focus()
                            }), 500)
                        }))
                    }, e.prototype.gaHandler = function() {
                        var t = this.adsUrl;
                        "rog.asus.com.cn" !== window.location.host && window.dataLayer.push({
                            event: "promotionClick",
                            ecommerce: {
                                promoClick: {
                                    promotions: [{
                                        id: t,
                                        name: "live stream",
                                        position: "homepage_Pop-up"
                                    }]
                                }
                            },
                            eventCallback: function() {
                                window.location.href = t
                            }
                        })
                    }, e.prototype.gaDefaultHandler = function() {
                        window.dataLayer && this.popUpAds && this.popUpAds.url && "rog.asus.com.cn" !== window.location.host && window.dataLayer.push({
                            event: "promotionView",
                            ecommerce: {
                                promoView: {
                                    promotions: [{
                                        id: this.adsUrl,
                                        name: "live stream",
                                        position: "homepage_Pop-up"
                                    }]
                                }
                            }
                        })
                    }, e.prototype.mounted = function() {
                        var t = this;
                        this.closeDate(), this.focusOnAdvertise(), setTimeout((function() {
                            t.gaDefaultHandler()
                        }), 1500)
                    }, _([Object(d.Action)("getPopUpAds")], e.prototype, "getPopUpAds", void 0), _([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), _([Object(d.Getter)("popUpAds")], e.prototype, "popUpAds", void 0), _([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "isShow", void 0), e = _([Object(l.Component)({})], e)
                }(l.Vue),
                y = f,
                v = o(391),
                m = o(25);
            var component = Object(m.a)(y, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.isShow && t.popUpAds && Object.keys(t.popUpAds).length > 0 && "" !== t.popUpAds.mediaPC ? e("div", [e("div", {
                    ref: "advertiseWrapper",
                    class: t.$style.AdvertisingActivityWrapper,
                    attrs: {
                        tabindex: "0"
                    },
                    on: {
                        click: t.closeHandler,
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "esc", 27, e.key, ["Esc", "Escape"]) ? null : t.isShowHandler.apply(null, arguments)
                        }
                    }
                }, [e("div", {
                    class: [t.$style.AdvertisingActivityContent, Object(r.a)({}, t.$style.youtubeContent, t.isYoutube)]
                }, [e("button", {
                    staticClass: "closeLightBox",
                    class: t.$style.closeLightBox,
                    attrs: {
                        tabindex: "0"
                    },
                    on: {
                        click: t.isShowHandler
                    }
                }, [e("svg", {
                    class: "closeLightBox",
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        role: "none",
                        focusable: "false",
                        "aria-hidden": "true",
                        alt: "no image",
                        title: "no image",
                        loading: "lazy"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M28 5.41L26.59 4 16 14.59 5.41 4 4 5.41 14.59 16 4 26.59 5.41 28 16 17.41 26.59 28 28 26.59 17.41 16 28 5.41z"
                    }
                })])]), t._v(" "), e("div", {
                    class: t.$style.AdsWrapper
                }, [e("a", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !t.isYoutube && !t.isFB,
                        expression: "!isYoutube && !isFB"
                    }],
                    attrs: {
                        href: t.adsUrl
                    },
                    on: {
                        click: function(e) {
                            return e.preventDefault(), t.gaHandler()
                        }
                    }
                }, [e("img", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.adsImgUrl,
                        expression: "adsImgUrl"
                    }],
                    class: t.$style.desktopSize,
                    attrs: {
                        src: encodeURI("".concat(t.adsImgUrl)),
                        alt: t.adsAltPC,
                        loading: "lazy"
                    }
                }), t._v(" "), e("img", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.adsMobileImgUrl,
                        expression: "adsMobileImgUrl"
                    }],
                    class: t.$style.mobileSize,
                    attrs: {
                        src: encodeURI("".concat(t.adsMobileImgUrl)),
                        alt: t.adsAltMobile,
                        loading: "lazy"
                    }
                })]), t._v(" "), e("iframe", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.isFB,
                        expression: "isFB"
                    }],
                    staticStyle: {
                        border: "none",
                        overflow: "hidden"
                    },
                    attrs: {
                        width: "100%",
                        height: "100%",
                        src: "".concat(t.fbHandler(t.adsUrl)),
                        scrolling: "no",
                        frameborder: "0",
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share",
                        allowfullscreen: ""
                    }
                }), t._v(" "), e("iframe", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.isYoutube,
                        expression: "isYoutube"
                    }],
                    attrs: {
                        width: "100%",
                        height: "100%",
                        src: "".concat(t.youtubeHandler(t.adsUrl)),
                        frameborder: "0",
                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                        allowfullscreen: ""
                    }
                })])])])]) : t._e()
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        }
    }
]);