(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [18], {
        102: function(e, t, r) {
            "use strict";
            r(10), r(43), r(46), r(52), r(37), r(38), r(18);
            var n = r(484),
                o = r(1),
                _ = r(36),
                c = function(e, t, r, n) {
                    return new(r || (r = Promise))((function(o, _) {
                        function c(e) {
                            try {
                                f(n.next(e))
                            } catch (e) {
                                _(e)
                            }
                        }

                        function l(e) {
                            try {
                                f(n.throw(e))
                            } catch (e) {
                                _(e)
                            }
                        }

                        function f(e) {
                            var t;
                            e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(c, l)
                        }
                        f((n = n.apply(e, t || [])).next())
                    }))
                },
                l = function(e, body) {
                    var t, r, n, g, o = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: _(0),
                        throw: _(1),
                        return: _(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function _(_) {
                        return function(c) {
                            return function(_) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, _[0] && (o = 0)), o;) try {
                                    if (t = 1, r && (n = 2 & _[0] ? r.return : _[0] ? r.throw || ((n = r.return) && n.call(r), 0) : r.next) && !(n = n.call(r, _[1])).done) return n;
                                    switch (r = 0, n && (_ = [2 & _[0], n.value]), _[0]) {
                                        case 0:
                                        case 1:
                                            n = _;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: _[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, r = _[1], _ = [0];
                                            continue;
                                        case 7:
                                            _ = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = o.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== _[0] && 2 !== _[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === _[0] && (!n || _[1] > n[0] && _[1] < n[3])) {
                                                o.label = _[1];
                                                break
                                            }
                                            if (6 === _[0] && o.label < n[1]) {
                                                o.label = n[1], n = _;
                                                break
                                            }
                                            if (n && o.label < n[2]) {
                                                o.label = n[2], o.ops.push(_);
                                                break
                                            }
                                            n[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    _ = body.call(e, o)
                                } catch (e) {
                                    _ = [6, e], r = 0
                                } finally {
                                    t = n = 0
                                }
                                if (5 & _[0]) throw _[1];
                                return {
                                    value: _[0] ? _[1] : void 0,
                                    done: !0
                                }
                            }([_, c])
                        }
                    }
                },
                f = function() {
                    function e() {
                        this.routeInfoParam = {
                            url: ""
                        }
                    }
                    return e.prototype.pathnameVal = function() {
                        try {
                            return window.location.pathname
                        } catch (e) {
                            return ""
                        }
                    }, e.prototype.isECSite = function(e) {
                        return e.indexOf("stage.store") > -1 ? "https://dev-rog.asus.com" : "https://rog.asus.com"
                    }, e.prototype.originVal = function() {
                        try {
                            return Object(_.a)() ? encodeURI(window.location.origin) : this.isECSite(encodeURI(window.location.origin))
                        } catch (e) {
                            return ""
                        }
                    }, e.prototype.getRouteInfoAPI = function(e) {
                        return c(this, void 0, Promise, (function() {
                            var t, r, _, c;
                            return l(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return t = e ? this.splitePathNameVal(e.path) : this.splitePathNameVal(), r = this.originVal(), _ = this.chkPathnameSite(), c = this.routeInfoParam, t && (c.url = "".concat(t)), _.type ? [4, n.a.getWebsiteInfo(r, c)] : [3, 2];
                                    case 1:
                                    case 3:
                                        return [2, l.sent()];
                                    case 2:
                                        return [4, o.a.getRouteInfo(c)]
                                }
                            }))
                        }))
                    }, e.prototype.chkPathnameSite = function() {
                        var e = this.pathnameVal(),
                            t = {
                                type: null,
                                basicPathname: null
                            };
                        return t.type = /(\/elite)/gi.test(e), t.basicPathname = e, t
                    }, e.prototype.splitePathNameVal = function(path) {
                        void 0 === path && (path = "");
                        return "" === path ? this.pathnameVal() : path
                    }, e
                }();
            t.a = f
        },
        235: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            }));
            r(10), r(32);

            function n(e, area) {
                var t = "";
                return e ? (e.forEach((function(e) {
                    e.WebPath !== area && e.webPath !== area || (t = e.AccountLang || e.accountLang)
                })), t) : t
            }
        },
        36: function(e, t, r) {
            "use strict";
            r.d(t, "c", (function() {
                return c
            })), r.d(t, "b", (function() {
                return n
            }));
            r(10);
            var n = ["dev-rog.asus.com", "stage-rog.asus.com", "rogmars.asus.com", "rogmars.asus.com:8034", "rog.asus.com.cn", "rog.asus.com", "localhost", "rog-bacchus.asus.com", "www.asus.com", "nomos.asus.com", "sowoverload.asus.com", "localhost:8000"],
                o = ["rogmars.asus.com", "rog.asus.com", "stage-rog.asus.com", "rog.asus.com.cn"],
                _ = function() {
                    try {
                        if (window) return encodeURI(window.location.hostname)
                    } catch (e) {
                        return ""
                    }
                },
                c = function() {
                    var e = !1,
                        t = _();
                    return o.forEach((function(r) {
                        r === t && (e = !0)
                    })), e
                };
            t.a = function() {
                var e = !1,
                    t = _();
                return n.forEach((function(r) {
                    r === t && (e = !0)
                })), e
            }
        },
        396: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            }));
            r(10), r(32), r(73), r(44);

            function n(e, t) {
                var r = null;
                return e.forEach((function(element) {
                    Number(element.id) === Number(t) && (r = element.filter)
                })), r
            }
        },
        397: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            }));
            r(10), r(33), r(32);

            function n(e, t) {
                var r = t.split(","),
                    n = e.toString(),
                    o = !1;
                return r.forEach((function(e) {
                    e === n && (o = !0)
                })), o
            }
        },
        4: function(e, t, r) {
            "use strict";
            r.d(t, "b", (function() {
                return n
            })), r.d(t, "c", (function() {
                return o
            })), r.d(t, "a", (function() {
                return _
            }));
            r(18), r(103), r(615), r(10), r(37), r(620), r(621), r(622), r(623), r(624), r(625), r(627), r(628), r(629), r(630), r(631), r(632), r(633), r(38), r(73);

            function n(e) {
                var t = document.cookie.match("(^|;) ?" + e + "=([^;]*)(;|$)");
                return t ? t[2] : null
            }

            function o(e, t, r) {
                var n, o, _ = encodeURI(t);
                r ? ((n = new Date).setTime(n.getTime() + 864e5 * Number(r)), o = new Date(n).getTimezoneOffset() / 60) : ((n = new Date).setTime(n.getTime() + 2592e6), o = new Date(n).getTimezoneOffset() / 60), n.setTime(n.getTime() + 24 * (-8 - o) * 60 * 60 * 1e3);
                var c = "expires=" + n.toUTCString(),
                    l = window.location.host.indexOf("asus.com.cn") > -1 ? ".asus.com.cn" : ".asus.com";
                void 0 !== _ && (document.cookie = e + "=" + _ + ";" + c + ";domain=" + l + ";path=/;SameSite=Lax;secure;")
            }

            function _(e) {
                document.cookie = e + "=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/; domain=" + encodeURI(".asus.com") + ";"
            }
        },
        401: function(e, t, r) {
            "use strict";
            var n, o = r(9),
                _ = (r(54), r(41), r(10), r(47), r(70), r(8)),
                c = r(3),
                l = (n = function(e, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, b) {
                        e.__proto__ = b
                    } || function(e, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (e[p] = b[p])
                    }, n(e, b)
                }, function(e, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function t() {
                        this.constructor = e
                    }
                    n(e, b), e.prototype = null === b ? Object.create(b) : (t.prototype = b.prototype, new t)
                }),
                f = function(e, t, r, desc) {
                    var n, _ = arguments.length,
                        c = _ < 3 ? t : null === desc ? desc = Object.getOwnPropertyDescriptor(t, r) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(o.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, r, desc);
                    else
                        for (var i = e.length - 1; i >= 0; i--)(n = e[i]) && (c = (_ < 3 ? n(c) : _ > 3 ? n(t, r, c) : n(t, r)) || c);
                    return _ > 3 && c && Object.defineProperty(t, r, c), c
                },
                d = function(e) {
                    function t() {
                        return null !== e && e.apply(this, arguments) || this
                    }
                    return l(t, e), t.prototype.gaDataLayerPush = function(data) {
                        try {
                            if ("data_layer_page_level_SPA" === data.event && (window.countOfDataLayerPageLevelSPA = window.countOfDataLayerPageLevelSPA + 1, 1 === window.countOfDataLayerPageLevelSPA)) return;
                            window.location.hostname.includes(".cn") && "cn" === this.$route.params.area || window.dataLayer.push(data)
                        } catch (e) {}
                    }, t.prototype.gaHmtPush = function(data) {
                        var e;
                        try {
                            ((null === (e = "api-rog.asus.com") ? void 0 : e.includes(".cn")) || "cn" === this.$route.params.area) && window._hmt.push(data)
                        } catch (e) {}
                    }, t = f([Object(c.Component)({})], t)
                }(_.default);
            t.a = d
        },
        478: function(module, __webpack_exports__, __webpack_require__) {
            "use strict";
            (function(process) {
                __webpack_require__.d(__webpack_exports__, "a", (function() {
                    return createHttpClient
                }));
                var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(47),
                    core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_0__),
                    core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10),
                    core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_1__),
                    core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33),
                    core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_2__),
                    core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(37),
                    core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_3__),
                    core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38),
                    core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = __webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_4__),
                    core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(146),
                    core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5___default = __webpack_require__.n(core_js_modules_web_url_search_params_js__WEBPACK_IMPORTED_MODULE_5__),
                    core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32),
                    core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_6___default = __webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_6__),
                    core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(18),
                    core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7___default = __webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_7__),
                    core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(29),
                    core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8___default = __webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_8__),
                    https__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(118),
                    https__WEBPACK_IMPORTED_MODULE_9___default = __webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_9__),
                    axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6),
                    axios__WEBPACK_IMPORTED_MODULE_10___default = __webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_10__);

                function createHttpClient(baseUrl, config) {
                    var instance;
                    void 0 === config && (config = {}), instance = axios__WEBPACK_IMPORTED_MODULE_10___default.a.create({
                        httpsAgent: new https__WEBPACK_IMPORTED_MODULE_9___default.a.Agent({
                            rejectUnauthorized: !1,
                            keepAlive: !0,
                            maxSockets: 200
                        }),
                        timeout: 25e3
                    });
                    var EXCLUDED_DOMAINS = ["stage-api-rog.asus.com", "stage-api-rog.asus.com.cn", "api-rog.asus.com", "api-rog.asus.com.cn", "rog.asus.com", "rog.asus.com.cn"];
                    return instance.interceptors.response.use((function(res) {
                        try {
                            if ("undefined" != typeof window && !EXCLUDED_DOMAINS.includes(baseUrl)) {
                                var NDATA = eval('window["__NUXT__"].state.Config');
                                NDATA.APIList += "," + res.request.responseURL
                            }
                        } catch (e) {}
                        return res
                    })), process.env.APILIST = "", instance.interceptors.request.use((function(e) {
                        var t = "";
                        if (-1 === e.url.indexOf("127.0.0.1")) {
                            t = e.url.split("https://")[1].split("/")[0], e.url;
                            var r = e.params || {};
                            e.url.indexOf("nomos") > -1 || e.url.indexOf("service/sign") > -1 || (r.systemCode = setCDNSystemCodeHandler(t), e.params = r)
                        }
                        return e
                    })), instance
                }
                var setCDNSystemCodeHandler = function(e) {
                        var t = window.location.host,
                            r = window.location.href;
                        if (r.indexOf("/event") > -1 || r.indexOf("/microsite") > -1 || r.indexOf("/campaign") > -1) return r.indexOf("/event") > -1 ? "rogevent" : r.indexOf("/microsite") > -1 ? "rogmicrosite" : r.indexOf("/campaign") > -1 ? "rogcampaign" : "";
                        switch (e) {
                            case "dev-api-rog.asus.com":
                                return "devrog";
                            case "api-rogmars.asus.com":
                                return "rogmars";
                            case "stage-api-rog.asus.com":
                                return "stage-rog";
                            case "api-rog.asus.com":
                            case "rog-bacchus.asus.com":
                                return "rog";
                            case "api-rog.asus.com.cn":
                                return "rogcn"
                        }
                        switch (t) {
                            case "localhost:8000":
                                return "localrog";
                            case "dev-rog.asus.com":
                                return "devrog";
                            case "rogmars.asus.com":
                                return "rogmars";
                            case "stage-rog.asus.com":
                                return "stage-rog";
                            case "rog.asus.com":
                                return "rog";
                            case "sowoverload.asus.com":
                                return "sowoverload";
                            case "www.asus.com":
                                return "asus";
                            case "account.asus.com":
                                return "account";
                            case "dev-account.asus.com":
                                return "devaccount";
                            case "nomos.asus.com":
                                return "nomos";
                            case "rog.asus.com.cn":
                                return "cdnta.asus.com.cn" === e ? "rog" : "rogcn";
                            case "rog-bacchus.asus.com":
                                return "devsupport";
                            default:
                                var n = window.location.host.replace(".asus.com", "").replace(".", "");
                                return "rog".concat(n)
                        }
                    },
                    setServerCDNSystemCodeHandler = function(e, t) {
                        var r = e;
                        if (t.indexOf("/event") > -1 || t.indexOf("/microsite") > -1 || t.indexOf("/campaign") > -1) return t.indexOf("/event") > -1 ? "rogevent" : t.indexOf("/microsite") > -1 ? "rogmicrosite" : t.indexOf("/campaign") > -1 ? "rogcampaign" : "";
                        switch (r) {
                            case "localhost:8000":
                                return "localrog";
                            case "dev-api-rog.asus.com":
                                return "devrog";
                            case "api-rogmars.asus.com":
                                return "rogmars";
                            case "stage-api-rog.asus.com":
                                return "stage-rog";
                            case "api-rog.asus.com.cn":
                                return "rogcn";
                            case "api-rog.asus.com":
                                return "rog";
                            default:
                                var n = r.replace(".asus.com", "").replace(".", "");
                                return "rog".concat(n)
                        }
                    }
            }).call(this, __webpack_require__(74))
        },
        485: function(e, t, r) {
            "use strict";
            t.a = function() {
                return encodeURI(window.location.origin), "Em3l6i7t2qe"
            }
        },
        486: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            }));
            r(47), r(70);

            function n(e) {
                var t, r = "";
                if (null === (t = "api-rog.asus.com") ? void 0 : t.includes(".cn")) r = "cn";
                else if (e) {
                    r = e.toLowerCase()
                } else r = "global";
                return r
            }
        },
        557: function(e, t, r) {
            "use strict";
            r.r(t), t.default = function(e, t, r) {
                var n = t.writeHead;
                t.writeHead = function(e, t) {
                    return e < 400 && (t || (t = {}), t["Cache-Control"] = "max-age=3600"), n.apply(this, [e, t])
                }, r()
            }
        },
        558: function(e, t, r) {
            "use strict";
            r.r(t),
                function(e) {
                    var n = r(31),
                        o = (r(116), r(122), r(47), r(70), r(18), r(29), r(51), r(103), r(10), r(33), r(37), r(38), r(146), r(88)),
                        _ = r(1);

                    function c() {
                        return c = Object(n.a)(regeneratorRuntime.mark((function t(r) {
                            var c, l, f, d, m, h, w, E, P, O, v, D, path, j, M, y, C;
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return c = r.route, l = r.store, f = r.redirect, r.req, r.error, d = r.env, r.$axios, m = decodeURIComponent(c.fullPath), !1, h = m.split("?"), w = h.join("&"), w.substr(0, w.indexOf("&")) + "?" + w.substr(w.indexOf("&") + 1, w.length), E = c.fullPath.split("/")[1].toLowerCase(), P = "global", O = o.a, -1 !== d.baseUrl.indexOf(".cn") ? P = "cn" : "global" !== E && O.includes(E) ? "cn" === E ? ("api-rogmars.asus.com" === d.baseUrl || "dev-api-rog.asus.com" === d.baseUrl || "stage-api-rog.asus.com" === d.baseUrl ? P = "cn" : c.fullPath.indexOf("/cn") > -1 && (v = c.fullPath.replace("/cn/", ""), f(301, "https://rog.asus.com.cn/".concat(v)), P = "cn"), P = "cn") : P = E : P = "global", D = c.fullPath, path = c.path, "/" === D.slice(-1) || D.includes("?") || (D = c.fullPath + "/"), null !== path.match(/^.*[A-Z]+.*$/) && (j = (j = new URLSearchParams(c.query).toString() ? "?" + new URLSearchParams(c.query).toString() : "").replace(/apilist=null/i, "apilist"), D = path.toLowerCase() + j), D !== c.fullPath && f(301, D), e.env.APILIST = "", "/" === c.fullPath ? c.fullPath : c.fullPath.slice(1), t.next = 19, l.dispatch("setLeaveStatus", !0);
                                    case 19:
                                        return t.next = 21, l.dispatch("setRoute", c.fullPath);
                                    case 21:
                                        if ({
                                                dev: {
                                                    username: "chatbot",
                                                    password: "E))CTBSk)fpJaMk*"
                                                },
                                                stage: {
                                                    username: "chatbot",
                                                    password: "y2&YvU47sQqv4k34"
                                                },
                                                prod: {
                                                    username: "chatbot",
                                                    password: "axyyme6&(R7ftrDI"
                                                }
                                            }, {
                                                dev: "https://dev-accountmw.asus.com",
                                                stage: "https://stage-accountmw.asus.com",
                                                prod: "https://accountmw.asus.com"
                                            }, M = {
                                                dev: "https://dev-mwservice.asus.com",
                                                stage: "https://stage-mwservice.asus.com",
                                                prod: "https://mwservice.asus.com"
                                            }, "prod", y = function() {
                                                var e = Object(n.a)(regeneratorRuntime.mark((function e(t) {
                                                    var r;
                                                    return regeneratorRuntime.wrap((function(e) {
                                                        for (;;) switch (e.prev = e.next) {
                                                            case 0:
                                                                return e.next = 2, _.a.getAiAssistantStatus({
                                                                    baseUrl: M.prod,
                                                                    websiteCode: t,
                                                                    systemId: 2
                                                                }).then((function(e) {
                                                                    var t;
                                                                    return !(null == e || null === (t = e.data) || void 0 === t || null === (t = t.result) || void 0 === t || !t.status) && e.data.result.status
                                                                }));
                                                            case 2:
                                                                return r = e.sent, e.abrupt("return", r);
                                                            case 4:
                                                            case "end":
                                                                return e.stop()
                                                        }
                                                    }), e)
                                                })));
                                                return function(t) {
                                                    return e.apply(this, arguments)
                                                }
                                            }(), C = !1, "cn" === P) {
                                            t.next = 34;
                                            break
                                        }
                                        if ("localhost" === window.location.hostname) {
                                            t.next = 34;
                                            break
                                        }
                                        return t.next = 33, y(P);
                                    case 33:
                                        C = t.sent;
                                    case 34:
                                        return t.next = 36, l.dispatch("setAIStatus", C);
                                    case 36:
                                        0;
                                    case 37:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        }))), c.apply(this, arguments)
                    }
                    t.default = function(e) {
                        return c.apply(this, arguments)
                    }
                }.call(this, r(74))
        },
        79: function(e, t, r) {
            "use strict";

            function n() {
                return {
                    width: window.innerWidth,
                    height: window.innerHeight
                }
            }
            r.d(t, "a", (function() {
                return n
            }))
        },
        88: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            })), r.d(t, "b", (function() {
                return o
            }));
            r(20);
            var n = ["global", "de", "pl", "se", "dk", "cz", "it", "hu", "fi", "pt", "es", "fr", "nl", "be-fr", "be-nl"].concat(["bt", "me-en", "lk", "in", "tr", "tw", "bd", "cn", "hk", "vn", "kr", "jp", "ru", "th", "sg", "nz", "ph", "id", "au", "my", "br", "latin", "no", "uk", "sk", "ch-fr", "ch-it", "ch-de", "ro", "rs", "ua", "gr", "za", "ca-fr", "ca-en", "us", "me-ar", "mx", "bg", "ie", "il", "ea", "middleeast-fa", "eg", "ua-ua", "nafr-ar", "africa-fr", "np", "wa", "lt", "lv", "ee", "kz", "mm", "eg-en", "hk-en", "co", "cl", "ar", "pe", "ea-sw", "ch-en", "bn", "gr-el", "ec", "py", "uy", "pk", "kh", "sa-ar", "sa-en", "gr-en", "rs-en", "hr", "si", "mn"]),
                o = ["il", "eg", "me-ar", "nafr-ar", "sa-ar"]
        }
    }
]);