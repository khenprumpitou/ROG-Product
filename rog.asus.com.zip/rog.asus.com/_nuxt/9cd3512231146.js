(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [1], {
        1040: function(t, e, o) {
            "use strict";
            var n = o(771),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1041: function(t, e, o) {
            "use strict";
            var n = o(772),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1085: function(t, e, o) {
            t.exports = o.p + "img/hdmi-logo.cedf31f.png"
        },
        1086: function(t, e, o) {
            t.exports = o.p + "img/HDMI_logo_R_Gray.3857aa7.png"
        },
        1088: function(t, e, o) {
            "use strict";
            var n = o(813),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1202: function(t, e, o) {
            t.exports = o.p + "img/icon-star-off.9097aa8.png"
        },
        1203: function(t, e, o) {
            t.exports = o.p + "img/icon-star-half.fd3469c.png"
        },
        1204: function(t, e, o) {
            t.exports = o.p + "img/icon-star-on.bb88e69.png"
        },
        691: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(28), o(18), o(29), o(59), o(3)),
                f = o(7),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                y = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.windowOffsetTop = 0, e.offsetTopHandler = 0, e.criticalPoint = 2500, e
                    }
                    return d(e, t), Object.defineProperty(e.prototype, "isShow", {
                        get: function() {
                            return !(this.windowOffsetTop < 1) && (this.windowOffsetTop, this.criticalPoint, !0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.scrollListener = function() {
                        "undefined" != typeof window && (this.offsetTopHandler = window.pageYOffset || document.documentElement.scrollTop, this.offsetTopHandler >= this.criticalPoint ? this.windowOffsetTop = this.criticalPoint : 0 === this.offsetTopHandler && (this.windowOffsetTop = 0))
                    }, e.prototype.scrollToTopHandler = function() {
                        var t = -window.scrollY / (1e3 / 30),
                            e = setInterval((function() {
                                0 != window.scrollY ? window.scrollBy(0, t) : clearInterval(e)
                            }), 5)
                    }, e.prototype.mounted = function() {
                        var t = this;
                        "undefined" != typeof window && window.addEventListener("scroll", (function() {
                            return t.scrollListener()
                        }))
                    }, e.prototype.beforeDestroy = function() {
                        var t = this;
                        "undefined" != typeof window && window.removeEventListener("scroll", (function() {
                            return t.scrollListener()
                        }))
                    }, h([Object(f.Getter)("translation")], e.prototype, "translation", void 0), e = h([Object(c.Component)({})], e)
                }(c.Vue),
                _ = y,
                m = o(1040),
                w = o(25);
            var component = Object(w.a)(_, (function() {
                    var t = this,
                        e = t._self._c;
                    t._self._setupProxy;
                    return e("button", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isShow,
                            expression: "isShow"
                        }],
                        class: t.$style.goTop,
                        attrs: {
                            "aria-label": t.translation.Aria_Go_Top,
                            tabindex: "0",
                            type: "button"
                        },
                        on: {
                            keydown: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.scrollToTopHandler.apply(null, arguments)
                            },
                            click: t.scrollToTopHandler
                        }
                    }, [e("svg", {
                        attrs: {
                            width: "60",
                            height: "60",
                            viewBox: "0 0 60 60",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            "aria-hidden": "true",
                            alt: "",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [e("circle", {
                        attrs: {
                            cx: "30",
                            cy: "30",
                            r: "30",
                            fill: "#7F7F7F"
                        }
                    }), e("path", {
                        attrs: {
                            d: "M17 34.91V38l13-13.91L43 38v-3.09L30 21 17 34.91z",
                            fill: "#fff"
                        }
                    })])])
                }), [], !1, (function(t) {
                    this.$style = m.default.locals || m.default
                }), null, null),
                v = component.exports,
                O = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                x = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                j = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isChatBot = !1, e
                    }
                    return O(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return Object.keys(this.routeInfo).length > 0 ? (this.routeInfo.websitePath, this.routeInfo.websitePath) : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareType", {
                        get: function() {
                            if (this.routeInfo.fullPath) {
                                var t = this.routeInfo.fullPath;
                                return "global" === this.routeInfo.websitePath ? t.split("/")[0].replace("-group", "") : "cn" === this.routeInfo.websitePath ? t.indexOf("cn/") > -1 ? t.split("/")[1].replace("-group", "") : t.split("/")[0].replace("-group", "") : t.split("/")[1].replace("-group", "")
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareAmount", {
                        get: function() {
                            if (this.compareType && this.compareSelect[this.compareType]) return this.compareSelect[this.compareType].length
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.mounted = function() {
                        var t = this;
                        setTimeout((function() {
                            "undefined" != typeof window && ("function" == typeof window.brandAssistantGetStatus ? t.isChatBot = window.brandAssistantGetStatus().display : t.isChatBot = !1)
                        }), 1e3)
                    }, x([Object(f.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), x([Object(f.Getter)("comparePanelStatus")], e.prototype, "comparePanelStatus", void 0), x([Object(f.Getter)("compareSelect")], e.prototype, "compareSelect", void 0), x([Object(f.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), x([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "haveCompareStatus", void 0), x([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isMember", void 0), e = x([Object(c.Component)({
                        components: {
                            GoTop: v
                        }
                    })], e)
                }(c.Vue),
                P = j,
                B = o(1041);
            var M = Object(w.a)(P, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    class: [e.$style.fixedStatus, (t = {}, Object(r.a)(t, e.$style.haveCompare, e.haveCompareStatus), Object(r.a)(t, e.$style.isCoCl, "co" === e.lang || "cl" === e.lang), Object(r.a)(t, e.$style.compareOpen, e.comparePanelStatus), Object(r.a)(t, e.$style.isChatBot, e.isChatBot || e.getAIStatus), Object(r.a)(t, e.$style.isMember, e.isMember), Object(r.a)(t, e.$style.compareChecked, e.compareAmount > 0), t)]
                }, [o("GoTop"), e._v(" "), e._t("default")], 2)
            }), [], !1, (function(t) {
                this.$style = B.default.locals || B.default
            }), null, null);
            e.a = M.exports
        },
        716: function(t, e, o) {
            t.exports = {
                lightBoxActivityContainer: "VideoLightBox__lightBoxActivityContainer__-bAYZ",
                lightBoxActivtyLink: "VideoLightBox__lightBoxActivtyLink__nUOGp",
                profile: "VideoLightBox__profile__qUkgn",
                closeLightBox: "VideoLightBox__closeLightBox__OoSof",
                lightBoxActivityWrapper: "VideoLightBox__lightBoxActivityWrapper__gYD4b",
                lightBoxActivityContent: "VideoLightBox__lightBoxActivityContent__kp+Tt",
                active: "VideoLightBox__active__uT5h1"
            }
        },
        771: function(t, e, o) {
            t.exports = {
                goTop: "GoTop__goTop__O8C7D"
            }
        },
        772: function(t, e, o) {
            t.exports = {
                fixedStatus: "FixedStatus__fixedStatus__d-MD2",
                haveCompare: "FixedStatus__haveCompare__f-Ebc",
                compareOpen: "FixedStatus__compareOpen__XU8n+",
                isChatBot: "FixedStatus__isChatBot__RORXw",
                compareChecked: "FixedStatus__compareChecked__+vJki",
                isMember: "FixedStatus__isMember__7Qjwd",
                isCoCl: "FixedStatus__isCoCl__insKo"
            }
        },
        813: function(t, e, o) {
            t.exports = {
                potentialMemberWrapper: "PotentialMember__potentialMemberWrapper__HpOOf",
                closeButton: "PotentialMember__closeButton__qO6Gw",
                potentialMemberInputWrapper: "PotentialMember__potentialMemberInputWrapper__WjFIX",
                measureSpan: "PotentialMember__measureSpan__GhUQv",
                potentialMemberInput: "PotentialMember__potentialMemberInput__Wsp-G",
                warn: "PotentialMember__warn__UeRhY",
                potentialMemberButton: "PotentialMember__potentialMemberButton__3Cxiw",
                warnText: "PotentialMember__warnText__Y3RfU",
                show: "PotentialMember__show__8zY5O"
            }
        },
        898: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(59), o(3)),
                f = o(7),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                y = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isActive = !1, e.isEnd = !1, e
                    }
                    return d(e, t), e.prototype.watchVideoPop = function(t, e) {
                        var o = this;
                        t.status && setTimeout((function() {
                            var t = o.$refs.videoClose;
                            t instanceof HTMLElement && t.focus()
                        }), 1e3)
                    }, e.prototype.closeLightBox = function() {
                        this.$emit("closeBox", !1)
                    }, e.prototype.showHandler = function() {
                        this.isActive = !0
                    }, e.prototype.youtubeHandler = function(t) {
                        var e = "";
                        if (t.split("?v=").length > 1) e = t.split("?v=")[1].split("&")[0];
                        else if (t.indexOf("https://www.youtube.com/embed/") > -1 && t.split("https://www.youtube.com/embed/").length > 1) e = t.split("?")[0].split("https://www.youtube.com/embed/")[1];
                        else if (t.indexOf("https://www.youtube-nocookie.com/embed/") > -1 && t.split("https://www.youtube-nocookie.com/embed/").length > 1) e = t.split("?")[0].split("https://www.youtube-nocookie.com/embed/")[1];
                        else if (t.indexOf("https://youtu.be/") > -1 && t.split("https://youtu.be/").length > 1) e = t.split("?")[0].split("https://youtu.be/")[1];
                        else if (t.indexOf("https://www.youtube.com/shorts/") > -1 && t.split("https://www.youtube.com/shorts/").length > 1) e = t.split("https://www.youtube.com/shorts/")[1];
                        else if (t.indexOf("https://www.youtube-nocookie.com/shorts/") > -1 && t.split("https://www.youtube-nocookie.com/shorts/").length > 1) e = t.split("https://www.youtube-nocookie.com/shorts/")[1];
                        else if (t.indexOf("https://youtube.com/shorts/") > -1 && t.split("https://youtube.com/shorts/").length > 1) {
                            e = t.split("?")[0].split("https://youtube.com/shorts/")[1]
                        }
                        return "https://www.youtube-nocookie.com/embed/".concat(e)
                    }, e.prototype.closeHandler = function(t) {
                        t.target.className.baseVal && t.target.className.baseVal.indexOf("closeLightBox") > -1 && (this.isActive = !1, this.closeVideo()), t.target.className.indexOf("closeLightBox") > -1 && (this.isActive = !1, this.closeVideo()), t.target.className.indexOf("lightBoxActivityWrapper") > -1 && (this.isActive = !1, this.closeVideo())
                    }, e.prototype.closeVideo = function() {
                        var t = document.getElementsByTagName("html")[0],
                            e = t.getAttribute("data-Y");
                        t.classList.remove("fixScroll"), window.scrollTo(0, parseInt(e)), this.getCookie({
                            type: "videoPop",
                            value: {
                                status: !1,
                                url: ""
                            }
                        })
                    }, e.prototype.mounted = function() {}, h([Object(f.Action)("getCookie")], e.prototype, "getCookie", void 0), h([Object(f.Getter)("videoPop")], e.prototype, "videoPop", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isProfile", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isShow", void 0), h([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "youtubeLink", void 0), h([Object(c.Watch)("videoPop")], e.prototype, "watchVideoPop", null), e = h([Object(c.Component)({})], e)
                }(c.Vue),
                _ = y,
                m = o(980),
                w = o(25);
            var component = Object(w.a)(_, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return this.videoPop && this.videoPop.status ? e("div", {
                    staticClass: "popup",
                    class: [t.$style.lightBoxActivityContainer]
                }, [e("div", {
                    class: [t.$style.lightBoxActivityWrapper, Object(r.a)({}, t.$style.active, !0)],
                    on: {
                        click: t.closeHandler
                    }
                }, [e("div", {
                    class: t.$style.lightBoxActivityContent
                }, [e("span", {
                    ref: "videoClose",
                    staticClass: "closeLightBox",
                    class: t.$style.closeLightBox,
                    attrs: {
                        tabindex: "0",
                        "aria-label": "close"
                    },
                    on: {
                        keydown: function(e) {
                            return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.closeVideo.apply(null, arguments)
                        },
                        click: t.closeVideo
                    }
                }, [e("svg", {
                    class: "closeLightBox",
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        role: "none",
                        focusable: "false",
                        "aria-hidden": "true",
                        alt: "no image"
                    }
                }, [e("path", {
                    attrs: {
                        d: "M28 5.41L26.59 4 16 14.59 5.41 4 4 5.41 14.59 16 4 26.59 5.41 28 16 17.41 26.59 28 28 26.59 17.41 16 28 5.41z"
                    }
                })])]), t._v(" "), e("a", {
                    staticClass: "asusCB-video",
                    attrs: {
                        href: "".concat(t.youtubeHandler(this.videoPop.url)),
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }
                }, [e("img", {
                    attrs: {
                        src: "".concat(this.videoPop.img)
                    }
                })])])])]) : t._e()
            }), [], !1, (function(t) {
                this.$style = m.default.locals || m.default
            }), null, null);
            e.a = component.exports
        },
        947: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(91), o(18), o(33), o(59), o(3)),
                f = o(7),
                d = o(144),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                y = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                _ = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isShowMember = !0, e.showWarn = !1, e.potentialMemberValue = "", e.warnText = "Please enter a valid email address.", e.inputWidth = 240, e
                    }
                    return h(e, t), Object.defineProperty(e.prototype, "potentialMemberButtonData", {
                        get: function() {
                            return {
                                name: this.campaignButtonName,
                                disabled: !1
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.potentialMemberHandler = function() {
                        var t = new RegExp(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/gim);
                        if (this.showWarn = !1, "" === this.potentialMemberValue) return this.showWarn = !0, void(this.warnText = this.translation.crm_email_required);
                        t.test(this.potentialMemberValue) ? (window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "register_non_member_edm",
                            event_category_DL: "non_member_edm",
                            event_action_DL: "clicked",
                            event_label_DL: "register/7A4FA00D-EBC2-4EC3-97E2-F995A0588A94/non_member_edm",
                            event_value_DL: ""
                        }), this.showWarn = !1, window.triggerSubscribeForm(this.potentialMemberValue, this.campaignId)) : (this.showWarn = !0, this.warnText = this.translation.crm_valid_email)
                    }, e.prototype.closeMemberHandler = function() {
                        this.isShowMember = !1
                    }, e.prototype.mounted = function() {
                        var t = this;
                        setTimeout((function() {
                            if ("function" == typeof window.brandAssistantGetStatus) {
                                var e = t.$refs.potentialMemberWrapper.clientHeight;
                                window.brandAssistantChangeOffsetY(e + 32 + 24)
                            }
                        }), 1e3)
                    }, y([Object(f.Getter)("translation")], e.prototype, "translation", void 0), y([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "campaignId", void 0), y([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "campaignTitle", void 0), y([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "campaignButtonName", void 0), e = y([Object(c.Component)({
                        components: {
                            ButtonRed: d.a
                        }
                    })], e)
                }(c.Vue),
                m = _,
                w = o(1088),
                v = o(25);
            var component = Object(v.a)(m, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return e.isShowMember ? o("div", {
                    ref: "potentialMemberWrapper",
                    class: e.$style.potentialMemberWrapper
                }, [o("label", {
                    class: [{
                        jpFont: "jp" === e.lang
                    }],
                    attrs: {
                        for: "potentialMemberInput"
                    }
                }, [e._v(e._s(e.campaignTitle))]), e._v(" "), o("button", {
                    class: e.$style.closeButton,
                    on: {
                        click: e.closeMemberHandler
                    }
                }, [o("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        role: "none",
                        focusable: "false",
                        "aria-hidden": "true",
                        alt: "no image",
                        title: "no image",
                        loading: "lazy"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M28 5.41L26.59 4 16 14.59 5.41 4 4 5.41 14.59 16 4 26.59 5.41 28 16 17.41 26.59 28 28 26.59 17.41 16 28 5.41z"
                    }
                })])]), e._v(" "), o("div", {
                    class: e.$style.potentialMemberInputWrapper
                }, [o("span", {
                    ref: "measureSpan",
                    class: e.$style.measureSpan
                }, [e._v("\n      " + e._s(e.translation.crm_emailplaceholder) + "\n    ")]), e._v(" "), o("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.potentialMemberValue,
                        expression: "potentialMemberValue"
                    }],
                    class: [e.$style.potentialMemberInput, (t = {}, Object(r.a)(t, e.$style.warn, e.showWarn), Object(r.a)(t, "jpFont", "jp" === e.lang), t)],
                    attrs: {
                        id: "potentialMemberInput",
                        type: "email",
                        placeholder: e.translation.crm_emailplaceholder
                    },
                    domProps: {
                        value: e.potentialMemberValue
                    },
                    on: {
                        input: function(t) {
                            t.target.composing || (e.potentialMemberValue = t.target.value)
                        }
                    }
                }), e._v(" "), o("div", {
                    class: e.$style.potentialMemberButton
                }, [o("ButtonRed", {
                    attrs: {
                        buttonData: e.potentialMemberButtonData,
                        isMaxWidth: !0,
                        isCrmButton: !0
                    },
                    on: {
                        click: e.potentialMemberHandler
                    }
                })], 1)]), e._v(" "), o("p", {
                    class: [e.$style.warnText, Object(r.a)({}, e.$style.show, e.showWarn)]
                }, [o("svg", {
                    class: "icon",
                    attrs: {
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "warn",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M6 0a6 6 0 110 12A6 6 0 016 0z",
                        fill: "#000"
                    }
                }), o("path", {
                    attrs: {
                        d: "M6 0a6 6 0 106 6 6.018 6.018 0 00-6-6zm.692 9H5.308V7.846h1.384V9zm0-2.538H5.308V2.769h1.384v3.693z",
                        fill: "#FA5C00"
                    }
                })]), e._v("\n\n    " + e._s(e.warnText) + "\n  ")])]) : e._e()
            }), [], !1, (function(t) {
                this.$style = w.default.locals || w.default
            }), null, null);
            e.a = component.exports
        },
        980: function(t, e, o) {
            "use strict";
            var n = o(716),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        }
    }
]);