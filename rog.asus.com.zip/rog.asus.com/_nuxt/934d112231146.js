(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [25], {
        1231: function(t, e, o) {
            "use strict";
            o(28), o(60);
            var n, r = o(9),
                c = (o(54), o(41), o(10), o(59), o(3)),
                l = o(7),
                d = (o(43), o(46), o(903)),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), e.prototype.gaDataLayer = function(t) {
                        if ("rog.asus.com.cn" !== window.location.host) window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "internal-links",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(t),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "internal-links",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t),
                                event_value_DL: "0"
                            })
                        }), 100);
                        else {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "internal-links", "clicked", "".concat(t)])
                        }
                    }, f([Object(l.Getter)("translation")], e.prototype, "translation", void 0), f([Object(c.Prop)()], e.prototype, "articleParam", void 0), e = f([Object(c.Component)({
                        components: {
                            Tag: d.a
                        }
                    })], e)
                }(c.Vue),
                _ = m,
                v = o(975),
                y = o(25);
            var w = Object(y.a)(_, (function() {
                    var t = this,
                        e = t._self._c;
                    t._self._setupProxy;
                    return e("div", {
                        class: t.$style.gamerItem
                    }, [e("a", {
                        class: t.$style.articleLink,
                        attrs: {
                            href: t.articleParam.link
                        },
                        on: {
                            click: function(e) {
                                return t.gaDataLayer(t.articleParam.title)
                            }
                        }
                    }, [e("div", {
                        class: t.$style.gamerItemImage
                    }, [e("ClientOnly", [e("picture", [e("source", {
                        attrs: {
                            srcset: "".concat(encodeURI(t.articleParam.imageUrl)),
                            media: "(max-width:1024px)"
                        }
                    }), t._v(" "), e("source", {
                        attrs: {
                            srcset: encodeURI(t.articleParam.imageUrl)
                        }
                    }), t._v(" "), e("img", {
                        attrs: {
                            src: encodeURI(t.articleParam.imageUrl),
                            alt: "",
                            loading: "lazy"
                        }
                    })])])], 1), t._v(" "), e("div", {
                        class: t.$style.gamerText
                    }, [e("Tag", {
                        attrs: {
                            "tag-data": t.articleParam.titleTag
                        }
                    }), t._v(" "), e("p", {
                        class: t.$style.itemTitle
                    }, [t._v(t._s(t.articleParam.title))]), t._v(" "), e("span", {
                        class: t.$style.itemDescription
                    }, [t._v(t._s(t.articleParam.description))])], 1)])])
                }), [], !1, (function(t) {
                    this.$style = v.default.locals || v.default
                }), null, null).exports,
                O = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                S = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                j = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return O(e, t), S([Object(c.Prop)()], e.prototype, "itemData", void 0), e = S([Object(c.Component)({
                        components: {
                            GamerItem: w
                        }
                    })], e)
                }(c.Vue),
                P = j,
                L = o(976);
            var I = Object(y.a)(P, (function() {
                    var t = this,
                        e = t._self._c;
                    t._self._setupProxy;
                    return e("div", {
                        class: t.$style.gamerItemContent,
                        attrs: {
                            role: "list"
                        }
                    }, t._l(t.itemData, (function(t, o) {
                        return e("GamerItem", {
                            key: o,
                            attrs: {
                                role: "listitem",
                                articleParam: t
                            }
                        })
                    })), 1)
                }), [], !1, (function(t) {
                    this.$style = L.default.locals || L.default
                }), null, null).exports,
                C = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                W = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                T = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return C(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), W([Object(l.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), W([Object(c.Prop)({
                        default: {
                            sectionName: "",
                            title: "",
                            description: "",
                            link: "",
                            linkTitle: "",
                            linkTarget: ""
                        }
                    })], e.prototype, "gameTextData", void 0), e = W([c.Component], e)
                }(c.Vue),
                x = T,
                k = o(977);
            var A = Object(y.a)(x, (function() {
                    var t = this,
                        e = t._self._c;
                    t._self._setupProxy;
                    return e("div", {
                        class: t.$style.gamerTextContent
                    }, [t.gameTextData.title ? e("h2", {
                        staticClass: "title",
                        class: [{
                            ruRogFont: "ru" === t.lang,
                            "vnRogFont font36": "vn" === t.lang
                        }]
                    }, [t._v(t._s(t.gameTextData.title))]) : t._e(), t._v(" "), t.gameTextData.description ? e("p", [t._v(t._s(t.gameTextData.description))]) : t._e()])
                }), [], !1, (function(t) {
                    this.$style = k.default.locals || k.default
                }), null, null).exports,
                D = o(687),
                R = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                $ = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                G = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.gameSectionName = "ROG-IN-ACTIONS", e
                    }
                    return R(e, t), e.prototype.beforeMount = function() {}, e.prototype.toArticlePage = function() {
                        var t = this;
                        setTimeout((function() {
                            "rog.asus.com.cn" !== window.location.host ? window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "buttons",
                                event_action_DL: "clicked",
                                event_label_DL: "rog_in_actions/more",
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "buttons",
                                    event_action_DL: "clicked",
                                    event_label_DL: "rog_in_actions/more",
                                    event_value_DL: "0"
                                })
                            }), 200) : void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "buttons", "clicked", "rog_in_actions/more"]), window.location.assign(t.gridAction.link + "/")
                        }), 100)
                    }, $([Object(l.Action)("getSection")], e.prototype, "getSection", void 0), $([Object(l.Action)("getGrid")], e.prototype, "getGrid", void 0), $([Object(l.Getter)("gridAction")], e.prototype, "gridAction", void 0), $([Object(l.Getter)("translation")], e.prototype, "translation", void 0), e = $([Object(c.Component)({
                        components: {
                            GamerItemContent: I,
                            GamerTextContent: A,
                            MoreButton: D.a
                        }
                    })], e)
                }(c.Vue),
                B = G,
                N = o(978);
            var F = Object(y.a)(B, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return t.gridAction && t.gridAction.grid && Object.keys(t.gridAction.grid).length > 0 ? e("div", {
                    class: t.$style.gamerContainer
                }, [t.gridAction ? e("GamerTextContent", {
                    attrs: {
                        gameTextData: t.gridAction
                    }
                }) : t._e(), t._v(" "), e("GamerItemContent", {
                    attrs: {
                        "item-data": t.gridAction.grid
                    }
                }), t._v(" "), e("div", {
                    class: t.$style.moreButtons
                }, [e("MoreButton", {
                    attrs: {
                        moreName: t.translation.LearnMore,
                        moreLink: t.gridAction.link + "/",
                        isLargerFontSize: !0,
                        otherName: "article tag community",
                        ariaLabel: "".concat(t.translation.LearnMore, " article tag community"),
                        isRouterPush: !1
                    },
                    on: {
                        click: function(e) {
                            return t.toArticlePage()
                        }
                    }
                })], 1)], 1) : t._e()
            }), [], !1, (function(t) {
                this.$style = N.default.locals || N.default
            }), null, null);
            e.a = F.exports
        },
        1240: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(20), o(26), o(9)),
                l = (o(54), o(41), o(10), o(59), o(3)),
                d = o(7),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.value = 0, e.moveSumTime = 0, e.moveTime = 0, e.moreItem = 0, e.itemNumber = 14, e.itemWidth = 240, e.moveWidth = 1520, e.slideShowGroupWidth = 6544, e.paddingValue = 32, e.itemCount = 5, e.touchStartX = 0, e.touchStartY = 0, e.touchEndX = 0, e.touchEndY = 0, e.currentPage = 0, e
                    }
                    return h(e, t), Object.defineProperty(e.prototype, "productLineNumber", {
                        get: function() {
                            return this.productLine && this.productLine.level ? this.productLine.level.length : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "area", {
                        get: function() {
                            return this.$route.params.area
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "dirType", {
                        get: function() {
                            if (this.$route && this.$route.params.area) switch (this.$route.params.area.toLowerCase()) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return "rtl";
                                default:
                                    return "ltr"
                            } else if (this.$route && this.$route.fullPath) {
                                switch (this.$route.fullPath.split("/")[1].toLowerCase()) {
                                    case "il":
                                    case "me-ar":
                                    case "sa-ar":
                                    case "eg":
                                    case "nafr-ar":
                                        return "rtl";
                                    default:
                                        return "ltr"
                                }
                            }
                            return "ltr"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "pageCount", {
                        get: function() {
                            return this.productLine && this.productLine.level ? Math.ceil(this.productLine.count / this.itemCount) : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchProductLine = function() {
                        this.initial()
                    }, e.prototype.mounted = function() {
                        var t = this;
                        setTimeout((function() {
                            t.initial()
                        }), 100), window.addEventListener("resize", (function() {
                            "pc" === (navigator.userAgent.indexOf("Mobile") > -1 || navigator.userAgent.indexOf("iPad") > -1 || navigator.userAgent.indexOf("Macintosh") > -1 ? "mobile" : "pc") ? (t.initial(), t.moveTime = 0, t.value = 0) : t.initial()
                        }))
                    }, e.prototype.initial = function() {
                        var t = 5,
                            e = 140;
                        this.itemNumber = this.productLine.count, window.innerWidth > 1536 ? (t = 5, this.itemCount = 5, this.moreItem = 0, this.itemWidth = 240 + 2 * this.paddingValue, this.itemNumber % t > 0 ? (this.moreItem = this.itemNumber % t, this.moveSumTime = Math.floor(this.itemNumber / t), this.moveWidth = 1456) : (this.moveSumTime = Math.floor(this.itemNumber / t) - 1, this.moveWidth = 1456), this.slideShowGroupWidth = this.itemWidth * this.itemNumber + 2 * this.paddingValue * this.itemNumber) : window.innerWidth <= 1536 && window.innerWidth > 1024 ? (t = 5, this.itemCount = 5, this.moreItem = 0, this.itemWidth = (window.innerWidth - e - 8 * this.paddingValue) / t + 2 * this.paddingValue, this.itemNumber % t > 0 ? (this.moreItem = this.itemNumber % t, this.moveSumTime = Math.floor(this.itemNumber / t), this.moveWidth = window.innerWidth - e) : (this.moveSumTime = Math.floor(this.itemNumber / t) - 1, this.moveWidth = window.innerWidth - e), this.paddingValue = 20, this.slideShowGroupWidth = this.itemWidth * this.itemNumber + 2 * this.paddingValue * this.itemNumber) : window.innerWidth <= 1024 && window.innerWidth > 768 ? (t = 5, this.itemCount = 5, this.paddingValue = 10, this.moreItem = 0, this.itemWidth = (window.innerWidth - e - 8 * this.paddingValue) / t + 2 * this.paddingValue, this.itemNumber % t > 0 ? (this.moreItem = this.itemNumber % t, this.moveSumTime = Math.floor(this.itemNumber / t), this.moveWidth = window.innerWidth - e) : (this.moveSumTime = Math.floor(this.itemNumber / t) - 1, this.moveWidth = window.innerWidth - e), this.slideShowGroupWidth = this.itemWidth * this.itemNumber + 2 * this.paddingValue * this.itemNumber) : window.innerWidth <= 768 && window.innerWidth > 540 ? (t = 3, this.moreItem = 0, this.itemCount = 3, this.paddingValue = 18, e = 96, this.itemWidth = (window.innerWidth - e - 2 * this.paddingValue) / t, this.itemNumber % t > 0 ? (this.moreItem = this.itemNumber % t, this.moveSumTime = Math.floor(this.itemNumber / t), this.moveWidth = window.innerWidth - e) : (this.moveSumTime = Math.floor(this.itemNumber / t) - 1, this.moveWidth = window.innerWidth - e), this.slideShowGroupWidth = this.itemWidth * this.itemNumber + 2 * this.paddingValue * this.itemNumber) : window.innerWidth <= 540 && (this.itemCount = 2, this.paddingValue = 8, this.itemWidth = window.innerWidth / 3, this.moveWidth = window.innerWidth - 16, this.slideShowGroupWidth = this.itemWidth * this.itemNumber)
                    }, e.prototype.touchStart = function(t) {
                        window.innerWidth <= 540 && (this.touchStartX = t.touches[0].clientX, this.touchStartY = t.touches[0].clientY)
                    }, e.prototype.touchEnd = function(t) {
                        if (window.innerWidth <= 540) {
                            this.touchEndX = t.changedTouches[0].clientX, this.touchEndY = t.changedTouches[0].clientY;
                            var e = this.touchStartX - this.touchEndX,
                                o = this.touchStartY - this.touchEndY;
                            if (Math.abs(o) > Math.abs(e)) return;
                            if (e > 100) {
                                var n = (this.currentPage + 1) % this.pageCount;
                                this.goToSlide(n)
                            } else if (e < -100) {
                                n = (this.currentPage - 1 + this.pageCount) % this.pageCount;
                                this.goToSlide(n)
                            }
                        }
                    }, e.prototype.goToSlide = function(t) {
                        this.moveTime = t, 0 === t ? this.value = 0 : this.moveSumTime === this.moveTime && this.moreItem > 0 ? this.value = -1 * (this.moveTime - 1) * this.$refs.slideShowWrapper.clientWidth + -1 * this.$refs.slideShowWrapperItem[0].clientWidth * this.moreItem : window.innerWidth <= 540 ? this.value = -1 * this.moveTime * (2 * this.$refs.slideShowWrapperItem[0].clientWidth + 32) : (this.value = -1 * this.moveTime * (this.$refs.slideShowWrapper.clientWidth + 2 * this.paddingValue), this.value = -1 * this.moveTime * this.$refs.slideShowWrapper.clientWidth), this.currentPage = t
                    }, e.prototype.slideNext = function() {
                        this.moveSumTime > this.moveTime ? (this.moveTime++, this.moveSumTime === this.moveTime && this.moreItem > 0 ? this.value = this.value - this.$refs.slideShowWrapperItem[0].clientWidth * this.moreItem : window.innerWidth <= 1636 ? this.value = this.value - this.$refs.slideShowWrapper.clientWidth : this.value = this.value - (this.$refs.slideShowWrapper.clientWidth - 1)) : (this.moveTime = 0, this.value = 0)
                    }, e.prototype.slidePrev = function() {
                        0 === this.value ? this.moreItem > 0 ? (this.moveTime = this.moveSumTime, this.value = this.value - this.$refs.slideShowWrapper.clientWidth * (this.moveTime - 1) - this.$refs.slideShowWrapperItem[0].clientWidth * this.moreItem) : (this.moveTime = this.moveSumTime, this.value = this.value - this.$refs.slideShowWrapper.clientWidth * this.moveTime) : (this.moveTime--, 0 === this.moveTime ? this.value = 0 : this.moveSumTime === this.moveTime + 1 && this.moreItem > 0 ? this.value = this.value + this.$refs.slideShowWrapperItem[0].clientWidth * this.moreItem : this.value = this.value + this.$refs.slideShowWrapper.clientWidth)
                    }, Object.defineProperty(e.prototype, "transformValue", {
                        get: function() {
                            switch (this.area) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return Math.abs(this.value);
                                default:
                                    return this.value
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.fixedScroll = function() {
                        var t = this;
                        setTimeout((function() {
                            t.$refs.slideShowWrapper.scrollLeft = 0
                        }), 0)
                    }, e.prototype.tabFocus = function(t) {
                        this.fixedScroll(), t % 5 == 0 && this.slideNext()
                    }, e.prototype.shiftTabFocus = function(t) {
                        this.fixedScroll(), 1 !== t && t % 5 == 1 && this.slidePrev()
                    }, e.prototype.goL2Handler = function(link) {
                        -1 !== link.indexOf("-group") || link.indexOf("allmodels"), window.location.href = "/".concat(link.toLowerCase())
                    }, e.prototype.gaDataLayer = function(t, e) {
                        if (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "buttons",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "-").concat(e),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "buttons",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t, "-").concat(e),
                                    event_value_DL: "0"
                                })
                            }), 100), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "buttons", "clicked", "".concat(t, "-").concat(e)])
                        }
                    }, f([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "bannerColor", void 0), f([Object(d.Getter)("productLine")], e.prototype, "productLine", void 0), f([Object(d.Getter)("websitePath")], e.prototype, "websitePath", void 0), f([Object(d.Getter)("translation")], e.prototype, "translation", void 0), f([Object(l.Watch)("productLine")], e.prototype, "watchProductLine", null), e = f([l.Component], e)
                }(l.Vue),
                _ = m,
                v = o(969),
                y = o(25);
            var component = Object(y.a)(_, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("section", {
                    class: [t.$style.slideShowContainer, Object(r.a)({}, t.$style.white, !1)],
                    attrs: {
                        "aria-roledescription": "carousel",
                        "aria-label": "".concat(t.translation.Home_Product_Line),
                        role: "region"
                    }
                }, [e("div", {
                    class: t.$style.slideShowContent
                }, [e("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.productLineNumber > 5,
                        expression: "productLineNumber > 5"
                    }],
                    class: t.$style.leftButton,
                    attrs: {
                        "aria-label": "Previous slide",
                        type: "button"
                    },
                    on: {
                        click: t.slidePrev
                    }
                }, [e("span", {
                    staticClass: "sr-only"
                }, [t._v(t._s(t.translation.Aria_Previous_Slide))]), t._v(" "), e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "72",
                        height: "72",
                        viewBox: "0 0 72 72",
                        "svg-inline": "",
                        alt: "slide previous",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("defs", [e("clipPath", {
                    attrs: {
                        id: "a"
                    }
                }, [e("path", {
                    attrs: {
                        "data-name": "矩形 11055",
                        transform: "translate(-11812 4633)",
                        d: "M0 0h72v72H0z",
                        fill: "none"
                    }
                })])]), e("g", {
                    attrs: {
                        "data-name": "icon-arrow-big",
                        transform: "translate(11812 -4633)",
                        "clip-path": "url(#a)"
                    }
                }, [e("path", {
                    attrs: {
                        "data-name": "联合 614",
                        d: "M-11787 4697l18-28h4l-18 28zm18-28l-18-28h4l18 28z",
                        fill: "#fff"
                    }
                })])])]), t._v(" "), e("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.productLineNumber > 5,
                        expression: "productLineNumber > 5"
                    }],
                    class: t.$style.rightButton,
                    attrs: {
                        "aria-label": "Next slide",
                        type: "button"
                    },
                    on: {
                        click: t.slideNext
                    }
                }, [e("span", {
                    staticClass: "sr-only"
                }, [t._v(t._s(t.translation.Aria_Next_Slide))]), t._v(" "), e("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "72",
                        height: "72",
                        viewBox: "0 0 72 72",
                        "svg-inline": "",
                        alt: "slide next",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [e("defs", [e("clipPath", {
                    attrs: {
                        id: "a"
                    }
                }, [e("path", {
                    attrs: {
                        "data-name": "矩形 11055",
                        transform: "translate(-11812 4633)",
                        d: "M0 0h72v72H0z",
                        fill: "none"
                    }
                })])]), e("g", {
                    attrs: {
                        "data-name": "icon-arrow-big",
                        transform: "translate(11812 -4633)",
                        "clip-path": "url(#a)"
                    }
                }, [e("path", {
                    attrs: {
                        "data-name": "联合 614",
                        d: "M-11787 4697l18-28h4l-18 28zm18-28l-18-28h4l18 28z",
                        fill: "#fff"
                    }
                })])])]), t._v(" "), e("div", {
                    ref: "slideShowWrapper",
                    staticClass: "slideContent",
                    class: t.$style.slideShowWrapper
                }, [e("div", {
                    class: t.$style.slideShowGroup,
                    style: "width:" + t.slideShowGroupWidth + "px;transform: translate3d(" + t.transformValue + "px, 0, 0)",
                    attrs: {
                        id: "slideGroup"
                    },
                    on: {
                        touchstart: t.touchStart,
                        touchend: t.touchEnd
                    }
                }, t._l(t.productLine.level, (function(o, n) {
                    return e("div", {
                        key: o.id,
                        ref: "slideShowWrapperItem",
                        refInFor: !0,
                        class: t.$style.slideShowItem,
                        attrs: {
                            role: "group",
                            "aria-roledescription": "slide",
                            "aria-label": "".concat(n + 1, " of ").concat(t.productLine.level.length)
                        },
                        on: {
                            click: function(e) {
                                return t.gaDataLayer(o.globalName, o.name)
                            }
                        }
                    }, [e("a", {
                        class: t.$style.slideShowItemLink,
                        attrs: {
                            tabindex: "0",
                            href: "/".concat(o.url ? o.url.toLowerCase() : "")
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), t.goL2Handler(o.url)
                            },
                            keydown: [function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "tab", 9, e.key, "Tab") ? null : e.shiftKey ? e.ctrlKey || e.altKey || e.metaKey ? null : t.shiftTabFocus(n + 1) : null
                            }, function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "tab", 9, e.key, "Tab") || e.ctrlKey || e.shiftKey || e.altKey || e.metaKey ? null : t.tabFocus(n + 1)
                            }]
                        }
                    }, [e("div", {
                        class: t.$style.slideShowItemImageContent
                    }, [e("ClientOnly", [e("img", {
                        attrs: {
                            src: "".concat(encodeURI(o.image.discoverPD), "/fwebp"),
                            loading: "ltr" === t.dirType ? "lazy" : "eager",
                            role: "presentation",
                            alt: ""
                        }
                    })])], 1), t._v(" "), e("div", {
                        class: t.$style.slideShowItemNameContent
                    }, [e("span", {
                        class: t.$style.slideShowItemName
                    }, [t._v("\n                " + t._s(o.name) + "\n              ")])])])])
                })), 0)]), t._v(" "), e("div", {
                    class: t.$style.pagination
                }, [e("ClientOnly", t._l(t.pageCount, (function(o, n) {
                    return e("button", {
                        key: n,
                        class: [t.$style.pageBullets, Object(r.a)({}, t.$style.active, n === t.moveTime)],
                        attrs: {
                            "aria-label": "click item ".concat(n),
                            type: "button"
                        },
                        on: {
                            click: function(e) {
                                return t.goToSlide(n)
                            }
                        }
                    })
                })), 0)], 1)])])
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        1241: function(t, e, o) {
            "use strict";
            o(28), o(60);
            var n, r = o(9),
                c = (o(54), o(41), o(10), o(59), o(3)),
                l = o(7),
                d = o(954),
                h = o(687),
                f = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                _ = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.actionWidth = 1520, e.tabletWidth = 820, e.actionSectionName = "LIVING-FOR-GAMERS-ABOUT-ROG", e
                    }
                    return f(e, t), e.prototype.watchGridAction = function(t, e) {
                        t && this.resizeActionContent()
                    }, Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.showLightBox = function(t) {
                        this.$emit("showBox", t)
                    }, e.prototype.beforeMount = function() {
                        var t = this;
                        setTimeout((function() {
                            t.resizeActionContent()
                        }), 0)
                    }, e.prototype.mounted = function() {
                        var t = this;
                        window.addEventListener("resize", (function() {
                            t.resizeActionContent()
                        }))
                    }, e.prototype.resizeActionContent = function() {
                        var t = document.body.clientWidth;
                        t <= this.tabletWidth ? this.actionWidth = (76 * t / 100 + 20) * this.newArticles.grid.length - 20 + 40 : t <= 1650 && t >= 1200 ? this.actionWidth = t - 130 + 20 : t <= 1200 && t > this.tabletWidth ? this.actionWidth = t - 90 : this.actionWidth = 1520
                    }, e.prototype.toArticlePage = function() {
                        var t = this;
                        setTimeout((function() {
                            "rog.asus.com.cn" !== window.location.host ? window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "buttons",
                                event_action_DL: "clicked",
                                event_label_DL: "about_rog/more",
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "buttons",
                                    event_action_DL: "clicked",
                                    event_label_DL: "about_rog/more",
                                    event_value_DL: "0"
                                })
                            }), 100) : void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "buttons", "clicked", "about_rog/more"]), window.location.assign(t.newArticles.link + "/")
                        }), 100)
                    }, m([Object(l.Action)("getSection")], e.prototype, "getSection", void 0), m([Object(l.Action)("getGrid")], e.prototype, "getGrid", void 0), m([Object(l.Getter)("newArticles")], e.prototype, "newArticles", void 0), m([Object(l.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), m([Object(l.Getter)("translation")], e.prototype, "translation", void 0), m([Object(c.Watch)("newArticles")], e.prototype, "watchGridAction", null), e = m([Object(c.Component)({
                        components: {
                            ActionItem: d.a,
                            MoreButton: h.a
                        }
                    })], e)
                }(c.Vue),
                v = _,
                y = o(974),
                w = o(25);
            var component = Object(w.a)(v, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return e.newArticles && null !== (t = e.newArticles) && void 0 !== t && t.grid && Object.keys(e.newArticles.grid).length > 0 ? o("div", {
                    class: e.$style.actionsContainer
                }, [o("div", {
                    class: e.$style.actionsWrapper
                }, [o("h2", {
                    class: [e.$style.actionsTitle, {
                        ruRogFont: "ru" === e.lang,
                        "vnRogFont font36": "vn" === e.lang
                    }]
                }, [e._v(e._s(e.newArticles.title))]), e._v(" "), o("div", {
                    class: e.$style.actionScrollBar
                }, [e.newArticles.grid ? o("div", {
                    class: e.$style.actionContent,
                    style: "width:".concat(e.actionWidth, "px;")
                }, e._l(e.newArticles.grid, (function(t, n) {
                    return o("ActionItem", {
                        key: "action-post-".concat(n),
                        ref: "actionItem",
                        refInFor: !0,
                        attrs: {
                            actionItemData: t,
                            itemNumber: n,
                            itemTotalNumber: e.newArticles.grid.length
                        }
                    })
                })), 1) : e._e()]), e._v(" "), o("div", {
                    class: e.$style.moreButtons
                }, [o("MoreButton", {
                    attrs: {
                        moreName: e.translation.LearnMore,
                        moreLink: e.newArticles.link + "/",
                        isLargerFontSize: !0,
                        isBlackBackground: !0,
                        otherName: "article tag product",
                        ariaLabel: "".concat(e.translation.LearnMore, " article tag product"),
                        isRouterPush: !1
                    },
                    on: {
                        click: function(t) {
                            return e.toArticlePage()
                        }
                    }
                })], 1)])]) : e._e()
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        1242: function(t, e, o) {
            "use strict";
            o(60);
            var n, r = o(9),
                c = (o(54), o(41), o(10), o(400), o(43), o(46), o(3)),
                l = o(7),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, c = arguments.length,
                        l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                    return c > 3 && l && Object.defineProperty(e, o, l), l
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.pcBannerUrl = "", e.mobileBannerUrl = "", e.title = "", e.desc = "", e.gameSectionName = "ROG-Story", e
                    }
                    return d(e, t), Object.defineProperty(e.prototype, "getStoryInfo", {
                        get: function() {
                            var t = this;
                            return this.section.find((function(e) {
                                return e.sectionName === t.gameSectionName
                            })) || null
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.getOriginVal = function() {
                        return encodeURI(window.location.origin)
                    }, e.prototype.goLink = function(t) {
                        window.location.href = encodeURI(t)
                    }, e.prototype.swLanguageMeta = function(data) {
                        if (data) {
                            var t = data;
                            if (t) return this.pcBannerUrl = t.imgUrl ? t.imgUrl.pc : "", this.mobileBannerUrl = t.imgUrl ? t.imgUrl.mobile : "", this.title = t.subject, this.desc = t.description, t
                        }
                        return !1
                    }, e.prototype.beforeMount = function() {}, h([Object(l.Getter)("getStoryBanner")], e.prototype, "getStoryBanner", void 0), h([Object(l.Getter)("section")], e.prototype, "section", void 0), h([Object(l.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), e = h([c.Component], e)
                }(c.Vue),
                m = f,
                _ = o(979),
                v = o(25);
            var component = Object(v.a)(m, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return e.swLanguageMeta(e.getStoryBanner) ? o("div", {
                    class: e.$style.storyFooterContainer,
                    attrs: {
                        tabindex: "-1"
                    },
                    on: {
                        click: function(t) {
                            var o;
                            return e.goLink(null === (o = e.getStoryInfo) || void 0 === o ? void 0 : o.link)
                        }
                    }
                }, [o("ClientOnly", [o("picture", [o("source", {
                    attrs: {
                        srcset: "".concat(e.mobileBannerUrl),
                        media: "(max-width: 768px)"
                    }
                }), e._v(" "), o("source", {
                    attrs: {
                        srcset: "".concat(e.pcBannerUrl)
                    }
                }), e._v(" "), o("img", {
                    class: [e.$style.backgroundImage],
                    attrs: {
                        src: "".concat(e.pcBannerUrl),
                        role: "presentation",
                        alt: "",
                        loading: "lazy"
                    }
                })])]), e._v(" "), o("div", {
                    class: [e.$style.backgroundImageContent]
                }, [e.title || e.desc ? o("div", {
                    class: e.$style.descriptionContent
                }, [e.title ? o("a", {
                    class: [e.$style.title, {
                        "vnRogFont font54 font36": "vn" === e.lang,
                        ruRogFont: "ru" === e.lang,
                        jpBoldFont: "jp" === e.lang
                    }],
                    attrs: {
                        href: null === (t = e.getStoryInfo) || void 0 === t ? void 0 : t.link
                    }
                }, [e._v(e._s(e.title))]) : e._e(), e._v(" "), e.desc ? o("p", {
                    class: e.$style.desc
                }, [e._v(e._s(e.desc))]) : e._e()]) : e._e()])], 1) : e._e()
            }), [], !1, (function(t) {
                this.$style = _.default.locals || _.default
            }), null, null);
            e.a = component.exports
        },
        1243: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = o(9),
                l = (o(54), o(41), o(10), o(28), o(3)),
                d = o(7),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                m = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), Object.defineProperty(e.prototype, "disclaimerNumber", {
                        get: function() {
                            var t, e;
                            return !!((null === (t = this.productDisclaimer) || void 0 === t ? void 0 : t.disclaimer) && Object.keys(null === (e = this.productDisclaimer) || void 0 === e ? void 0 : e.disclaimer).length > 0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), f([Object(d.Getter)("productDisclaimer")], e.prototype, "productDisclaimer", void 0), f([Object(l.Prop)({
                        default: "black"
                    })], e.prototype, "backgroundType", void 0), f([Object(l.Prop)({
                        default: !1
                    })], e.prototype, "noBottomBanner", void 0), e = f([l.Component], e)
                }(l.Vue),
                _ = m,
                v = o(981),
                y = o(25);
            var component = Object(y.a)(_, (function() {
                var t, e, o = this,
                    n = o._self._c;
                o._self._setupProxy;
                return o.disclaimerNumber ? n("div", {
                    class: [o.$style.productLineFooterContainer, (t = {}, Object(r.a)(t, o.$style.productBackgroundBlack, "black" === o.backgroundType), Object(r.a)(t, o.$style.noBottomBanner, o.noBottomBanner), t)]
                }, [n("div", {
                    class: o.$style.productLineFooterContent
                }, [null !== (e = o.productDisclaimer) && void 0 !== e && e.disclaimer ? n("div", {
                    class: o.$style.productLineFooterList,
                    domProps: {
                        innerHTML: o._s(o.productDisclaimer.disclaimer[0])
                    }
                }) : o._e()])]) : o._e()
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        672: function(t, e, o) {
            "use strict";
            o.r(e);
            var n = o(2),
                r = o(906).a,
                c = o(982),
                l = o(25);
            var component = Object(l.a)(r, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    ref: "homePage",
                    staticClass: "home-page"
                }, [o("div", {
                    class: e.$style.homeWrapper
                }, [o("h1", {
                    style: "height:0;width:0;margin:0;padding:0;font-size:0;"
                }, [e._v(e._s("ROG - Republic of Gamers"))]), e._v(" "), o("BannerSlideShow", {
                    attrs: {
                        showBanner: !0,
                        userDeviceValue: e.userDeviceValue
                    }
                }), e._v(" "), o("div", {
                    class: e.$style.slideShowWrapper
                }, [o("h2", {
                    class: [e.$style.slideShowTitle, (t = {}, Object(n.a)(t, e.$style.vnStyle, "vn" === e.lang), Object(n.a)(t, "vnRogFont font36", "vn" === e.lang), Object(n.a)(t, "ruRogFont", "ru" === e.lang), t)]
                }, [e._v(e._s(e.translation.Home_Product_Line))]), e._v(" "), o("SlideShow", {
                    attrs: {
                        bannerColor: !0
                    }
                })], 1), e._v(" "), o("Actions"), e._v(" "), o("Gamer"), e._v(" "), o("StoryFooter"), e._v(" "), o("DisclaimerContent")], 1), e._v(" "), o("ClientOnly", [o("VideoLightBox", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !0,
                        expression: "true"
                    }]
                })], 1), e._v(" "), e.isShowApiList ? o("div", {
                    staticClass: "apiList"
                }, [o("div", {
                    domProps: {
                        innerHTML: e._s(e.apilist)
                    }
                })]) : e._e()], 1)
            }), [], !1, (function(t) {
                this.$style = c.default.locals || c.default
            }), null, null);
            e.default = component.exports
        },
        704: function(t, e, o) {
            t.exports = {
                slideShowContainer: "SlideShow__slideShowContainer__Jxs4N",
                leftButton: "SlideShow__leftButton__n4gw4",
                rightButton: "SlideShow__rightButton__36zeS",
                white: "SlideShow__white__VDd95",
                slideShowItemName: "SlideShow__slideShowItemName__Ev2-H",
                pagination: "SlideShow__pagination__PgUyT",
                pageBullets: "SlideShow__pageBullets__SmhE4",
                active: "SlideShow__active__DnK6Y",
                slideShowContent: "SlideShow__slideShowContent__tTrta",
                slideShowWrapper: "SlideShow__slideShowWrapper__RI9cj",
                slideShowGroup: "SlideShow__slideShowGroup__OXhRe",
                slideShowItem: "SlideShow__slideShowItem__X6Qi3",
                slideShowItemLink: "SlideShow__slideShowItemLink__tZtV2",
                slideShowItemNameContent: "SlideShow__slideShowItemNameContent__rK3J6",
                slideShowItemImageContent: "SlideShow__slideShowItemImageContent__vSiwi"
            }
        },
        710: function(t, e, o) {
            t.exports = {
                actionsContainer: "Actions__actionsContainer__iZAlE",
                actionsWrapper: "Actions__actionsWrapper__FUy8D",
                moreButtons: "Actions__moreButtons__ymVlM",
                actionsTitle: "Actions__actionsTitle__+RDtv",
                vnRogFontSize: "Actions__vnRogFontSize__crN90",
                actionContent: "Actions__actionContent__7kIJU",
                actionScrollBar: "Actions__actionScrollBar__03Dj2"
            }
        },
        711: function(t, e, o) {
            t.exports = {
                gamerItem: "GamerItem__gamerItem__8Bmia",
                gamerItemImage: "GamerItem__gamerItemImage__xln-4",
                itemTitle: "GamerItem__itemTitle__UAqba",
                itemDescription: "GamerItem__itemDescription__2vUGX",
                articleLink: "GamerItem__articleLink__QtXWa",
                gamerText: "GamerItem__gamerText__M4-T5"
            }
        },
        712: function(t, e, o) {
            t.exports = {
                gamerItemContent: "GamerItemContent__gamerItemContent__Uqf4O"
            }
        },
        713: function(t, e, o) {
            t.exports = {
                gamerTextContent: "GamerTextContent__gamerTextContent__bdcEQ",
                vnRogFontSize: "GamerTextContent__vnRogFontSize__G4noc"
            }
        },
        714: function(t, e, o) {
            t.exports = {
                gamerContainer: "Gamer__gamerContainer__BU00T",
                moreButtons: "Gamer__moreButtons__kaZ4d"
            }
        },
        715: function(t, e, o) {
            t.exports = {
                storyFooterContainer: "StoryFooter__storyFooterContainer__A2I-c",
                backgroundImage: "StoryFooter__backgroundImage__xE+Su",
                backgroundImageContent: "StoryFooter__backgroundImageContent__LIktN",
                descriptionContent: "StoryFooter__descriptionContent__kbbMz",
                title: "StoryFooter__title__XpLWQ",
                desc: "StoryFooter__desc__WYSx3"
            }
        },
        717: function(t, e, o) {
            t.exports = {
                productLineFooterContent: "DisclaimerContent__productLineFooterContent__Fb9m9",
                productLineFooterList: "DisclaimerContent__productLineFooterList__XJmac",
                productLineFooterHDMI: "DisclaimerContent__productLineFooterHDMI__hUhac",
                productLineFooterContainer: "DisclaimerContent__productLineFooterContainer__Bf4ok",
                productBackgroundBlack: "DisclaimerContent__productBackgroundBlack__NtugL",
                noBottomBanner: "DisclaimerContent__noBottomBanner__qZJOT"
            }
        },
        718: function(t, e, o) {
            t.exports = {
                homeWrapper: "Home__homeWrapper__vDmOJ",
                slideShowWrapper: "Home__slideShowWrapper__BXPPs",
                slideShowTitle: "Home__slideShowTitle__pR2sz",
                vnStyle: "Home__vnStyle__aZEub",
                apiList: "Home__apiList__0qwvH"
            }
        },
        906: function(t, e, o) {
            "use strict";
            (function(t) {
                var n, r = o(9),
                    c = (o(54), o(41), o(10), o(43), o(46), o(52), o(37), o(38), o(51), o(20), o(78), o(60), o(22)),
                    l = o(148),
                    d = o(401),
                    h = (o(1), o(937)),
                    f = o(1240),
                    m = o(1241),
                    _ = o(1231),
                    v = o(1242),
                    y = o(898),
                    w = o(1243),
                    O = (n = function(t, b) {
                        return n = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, n(t, b)
                    }, function(t, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function e() {
                            this.constructor = t
                        }
                        n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                    }),
                    S = function(t, e, o, desc) {
                        var n, c = arguments.length,
                            l = c < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                        if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                        else
                            for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (c < 3 ? n(l) : c > 3 ? n(e, o, l) : n(e, o)) || l);
                        return c > 3 && l && Object.defineProperty(e, o, l), l
                    },
                    j = function(t, e, o, n) {
                        return new(o || (o = Promise))((function(r, c) {
                            function l(t) {
                                try {
                                    h(n.next(t))
                                } catch (t) {
                                    c(t)
                                }
                            }

                            function d(t) {
                                try {
                                    h(n.throw(t))
                                } catch (t) {
                                    c(t)
                                }
                            }

                            function h(t) {
                                var e;
                                t.done ? r(t.value) : (e = t.value, e instanceof o ? e : new o((function(t) {
                                    t(e)
                                }))).then(l, d)
                            }
                            h((n = n.apply(t, e || [])).next())
                        }))
                    },
                    P = function(t, body) {
                        var e, o, n, g, r = {
                            label: 0,
                            sent: function() {
                                if (1 & n[0]) throw n[1];
                                return n[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return g = {
                            next: c(0),
                            throw: c(1),
                            return: c(2)
                        }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                            return this
                        }), g;

                        function c(c) {
                            return function(l) {
                                return function(c) {
                                    if (e) throw new TypeError("Generator is already executing.");
                                    for (; g && (g = 0, c[0] && (r = 0)), r;) try {
                                        if (e = 1, o && (n = 2 & c[0] ? o.return : c[0] ? o.throw || ((n = o.return) && n.call(o), 0) : o.next) && !(n = n.call(o, c[1])).done) return n;
                                        switch (o = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                            case 0:
                                            case 1:
                                                n = c;
                                                break;
                                            case 4:
                                                return r.label++, {
                                                    value: c[1],
                                                    done: !1
                                                };
                                            case 5:
                                                r.label++, o = c[1], c = [0];
                                                continue;
                                            case 7:
                                                c = r.ops.pop(), r.trys.pop();
                                                continue;
                                            default:
                                                if (!(n = r.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                    r = 0;
                                                    continue
                                                }
                                                if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                    r.label = c[1];
                                                    break
                                                }
                                                if (6 === c[0] && r.label < n[1]) {
                                                    r.label = n[1], n = c;
                                                    break
                                                }
                                                if (n && r.label < n[2]) {
                                                    r.label = n[2], r.ops.push(c);
                                                    break
                                                }
                                                n[2] && r.ops.pop(), r.trys.pop();
                                                continue
                                        }
                                        c = body.call(t, r)
                                    } catch (t) {
                                        c = [6, t], o = 0
                                    } finally {
                                        e = n = 0
                                    }
                                    if (5 & c[0]) throw c[1];
                                    return {
                                        value: c[0] ? c[1] : void 0,
                                        done: !0
                                    }
                                }([c, l])
                            }
                        }
                    },
                    L = function(e) {
                        function o() {
                            var t = null !== e && e.apply(this, arguments) || this;
                            return t.deviceType = "pc", t.apiListContent = "", t.userDeviceValue = "", t
                        }
                        return O(o, e), o.prototype.asyncData = function(e) {
                            e.query, e.params;
                            var o, n, r = e.route,
                                c = e.store,
                                l = (e.res, e.req),
                                d = e.error;
                            e.redirect;
                            return j(this, void 0, Promise, (function() {
                                var e, h, f, m, _, v;
                                return P(this, (function(y) {
                                    switch (y.label) {
                                        case 0:
                                            return e = "/" === r.fullPath.split("?")[0] ? r.fullPath.split("?")[0] : r.fullPath.split("?")[0].slice(1), h = "global", (null === (o = r.params) || void 0 === o ? void 0 : o.area) && (h = r.params.area), "api-rog.asus.com".indexOf(".cn") > -1 && (h = "cn"), [3, 2];
                                        case 1:
                                            return y.sent(), [3, 4];
                                        case 2:
                                            return [4, Promise.all([c.dispatch("getRoute", {
                                                url: e
                                            }), c.dispatch("getBanners", {
                                                WebsiteCode: h,
                                                LevelTagId: 0
                                            }), c.dispatch("getProductLine", {
                                                WebsiteCode: h
                                            }), c.dispatch("getSection", {
                                                WebsiteCode: h
                                            }), c.dispatch("getRogStory", {
                                                WebsiteCode: h
                                            })])];
                                        case 3:
                                            y.sent(), y.label = 4;
                                        case 4:
                                            return -1 === c.getters.routeInfo.type && d({
                                                statusCode: 404,
                                                message: "頁面不存在"
                                            }), l && (null == l ? void 0 : l.headers) && (null == l ? void 0 : l.headers.authorization) ? (f = l.headers.authorization, [4, c.dispatch("setAuth", f)]) : [3, 6];
                                        case 5:
                                            y.sent(), y.label = 6;
                                        case 6:
                                            return (null === (n = c.getters.mappingWebsite) || void 0 === n ? void 0 : n.webPath) ? [3, 8] : [4, c.dispatch("getWebsiteID", {
                                                region: c.getters.routeInfo.websitePath
                                            })];
                                        case 7:
                                            y.sent(), y.label = 8;
                                        case 8:
                                            return m = "pc", l && (null == l ? void 0 : l.headers) && (null == l ? void 0 : l.headers["user-agent"]) && (m = l.headers["user-agent"].indexOf("Mobile") > -1 || l.headers["user-agent"].indexOf("iPad") > -1 || l.headers["user-agent"].indexOf("Macintosh") > -1 ? "mobile" : "pc", c.dispatch("setUserDevice", m)), _ = "", _ = l ? l.headers.host.indexOf("rogweb") > -1 ? "rog.asus.com" + e : l.headers.host + e : window.location.host + r.fullPath, "" !== (v = t.env.APILIST) && r.fullPath.indexOf("apilist") > -1 && (c.dispatch("APIList", {
                                                apiListContent: v,
                                                websitePath: h
                                            }), c.dispatch("showAPIList", !0)), [2, {
                                                siteURL: _,
                                                apiListContent: v,
                                                userDeviceValue: m
                                            }]
                                    }
                                }))
                            }))
                        }, o.prototype.head = function() {
                            var t, e, o, n, r, c, l, d, h, f, m, _, meta = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.metaInfo,
                                v = null === (o = null === (e = meta[0]) || void 0 === e ? void 0 : e.url) || void 0 === o ? void 0 : o.split("/")[2],
                                y = "";
                            y = "global" === this.routeInfo.websitePath || "cn" === this.routeInfo.websitePath ? "https://".concat(v, "/") : "https://".concat(v, "/").concat(this.routeInfo.websitePath, "/");
                            var w = "index";
                            return ("api-rog.asus.com".indexOf("dev") > -1 || "api-rog.asus.com".indexOf("stage") > -1 || "api-rog.asus.com".indexOf("rogmars") > -1) && (w = "noindex"), {
                                title: null === (n = meta[0]) || void 0 === n ? void 0 : n.metaTitle,
                                meta: [{
                                    name: "robots",
                                    content: w
                                }, {
                                    hid: "description",
                                    name: "description",
                                    content: null === (r = meta[0]) || void 0 === r ? void 0 : r.description
                                }, {
                                    hid: "og:title",
                                    property: "og:title",
                                    content: null === (c = meta[1]) || void 0 === c ? void 0 : c.metaTitle
                                }, {
                                    hid: "og:type",
                                    property: "og:type",
                                    content: "website"
                                }, {
                                    hid: "og:site_name",
                                    property: "og:site_name",
                                    content: "@ROG"
                                }, {
                                    hid: "og:description",
                                    property: "og:description",
                                    content: null === (l = meta[1]) || void 0 === l ? void 0 : l.description
                                }, {
                                    hid: "og:url",
                                    property: "og:url",
                                    content: null === (d = meta[0]) || void 0 === d ? void 0 : d.url
                                }, {
                                    hid: "og:image",
                                    property: "og:image",
                                    content: null === (h = meta[0]) || void 0 === h ? void 0 : h.mediaPC
                                }, {
                                    hid: "twitter:title",
                                    property: "twitter:title",
                                    content: null === (f = meta[2]) || void 0 === f ? void 0 : f.metaTitle
                                }, {
                                    hid: "twitter:site",
                                    property: "twitter:site",
                                    content: "@ROG"
                                }, {
                                    hid: "twitter:description",
                                    property: "twitter:description",
                                    content: null === (m = meta[2]) || void 0 === m ? void 0 : m.description
                                }, {
                                    hid: "twitter:card",
                                    property: "twitter:card",
                                    content: "summary_large_image"
                                }, {
                                    hid: "twitter:image",
                                    property: "twitter:image",
                                    content: null === (_ = meta[2]) || void 0 === _ ? void 0 : _.mediaPC
                                }],
                                link: [{
                                    rel: "canonical",
                                    href: y
                                }],
                                script: []
                            }
                        }, o.prototype.jsonld = function() {
                            var t, e, o, meta = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.metaInfo,
                                n = null === (e = this.footerApi.socialMedia) || void 0 === e ? void 0 : e.map((function(t) {
                                    return t.link
                                }));
                            return [{
                                "@context": "http://schema.org",
                                "@type": "Organization",
                                url: meta[0].url,
                                sameAs: n,
                                logo: "https://rog.asus.com/rog/nuxtStatic/img/logo-rog.svg",
                                name: "ROG",
                                description: meta[0].description,
                                contactPoint: {
                                    "@type": "ContactPoint",
                                    telephone: ""
                                }
                            }, {
                                "@context": "http://schema.org",
                                "@type": "WebSite",
                                url: null === (o = meta[0]) || void 0 === o ? void 0 : o.url,
                                potentialAction: {
                                    "@type": "SearchAction",
                                    target: {
                                        "@type": "EntryPoint",
                                        urlTemplate: "".concat(meta[0].url, "search/explore?searchkeyword={search_term_string}")
                                    },
                                    "query-input": "required name=search_term_string"
                                }
                            }]
                        }, Object.defineProperty(o.prototype, "lang", {
                            get: function() {
                                return this.routeInfo ? this.routeInfo.websitePath : ""
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(o.prototype, "showAPIList", {
                            get: function() {
                                return "undefined" != typeof window && window.location.href.indexOf("apilist") > -1
                            },
                            enumerable: !1,
                            configurable: !0
                        }), o.prototype.beforeMount = function() {}, o.prototype.mounted = function() {}, S([Object(c.Getter)("routeInfo")], o.prototype, "routeInfo", void 0), S([Object(c.Getter)("translation")], o.prototype, "translation", void 0), S([Object(c.Getter)("footerApi")], o.prototype, "footerApi", void 0), S([Object(c.Getter)("getAuth")], o.prototype, "getAuth", void 0), S([Object(c.Getter)("isShowApiList")], o.prototype, "isShowApiList", void 0), S([Object(c.Getter)("apilist")], o.prototype, "apilist", void 0), S([Object(c.Action)("getRoute")], o.prototype, "getRoute", void 0), S([Object(c.Action)("getHeader")], o.prototype, "getHeader", void 0), S([Object(c.Action)("getBanners")], o.prototype, "getBanners", void 0), S([Object(c.Action)("getProductLine")], o.prototype, "getProductLine", void 0), S([Object(c.Action)("getSection")], o.prototype, "getSection", void 0), S([Object(c.Action)("getRogStory")], o.prototype, "getRogStory", void 0), o = S([l.Jsonld, Object(c.Component)({
                            components: {
                                BannerSlideShow: h.a,
                                SlideShow: f.a,
                                Actions: m.a,
                                Gamer: _.a,
                                StoryFooter: v.a,
                                VideoLightBox: y.a,
                                DisclaimerContent: w.a
                            }
                        })], o)
                    }(Object(c.mixins)(d.a));
                e.a = L
            }).call(this, o(74))
        },
        969: function(t, e, o) {
            "use strict";
            var n = o(704),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        974: function(t, e, o) {
            "use strict";
            var n = o(710),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        975: function(t, e, o) {
            "use strict";
            var n = o(711),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        976: function(t, e, o) {
            "use strict";
            var n = o(712),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        977: function(t, e, o) {
            "use strict";
            var n = o(713),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        978: function(t, e, o) {
            "use strict";
            var n = o(714),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        979: function(t, e, o) {
            "use strict";
            var n = o(715),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        981: function(t, e, o) {
            "use strict";
            var n = o(717),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        982: function(t, e, o) {
            "use strict";
            var n = o(718),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        }
    }
]);