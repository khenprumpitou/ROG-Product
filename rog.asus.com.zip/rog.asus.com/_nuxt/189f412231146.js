(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [15], {
        183: function(t, e, o) {
            t.exports = {
                headerWrapper: "Header__headerWrapper__4ipKk",
                isMotherboards: "Header__isMotherboards__Jc8Xn",
                scrolled: "Header__scrolled__dwLDV",
                upscrolled: "Header__upscrolled__V-ogp",
                noSticky: "Header__noSticky__kZaPC",
                headerContainer: "Header__headerContainer__-AktX",
                fixed: "Header__fixed__ucce9",
                header: "Header__header__iNAJ6",
                rogLogo: "Header__rogLogo__LY-pL",
                rogLogoIcon: "Header__rogLogoIcon__SUCq+",
                headerNav: "Header__headerNav__9MLbL",
                headerBurger: "Header__headerBurger__sqASp",
                headerMenuToolBar: "Header__headerMenuToolBar__SrL+j",
                closeButton: "Header__closeButton__jIbDj",
                headerMenuList: "Header__headerMenuList__jpBKd",
                menuList: "Header__menuList__61wq5",
                smallItem: "Header__smallItem__SO4rZ",
                menuItem: "Header__menuItem__yvKxM",
                active: "Header__active__9kAE-",
                userButton: "Header__userButton__rc8F9",
                iconBlock: "Header__iconBlock__WQh2q",
                asusLogo: "Header__asusLogo__I7sul",
                mobileAsusLogo: "Header__mobileAsusLogo__UzZfj",
                searchButton: "Header__searchButton__NyfWa",
                messageButton: "Header__messageButton__WDPnW",
                unReadMessageNumberIcon: "Header__unReadMessageNumberIcon__+P6kV",
                messageListMobile: "Header__messageListMobile__fh34o",
                userListMobile: "Header__userListMobile__Xz0G0",
                messageListContent: "Header__messageListContent__yI67y",
                isMobileArrow: "Header__isMobileArrow__8hwJn",
                accessibility: "Header__accessibility__Wa+tY",
                smallList: "Header__smallList__oi526",
                isLogin: "Header__isLogin__koaQi",
                rogBurger: "Header__rogBurger__di8FM",
                headerMenu: "Header__headerMenu__lncT7",
                close: "Header__close__JB-fV",
                isMobileActived: "Header__isMobileActived__DUdoH",
                noArrow: "Header__noArrow__bv8YA",
                userMobileListTitle: "Header__userMobileListTitle__HY03J",
                accountLinkSection: "Header__accountLinkSection__-4tgi",
                accountInfo: "Header__accountInfo__X2Xvi",
                accountName: "Header__accountName__Y426I",
                accountPoints: "Header__accountPoints__gLMa3",
                messageMobileListTitle: "Header__messageMobileListTitle__vhC1N",
                messageItem: "Header__messageItem__MohAD",
                messageItemContent: "Header__messageItemContent__KG6FH",
                messageItemData: "Header__messageItemData__P4ov8",
                messageItemDate: "Header__messageItemDate__i8AJ9",
                messageItemName: "Header__messageItemName__Zu4Yt",
                messageItemLastShortMsg: "Header__messageItemLastShortMsg__urRZL",
                messageImageContent: "Header__messageImageContent__pLIqR",
                messageUnreadNumber: "Header__messageUnreadNumber__wYdPe",
                messageMoreContent: "Header__messageMoreContent__E+Fvz",
                messageEmpty: "Header__messageEmpty__xeTxU"
            }
        },
        185: function(t, e, o) {
            t.exports = {
                footerContainer: "Footer__footerContainer__4paCr",
                footerContent: "Footer__footerContent__8f6dw",
                vnStyle: "Footer__vnStyle__xvR1C",
                krStyle: "Footer__krStyle__yae0o",
                footerLogo: "Footer__footerLogo__ucsxG",
                footerTopContent: "Footer__footerTopContent__vP++P",
                noBottomBanner: "Footer__noBottomBanner__MW5d9",
                privateContent: "Footer__privateContent__hl0oD",
                siteMap: "Footer__siteMap__NF2ry",
                cnSite: "Footer__cnSite__vr-PO",
                isHome: "Footer__isHome__0fShg",
                siteLeftContent: "Footer__siteLeftContent__lMlV3",
                noCRM: "Footer__noCRM__2tGI9",
                footerLine: "Footer__footerLine__3dhcV",
                legalInfoContent: "Footer__legalInfoContent__BUNpk",
                footerLink: "Footer__footerLink__jWbYC",
                socialLink: "Footer__socialLink__MRz8L",
                socialList: "Footer__socialList__nGDiB",
                isDesktop: "Footer__isDesktop__at9Kk",
                isMobile: "Footer__isMobile__vIGu2",
                socialItem: "Footer__socialItem__sqbj-",
                crmWrapper: "Footer__crmWrapper__YQPB5",
                crmInputWrapper: "Footer__crmInputWrapper__CwI5O",
                measureSpan: "Footer__measureSpan__CYOrq",
                crmInput: "Footer__crmInput__9HXwz",
                warn: "Footer__warn__AZWx1",
                crmButton: "Footer__crmButton__tkSOw",
                warnText: "Footer__warnText__A96XK",
                show: "Footer__show__sxhAW",
                language: "Footer__language__wc6xe",
                languageIcon: "Footer__languageIcon__7s29R",
                reclamacioneLink: "Footer__reclamacioneLink__CLwsx",
                reclamacione: "Footer__reclamacione__9v7xQ",
                personalContent: "Footer__personalContent__AjxR0",
                copyRightContent: "Footer__copyRightContent__2jo3j",
                termsContent: "Footer__termsContent__lvktr",
                cookieSettingButton: "Footer__cookieSettingButton__0JFaZ",
                footerBanner: "Footer__footerBanner__AuWBh",
                footerPCMode: "Footer__footerPCMode__Uwsfg",
                footerItemName: "Footer__footerItemName__DEwd0",
                footerItemLink: "Footer__footerItemLink__Qbyko",
                footerLeftBottomContent: "Footer__footerLeftBottomContent__MLbtq",
                footerRegionButton: "Footer__footerRegionButton__GbKJs",
                mobileFollowSocialMediaName: "Footer__mobileFollowSocialMediaName__JuIQk",
                footerLinks: "Footer__footerLinks__p1J6O",
                socialMediaIcon: "Footer__socialMediaIcon__x-FOY",
                "sr-only": "Footer__sr-only__HWZ+d"
            }
        },
        392: function(t, e, o) {
            "use strict";
            var n = o(183),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        394: function(t, e, o) {
            "use strict";
            var n = o(185),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        405: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(635), o(26), o(60), o(28), o(9)),
                l = (o(54), o(41), o(10), o(43), o(46), o(52), o(37), o(38), o(44), o(59), o(18), o(29), o(20), o(32), o(33), o(47), o(91), o(145), o(3)),
                d = o(7),
                h = o(475),
                m = o(6),
                v = o.n(m),
                _ = o(50),
                f = o(79),
                w = o(4),
                y = o(36),
                C = o(491),
                k = o(492),
                M = o(493),
                I = o(494),
                S = o(495),
                L = o(496),
                A = o(0),
                O = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                P = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                j = function(t, e, o, n) {
                    return new(o || (o = Promise))((function(r, c) {
                        function l(t) {
                            try {
                                h(n.next(t))
                            } catch (t) {
                                c(t)
                            }
                        }

                        function d(t) {
                            try {
                                h(n.throw(t))
                            } catch (t) {
                                c(t)
                            }
                        }

                        function h(t) {
                            var e;
                            t.done ? r(t.value) : (e = t.value, e instanceof o ? e : new o((function(t) {
                                t(e)
                            }))).then(l, d)
                        }
                        h((n = n.apply(t, e || [])).next())
                    }))
                },
                E = function(t, body) {
                    var e, o, n, g, r = {
                        label: 0,
                        sent: function() {
                            if (1 & n[0]) throw n[1];
                            return n[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(l) {
                            return function(c) {
                                if (e) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (r = 0)), r;) try {
                                    if (e = 1, o && (n = 2 & c[0] ? o.return : c[0] ? o.throw || ((n = o.return) && n.call(o), 0) : o.next) && !(n = n.call(o, c[1])).done) return n;
                                    switch (o = 0, n && (c = [2 & c[0], n.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            n = c;
                                            break;
                                        case 4:
                                            return r.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            r.label++, o = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = r.ops.pop(), r.trys.pop();
                                            continue;
                                        default:
                                            if (!(n = r.trys, (n = n.length > 0 && n[n.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                r = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!n || c[1] > n[0] && c[1] < n[3])) {
                                                r.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && r.label < n[1]) {
                                                r.label = n[1], n = c;
                                                break
                                            }
                                            if (n && r.label < n[2]) {
                                                r.label = n[2], r.ops.push(c);
                                                break
                                            }
                                            n[2] && r.ops.pop(), r.trys.pop();
                                            continue
                                    }
                                    c = body.call(t, r)
                                } catch (t) {
                                    c = [6, t], o = 0
                                } finally {
                                    e = n = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, l])
                        }
                    }
                },
                D = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isScrolled = !1, e.isMotherboards = !1, e.isBurgerActived = !1, e.isFixed = !1, e.isRogSite = !0, e.isAccount = !1, e.isRegion = !1, e.isMobileStatus = !1, e.showUserListMobile = !1, e.isSmallItem = !0, e.isDisplay = !1, e.isMobileDisplay = !1, e.AccessibilityPolicySite = "/us", e.mobileDropDownMenuActivedMeta = null, e.headerBasicPosition = 0, e.windowSize = null, e.menuWidth = 286, e.searchPanelStatus = !1, e.headerListPosition = {
                            top: 0,
                            left: -52,
                            right: 0
                        }, e.mobilePosition = {
                            top: 50,
                            left: 0,
                            right: 0
                        }, e.dropDownMenuActivedMeta = null, e.activeNumber = -1, e.tabClickStatus = !1, e.exportWebsitePath = "global", e.exportStatus = !1, e.exportWebsiteID = 0, e.mainMenuActivedStatus = {
                            leave: !0
                        }, e.subMenuActivedStatus = {
                            leave: !0
                        }, e.cartList = null, e.ECToken = "", e.ECCartId = "", e.ECMemberToken = "", e.ECMemberCartId = "", e.ECGuestId = "", e.resetToken = !1, e.triggerECHandler = !1, e.alertStatus = !1, e.haveCallMiniCart = !1, e.getMiniCartStatus = !1, e.accountLanguage = "", e.miniCartNumber = 0, e.regions = [{
                            name: "American",
                            code: "us"
                        }, {
                            name: "Baltics",
                            code: "bt"
                        }, {
                            name: "Belgium",
                            code: "be-nl"
                        }, {
                            name: "Belgium",
                            code: "be-fr"
                        }, {
                            name: "Bulgaria",
                            code: "bg"
                        }, {
                            name: "CIS",
                            code: "ru"
                        }, {
                            name: "Croatia",
                            code: "hr"
                        }, {
                            name: "Czech Republic",
                            code: "cz"
                        }, {
                            name: "Denmark",
                            code: "dk"
                        }, {
                            name: "Finland",
                            code: "fi"
                        }, {
                            name: "France",
                            code: "fr"
                        }, {
                            name: "Germany",
                            code: "de"
                        }, {
                            name: "Greece",
                            code: "gr-en"
                        }, {
                            name: "Greece",
                            code: "gr"
                        }, {
                            name: "Hungary",
                            code: "hu"
                        }, {
                            name: "Ireland",
                            code: "ie"
                        }, {
                            name: "Italy",
                            code: "it"
                        }, {
                            name: "Netherlands",
                            code: "nl"
                        }, {
                            name: "Norway",
                            code: "no"
                        }, {
                            name: "Poland",
                            code: "pl"
                        }, {
                            name: "Portugal",
                            code: "pt"
                        }, {
                            name: "Romania",
                            code: "ro"
                        }, {
                            name: "Serbia",
                            code: "rs"
                        }, {
                            name: "Serbia",
                            code: "rs-en"
                        }, {
                            name: "Slovakia",
                            code: "sk"
                        }, {
                            name: "Slovenia",
                            code: "si"
                        }, {
                            name: "Spain",
                            code: "es"
                        }, {
                            name: "Sweden",
                            code: "se"
                        }, {
                            name: "Switzerland",
                            code: "ch-fr"
                        }, {
                            name: "Switzerland",
                            code: "ch-de"
                        }, {
                            name: "Switzerland",
                            code: "ch-en"
                        }, {
                            name: "Türkiye",
                            code: "tr"
                        }, {
                            name: "Ukraine",
                            code: "ua-ua"
                        }, {
                            name: "United Kingdom",
                            code: "uk"
                        }], e
                    }
                    return O(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t;
                            return Object.keys(this.routeInfo).length > 0 ? null === (t = this.routeInfo) || void 0 === t ? void 0 : t.websitePath : "undefined" != typeof window && (null === window || void 0 === window ? void 0 : window.AsusAPIConfig) ? window.AsusAPIConfig.websitePath : this.exportWebsitePath
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "asusLinkArea", {
                        get: function() {
                            if (this.$route && this.routeInfo) {
                                var area = "global" === this.routeInfo.websitePath ? "" : "/".concat(this.routeInfo.websitePath, "/");
                                return "/cn/" === area.toLowerCase() ? "https://w3.asus.com.cn" : "https://www.asus.com".concat(area)
                            }
                            var t = this.$root ? this.$root.$data : null;
                            if (t && Object.keys(t).length > 0) {
                                var path = "global" === t.websitePath ? "" : "/".concat(t.websitePath, "/");
                                return "/cn/" === path.toLowerCase() ? "https://w3.asus.com.cn" : "https://www.asus.com".concat(path)
                            }
                            return ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "createUrl", {
                        get: function() {
                            return this.accountStatus && this.accountStatus.userInfo && this.accountStatus.userInfo.mediaUrl ? this.accountStatus.userInfo.mediaUrl.indexOf("rog_avator") > -1 ? "" : this.accountStatus.userInfo.mediaUrl : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "dirType", {
                        get: function() {
                            if (this.$route) switch (this.routeInfo.websitePath) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return this.textRightToLeft(), "rtl";
                                default:
                                    return "ltr"
                            } else if (this.exportWebsitePath) switch (this.exportWebsitePath) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return this.textRightToLeft(), document.documentElement.setAttribute("data-dirtype", "rtl"), "rtl";
                                default:
                                    return this.headerListPosition.left = -52, this.headerListPosition.right = "auto", document.documentElement.setAttribute("data-dirtype", "ltr"), "ltr"
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isHomePage", {
                        get: function() {
                            var t, e;
                            return "1" === (null === (e = null === (t = this.$route) || void 0 === t ? void 0 : t.meta) || void 0 === e ? void 0 : e.homePage)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isECSite", {
                        get: function() {
                            return this.mappingWebsite.ecStatus
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getCnAccountLink", {
                        get: function() {
                            var t = "https://account.asus.com.cn";
                            return "undefined" != typeof window && (t = "rog.asus.com.cn" === window.location.host || "rogmars.asus.com" === window.location.host ? "https://account.asus.com.cn" : "https://accts-account.asus.com.cn"), t
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchLang = function(t, e) {
                        var o = this;
                        this.regions.filter((function(e) {
                            e.code === t && (o.AccessibilityPolicySite = "/".concat(t))
                        }))
                    }, e.prototype.watchEcObject = function(t, e) {
                        var o = this;
                        (this.$route && !this.triggerECHandler && "" === this.ECToken && t && Object.keys(t).length > 0 && t.ecStatus || !this.triggerECHandler && "" === this.ECToken && t && Object.keys(t).length > 0 && t.ecStatus) && (this.triggerECHandler = !0, setTimeout((function() {
                            o.setSessionStorageHandler(), o.ecHandler()
                        }), 200))
                    }, e.prototype.created = function() {
                        this.menuApis && this.menuApis.length < 8 && (this.isSmallItem = !1)
                    }, e.prototype.canonicalHandler = function() {
                        document.querySelector('link[rel="canonical"]').href = encodeURI(window.location.href)
                    }, e.prototype.textRightToLeft = function() {
                        this.headerListPosition.left = "auto", this.headerListPosition.right = -52
                    }, e.prototype.debounceDisplaySubMenu = function() {
                        this.displaySubMenu()
                    }, e.prototype.beforeMount = function() {
                        "0" === Object(w.b)("groupid_rog_".concat(this.lang)) && Object(w.a)("groupid_rog_".concat(this.lang)), this.advertisingCookieHandler()
                    }, e.prototype.mounted = function() {
                        var t = this;
                        "undefined" != typeof window && (this.defaultStatus(), setTimeout((function() {
                            t.setWindowSize()
                        }), 1e3), window.addEventListener("resize", (function() {
                            t.defaultStatus(), t.setWindowSize()
                        }), !1)), document.addEventListener("blur", (function(t) {
                            document.getElementById("search").blur(), document.getElementsByTagName("html")[0].setAttribute("style", "overflow:hidden")
                        }), {
                            passive: !0
                        }), document.documentElement.addEventListener("click", (function(e) {
                            var o = e.target; - 1 !== navigator.userAgent.indexOf("MSIE") || navigator.appVersion.indexOf("Trident/"), o.closest(".searchHeaderPanel") || o.closest(".searchButton") || (t.searchPanelStatus = !1)
                        })), window.refreshCart = function() {
                            t.haveCallMiniCart || (t.haveCallMiniCart = !0, setTimeout((function() {
                                t.setSessionStorageHandler(), t.ecHandler()
                            }), 200))
                        }, this.exportHeader(), this.$route && setTimeout((function() {
                            t.isECSite && (t.setSessionStorageHandler(), t.ecHandler())
                        }), 100)
                    }, e.prototype.defaultStatus = function() {
                        this.windowSize = Object(f.a)(), this.windowSize.width <= 1024 ? this.isMobileStatus = !0 : this.isMobileStatus = !1, this.windowSize.width <= 1024 && (this.isDisplay = !1)
                    }, e.prototype.exportHeader = function() {
                        if (this.$root && !this.$route) {
                            var t = this.$root ? this.$root.$data : null;
                            if (this.exportStatus = !0, t && Object.keys(t).length > 0) {
                                if (this.exportWebsiteID = t.websiteID, window.AsusAPIConfig) {
                                    var e = window.AsusAPIConfig;
                                    if (this.exportWebsitePath = e.websitePath, this.isRogSite = !1, this.isAccount = e && e.simplifyHeader || !1, this.loadFont(e.websitePath), document.body.classList.add(this.exportWebsitePath), "jp" === this.exportWebsitePath) {
                                        var o = document.createElement("script");
                                        o.type = "text/javascript", o.src = "https://dlcdnimgs.asus.com/vendor/public/fonts/js/biz_udgothic.js", document.body.appendChild(o)
                                    }
                                }
                                this.setHeaderParam()
                            }
                        }
                    }, e.prototype.loadFont = function(t) {
                        var e = encodeURI(window.location.host),
                            o = e.replace(".asus.com", ""),
                            n = document.createElement("link");
                        n.rel = "stylesheet", n.type = "text/css", "cn" === t ? n.href = "https://rog.asus.com.cn/rog/nuxtStatic/css/fontCN.css?systemCode=".concat(o) : e.indexOf("stage") > -1 ? n.href = "https://stage-rog.asus.com/rog/nuxtStatic/css/fontHQ.css?systemCode=".concat(o) : e.indexOf("dev") > -1 ? n.href = "https://dev-rog.asus.com/rog/nuxtStatic/css/fontHQ.css?systemCode=".concat(o) : n.href = "https://rog.asus.com/rog/nuxtStatic/css/fontHQ.css?systemCode=".concat(o), document.body.appendChild(n)
                    }, e.prototype.setHeaderParam = function() {
                        return j(this, void 0, Promise, (function() {
                            var t, e, o, n, param, r, c = this;
                            return E(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return t = this.$root ? this.$root.$data : null, e = t.websitePath ? t.websitePath : this.exportWebsitePath, o = encodeURI(window.location.host), n = o.replace(".asus.com", ""), param = {
                                            region: e
                                        }, "rog.asus.com.cn" !== o ? [3, 3] : [4, v()({
                                            method: "get",
                                            url: "https://api-rog.asus.com.cn/recent-data/api/v4/Common/Website?systemCode=".concat(n)
                                        }).then((function(t) {
                                            c.rogExportWebsite({
                                                data: t.data.result,
                                                param: param
                                            })
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))];
                                    case 1:
                                        return l.sent(), [4, v()({
                                            method: "get",
                                            url: "https://api-rog.asus.com.cn/recent-data/api/v4/Common/Header?WebsiteCode=".concat(e, "&systemCode=").concat(n)
                                        }).then((function(t) {
                                            c.rogExportHeader(t.data.result)
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))];
                                    case 2:
                                        return l.sent(), [3, 6];
                                    case 3:
                                        return r = "api-rog.asus.com", o.indexOf("dev") > -1 ? r = "dev-api-rog.asus.com" : o.indexOf("stage") > -1 ? r = "stage-api-rog.asus.com" : o.indexOf("rogmars") > -1 && (r = "api-rogmars.asus.com"), [4, v()({
                                            method: "get",
                                            url: "https://".concat(r, "/recent-data/api/v4/Common/Website?systemCode=").concat(n)
                                        }).then((function(t) {
                                            c.rogExportWebsite({
                                                data: t.data.result,
                                                param: param
                                            })
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))];
                                    case 4:
                                        return l.sent(), [4, v()({
                                            method: "get",
                                            url: "https://".concat(r, "/recent-data/api/v4/Common/Header?WebsiteCode=").concat(e, "&systemCode=").concat(n)
                                        }).then((function(t) {
                                            c.rogExportHeader(t.data.result), setTimeout((function() {
                                                t.data.result && t.data.result.length < 8 ? c.isSmallItem = !1 : c.isSmallItem = !0
                                            }), 1e3)
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))];
                                    case 5:
                                        l.sent(), l.label = 6;
                                    case 6:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.displaySubMenu = function() {
                        this.windowSize = Object(f.a)(), document.documentElement.scrollWidth > 1024 && (this.subMenuActivedStatus.leave && this.mainMenuActivedStatus.leave || (this.isDisplay = !0), this.subMenuActivedStatus.leave && this.mainMenuActivedStatus.leave && (this.isDisplay = !1))
                    }, e.prototype.checkMenuItems = function(t) {
                        return null == t ? void 0 : t.items.some((function(meta) {
                            return meta.subItem.length > 0
                        }))
                    }, e.prototype.chkMenuApisObject = function(t) {
                        return !!(t && (null == t ? void 0 : t.length) > 0) && (this.settingHeaderTop(), !0)
                    }, e.prototype.settingHeaderTop = function() {
                        var t = this.$refs.header,
                            e = this.$refs.menuList;
                        if (e && t) {
                            var o = t.clientHeight;
                            "undefined" != typeof window && (window.innerWidth <= 1305 && this.isSmallItem ? (this.headerBasicPosition = 20, this.headerListPosition.top = 20) : (this.headerBasicPosition = o - e.offsetTop, this.headerListPosition.top = o - e.offsetTop))
                        }
                    }, e.prototype.menuClick = function(meta, t) {
                        t.preventDefault(), document.documentElement.clientWidth <= 1024 && (this.isMobileDisplay = !this.isMobileDisplay, this.mobileDropDownMenuActivedMeta = meta)
                    }, e.prototype.tabClick = function(data, t, e) {
                        t.preventDefault(), e !== this.activeNumber && (this.tabClickStatus = !1, this.menuMouseLeave()), this.activeNumber = e, this.tabClickStatus ? (this.menuMouseLeave(), this.tabClickStatus = !this.tabClickStatus) : (this.menuListOver(), this.menuMouseOver(data, t, e), this.tabClickStatus = !this.tabClickStatus), "" !== data.url && (this.getAIStatus ? window.open(encodeURI(data.url)) : window.location.assign(encodeURI(data.url)))
                    }, e.prototype.menuMouseLeave = function() {
                        this.mainMenuActivedStatus.leave = !0, this.activeNumber = -1, this.debounceDisplaySubMenu()
                    }, e.prototype.closeMenuHandler = function() {
                        this.mainMenuActivedStatus.leave = !0, this.subMenuActivedStatus.leave = !0, this.debounceDisplaySubMenu()
                    }, e.prototype.menuMouseOver = function(data, t, e) {
                        t.target && (this.dropDownMenuActivedMeta = data, this.activeNumber = e, this.setMenuWidth(this.dropDownMenuActivedMeta))
                    }, e.prototype.menuListOver = function() {
                        this.mainMenuActivedStatus.leave = !1, this.debounceDisplaySubMenu()
                    }, e.prototype.closeMobileMenuList = function() {
                        this.isMobileDisplay = !1
                    }, e.prototype.searchPanelHandler = function() {
                        this.gaSetting("search"), this.searchPanelStatus = !this.searchPanelStatus, this.searchPanelStatus ? setTimeout((function() {
                            document.getElementById("search").focus(), document.getElementsByTagName("html")[0].setAttribute("style", "overflow:hidden")
                        }), 100) : setTimeout((function() {
                            document.getElementById("searchButton").focus(), document.getElementsByTagName("html")[0].setAttribute("style", "overflow:unset")
                        }), 100)
                    }, e.prototype.subMenuStatus = function(t) {
                        this.subMenuActivedStatus.leave = t.leave, this.debounceDisplaySubMenu()
                    }, e.prototype.setMenuWidth = function(meta) {
                        var t, e, o, n, r, c, l, time = 0;
                        (null === (t = null == meta ? void 0 : meta.items) || void 0 === t ? void 0 : t.length) > 0 ? (null === (e = null == meta ? void 0 : meta.items) || void 0 === e ? void 0 : e.length) > 1 ? (meta.items.forEach((function(t) {
                            t.subItem.length > 8 && (time += 1)
                        })), time > 0 ? 4 === (null === (o = null == meta ? void 0 : meta.items) || void 0 === o ? void 0 : o.length) ? this.menuWidth = 716 : this.menuWidth = 180 * (null === (n = null == meta ? void 0 : meta.items) || void 0 === n ? void 0 : n.length) + 52 + 52 + 36 + 36 : 4 === (null === (r = null == meta ? void 0 : meta.items) || void 0 === r ? void 0 : r.length) ? this.menuWidth = 672 : this.menuWidth = 190 * (null === (c = null == meta ? void 0 : meta.items) || void 0 === c ? void 0 : c.length) + 102) : this.menuWidth = 286 : this.menuWidth = 210 * (null === (l = null == meta ? void 0 : meta.items) || void 0 === l ? void 0 : l.length) + 84
                    }, e.prototype.burgerClick = function() {
                        window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "button",
                            event_action_DL: "clicked",
                            event_label_DL: "display the top menu",
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "button",
                                event_action_DL: "clicked",
                                event_label_DL: "display the top menu",
                                event_value_DL: "0"
                            })
                        }), 100)), "rog.asus.com.cn" === window.location.host && void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "button", "clicked", "display the top menu"]), document.querySelector(".mobileMenu").classList.add("close"), this.isMobileDisplay = !1, this.isBurgerActived = !this.isBurgerActived;
                        var t = document.getElementsByTagName("html")[0];
                        this.isBurgerActived ? t.classList.add("fixScroll") : (this.isMobileDisplay = !1, t.classList.remove("fixScroll")), this.showUserListMobile = !1, setTimeout((function() {
                            document.querySelector(".mobileMenu").classList.remove("close")
                        }), 300)
                    }, e.prototype.isLogin = function() {
                        return !("undefined" == typeof window || !Object(w.b)("aticket"))
                    }, e.prototype.closeUserMobileHandler = function() {
                        this.showUserListMobile = !1
                    }, e.prototype.mobileSubMenuClickEvent = function() {
                        this.isMobileDisplay = !1
                    }, e.prototype.setWindowSize = function() {
                        this.setMenuWidthHandler()
                    }, e.prototype.setMenuWidthHandler = function() {
                        var t, e = document.querySelector(".headerMenuList") ? null === (t = document.querySelector(".headerMenuList")) || void 0 === t ? void 0 : t.clientWidth : 1520,
                            o = 0,
                            n = 64;
                        document.querySelectorAll(".headerItem").forEach((function(t) {
                            document.documentElement.clientWidth <= 1200 ? n = 10 : document.documentElement.clientWidth <= 1305 ? n = 20 : document.documentElement.clientWidth <= 1450 && (n = 28), o = o + t.clientWidth + n
                        })), o > e ? (this.isSmallItem = !0, document.documentElement.clientWidth >= 1640 && (this.menuApis && this.menuApis.length < 8 ? this.isSmallItem = !1 : this.isSmallItem = !0)) : document.documentElement.clientWidth <= 1300 && (this.isSmallItem = !0)
                    }, e.prototype.userMobileHandler = function() {
                        this.gaSetting("member"), this.showUserListMobile = !0
                    }, e.prototype.triggerDisplaySubMenu = function(t) {
                        this.displaySubMenu(), this.gaMenuClick(t.class, t.name)
                    }, e.prototype.goHomeLink = function() {
                        if ("undefined" != typeof window) {
                            if (this.$route) {
                                if (this.routeInfo) {
                                    var area = "global" === this.routeInfo.websitePath ? "" : "".concat(this.routeInfo.websitePath, "/");
                                    return "undefined" == typeof window || "rog.asus.com.cn" !== window.location.host && "stage.asus.com.cn" !== window.location.host || (area = ""), "/".concat(area)
                                }
                                if (Object(w.b)("rog_site_area")) {
                                    area = "global" === Object(w.b)("rog_site_area") ? "" : "/".concat(Object(w.b)("rog_site_area"), "/");
                                    return "".concat(area)
                                }
                                area = "global" === window.location.pathname.split("/")[1] ? "" : "/".concat(window.location.pathname.split("/")[1], "/");
                                return "".concat(area)
                            }
                            var t = this.$root ? this.$root.$data : null;
                            if (t && Object.keys(t).length > 0) {
                                var path = "global" === t.websitePath ? "" : "/".concat(t.websitePath, "/");
                                return "undefined" != typeof window && "rog-bacchus.asus.com" === window.location.host || "undefined" != typeof window && "rogmars.asus.com" === window.location.host ? "https://rogmars.asus.com".concat(path) : "undefined" != typeof window && "rog.asus.com.cn" === window.location.host ? "https://rog.asus.com.cn" : "undefined" != typeof window && window.location.host.indexOf("stage") > -1 ? "https://stage-rog.asus.com".concat(path) : "https://rog.asus.com".concat(path)
                            }
                            return encodeURI("".concat(window.location.origin))
                        }
                        return "/"
                    }, e.prototype.goToHome = function() {
                        if (window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-L1",
                                event_action_DL: "clicked",
                                event_label_DL: "ROG",
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "header-L1",
                                    event_action_DL: "clicked",
                                    event_label_DL: "ROG",
                                    event_value_DL: "0"
                                })
                            }), 200)), "rog.asus.com.cn" === window.location.host && void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "header-L1", "clicked", "ROG"]), this.$route) {
                            var area = encodeURI("global" === this.routeInfo.websitePath ? "" : "/".concat(this.routeInfo.websitePath, "/"));
                            "rog.asus.com.cn" === window.location.host ? window.location.href = encodeURI("".concat(window.location.origin)) : (window.location.host, window.location.href = encodeURI("".concat(window.location.origin).concat(area)))
                        } else {
                            var t = this.$root ? this.$root.$data : null;
                            if (t && Object.keys(t).length > 0) {
                                var path = encodeURI("global" === t.websitePath ? "" : "/".concat(t.websitePath, "/"));
                                "undefined" != typeof window && "rog-bacchus.asus.com" === window.location.host || "undefined" != typeof window && "rogmars.asus.com" === window.location.host ? top.location.href = encodeURI("https://rogmars.asus.com".concat(path)) : "undefined" != typeof window && "rog.asus.com.cn" === window.location.host ? top.location.href = encodeURI("https://rog.asus.com.cn") : "undefined" != typeof window && window.location.host.indexOf("stage") > -1 ? top.location.href = encodeURI("https://stage-rog.asus.com".concat(path)) : top.location.href = encodeURI("https://rog.asus.com".concat(path))
                            }
                        }
                    }, e.prototype.goToASUS = function(t) {
                        if (this.$route) {
                            encodeURI("global" === this.routeInfo.websitePath ? "" : "/".concat(this.routeInfo.websitePath, "/"));
                            this.getAIStatus ? window.open(encodeURI("".concat(t))) : window.location.href = encodeURI("".concat(t))
                        } else {
                            var e = this.$root ? this.$root.$data : null;
                            if (e && Object.keys(e).length > 0) {
                                var path = encodeURI("global" === e.websitePath ? "" : "/".concat(e.websitePath, "/"));
                                "undefined" != typeof window && "rog-bacchus.asus.com" === window.location.host ? top.location.href = encodeURI("https://www.asus.com".concat(path)) : "undefined" != typeof window && "rogmars.asus.com" === window.location.host ? top.location.href = encodeURI("https://wwww.asus.com".concat(path)) : "undefined" != typeof window && "rog.asus.com.cn" === window.location.host ? top.location.href = encodeURI("https://wwww.asus.com.cn") : ("undefined" != typeof window && window.location.host.indexOf("stage"), top.location.href = encodeURI("https://www.asus.com".concat(path)))
                            }
                        }
                    }, e.prototype.goToOtherSite = function(t) {
                        if (this.$route) this.getAIStatus ? window.open(encodeURI("".concat(t))) : window.location.href = encodeURI("".concat(t));
                        else {
                            var e = this.$root ? this.$root.$data : null;
                            if (e && Object.keys(e).length > 0) {
                                encodeURI("global" === e.websitePath ? "" : "/".concat(e.websitePath, "/"));
                                "undefined" != typeof window && "rog-bacchus.asus.com" === window.location.host || "undefined" != typeof window && "rogmars.asus.com" === window.location.host ? top.location.href = encodeURI("".concat(t)) : "undefined" != typeof window && "rog.asus.com.cn" === window.location.host ? top.location.href = encodeURI("https://wwww.asus.com.cn") : ("undefined" != typeof window && window.location.host.indexOf("stage"), top.location.href = encodeURI("".concat(t)))
                            }
                        }
                    }, e.prototype.usersEcToken = function() {
                        return j(this, void 0, Promise, (function() {
                            var t;
                            return E(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return this.setPlusSale() ? (t = "", 1 === this.mappingWebsite.groupIdOnly && (t = 'group_id_only:"Y"'), this.mappingWebsite.authHasGroup ? [4, _.a.usersEcTokenGroupId(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, {
                                            store: this.mappingWebsite.storeviewCode
                                        })] : [3, 2]) : [3, 5];
                                    case 1:
                                    case 3:
                                    case 6:
                                    case 8:
                                        return [2, e.sent()];
                                    case 2:
                                        return [4, _.a.usersEcShopToken(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, t)];
                                    case 4:
                                        return [3, 9];
                                    case 5:
                                        return t = "", 1 === this.mappingWebsite.groupIdOnly && (t = 'group_id_only:"Y"'), this.mappingWebsite.authHasGroup ? [4, _.a.usersEcTokenGroupId(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, {
                                            store: this.mappingWebsite.storeviewCode
                                        })] : [3, 7];
                                    case 7:
                                        return [4, _.a.usersEcToken(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, t)];
                                    case 9:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.usersEcGroupId = function() {
                        return j(this, void 0, Promise, (function() {
                            var t = this;
                            return E(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, _.a.usersEcTokenGroupId(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, {
                                            token: this.ECToken,
                                            store: this.mappingWebsite.storeviewCode
                                        }).then((function(e) {
                                            var o, n, r;
                                            (null === (r = null === (n = null === (o = null == e ? void 0 : e.data) || void 0 === o ? void 0 : o.data) || void 0 === n ? void 0 : n.getAuthorizationToken) || void 0 === r ? void 0 : r.group_id) ? Object(w.c)("groupid_rog_".concat(t.lang), e.data.data.getAuthorizationToken.group_id, "1"): Object(w.c)("groupid_rog_".concat(t.lang), "0", "1")
                                        }))];
                                    case 1:
                                        return e.sent(), [2]
                                }
                            }))
                        }))
                    }, e.prototype.miniCartMemberNumber = function() {
                        return j(this, void 0, Promise, (function() {
                            return E(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, _.a.miniCartMemberNumber(Object(w.b)("aticket"), this.mappingWebsite.ecDomain, {
                                            token: this.ECToken,
                                            store: this.mappingWebsite.storeviewCode
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.usersEcCartId = function(param) {
                        return j(this, void 0, Promise, (function() {
                            return E(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, _.a.getEcCartId(param, this.mappingWebsite.ecDomain)];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.usersEcCustomer = function(param) {
                        return j(this, void 0, Promise, (function() {
                            return E(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, _.a.getEcCustomer(param, this.mappingWebsite.ecDomain)];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.usersEcCartItems = function(param) {
                        return j(this, void 0, Promise, (function() {
                            var t = this;
                            return E(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return this.setPlusSale() ? [4, _.a.getShopComEcCartItems(param, this.mappingWebsite.ecDomain).then((function(e) {
                                            var o, n, r, c;
                                            if (t.haveCallMiniCart = !1, t.getMiniCartStatus = !0, (null === (o = null == e ? void 0 : e.data) || void 0 === o ? void 0 : o.errors) && (null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.errors[0].message.indexOf("The current user cannot perform operations on cart")) > -1) return t.ecHandler(), void(t.miniCartNumber = 0);
                                            if ((null === (r = null == e ? void 0 : e.data) || void 0 === r ? void 0 : r.errors) && (null === (c = null == e ? void 0 : e.data) || void 0 === c ? void 0 : c.errors[0].message.indexOf("Could not find a cart with ID")) > -1) return t.miniCartNumber = 0, void t.visitEcCartIdHandler({
                                                token: param.token,
                                                store: param.store
                                            });
                                            t.setSessionStorage("rog_ec_cartList_".concat(t.lang), JSON.stringify(e.data.data.cart));
                                            var l = e.data.data.cart;
                                            t.miniCartNumber = l.total_quantity, t.cartList = l
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))] : [3, 2];
                                    case 1:
                                        return e.sent(), [3, 4];
                                    case 2:
                                        return [4, _.a.getEcCartItems(param, this.mappingWebsite.ecDomain).then((function(e) {
                                            var o, n, r, c;
                                            if (t.haveCallMiniCart = !1, t.getMiniCartStatus = !0, (null === (o = null == e ? void 0 : e.data) || void 0 === o ? void 0 : o.errors) && (null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.errors[0].message.indexOf("The current user cannot perform operations on cart")) > -1) return t.ecHandler(), void(t.miniCartNumber = 0);
                                            if ((null === (r = null == e ? void 0 : e.data) || void 0 === r ? void 0 : r.errors) && (null === (c = null == e ? void 0 : e.data) || void 0 === c ? void 0 : c.errors[0].message.indexOf("Could not find a cart with ID")) > -1) return t.visitEcCartIdHandler({
                                                token: param.token,
                                                store: param.store
                                            }), void(t.miniCartNumber = 0);
                                            t.setSessionStorage("rog_ec_cartList_".concat(t.lang), JSON.stringify(e.data.data.cart));
                                            var l = e.data.data.cart;
                                            t.miniCartNumber = l.total_quantity, t.cartList = l
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))];
                                    case 3:
                                        e.sent(), e.label = 4;
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.visitEcCartId = function(param) {
                        return j(this, void 0, Promise, (function() {
                            return E(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, _.a.getVisitorEcCartId(param, this.mappingWebsite.ecDomain)];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.visitEcCartIdHandler = function(param) {
                        var t = this;
                        Object.keys(this.routeInfo).length > 0 ? this.routeInfo.websitePath : window.AsusAPIConfig && window.AsusAPIConfig.websitePath;
                        var e = null !== this.mappingWebsite.storeviewCode ? this.mappingWebsite.storeviewCode : null;
                        this.visitEcCartId(param).then((function(o) {
                            var n, r, c, l, d, h;
                            if (t.haveCallMiniCart = !1, t.setSessionStorage("rog_ec_member_cartID_".concat(t.lang), o.data.data.createEmptyCart), t.ECMemberCartId = o.data.data.createEmptyCart, (null === (n = null == o ? void 0 : o.data) || void 0 === n ? void 0 : n.errors) && "The Guest Token not exists" === (null === (c = null === (r = null == o ? void 0 : o.data) || void 0 === r ? void 0 : r.errors[0]) || void 0 === c ? void 0 : c.message)) {
                                if (null === t.ECMemberCartId || "" === t.ECMemberCartId || "null" === t.ECMemberCartId) return;
                                t.ecHandler()
                            } else if ((null === (l = null == o ? void 0 : o.data) || void 0 === l ? void 0 : l.errors) && "Empty Cart" === (null === (h = null === (d = null == o ? void 0 : o.data) || void 0 === d ? void 0 : d.errors[0]) || void 0 === h ? void 0 : h.message)) {
                                if (null === t.ECMemberCartId || "" === t.ECMemberCartId || "null" === t.ECMemberCartId) return;
                                t.visitEcCartIdHandler(param)
                            } else null !== t.ECMemberCartId && "" !== t.ECMemberCartId && "null" !== t.ECMemberCartId && t.usersEcCartItems({
                                token: t.ECMemberToken,
                                store: e,
                                cartID: t.ECMemberCartId
                            }).catch((function(t) {
                                console.error(t)
                            }))
                        })).catch((function(t) {
                            console.error(t)
                        }))
                    }, e.prototype.setPlusSale = function() {
                        return 1 === this.mappingWebsite.addOn
                    }, e.prototype.setCookiesHandler = function() {
                        if (!Object(w.b)("rog_site_area")) {
                            var t = "";
                            t = Object.keys(this.routeInfo).length > 0 ? this.routeInfo.websitePath : window.AsusAPIConfig.websitePath, Object(w.c)("rog_site_area", t, "")
                        }
                        if (!Object(w.b)("rog_site_id")) {
                            t = this.mappingWebsiteId ? this.mappingWebsiteId.toString() : window.AsusAPIConfig.websitePath;
                            Object(w.c)("rog_site_id", t, "")
                        }
                    }, e.prototype.setSessionStorageHandler = function() {
                        this.setCookiesHandler();
                        var t = Object(w.b)("private_content_version_asus"),
                            e = this.getSessionStorage("private_content_version_asus");
                        null !== t ? e && "null" !== e ? t !== e ? (this.setSessionStorage("private_content_version_asus", t), this.resetToken = !0) : this.resetToken = !1 : (this.setSessionStorage("private_content_version_asus", t), this.resetToken = !0) : this.resetToken = !1, this.ECToken = this.getSessionStorage("rog_ec_token_".concat(this.lang)), this.ECCartId = this.getSessionStorage("rog_ec_cartID_".concat(this.lang));
                        ["us", "ca-fr", "ca-en", "tw", "mx", "my", "ph", "tr"].includes(this.lang) ? this.ECGuestId = Object(w.b)(this.mappingWebsite.guestId || "asus_mg_guest_id") : this.ECGuestId = Object(w.b)(this.mappingWebsite.guestId || "mg_guest_id"), this.ECMemberToken = this.getSessionStorage("rog_ec_member_token_".concat(this.lang)), this.ECMemberCartId = this.getSessionStorage("rog_ec_member_cartID_".concat(this.lang))
                    }, e.prototype.ecHandler = function() {
                        var t, e, o, n = this;
                        if ("cn" !== this.lang) {
                            Object.keys(this.routeInfo).length > 0 ? this.routeInfo.websitePath : window.AsusAPIConfig && window.AsusAPIConfig.websitePath;
                            var r = null !== this.mappingWebsite.storeviewCode ? this.mappingWebsite.storeviewCode : null;
                            if (Object(w.b)("aticket") || Object(w.a)("groupid_rog_".concat(this.lang)), Object(w.b)("aticket")) Object(w.b)("groupid_rog_".concat(this.lang)) || Object(w.c)("groupid_rog_".concat(this.lang), "0", "1"), (null === (t = this.mappingWebsite) || void 0 === t ? void 0 : t.miniCarQty) && this.mappingWebsite.miniCarQty && this.miniCartMemberNumber().then((function(t) {
                                var e;
                                n.getMiniCartStatus || (n.miniCartNumber = null === (e = t.data.data.miniCartQty) || void 0 === e ? void 0 : e.qty)
                            })), this.ECToken && "null" !== this.ECToken ? this.resetToken ? this.usersEcToken().then((function(t) {
                                n.haveCallMiniCart = !1;
                                var e = t.data.data.getAuthorizationToken;
                                n.setSessionStorage("rog_ec_token_".concat(n.lang), e.token), e && (n.mappingWebsite.authHasGroup && (null == e ? void 0 : e.group_id) && Object(w.c)("groupid_rog_".concat(n.lang), e.group_id, "1"), "" !== e.token && ("null" !== e.token && null !== e.token ? (n.ECToken = e.token, n.mappingWebsite.authHasGroup && (null == e ? void 0 : e.group_id) ? Object(w.c)("groupid_rog_".concat(n.lang), e.group_id, "1") : n.getECGroupIdHandler(r), n.usersEcCartId({
                                    token: n.ECToken,
                                    store: r
                                }).then((function(t) {
                                    n.haveCallMiniCart = !1, n.setSessionStorage("rog_ec_cartID_".concat(n.lang), t.data.data.customerCart.id), n.ECCartId = t.data.data.customerCart.id, n.usersEcCartItems({
                                        token: n.ECToken,
                                        store: r,
                                        cartID: n.ECCartId
                                    })
                                })).catch((function(t) {
                                    console.error(t)
                                }))) : Object(w.c)("groupid_rog_".concat(n.lang), "0", "1")))
                            })).catch((function(t) {
                                console.error(t)
                            })) : (this.mappingWebsite.authHasGroup || this.getECGroupIdHandler(r), this.ECCartId && "null" !== this.ECCartId ? this.getSessionStorage("rog_ec_cartList_".concat(this.lang)) && "null" !== this.getSessionStorage("rog_ec_cartList_" + this.lang) ? this.exportStatus ? this.ECCartId ? this.usersEcCartItems({
                                token: this.ECToken,
                                store: r,
                                cartID: this.ECCartId
                            }).then((function() {
                                n.getMiniCartStatus = !0
                            })) : this.miniCartNumber = 0 : (this.cartList = JSON.parse(this.getSessionStorage("rog_ec_cartList_".concat(this.lang))), this.getMiniCartStatus = !0, this.miniCartNumber = this.cartList.total_quantity) : this.usersEcCartItems({
                                token: this.ECToken,
                                store: r,
                                cartID: this.ECCartId
                            }) : this.usersEcCartId({
                                token: this.ECToken,
                                store: r
                            }).then((function(t) {
                                n.haveCallMiniCart = !1, n.setSessionStorage("rog_ec_cartID_".concat(n.lang), t.data.data.customerCart.id), n.ECCartId = t.data.data.customerCart.id, n.usersEcCartItems({
                                    token: n.ECToken,
                                    store: r,
                                    cartID: n.ECCartId
                                })
                            })).catch((function(t) {
                                console.error(t)
                            }))) : this.usersEcToken().then((function(t) {
                                n.haveCallMiniCart = !1;
                                var e = t.data.data.getAuthorizationToken;
                                n.setSessionStorage("rog_ec_token_".concat(n.lang), e.token), e && (n.mappingWebsite.authHasGroup && (null == e ? void 0 : e.group_id) && Object(w.c)("groupid_rog_".concat(n.lang), e.group_id, "1"), "" !== e.token && ("null" !== e.token && null !== e.token ? (n.ECToken = e.token, n.mappingWebsite.authHasGroup && (null == e ? void 0 : e.group_id) ? Object(w.c)("groupid_rog_".concat(n.lang), e.group_id, "1") : n.getECGroupIdHandler(r), n.usersEcCartId({
                                    token: n.ECToken,
                                    store: r
                                }).then((function(t) {
                                    n.haveCallMiniCart = !1, n.setSessionStorage("rog_ec_cartID_".concat(n.lang), t.data.data.customerCart.id), n.ECCartId = t.data.data.customerCart.id, n.usersEcCartItems({
                                        token: n.ECToken,
                                        store: r,
                                        cartID: n.ECCartId
                                    })
                                })).catch((function(t) {
                                    console.error(t)
                                }))) : Object(w.c)("groupid_rog_".concat(n.lang), "0", "1")))
                            })).catch((function(t) {
                                console.error(t)
                            }));
                            else if (Object(w.b)(this.mappingWebsite.guestId) || Object(w.b)("mg_guest_id") || Object(w.b)("asus_mg_guest_id"))
                                if ((null === (e = this.mappingWebsite) || void 0 === e ? void 0 : e.miniCarQty) && this.mappingWebsite.miniCarQty && _.a.miniCartVisitorNumber(this.ECGuestId, this.mappingWebsite.ecDomain, {
                                        token: this.ECMemberToken,
                                        store: this.mappingWebsite.storeviewCode
                                    }).then((function(t) {
                                        var e;
                                        n.getMiniCartStatus || (n.miniCartNumber = null === (e = t.data.data.miniCartQty) || void 0 === e ? void 0 : e.qty)
                                    })), this.ECMemberToken && "null" !== this.ECMemberToken)
                                    if (this.resetToken) {
                                        if (null === this.ECGuestId) return;
                                        c = "";
                                        1 === this.mappingWebsite.groupIdOnly && (c = 'group_id_only:"Y"'), (null === (o = this.mappingWebsite) || void 0 === o ? void 0 : o.miniCarQty) && this.mappingWebsite.miniCarQty && _.a.miniCartVisitorNumber(this.ECGuestId, this.mappingWebsite.ecDomain, this.routeInfo.websitePath).then((function(t) {
                                            var e;
                                            n.getMiniCartStatus || (n.miniCartNumber = null === (e = t.data.data.miniCartQty) || void 0 === e ? void 0 : e.qty)
                                        })), _.a.visitorEcToken(this.ECGuestId, this.mappingWebsite.ecDomain, c).then((function(t) {
                                            if (n.haveCallMiniCart = !1, t.data.data.getAuthorizationToken) {
                                                n.ECMemberToken = t.data.data.getAuthorizationToken.token;
                                                var e = t.data.data.getAuthorizationToken.token,
                                                    param = {
                                                        token: e,
                                                        store: r
                                                    };
                                                n.setSessionStorage("rog_ec_member_token_".concat(n.lang), e), n.visitEcCartIdHandler(param)
                                            }
                                        })).catch((function(t) {
                                            console.error(t)
                                        }))
                                    } else this.ECMemberCartId && "null" !== this.ECMemberCartId ? this.getSessionStorage("rog_ec_cartList_".concat(this.lang)) && "null" !== this.getSessionStorage("rog_ec_cartList_" + this.lang) ? this.usersEcCartItems({
                                        token: this.ECMemberToken,
                                        store: r,
                                        cartID: this.ECMemberCartId
                                    }) : "null" === this.getSessionStorage("rog_ec_cartList_" + this.lang) ? this.visitEcCartIdHandler({
                                        token: this.ECMemberToken,
                                        store: r
                                    }) : this.usersEcCartItems({
                                        token: this.ECMemberToken,
                                        store: r,
                                        cartID: this.ECMemberCartId
                                    }) : this.visitEcCartIdHandler({
                                        token: this.ECMemberToken,
                                        store: r
                                    });
                            else {
                                if (null === this.ECGuestId) return;
                                var c = "";
                                1 === this.mappingWebsite.groupIdOnly && (c = 'group_id_only:"Y"'), _.a.visitorEcToken(this.ECGuestId, this.mappingWebsite.ecDomain, c).then((function(t) {
                                    if (n.haveCallMiniCart = !1, t.data.data.getAuthorizationToken) {
                                        n.ECMemberToken = t.data.data.getAuthorizationToken.token;
                                        var e = t.data.data.getAuthorizationToken.token,
                                            param = {
                                                token: e,
                                                store: r
                                            };
                                        n.setSessionStorage("rog_ec_member_token_".concat(n.lang), e), n.ECMemberCartId && "null" !== n.ECMemberCartId ? n.usersEcCartItems({
                                            token: n.ECMemberToken,
                                            store: r,
                                            cartID: n.ECMemberCartId
                                        }) : n.visitEcCartIdHandler(param)
                                    }
                                })).catch((function(t) {
                                    console.error(t)
                                }))
                            }
                        }
                    }, e.prototype.getECGroupIdHandler = function(t) {
                        if (null === this.mappingWebsite.memberDiscount) {
                            if (0 === this.mappingWebsite.customerGroup) return
                        } else if (this.mappingWebsite.memberDiscount && 0 === this.mappingWebsite.memberDiscount) return;
                        Object(w.b)("groupid_rog_".concat(this.lang)) && "undefined" !== Object(w.b)("groupid_rog_".concat(this.lang)) ? "0" === Object(w.b)("groupid_rog_".concat(this.lang)) && this.usersEcCustomerHandler(t) : this.usersEcCustomerHandler(t)
                    }, e.prototype.usersEcCustomerHandler = function(t) {
                        var e = this;
                        this.usersEcCustomer({
                            token: this.ECToken,
                            store: t
                        }).then((function(o) {
                            var n, r, c;
                            (null === (c = null === (r = null === (n = null == o ? void 0 : o.data) || void 0 === n ? void 0 : n.data) || void 0 === r ? void 0 : r.customer) || void 0 === c ? void 0 : c.group_id) && o.data.data.customer.group_id > 0 ? Object(w.c)("groupid_rog_".concat(e.lang), o.data.data.customer.group_id, "1") : (Object(w.c)("groupid_rog_".concat(e.lang), "0", "1"), e.usersEcCustomerHandler(t))
                        }))
                    }, e.prototype.setSessionStorage = function(t, e) {
                        sessionStorage.setItem(t, e)
                    }, e.prototype.getSessionStorage = function(t) {
                        return sessionStorage.getItem(t)
                    }, e.prototype.accountDropDownLinkClick = function(t) {
                        (t || t.link) && (this.accountGaHandler(t), window.location = t.link)
                    }, e.prototype.accountStatusActived = function(t) {
                        var e = Object(y.a)(),
                            o = this.urlReplace(t.link);
                        (t || t.link) && (o ? e && ("object" === Object(c.a)(window._satellite) && window._satellite.track("spa-pageview"), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                            shouldTrackUrlChange: function(t, e) {
                                return t && e
                            }
                        }]), window.location = t.link) : (this.accountGaHandler(t), this.accountLinkActived(t)))
                    }, e.prototype.accountLinkActived = function(t) {
                        if ("post" === (t.type ? t.type : null)) {
                            this.accountLanguage = this.mappingWebsite.accountLang;
                            var e = this.routeInfo.websitePath;
                            if (this.exportStatus) {
                                var o = this.$root ? this.$root.$data : null;
                                o && Object.keys(o).length > 0 && (this.accountLanguage = o.language, e = o.websitePath, this.exportWebsitePath = o.websitePath)
                            }
                            "cn" === e ? "rog.asus.com.cn" === window.location.host || "rogmars.asus.com" === window.location.host ? sessionStorage.getItem("oidc.user:https://account.asus.com.cn:c3df97ef67b2022e") ? window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=logout" : window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=login" : sessionStorage.getItem("oidc.user:https://accts-account.asus.com.cn:63825193b2ed32d0") ? window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=logout" : window.location.href = window.location.origin + "/cnaccount/cnaccount.html?returnUrl=" + encodeURI(window.location.href) + "&status=login" : this.accountActive(t)
                        }
                    }, e.prototype.accountActive = function(t) {
                        var e = encodeURI(t.link),
                            o = new RegExp("logout", "ig");
                        if (0 === Object.keys(this.accountLanguage).length && (this.accountLanguage = this.mappingWebsite.accountLang), e && Object.keys(this.accountLanguage).length > 0) try {
                            if (window) {
                                var n = {
                                        lang: this.accountLanguage,
                                        site: this.lang,
                                        AppID: "0000000003",
                                        login_background: "general_black",
                                        login_panel: "simply",
                                        ReturnURL: encodeURI(window.location.href)
                                    },
                                    form = document.createElement("form");
                                for (var r in form.setAttribute("method", "post"), form.setAttribute("action", o.test(e) ? "".concat(e).concat(encodeURI(window.location.href)) : "".concat(e)), n)
                                    if (n.hasOwnProperty(r)) {
                                        var element = n[r],
                                            c = document.createElement("input");
                                        c.setAttribute("type", "hidden"), c.setAttribute("name", r), c.setAttribute("value", element), form.appendChild(c)
                                    }
                                document.body.appendChild(form), form.submit()
                            }
                        } catch (t) {
                            console.error(t)
                        }
                    }, e.prototype.urlReplace = function(t) {
                        for (var e = [], o = 0, n = y.b; o < n.length; o++) {
                            var r = n[o],
                                c = new RegExp(r);
                            c.test(t) && (e = t.split(c))
                        }
                        return e.length > 1 ? e[1] : null
                    }, e.prototype.accountGaHandler = function(t) {
                        var e = t.link,
                            o = new RegExp("elite", "ig"),
                            n = new RegExp("account", "ig");
                        o.test(e) ? this.gaSubMenuSetting("elite_rewards", t.name) : n.test(e) && this.gaSubMenuSetting("my_account", t.name)
                    }, e.prototype.regexEliteName = function(t) {
                        return !!new RegExp("elite", "ig").test(t)
                    }, e.prototype.accountName = function(t) {
                        return t.link.indexOf("signin") > -1 ? this.translation.Header_Login : t.link.indexOf("logout") > -1 ? this.translation.Header_Logout : this.translation.Header_Sign_up
                    }, e.prototype.closeTabControlMenu = function(t) {
                        t !== this.activeNumber && (this.tabClickStatus = !1, this.menuMouseLeave())
                    }, e.prototype.focusDropDownMenu = function() {
                        document.querySelector(".dropMenuItem > a").focus()
                    }, e.prototype.advertisingCookieHandler = function() {
                        var t = this;
                        Object(w.b)("rog_close_advert") || Object(w.c)("rog_close_advert", "", ""), Object(w.b)("rog_allPageShow_advert") || Object(w.c)("rog_allPageShow_advert", "", ""), this.$route && this.getPopUpAds({
                            WebsiteCode: this.routeInfo.websitePath
                        }).then((function(e) {
                            var o, n, r, c;
                            if (e) {
                                var l = e.result,
                                    d = l && l.repeatDisplay ? l.repeatDisplay : null,
                                    h = l && l.displayAllPage ? l.displayAllPage : null;
                                Object(w.c)("rog_repeatShow_advert", d ? encodeURI("1") : "", ""), Object(w.c)("rog_allPageShow_advert", h ? encodeURI("1") : "", ""), "" === Object(w.b)("rog_close_advert") ? "" === Object(w.b)("rog_allPageShow_advert") && (null === (n = null === (o = t.$route) || void 0 === o ? void 0 : o.meta) || void 0 === n ? void 0 : n.homePage) || "1" === Object(w.b)("rog_allPageShow_advert") ? t.alertStatus = !0 : t.alertStatus = !1 : "1" === Object(w.b)("rog_close_advert") && ("1" === Object(w.b)("rog_repeatShow_advert") && ("" === Object(w.b)("rog_allPageShow_advert") && (null === (c = null === (r = t.$route) || void 0 === r ? void 0 : r.meta) || void 0 === c ? void 0 : c.homePage) || "1" === Object(w.b)("rog_allPageShow_advert")) ? t.alertStatus = !0 : t.alertStatus = !1)
                            }
                        }))
                    }, e.prototype.gaSetting = function(t) {
                        window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "header-L1",
                            event_action_DL: "clicked",
                            event_label_DL: t,
                            event_value_DL: " 0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-L1",
                                event_action_DL: "clicked",
                                event_label_DL: t,
                                event_value_DL: " 0"
                            })
                        }), 100)), "rog.asus.com.cn" === window.location.host && void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "header-L1", "clicked", t])
                    }, e.prototype.gaMenuClick = function(t, e) {
                        window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "header-L1",
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(t, "-").concat(e),
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-L1",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "-").concat(e),
                                event_value_DL: "0"
                            })
                        }), 100)), "rog.asus.com.cn" === window.location.host && void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "header-L1", "clicked", "".concat(t, "-").concat(e)])
                    }, e.prototype.gaSubMenuSetting = function(t, e) {
                        if (window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "header-member-L2",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t, "-").concat(e),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "header-member-L2",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t, "-").concat(e),
                                    event_value_DL: "0"
                                })
                            }), 100), "rog.asus.com.cn" === window.location.host)) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", "header-member-L2", "clicked", "".concat(t, "-").concat(e)])
                        }
                    }, P([Object(d.Action)("getPopUpAds")], e.prototype, "getPopUpAds", void 0), P([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), P([Object(d.Getter)("translation")], e.prototype, "translation", void 0), P([Object(d.Getter)("headerGetter")], e.prototype, "menuApis", void 0), P([Object(d.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), P([Object(d.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), P([Object(d.Getter)("websiteObj")], e.prototype, "websiteObj", void 0), P([Object(d.Getter)("accountMenu")], e.prototype, "accountMenu", void 0), P([Object(d.Getter)("accountStatus")], e.prototype, "accountStatus", void 0), P([Object(d.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), P([Object(d.Mutation)(A.HEADER)], e.prototype, "rogExportHeader", void 0), P([Object(d.Mutation)(A.ROG_FOOTER)], e.prototype, "rogExportFooter", void 0), P([Object(d.Mutation)(A.ROG_WEBSITE)], e.prototype, "rogExportWebsite", void 0), P([Object(l.Watch)("lang", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchLang", null), P([Object(l.Watch)("mappingWebsite", {
                        deep: !0
                    })], e.prototype, "watchEcObject", null), P([Object(h.debounce)(100)], e.prototype, "debounceDisplaySubMenu", null), e = P([Object(l.Component)({
                        components: {
                            mobileDropDownMenuList: k.a,
                            dropDownMenuList: C.a,
                            personalBlock: M.a,
                            SearchHeaderPanel: I.a,
                            miniCartBlock: S.a,
                            Advertising: L.a
                        }
                    })], e)
                }(l.Vue),
                x = D,
                H = o(392),
                z = o(25);
            var component = Object(z.a)(x, (function() {
                var t, e, o = this,
                    n = o._self._c;
                o._self._setupProxy;
                return n("div", {
                    staticClass: "newHeader",
                    class: [o.$style.headerWrapper, (t = {}, Object(r.a)(t, o.$style.scrolled, o.isScrolled), Object(r.a)(t, o.$style.upscrolled, !o.isScrolled), Object(r.a)(t, o.$style.isMotherboards, o.isMotherboards), Object(r.a)(t, o.$style.noSticky, !o.isHomePage), t)],
                    attrs: {
                        dir: o.dirType
                    }
                }, [n("div", {
                    class: [o.$style.headerContainer, (e = {}, Object(r.a)(e, o.$style.isMobileActived, o.isBurgerActived), Object(r.a)(e, o.$style.scrolled, o.isScrolled), Object(r.a)(e, o.$style.fixed, o.isFixed), e)]
                }, [n("header", {
                    ref: "header",
                    staticClass: "robotoFont",
                    class: o.$style.header,
                    attrs: {
                        "aria-label": "rog header"
                    }
                }, [n("a", {
                    class: o.$style.rogLogo,
                    attrs: {
                        "aria-label": "ROG - Republic of Gamers",
                        href: o.goHomeLink(),
                        id: "rogLogo"
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), o.goToHome()
                        }
                    }
                }, [n("div", {
                    class: o.$style.rogLogoIcon
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 200 37",
                        "svg-inline": "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M22.2 29.1c.8.5 1.6 1 2.4 1.4 8.6 3.8 21.3 6.1 23.7 5.3C55 33.6 62.5 19.5 64.8 13c0 0-7 2.8-14.1 6.1-5.9 2.8-12.4 6-12.4 6l16.5-5s-4.4 10.4-10.2 11.6c-5.8 1.2-16-2.9-16-2.9.8-.7 11.6-8.6 36.8-18.9 1.1-.8 1.8-2.1 2-3.4-5.8.6-11.4 2.3-16.7 4.8-10.6 5-28.5 17.8-28.5 17.8zM3.8 24c1.8 2.3 9.2 4.2 10.2 4.4-4.6-3.2-14-12-14-12 1 2.7 2.3 5.2 3.8 7.6z"
                    }
                }), n("path", {
                    attrs: {
                        d: "M25.6 22.9C30.5 19.3 47.9 4.6 64.7.6c0 0-8.8-1.4-21.3 2.5-4.5 1.4-11 7.7-23.1 19.4-1.6.9-7.5-2.5-10.9-4.1 0 0 5.6 8.9 7.6 11.5 3 4.1 8.5 6.5 8.5 6.5-.5-.5-4.3-4.5-5.4-6.8-.7-1.1.1-2.7 5.5-6.7zM127.9 6.8h-3v8.9h-5.6V6.8h-3v10.4h11.6zM152.9 15.6h-7.5V6.8h-3.1v10.4h9.2zM154.2 6.8h3.1v10.4h-3.1zM191.7 8.3h6.9l1.4-1.5h-11.4v10.4h3.1v-5.1h6.7l1.2-1.6h-7.9zM106.6 13.8h8.3V7.6c0-.4-.3-.8-.7-.8h-10.7v10.3h3.1v-3.3zm0-5.5h5c.1 0 .3 0 .3.5v3.5h-5.3v-4zM140.7 10.8h-.9v-3c0-.6-.3-1-.8-1h-9.7v10.4h11.3l.1-6.4zm-3.1 4.8h-5.2v-3.3h5.2v3.3zm0-4.8h-5.2V8.3h4.9c.3 0 .3.4.3.5v2zM100.5 8.3l1.6-1.5H90.5v10.3h11.6l-1.6-1.5h-6.9v-2.8h7.8v-1.7h-7.8V8.3zM162 8.3h7l1.5-1.5h-11.6v10.3H169l1.5-1.5H162zM154 24.5l1.3-1.5h-11.8v5.6h8.5v3.1h-8.9l1.9 1.6h10.2V27h-8.6v-2.5zM100.6 23h-11v10.3h3.1v-4.4h5.5v4.4h3.1v-9.4c.1-.4-.2-.8-.7-.9zm-2.4 4.4h-5.4v-2.9h5.1c.3 0 .3.3.3.5v2.4zM127.2 24.5l1.6-1.5h-11.7v10.3h11.7l-1.6-1.5h-7V29h7.9v-1.7h-7.9v-2.8zM86.4 24.6L88 23H75.8v10.3h11.8v-5.6h-3.1v4.1H79v-7.2zM103 23v10.4h3.2v-6l3 2.1 3.1-2.1v6h3.1V23l-6.2 4.1zM141.8 28.9v-5c0-.5-.3-1-.8-1h-11.2v10.4h3.1v-8.8h5.4c.3 0 .3.3.3.5v2h-5.1l5.6 6.3h3.7l-3.9-4.4h2.9zM88.7 14.1V7.8c0-.5 0-1-.6-1H75.8V14l3.2 3.5V8.3h6c.4 0 .5.1.5.5v3.3h-5.3l8.5 8.9v-3.5L85.5 14h3.2zM186.1 6.8h-10.5v7.5l2.5 2.9h8.7V7.6c0-.4-.3-.8-.7-.8zm-2.4 8.8h-3.3l-1.7-2V8.3h5v7.3z"
                    }
                })])])]), o._v(" "), n("div", {
                    class: o.$style.accessibility
                }, [n("div", {
                    staticClass: "orb-skip-links"
                }, [n("span", [o._v("Accessibility links")]), o._v(" "), n("ul", [o.isRogSite ? n("li", [n("a", {
                    attrs: {
                        href: "#rogContent",
                        "aria-label": o.translation.ADA_Content
                    }
                }, [o._v(o._s(o.translation.ADA_Content))])]) : o._e(), o._v(" "), n("li", [n("a", {
                    attrs: {
                        "aria-label": o.translation.ADA_Accessibility_Help,
                        href: "https://www.asus.com".concat(o.AccessibilityPolicySite, "/content/Accessibility-Policy/")
                    }
                }, [o._v(o._s(o.translation.ADA_Accessibility_Help))])]), o._v(" "), o.isAccount ? o._e() : n("li", [n("a", {
                    attrs: {
                        href: "#rogMenu",
                        "aria-label": o.translation.ADA_Menu
                    }
                }, [o._v(o._s(o.translation.ADA_Menu))])]), o._v(" "), o.isAccount ? o._e() : n("li", [n("a", {
                    attrs: {
                        href: "#rogFooter",
                        "aria-label": o.translation.ADA_Footer
                    }
                }, [o._v(o._s(o.translation.ADA_Footer))])])])])]), o._v(" "), !o.menuApis || o.isRegion || o.isAccount ? o._e() : n("nav", {
                    class: o.$style.headerNav
                }, [n("div", {
                    class: o.$style.headerBurger,
                    attrs: {
                        "aria-label": "Menu",
                        role: "button",
                        tabindex: "0"
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && o._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : o.burgerClick.apply(null, arguments)
                        },
                        click: o.burgerClick
                    }
                }, [n("span", {
                    class: o.$style.rogBurger
                }, [n("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "close",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M20 6H4v1h16V6zm0 5.5H4v1h16v-1zM4 17h16v1H4v-1z",
                        fill: "#fff"
                    }
                })])])]), o._v(" "), n("div", {
                    staticClass: "mobileMenu",
                    class: o.$style.headerMenu
                }, [o.isMobileStatus ? n("div", {
                    class: o.$style.headerMenuToolBar
                }, [n("div", {
                    class: [o.$style.userButton, o.$style.accountButton],
                    attrs: {
                        role: "button",
                        tabindex: "0",
                        "aria-label": "Account",
                        "aria-expanded": o.showUserListMobile
                    },
                    on: {
                        click: o.userMobileHandler
                    }
                }, [o.isLogin() ? o._e() : n("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "none",
                        "svg-inline": "",
                        alt: "user",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M12.613 18.28v2.1H22l-4.009-4.009.7-3.982v-.1c-.484-1.44-2.1-6.195-2.783-6.846a18.386 18.386 0 00-3.701-1.874L12 3.5l-.17.069A18.393 18.393 0 008.13 5.443c-.69.651-2.89 5.848-3.32 6.88l-.063.139 1.235 3.939L2 20.383h8.886V18.53l-2.873-1.718-.442.739 2.448 1.452v.507H4.094l2.795-3.123-1.215-4.121a50.59 50.59 0 012.97-6.447 15.671 15.671 0 013.107-1.614V10.304l3.332-.868c.633.85 1.17 1.766 1.6 2.733l-1.587 4.425-2.483 1.686z",
                        fill: "#F7F7F7"
                    }
                })]), o._v(" "), o.isLogin() && "" === o.createUrl ? n("svg", {
                    class: o.$style.isLogin,
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "none",
                        "svg-inline": "",
                        alt: "user",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm0 1c6.07 0 11 4.93 11 11 0 2.64-.93 5.06-2.49 6.95l-2.52-2.52.7-3.98v-.1c-.48-1.44-2.1-6.2-2.78-6.85a18.36 18.36 0 00-3.7-1.87L12 3.56l-.17.07c-1.3.48-2.54 1.11-3.7 1.87-.69.65-2.89 5.85-3.32 6.88l-.06.14 1.23 3.94-2.5 2.5a10.97 10.97 0 01-2.49-6.95C1 5.93 5.93 1 12 1zm-1.11 21.94v-4.36l-2.87-1.72-.44.74 2.45 1.45v3.74c-.09 0-.18-.03-.27-.04-1.99-.42-3.77-1.38-5.21-2.71-.15-.16-.3-.32-.44-.49l2.8-3.12-1.22-4.12c.84-2.22 1.83-4.37 2.97-6.45.97-.65 2.01-1.19 3.11-1.61v6.1l3.33-.87c.63.85 1.17 1.77 1.6 2.73l-1.59 4.42-2.48 1.69v4.63c-.2.01-.41.03-.61.03-.38 0-.75-.02-1.11-.06l-.02.02z",
                        fill: "#fff"
                    }
                })]) : o._e(), o._v(" "), o.isLogin() && "" !== o.createUrl ? n("img", {
                    attrs: {
                        role: "none",
                        tabindex: "-1",
                        src: o.createUrl,
                        alt: "user",
                        "aria-hidden": o.isLogin()
                    }
                }) : o._e()]), o._v(" "), n("div", {
                    class: o.$style.closeButton,
                    attrs: {
                        role: "button",
                        "aria-label": "close menu",
                        tabindex: "0"
                    },
                    on: {
                        click: o.burgerClick
                    }
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "close",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M28 5.41L26.59 4 16 14.59 5.41 4 4 5.41 14.59 16 4 26.59 5.41 28 16 17.41 26.59 28 28 26.59 17.41 16 28 5.41z"
                    }
                })])])]) : o._e(), o._v(" "), n("ul", {
                    class: [o.$style.userListMobile, Object(r.a)({}, o.$style.active, o.showUserListMobile)],
                    attrs: {
                        "aria-hidden": !o.showUserListMobile
                    }
                }, [n("li", {
                    class: o.$style.userMobileListTitle
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        role: "button",
                        "aria-label": "go back",
                        "svg-inline": "",
                        alt: "left",
                        focusable: "false"
                    },
                    on: {
                        click: o.closeUserMobileHandler
                    }
                }, [n("path", {
                    attrs: {
                        d: "M8.93 13.77L22.94 0v6.7l-9.18 8.94 9.18 9.66V32L8.93 17.51l-1.87-1.87 1.87-1.87z"
                    }
                })]), o._v(" "), n("p", [o._v(o._s(o.translation.Header_M_User))])]), o._v(" "), "cn" !== o.lang && o.accountStatus && o.accountStatus.userInfo && o.accountStatus.userInfo.name ? n("li", {
                    class: o.$style.accountInfo
                }, [n("p", {
                    class: o.$style.accountName
                }, [o._v(o._s(o.accountStatus.userInfo.name))]), o._v(" "), n("p", {
                    class: o.$style.accountPoints
                }, [o._v(o._s(o.accountStatus.userInfo.points) + " " + o._s(o.translation.Points))])]) : o._e(), o._v(" "), n("li", [n("ul", {
                    class: o.$style.accountLinkSection,
                    attrs: {
                        role: "list"
                    }
                }, [o._l(o.accountMenu, (function(t, e) {
                    return n("li", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !("cn" === o.lang && o.regexEliteName(t.link)),
                            expression: "!(lang === 'cn' && regexEliteName(accountInfo.link))"
                        }],
                        key: e,
                        class: o.$style.dropDownLink,
                        attrs: {
                            role: "none"
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.accountDropDownLinkClick(t)
                            }
                        }
                    }, ["cn" !== o.lang ? n("a", {
                        attrs: {
                            "aria-label": t.name,
                            href: t.link
                        }
                    }, [o._v("\n                    " + o._s(t.name) + "\n                  ")]) : o._e(), o._v(" "), "cn" === o.lang ? n("a", {
                        attrs: {
                            "aria-label": t.name,
                            href: o.getCnAccountLink
                        }
                    }, [o._v("\n                    " + o._s(t.name) + "\n                  ")]) : o._e()])
                })), o._v(" "), o.accountStatus.linkSection && o.accountStatus.linkSection.length > 0 ? n("li", {
                    attrs: {
                        role: "none"
                    }
                }, o._l(o.accountStatus.linkSection, (function(t, e) {
                    return n("div", {
                        key: e,
                        class: o.$style.linkSectionLink
                    }, [n("a", {
                        attrs: {
                            "aria-label": o.accountName(t),
                            href: t.link
                        }
                    }, ["cn" !== o.lang ? n("span", {
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.accountStatusActived(t)
                            }
                        }
                    }, [o._v(o._s(o.accountName(t)))]) : o._e(), o._v(" "), "cn" === o.lang ? n("span", {
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.accountStatusActived(t)
                            }
                        }
                    }, [o._v(o._s(t.name))]) : o._e()])])
                })), 0) : o._e()], 2)])]), o._v(" "), n("ol", {
                    ref: "menuList",
                    staticClass: "headerMenuList",
                    class: [o.$style.headerMenuList, Object(r.a)({}, o.$style.smallList, o.isSmallItem)],
                    attrs: {
                        role: "list"
                    },
                    on: {
                        mouseover: o.menuListOver,
                        mouseleave: o.menuMouseLeave
                    }
                }, [o.chkMenuApisObject(o.menuApis) ? [o._l(o.menuApis, (function(t, e) {
                    return n("li", {
                        key: e,
                        staticClass: "headerItem",
                        class: [o.$style.menuList, Object(r.a)({}, o.$style.smallItem, o.isSmallItem)],
                        attrs: {
                            role: "listitem"
                        },
                        on: {
                            keydown: function(t) {
                                return !t.type.indexOf("key") && o._k(t.keyCode, "down", 40, t.key, ["Down", "ArrowDown"]) ? null : o.focusDropDownMenu.apply(null, arguments)
                            },
                            mouseover: function(n) {
                                return o.menuMouseOver(t, n, e)
                            },
                            click: function(e) {
                                return o.triggerDisplaySubMenu(t)
                            }
                        }
                    }, [t && t.items && Object.keys(t.items).length > 0 && Object.keys(t.items[0].subItem).length > 0 ? n("div", {
                        class: [o.$style.menuItem, {
                            firstMenuItem: 0 === e
                        }],
                        attrs: {
                            tabindex: "0",
                            "aria-haspopup": "true",
                            "aria-expanded": !(!o.isDisplay || !o.checkMenuItems(o.dropDownMenuActivedMeta) || o.activeNumber !== e),
                            id: "rogMenu".concat(0 === e ? "" : e)
                        },
                        on: {
                            click: function(e) {
                                return o.menuClick(t, e)
                            },
                            keydown: [function(n) {
                                return !n.type.indexOf("key") && o._k(n.keyCode, "space", 32, n.key, [" ", "Spacebar"]) ? null : o.tabClick(t, n, e)
                            }, function(n) {
                                return !n.type.indexOf("key") && o._k(n.keyCode, "enter", 13, n.key, "Enter") ? null : o.tabClick(t, n, e)
                            }]
                        }
                    }, [n("span", {
                        staticClass: "menuItem",
                        class: [Object(r.a)({}, o.$style.active, o.isDisplay && o.activeNumber === e)]
                    }, [o._v(o._s(t.name))]), o._v(" "), n("div", {
                        class: o.$style.isMobileArrow
                    }, [n("svg", {
                        attrs: {
                            width: "16",
                            height: "16",
                            viewBox: "0 0 16 16",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            role: "none",
                            alt: "right",
                            focusable: "false"
                        }
                    }, [n("path", {
                        attrs: {
                            d: "M12.733 8l-6.666 6.667H3.333L10 8 3.333 1.333h2.734L12.733 8z",
                            fill: "#181818"
                        }
                    })])])]) : n("a", {
                        class: o.$style.noArrow,
                        attrs: {
                            id: "rogMenu".concat(0 === e ? "" : e),
                            "aria-label": "".concat(t.name),
                            href: t.url,
                            target: "_blank",
                            rel: "noopener noreferrer"
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), o.goToOtherSite(t.url)
                            },
                            focus: function(t) {
                                return o.closeTabControlMenu(e)
                            }
                        }
                    }, [n("span", {
                        staticClass: "menuItem",
                        class: [Object(r.a)({}, o.$style.active, o.isDisplay && o.activeNumber === e)]
                    }, [o._v(o._s(t.name))])]), o._v(" "), o.isDisplay && o.checkMenuItems(o.dropDownMenuActivedMeta) && o.activeNumber === e ? n("dropDownMenuList", {
                        attrs: {
                            dropDownVal: o.dropDownMenuActivedMeta,
                            headerListBlockPosition: o.headerListPosition,
                            headerBlockPosition: o.headerBasicPosition,
                            menuWidth: o.menuWidth
                        },
                        on: {
                            enterSubMenu: o.subMenuStatus,
                            leaveSubMenu: o.subMenuStatus,
                            closeAction: o.closeMenuHandler
                        }
                    }) : o._e()], 1)
                })), o._v(" "), n("li", {
                    attrs: {
                        role: "listitem"
                    }
                }, [n("a", {
                    class: o.$style.mobileAsusLogo,
                    attrs: {
                        "aria-label": "ASUS",
                        href: "".concat(o.asusLinkArea)
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), o.goToASUS(o.asusLinkArea)
                        }
                    }
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "71.418",
                        height: "15.556",
                        viewBox: "0 0 71.418 15.556",
                        "svg-inline": "",
                        alt: "asus",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("g", {
                    attrs: {
                        "data-name": "组件 69 – 1"
                    }
                }, [n("path", {
                    attrs: {
                        fill: "#797979",
                        stroke: "rgba(0,0,0,0)",
                        "stroke-miterlimit": "10",
                        d: "M52.803 15.056l.009-3.84h13.593a1.609 1.609 0 00.649-.183.818.818 0 00.256-.578c0-.737-.613-.769-.921-.785l-9.882-.815A4.615 4.615 0 0154.3 7.812a3.758 3.758 0 01-1.271-2.052s12.766.746 14.184.877a4.359 4.359 0 013.618 3.351 6.077 6.077 0 01-.022 1.57 4.233 4.233 0 01-4.008 3.5zm-12.767-.017l-.354-.025a4.216 4.216 0 01-3.621-3.534v-.609a5.825 5.825 0 01-.077.656 4.261 4.261 0 01-3.52 3.5h-18.3v-9.8l3.8.276v5.738h13.688a.768.768 0 00.807-.74c.007-.738-.562-.814-.864-.828 0 0-9.444-.774-9.782-.806a4.988 4.988 0 01-2.284-1.074 3.976 3.976 0 01-1.2-2.258s12.694 1 14.119 1.129c2.392.221 3.494 2.753 3.59 3.327 0 0 .008.059.015.164V4.642l3.881.278v5.078a1.23 1.23 0 001.119 1.273h6.6a1.264 1.264 0 001.267-1.285v-4.46l3.843.227v5.358c0 3.627-3.817 3.931-3.817 3.931zM.918 15.021L7.651 4.597l4.341.458-6.472 9.966zM52.803 4.363v-.311a5.491 5.491 0 01.973-2A4.27 4.27 0 0156.918.5h14v3.866zm-3.937 0V.519h3.909v3.844zm-12.844 0V.519h3.912v3.844zm-28.216 0s1.589-2.59 1.983-3.1a1.682 1.682 0 011.4-.738h6.946v3.527a5.5 5.5 0 01.977-2A4.252 4.252 0 0122.253.496h13.086v3.863z",
                        "data-name": "联合 1"
                    }
                })])])])])] : o._e()], 2), o._v(" "), n("ClientOnly", [n("mobileDropDownMenuList", {
                    attrs: {
                        isMobile: o.isMobileDisplay,
                        dropDownVal: o.mobileDropDownMenuActivedMeta,
                        headerListBlockPosition: o.mobilePosition,
                        headerBlockPosition: o.mobilePosition.top,
                        isBurgerActived: o.isBurgerActived
                    },
                    on: {
                        mobileSubMenu: o.mobileSubMenuClickEvent,
                        closeMobileMenuList: o.closeMobileMenuList,
                        closeAction: o.burgerClick
                    }
                })], 1)], 1)]), o._v(" "), n("div", {
                    class: o.$style.iconBlock
                }, [o.isAccount ? o._e() : n("div", {
                    class: o.$style.asusLogo
                }, [n("a", {
                    attrs: {
                        "aria-label": "ASUS",
                        href: "".concat(o.asusLinkArea)
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), o.goToASUS(o.asusLinkArea)
                        }
                    }
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "71.418",
                        height: "15.556",
                        viewBox: "0 0 71.418 15.556",
                        "svg-inline": "",
                        alt: "asus",
                        role: "none",
                        focusable: "false"
                    }
                }, [n("g", {
                    attrs: {
                        "data-name": "组件 69 – 1"
                    }
                }, [n("path", {
                    attrs: {
                        fill: "#797979",
                        stroke: "rgba(0,0,0,0)",
                        "stroke-miterlimit": "10",
                        d: "M52.803 15.056l.009-3.84h13.593a1.609 1.609 0 00.649-.183.818.818 0 00.256-.578c0-.737-.613-.769-.921-.785l-9.882-.815A4.615 4.615 0 0154.3 7.812a3.758 3.758 0 01-1.271-2.052s12.766.746 14.184.877a4.359 4.359 0 013.618 3.351 6.077 6.077 0 01-.022 1.57 4.233 4.233 0 01-4.008 3.5zm-12.767-.017l-.354-.025a4.216 4.216 0 01-3.621-3.534v-.609a5.825 5.825 0 01-.077.656 4.261 4.261 0 01-3.52 3.5h-18.3v-9.8l3.8.276v5.738h13.688a.768.768 0 00.807-.74c.007-.738-.562-.814-.864-.828 0 0-9.444-.774-9.782-.806a4.988 4.988 0 01-2.284-1.074 3.976 3.976 0 01-1.2-2.258s12.694 1 14.119 1.129c2.392.221 3.494 2.753 3.59 3.327 0 0 .008.059.015.164V4.642l3.881.278v5.078a1.23 1.23 0 001.119 1.273h6.6a1.264 1.264 0 001.267-1.285v-4.46l3.843.227v5.358c0 3.627-3.817 3.931-3.817 3.931zM.918 15.021L7.651 4.597l4.341.458-6.472 9.966zM52.803 4.363v-.311a5.491 5.491 0 01.973-2A4.27 4.27 0 0156.918.5h14v3.866zm-3.937 0V.519h3.909v3.844zm-12.844 0V.519h3.912v3.844zm-28.216 0s1.589-2.59 1.983-3.1a1.682 1.682 0 011.4-.738h6.946v3.527a5.5 5.5 0 01.977-2A4.252 4.252 0 0122.253.496h13.086v3.863z",
                        "data-name": "联合 1"
                    }
                })])]), o._v(" "), n("span", {
                    staticClass: "sr-only"
                }, [o._v("ASUS home logo")])])]), o._v(" "), n("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !o.isRegion && !o.isAccount,
                        expression: "!isRegion && !isAccount"
                    }],
                    class: ["searchButton", o.$style.searchButton, Object(r.a)({}, o.$style.active, o.searchPanelStatus)],
                    attrs: {
                        id: "searchButton",
                        tabindex: "0",
                        "aria-haspopup": "true",
                        "aria-expanded": o.searchPanelStatus,
                        "aria-label": o.translation.Aria_SearchBar
                    },
                    on: {
                        click: o.searchPanelHandler
                    }
                }, [n("svg", {
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        role: "none",
                        "svg-inline": "",
                        alt: "search",
                        focusable: "false"
                    }
                }, [n("g", {
                    attrs: {
                        "clip-path": "url(#clip0_928_570)"
                    }
                }, [n("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M16.045 16.645a7.5 7.5 0 11.707-.707l4.254 4.254-.707.707-4.254-4.254zm-.342-1.049A6.5 6.5 0 106.51 6.404a6.5 6.5 0 009.193 9.192z",
                        fill: "#fff"
                    }
                })]), n("defs", [n("clipPath", {
                    attrs: {
                        id: "clip0_928_570"
                    }
                }, [n("path", {
                    attrs: {
                        fill: "#fff",
                        d: "M0 0h24v24H0z"
                    }
                })])])])]), o._v(" "), !o.searchPanelStatus || o.isRegion || o.isAccount ? o._e() : n("SearchHeaderPanel", {
                    staticClass: "searchHeaderPanel",
                    attrs: {
                        websiteId: o.mappingWebsiteId
                    },
                    on: {
                        close: o.searchPanelHandler
                    }
                }), o._v(" "), o.isMobileDisplay || o.isRegion || o.isAccount ? o._e() : n("personalBlock"), o._v(" "), o.isAccount ? o._e() : n("miniCartBlock", {
                    attrs: {
                        miniCartNumber: o.miniCartNumber,
                        cartList: o.cartList,
                        getMiniCartStatus: o.getMiniCartStatus
                    }
                })], 1)]), o._v(" "), n("ClientOnly", [n("Advertising", {
                    attrs: {
                        isShow: o.alertStatus
                    },
                    on: {
                        "update:isShow": function(t) {
                            o.alertStatus = t
                        },
                        "update:is-show": function(t) {
                            o.alertStatus = t
                        }
                    }
                })], 1)], 1)])
            }), [], !1, (function(t) {
                this.$style = H.default.locals || H.default
            }), null, null);
            e.a = component.exports
        },
        406: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                c = (o(60), o(26), o(20), o(9)),
                l = (o(54), o(41), o(10), o(28), o(44), o(59), o(51), o(18), o(121), o(29), o(91), o(33), o(103), o(3)),
                d = o(7),
                h = o(6),
                m = o.n(h),
                v = o(79),
                _ = o(36),
                f = o(0),
                w = o(4),
                y = o(144),
                C = o(476),
                k = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                M = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        l = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(c.a)(Reflect)) && "function" == typeof Reflect.decorate) l = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (l = (r < 3 ? n(l) : r > 3 ? n(e, o, l) : n(e, o)) || l);
                    return r > 3 && l && Object.defineProperty(e, o, l), l
                },
                I = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.rogFooterMode = "pc", e.activeBottomBanner = "", e.exportWebsiteID = 1, e.exportWebsitePath = "global", e.isAccount = !1, e.showWarn = !1, e.crmValue = "", e.warnText = "Please enter a valid email address.", e.inputWidth = 240, e.settingList = ["global", "cn", "in", "jp", "pl", "ch-de", "br", "de", "ee", "cl", "co", "us", "pe", "it", "bg", "bt", "es", "ch-en", "cz", "be-fr", "dk", "ch-fr", "ch-it", "lv", "pt", "fr", "gr", "gr-en", "lt", "ie", "hu", "be-nl", "nl", "ro", "no", "sk", "fi", "se", "uk", "tr", "za", "ch", "si", "hr"], e
                    }
                    return k(e, t), Object.defineProperty(e.prototype, "crmButtonData", {
                        get: function() {
                            return {
                                name: this.translation.Header_Sign_up,
                                disabled: !1
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "fullPath", {
                        get: function() {
                            return Object.keys(this.routeInfo).length > 0 ? this.routeInfo.fullPath ? this.routeInfo.fullPath : null : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isHome", {
                        get: function() {
                            var t;
                            return "HomePage" === (null === (t = this.$route) || void 0 === t ? void 0 : t.name)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isProductHome", {
                        get: function() {
                            var t;
                            return "ProductLinePage" === (null === (t = this.$route) || void 0 === t ? void 0 : t.name)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "noCRM", {
                        get: function() {
                            var t;
                            return "cn" === this.lang || ("undefined" != typeof window ? ((null === (t = window.AsusAPIConfig) || void 0 === t ? void 0 : t.campaignId) || (window.AsusAPIConfig.campaignId = "3f8bcb17-b07f-4992-bcf7-72cdfcf704f9"), !1) : void 0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t = "";
                            return Object.keys(this.routeInfo).length > 0 ? (this.routeInfo.websitePath, t = this.routeInfo.websitePath) : window && window.AsusAPIConfig ? (t = window.AsusAPIConfig.websitePath, this.isAccount = window.AsusAPIConfig && window.AsusAPIConfig.simplifyFooter || !1) : t = this.exportWebsitePath, t
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isShowSettingCookie", {
                        get: function() {
                            var t = this;
                            return this.settingList.filter((function(e) {
                                return e === t.lang
                            })).length > 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "pageNameType", {
                        get: function() {
                            var t, e;
                            return "1" === (null === (e = null === (t = this.$route) || void 0 === t ? void 0 : t.meta) || void 0 === e ? void 0 : e.homePage)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "dirtype", {
                        get: function() {
                            if (this.$route) switch (this.routeInfo.websitePath) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return "rtl";
                                default:
                                    return "ltr"
                            } else if (this.exportWebsitePath) switch (this.exportWebsitePath) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return "rtl";
                                default:
                                    return "ltr"
                            } else switch (this.routeInfo.websitePath, this.routeInfo.websitePath) {
                                case "il":
                                case "me-ar":
                                case "sa-ar":
                                case "eg":
                                case "nafr-ar":
                                    return "rtl";
                                default:
                                    return "ltr"
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "rogCategoryStatus", {
                        get: function() {
                            return !!(this.footerApi && Object.keys(this.footerApi.termsOfUseData).length > 0)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isPCMode", {
                        get: function() {
                            return "pc" === this.rogFooterMode && "" !== this.activeBottomBanner && this.isHome && !this.isAccount
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isShowBottomBanner", {
                        get: function() {
                            return Object.keys(this.bottomBanner).length > 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "spotLightStatus", {
                        get: function() {
                            return Object.keys(this.getSpotLight).length > 0 && Object.keys(this.getSpotLight[0].data).length > 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.listenDeviceMode = function() {
                        var t;
                        (null === (t = this.footerApi) || void 0 === t ? void 0 : t.logo) && ("pc" === this.rogFooterMode ? this.activeBottomBanner = this.footerApi.logo : this.activeBottomBanner = "")
                    }, e.prototype.showCookieSettingHandler = function() {
                        window.triggerCookieBanner(), setTimeout((function() {
                            document.querySelector(".btn-setting").click()
                        }), 0)
                    }, e.prototype.backgroundHander = function(t) {
                        return t ? "background-image:url(".concat(this.activeBottomBanner, ");background-size:auto;") : ""
                    }, e.prototype.imgHandler = function(t) {
                        return t ? "".concat(this.activeBottomBanner) : ""
                    }, e.prototype.footerRegionClick = function(t) {
                        window.location.host.indexOf("account") > -1 ? window.location.host.indexOf("dev-account") > -1 || window.location.host.indexOf("test-account") > -1 ? ("global" === window.AsusAPIConfig.websitePath ? Object(w.c)("rog_account", window.location.pathname.slice(1) + window.location.search, "") : Object(w.c)("rog_account", window.location.pathname.replace("/".concat(window.AsusAPIConfig.websitePath, "/"), "") + window.location.search, ""), window.location.href = "https://rogmars.asus.com/accountentry/") : ("global" === window.AsusAPIConfig.websitePath ? Object(w.c)("rog_account", window.location.pathname.slice(1) + window.location.search, "") : Object(w.c)("rog_account", window.location.pathname.replace("/".concat(window.AsusAPIConfig.websitePath, "/"), "") + window.location.search, ""), window.location.href = "https://rog.asus.com/accountentry/") : this.openUrl(t.link, t.linkTarget, "entry")
                    }, e.prototype.openSocialMediaLink = function(t) {
                        this.gaDataLayer(t.name, "buttons"), this.openUrl(t.link, t.linkTarget, "social")
                    }, e.prototype.siteMapListClick = function(t) {
                        this.gaDataLayer(t.name, "internal-links"), this.openUrl(t.link, t.linkTarget, "")
                    }, e.prototype.categoryClick = function(t) {
                        this.openUrl(t.link, null, "")
                    }, e.prototype.bindingSwitchDevice = function() {
                        var t = this;
                        try {
                            "undefined" != typeof window && (this.switchDeviceMode(), window.addEventListener("resize", (function() {
                                t.switchDeviceMode()
                            }), !1))
                        } catch (t) {
                            console.error(t)
                        }
                    }, e.prototype.chkFooterVal = function(t) {
                        return Object.keys(t).length > 0 && (this.bindingSwitchDevice(), !0)
                    }, e.prototype.openUrl = function(t, e, o) {
                        if (window && t) {
                            if (this.getAIStatus) return void("entry" === o ? top.location.href = "https://".concat(window.location.host, "/entry") : window.open(t, e));
                            e ? window.open(t, e) : window.location.href = encodeURI(t)
                        }
                    }, e.prototype.switchDeviceMode = function() {
                        Object(v.a)().width > 768 ? this.rogFooterMode = "pc" : this.rogFooterMode = "mobile"
                    }, e.prototype.getUrlOrigin = function() {
                        return Object(_.a)() ? encodeURI(window.location.origin) : "https://rog.asus.com"
                    }, e.prototype.reGetFooterAPI = function() {
                        this.getFooterAPI({
                            WebsiteCode: this.routeInfo.websitePath
                        })
                    }, e.prototype.getExportFooterAPI = function() {
                        var t = this,
                            e = this.$root ? this.$root.$data : null,
                            o = e.websitePath ? e.websitePath : this.exportWebsitePath,
                            n = "",
                            r = encodeURI(window.location.host),
                            c = r.replace(".asus.com", "");
                        "rog.asus.com.cn" === window.location.host ? (n = encodeURI(window.location.host), m()({
                            method: "get",
                            url: "https://api-rog.asus.com.cn/recent-data/api/v4/Common/Footer?WebsiteCode=".concat(o, "&systemCode=").concat(c)
                        }).then((function(e) {
                            t.rogExportFooter(e.data)
                        })).catch((function(t) {
                            console.error(t)
                        }))) : (n = "api-rog.asus.com", r.indexOf("dev") > -1 ? n = "dev-api-rog.asus.com" : r.indexOf("stage") > -1 ? n = "stage-api-rog.asus.com" : r.indexOf("rogmars") > -1 && (n = "api-rogmars.asus.com"), m()({
                            method: "get",
                            url: "https://".concat(n, "/recent-data/api/v4/Common/Footer?WebsiteCode=").concat(o, "&systemCode=").concat(c)
                        }).then((function(e) {
                            t.rogExportFooter(e.data)
                        })).catch((function(t) {
                            console.error(t)
                        })))
                    }, e.prototype.mounted = function() {
                        if (this.exportFooter(), "ca-en" === this.lang || "ca-fr" === this.lang) {
                            var t = document.createElement("script");
                            t.setAttribute("data-cfasync", "false"), t.text = "window.ju_num=\"5F08F32F-5D29-40EC-BA20-E24539C6857C\";window.asset_host='//cdn.jst.ai/';(function(i,s,o,g,r,a,m){i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)};a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script',asset_host+'vck.js','juapp');", document.body.appendChild(t)
                        }
                        this.$nextTick((function() {}))
                    }, e.prototype.exportFooter = function() {
                        if (this.$root && !this.$route) {
                            var t = this.$root ? this.$root.$data : null;
                            this.exportWebsiteID = t.websiteID;
                            encodeURI(window.location.host);
                            var e = window.AsusAPIConfig;
                            this.exportWebsitePath = e.websitePath;
                            t.websitePath ? t.websitePath : this.exportWebsitePath;
                            "cn" !== this.exportWebsitePath && this.addSubscribeFromScript(), this.getExportFooterAPI(), this.setTranslation()
                        }
                    }, e.prototype.addSubscribeFromScript = function() {
                        var t = "",
                            e = encodeURI(window.location.host);
                        t = "https://dlcdnimgs.asus.com/vendor/subscribe-form/js/subscribeform.min.js", e.indexOf("dev") > -1 || e.indexOf("stage") > -1 ? t = "https://stage-asgard.asus.com/vendor/subscribe-form/js/subscribeform.min.js" : e.indexOf("rogmars") > -1 && (t = "https://dlcdnimgs.asus.com/vendor/subscribe-form/js/subscribeform.min.js");
                        var o = document.createElement("script");
                        o.type = "text/javascript", o.src = t, o.defer = !0, document.body.appendChild(o)
                    }, e.prototype.setTranslation = function() {
                        var t = this;
                        if (0 === Object.keys(this.translation).length) {
                            var e = encodeURI(window.location.host),
                                o = "api-rog.asus.com",
                                n = e.replace(".asus.com", ""),
                                r = this.exportWebsitePath,
                                c = new RegExp(/stage/gim);
                            switch (e) {
                                case "rogmars.asus.com":
                                    o = "api-rogmars.asus.com", !0;
                                    break;
                                case "rog.asus.com":
                                case "account.asus.com":
                                default:
                                    o = "api-rog.asus.com", !0;
                                    break;
                                case "shop.asus.com":
                                    o = "api-rog.asus.com", !1;
                                    break;
                                case "stage-rog.asus.com":
                                    o = "stage-api-rog.asus.com", !0;
                                    break;
                                case "rog.asus.com.cn":
                                    o = "api-rog.asus.com.cn", !0;
                                    break;
                                case "rog-bacchus.asus.com":
                                    o = "rogmars.asus.com", !0
                            }
                            e.match(c) && (o = "stage-api-rog.asus.com", !1), m()({
                                method: "get",
                                url: "https://".concat(o, "/recent-data/api/v4/Common/Translation?WebsiteCode=").concat(r, "&systemCode=").concat(n)
                            }).then((function(e) {
                                t.rogExportTranslation(e.data)
                            })).catch((function(t) {
                                console.error(t)
                            }))
                        }
                    }, e.prototype.footerLinkHandler = function(t) {
                        if ("undefined" != typeof window) return "rog.asus.com.cn" === window.location.host && t && t.indexOf("/cn") > -1 ? "".concat(encodeURI(window.location.origin)).concat(t.replace("/cn", "")) : t
                    }, e.prototype.crmHandler = function() {
                        var t = new RegExp(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/gim);
                        if (this.showWarn = !1, "" === this.crmValue) return this.showWarn = !0, void(this.warnText = this.translation.crm_email_required);
                        t.test(this.crmValue) ? (window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "register_non_member_edm",
                            event_category_DL: "non_member_edm",
                            event_action_DL: "clicked",
                            event_label_DL: "register/7A4FA00D-EBC2-4EC3-97E2-F995A0588A94/non_member_edm",
                            event_value_DL: ""
                        }), this.showWarn = !1, window.triggerSubscribeForm(this.crmValue)) : (this.showWarn = !0, this.warnText = this.translation.crm_valid_email)
                    }, e.prototype.gaDataLayer = function(t, e) {
                        if (window.dataLayer && (window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: e,
                                event_action_DL: "clicked",
                                event_label_DL: "footer/".concat(t),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: e,
                                    event_action_DL: "clicked",
                                    event_label_DL: "footer/".concat(t),
                                    event_value_DL: "0"
                                })
                            }), 200)), "rog.asus.com.cn" === window.location.host) {
                            if (!window._hmt) return;
                            window._hmt.push(["_trackEvent", e, "clicked", "footer/".concat(t)])
                        }
                    }, M([Object(d.Getter)("footerApi")], e.prototype, "footerApi", void 0), M([Object(d.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), M([Object(d.Getter)("bottomBanner")], e.prototype, "bottomBanner", void 0), M([Object(d.Getter)("translation")], e.prototype, "translation", void 0), M([Object(d.Getter)("getSpotLight")], e.prototype, "getSpotLight", void 0), M([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), M([Object(d.Getter)("getAIStatus")], e.prototype, "getAIStatus", void 0), M([Object(d.Action)("getFooterAPI")], e.prototype, "getFooterAPI", void 0), M([Object(d.Action)("getTranslation")], e.prototype, "getTranslation", void 0), M([Object(d.Mutation)(f.ROG_FOOTER)], e.prototype, "rogExportFooter", void 0), M([Object(d.Mutation)(f.ROG_TRANSLATION)], e.prototype, "rogExportTranslation", void 0), M([Object(l.Watch)("rogFooterMode", {
                        immediate: !0
                    })], e.prototype, "listenDeviceMode", null), e = M([Object(l.Component)({
                        components: {
                            Breadcrumb: C.a,
                            ButtonRed: y.a
                        }
                    })], e)
                }(l.Vue),
                S = I,
                L = o(394),
                A = o(25);
            var component = Object(A.a)(S, (function() {
                var t, e, n, c = this,
                    l = c._self._c;
                c._self._setupProxy;
                return l("footer", {
                    staticClass: "footer newFooter",
                    class: [c.$style.footerContainer],
                    attrs: {
                        dir: c.dirtype
                    }
                }, [c.chkFooterVal(c.footerApi) ? l("div", {
                    class: [c.$style.footerContent, (t = {}, Object(r.a)(t, c.$style.footerPCMode, c.isPCMode), Object(r.a)(t, c.$style.vnStyle, ("vn" === c.lang || "kr" === c.lang) && c.pageNameType), Object(r.a)(t, c.$style.krStyle, "kr" === c.lang && c.pageNameType), Object(r.a)(t, "jpFont", "jp" === c.lang), t)]
                }, [l("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !c.isHome,
                        expression: "!isHome"
                    }],
                    class: [c.$style.footerTopContent, Object(r.a)({}, c.$style.noBottomBanner, c.isProductHome && !c.isShowBottomBanner && c.spotLightStatus)]
                }, [l("Breadcrumb", {
                    class: [],
                    attrs: {
                        breadList: c.fullPath
                    }
                })], 1), c._v(" "), !c.footerApi.link && !c.footerApi.socialMedia || c.isAccount ? c._e() : l("div", {
                    class: [c.$style.siteMap, (e = {}, Object(r.a)(e, c.$style.isHome, c.isHome), Object(r.a)(e, c.$style.vnStyle, ("vn" === c.lang || "kr" === c.lang) && c.pageNameType), e)]
                }, [l("div", {
                    class: [c.$style.siteLeftContent, Object(r.a)({}, c.$style.noCRM, c.noCRM)]
                }, [c.footerApi.link ? l("ul", {
                    class: c.$style.footerLinks,
                    attrs: {
                        role: "list"
                    }
                }, c._l(c.footerApi.link, (function(t, e) {
                    return l("li", {
                        key: "footerLink".concat(e),
                        class: c.$style.footerLink,
                        attrs: {
                            role: "listitem"
                        }
                    }, [l("a", {
                        class: [c.$style.footerItemName, {
                            firstFooterItem: 0 === e,
                            jpFont: "jp" === c.lang
                        }],
                        attrs: {
                            id: "rogFooter".concat(0 === e ? "" : e),
                            href: c.footerLinkHandler(t.link),
                            target: t.linkTarget,
                            rel: "_blank" === t.linkTarget ? "noopener noreferrer" : ""
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), c.siteMapListClick(t)
                            }
                        }
                    }, [c._v(c._s(t.name))])])
                })), 0) : c._e(), c._v(" "), c.footerApi.socialMedia ? l("ul", {
                    class: [c.$style.socialList, Object(r.a)({}, c.$style.noCRM, c.noCRM)],
                    attrs: {
                        role: "tree",
                        "aria-label": "socialMedia"
                    }
                }, c._l(c.footerApi.socialMedia, (function(t, e) {
                    return l("li", {
                        key: "socialMedia".concat(e),
                        class: c.$style.socialLink,
                        attrs: {
                            role: "treeitem"
                        }
                    }, [l("a", {
                        class: c.$style.socialItem,
                        attrs: {
                            href: t.link
                        },
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), e.preventDefault(), c.openSocialMediaLink(t)
                            }
                        }
                    }, ["facebook" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "facebook",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M12 1C5.925 1 1 5.925 1 12c0 5.158 3.552 9.487 8.343 10.676V15.36H7.075V12h2.268V10.55c0-3.744 1.694-5.479 5.37-5.479.697 0 1.9.137 2.391.273v3.047c-.26-.027-.71-.04-1.27-.04-1.804 0-2.501.683-2.501 2.459V12h3.593l-.617 3.361h-2.976v7.558C18.78 22.261 23 17.624 23 11.999 23 5.926 18.075 1 12 1z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "twitter" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "twitter",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M17.751 3.46h3.067l-6.7 7.658L22 21.538h-6.172l-4.833-6.32-5.531 6.32h-3.07l7.167-8.19L2 3.46h6.328l4.37 5.777L17.75 3.46zm-1.076 16.243h1.7L7.404 5.199H5.58l11.094 14.504z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "instagram" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "instagram",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M12.172 4.3c2.672 0 2.989.012 4.04.059.977.043 1.504.207 1.856.344.464.18.8.398 1.148.746.352.351.567.684.746 1.148.137.352.301.883.344 1.856.047 1.055.059 1.372.059 4.04 0 2.673-.012 2.989-.059 4.04-.043.977-.207 1.504-.344 1.856-.18.465-.398.8-.746 1.149a3.076 3.076 0 01-1.148.746c-.352.137-.883.3-1.856.344-1.055.046-1.372.058-4.04.058-2.673 0-2.989-.012-4.04-.058-.977-.043-1.504-.207-1.856-.344-.465-.18-.8-.399-1.148-.746a3.076 3.076 0 01-.747-1.15c-.136-.35-.3-.882-.344-1.855-.046-1.055-.058-1.371-.058-4.04 0-2.672.012-2.989.058-4.04.043-.976.208-1.504.344-1.856.18-.464.399-.8.747-1.148a3.076 3.076 0 011.148-.746c.352-.137.883-.301 1.856-.344 1.051-.047 1.367-.059 4.04-.059zm0-1.801c-2.716 0-3.055.012-4.122.059-1.063.047-1.793.218-2.426.465A4.882 4.882 0 003.85 4.179a4.9 4.9 0 00-1.157 1.77c-.246.637-.418 1.363-.464 2.426-.047 1.07-.06 1.41-.06 4.126 0 2.715.013 3.055.06 4.122.046 1.063.218 1.793.464 2.426.258.66.598 1.22 1.157 1.774a4.89 4.89 0 001.77 1.152c.637.247 1.363.418 2.426.465 1.067.047 1.407.059 4.122.059s3.055-.012 4.122-.059c1.063-.047 1.793-.218 2.426-.465a4.89 4.89 0 001.77-1.152 4.89 4.89 0 001.153-1.77c.246-.637.418-1.364.465-2.426.046-1.067.058-1.407.058-4.122s-.012-3.055-.058-4.122c-.047-1.063-.22-1.793-.465-2.426a4.686 4.686 0 00-1.145-1.778 4.889 4.889 0 00-1.77-1.153c-.637-.246-1.364-.418-2.426-.464-1.07-.051-1.41-.063-4.126-.063z",
                            fill: "#B3B3B3"
                        }
                    }), l("path", {
                        attrs: {
                            d: "M12.172 7.363a5.139 5.139 0 00-5.138 5.138 5.139 5.139 0 105.138-5.138zm0 8.47a3.333 3.333 0 110-6.666 3.333 3.333 0 010 6.667zM18.712 7.16a1.2 1.2 0 11-2.4 0 1.2 1.2 0 012.4 0z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "youtube" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "youtube",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M22.78 8.339s-.214-1.517-.876-2.183c-.838-.877-1.774-.881-2.204-.933C16.623 5 12.004 5 12.004 5h-.008s-4.62 0-7.696.223c-.43.052-1.366.056-2.204.933-.662.666-.873 2.183-.873 2.183S1 10.122 1 11.9v1.667c0 1.779.22 3.562.22 3.562s.214 1.517.871 2.183c.838.877 1.938.846 2.428.94 1.762.169 7.481.22 7.481.22s4.623-.008 7.7-.228c.43-.051 1.366-.056 2.204-.932.662-.666.877-2.183.877-2.183S23 15.351 23 13.568v-1.667c0-1.78-.22-3.562-.22-3.562zM9.728 15.592V9.409l5.942 3.102-5.942 3.08z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "twitch" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "twitch",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M6.499 2L2.57 5.929V20.07h4.714V24l3.929-3.929h3.143L21.427 13V2H6.5zm13.357 10.214l-3.143 3.143H13.57l-2.75 2.75v-2.75H7.284V3.571h12.572v8.643z",
                            fill: "#B3B3B3"
                        }
                    }), l("path", {
                        attrs: {
                            d: "M17.499 6.321h-1.572v4.715H17.5V6.32zM13.177 6.321h-1.571v4.715h1.571V6.32z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "threads" === t.class ? l("svg", {
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "threads",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M17.258 11.197a7.545 7.545 0 00-.288-.131c-.17-3.13-1.88-4.92-4.75-4.939h-.04c-1.717 0-3.145.733-4.024 2.067l1.58 1.083c.656-.997 1.686-1.209 2.445-1.209h.027c.945.006 1.658.281 2.12.817.336.39.56.93.672 1.61a12.085 12.085 0 00-2.714-.13c-2.73.156-4.484 1.748-4.366 3.96.06 1.122.619 2.087 1.574 2.718.807.533 1.847.794 2.928.735 1.428-.079 2.547-.623 3.329-1.62.593-.755.968-1.735 1.134-2.97.68.41 1.184.95 1.463 1.6.473 1.104.501 2.918-.98 4.397-1.296 1.296-2.855 1.857-5.211 1.874-2.614-.02-4.59-.858-5.876-2.491-1.203-1.53-1.825-3.74-1.848-6.568.023-2.828.645-5.038 1.848-6.568 1.285-1.633 3.262-2.471 5.875-2.49 2.633.019 4.644.86 5.978 2.502.655.805 1.148 1.818 1.473 2.998l1.85-.493c-.394-1.453-1.014-2.705-1.858-3.744-1.71-2.104-4.213-3.183-7.436-3.205h-.013c-3.217.022-5.69 1.105-7.353 3.217-1.478 1.88-2.241 4.496-2.267 7.775v.016c.026 3.279.789 5.895 2.267 7.775C6.46 21.895 8.933 22.978 12.15 23h.013c2.86-.02 4.876-.769 6.537-2.428 2.173-2.17 2.107-4.892 1.391-6.562-.514-1.198-1.493-2.17-2.833-2.813zm-4.938 4.642c-1.196.068-2.439-.47-2.5-1.62-.046-.852.607-1.803 2.573-1.917.226-.013.447-.02.664-.02.714 0 1.383.07 1.99.203-.226 2.83-1.556 3.29-2.727 3.354z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "weibo" === t.class ? l("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 32 32",
                            "svg-inline": "",
                            alt: "weibo",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M22.9 4.7c-.7 0-1.3 0-2 .1-.6.2-.9.8-.8 1.3s.7.9 1.3.8c1.9-.5 3.7.1 5 1.5 1.3 1.4 1.6 3.5 1.2 5.1-.1.6.1 1.2.7 1.4.6.1 1.2-.1 1.4-.7.8-2.3.2-5.1-1.5-7.2-1.4-1.2-3.3-2.1-5.3-2.3zM13.3 8c-2 .1-4.5 1.6-7.1 4.2C3.5 14.8 2 17.6 2 19.9c0 4.5 5.8 7.3 11.7 7.3 7.6 0 12.7-4.4 12.7-7.9 0-2.1-1.9-3.4-3.4-3.7-.5-.1-.7-.1-.5-.7.5-1.2.6-2.1 0-2.8-.8-1.3-3.4-1.3-6.3 0 0 0-.8.5-.7-.2.5-1.4.5-2.7-.2-3.1-.4-.7-1.1-1-2-.8zm9.5.5c-.2 0-.6 0-.9.1-.6.1-.8.6-.7 1.2s.6.8 1.2.7c.6-.1 1.3 0 1.6.6.5.5.6 1.2.5 1.6-.1.5.1.9.6 1.2.5.1.9-.1 1.2-.6.5-1.2.1-2.6-.7-3.5-1-.9-1.8-1.3-2.8-1.3zm-8.4 6.2c3.8.1 7 2.1 7.2 4.8.2 3-3.1 5.8-7.8 6.3-4.5.5-8.6-1.6-9-4.8-.2-3 3.1-5.8 7.8-6.3h1.8zm-1.8 2.2C11 17 9.5 18 8.8 19.4c-.9 2 0 4.2 2.2 4.9 2.3.7 5-.5 5.9-2.6.9-2.1-.2-4.2-2.6-4.8h-1.7zm1.1 2.7h.1c.2.1.5.5.2.7-.1.2-.6.5-.8.2-.2-.1-.5-.5-.2-.7.3-.2.4-.2.7-.2zm-2.3.5c.1 0 .5 0 .6.1.7.2.9 1.2.6 1.9-.5.7-1.4 1.2-2.1.7-.7-.2-.9-1.1-.5-1.8.4-.6 1-.9 1.4-.9z"
                        }
                    })]) : c._e(), c._v(" "), "discord" === t.class ? l("svg", {
                        class: "discord icon",
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "discord",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M19.624 5.39a18.14 18.14 0 00-4.478-1.389.068.068 0 00-.072.034c-.194.344-.408.793-.558 1.146a16.748 16.748 0 00-5.03 0 11.59 11.59 0 00-.565-1.146.07.07 0 00-.072-.034c-1.572.27-3.075.745-4.478 1.389a.064.064 0 00-.03.025C1.49 9.676.708 13.833 1.091 17.937c.002.02.013.04.029.052a18.244 18.244 0 005.493 2.777.071.071 0 00.077-.025c.423-.578.8-1.188 1.124-1.828a.07.07 0 00-.038-.097 12.013 12.013 0 01-1.716-.818.07.07 0 01-.007-.117 9.37 9.37 0 00.34-.268.068.068 0 01.072-.01c3.6 1.645 7.498 1.645 11.056 0a.068.068 0 01.072.01c.11.09.226.181.342.268a.07.07 0 01-.006.117c-.548.32-1.118.59-1.717.817a.07.07 0 00-.038.098c.33.64.708 1.249 1.123 1.827a.07.07 0 00.078.026 18.183 18.183 0 005.502-2.777.071.071 0 00.028-.05c.459-4.746-.768-8.868-3.253-12.523a.055.055 0 00-.028-.026zM8.352 15.438c-1.084 0-1.977-.995-1.977-2.217 0-1.223.875-2.218 1.977-2.218 1.11 0 1.994 1.004 1.977 2.218 0 1.222-.876 2.217-1.977 2.217zm7.31 0c-1.084 0-1.977-.995-1.977-2.217 0-1.223.876-2.218 1.977-2.218 1.11 0 1.994 1.004 1.977 2.218 0 1.222-.867 2.217-1.977 2.217z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "whatsapp" === t.class ? l("svg", {
                        class: "whatsapp icon",
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "whatsapp",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M19.004 4.906A9.844 9.844 0 0011.994 2c-5.463 0-9.909 4.445-9.91 9.91a9.89 9.89 0 001.322 4.954L2 22l5.254-1.378a9.898 9.898 0 004.736 1.206h.004c5.462 0 9.908-4.446 9.91-9.91a9.85 9.85 0 00-2.9-7.012zm-7.01 15.248h-.003a8.226 8.226 0 01-4.193-1.148l-.3-.178-3.119.817.832-3.04-.195-.311a8.216 8.216 0 01-1.26-4.384c.002-4.541 3.697-8.236 8.241-8.236 2.2 0 4.268.858 5.824 2.416a8.187 8.187 0 012.41 5.827c-.002 4.542-3.697 8.237-8.237 8.237zm4.518-6.169c-.248-.124-1.465-.722-1.692-.805-.227-.083-.392-.124-.557.124-.165.248-.64.806-.784.97-.145.166-.29.187-.537.063-.247-.124-1.045-.386-1.991-1.23-.736-.656-1.233-1.467-1.378-1.715-.144-.248-.015-.382.109-.505.11-.111.247-.29.371-.434.124-.144.165-.248.248-.413.082-.165.041-.31-.02-.434-.063-.124-.558-1.342-.764-1.838-.201-.483-.406-.417-.557-.425-.145-.008-.31-.009-.475-.009a.91.91 0 00-.66.31c-.228.248-.867.847-.867 2.066 0 1.218.887 2.396 1.01 2.561.125.166 1.747 2.667 4.231 3.74a14.2 14.2 0 001.412.521c.593.19 1.133.163 1.56.099.475-.072 1.465-.6 1.67-1.178.207-.578.207-1.074.145-1.177-.062-.103-.227-.166-.474-.29z",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), "vksocial" === t.class ? l("svg", {
                        class: "vk social icon",
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 80 80",
                            "svg-inline": "",
                            alt: "vk social",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M79.021 40c0 21.579-17.47 39.073-39.021 39.073C18.45 79.073.979 61.577.979 40 .979 18.421 18.452.927 40 .927 61.55.927 79.021 18.423 79.021 40z",
                            fill: "none",
                            stroke: "gray",
                            "stroke-width": "2",
                            "stroke-miterlimit": "10"
                        }
                    }), l("path", {
                        attrs: {
                            d: "M66.031 25.993c.377-1.27 0-2.198-1.81-2.198h-5.97c-1.51 0-2.214.804-2.593 1.69 0 0-3.034 7.397-7.33 12.206-1.394 1.385-2.022 1.833-2.786 1.833-.38 0-.948-.448-.948-1.708V25.993c0-1.52-.415-2.198-1.69-2.198h-9.378c-.946 0-1.519.71-1.519 1.376 0 1.438 2.147 1.766 2.372 5.811v8.79c0 1.934-.348 2.282-1.106 2.282-2.025 0-6.95-7.43-9.866-15.935-.576-1.655-1.145-2.324-2.674-2.324h-5.968c-1.705 0-2.047.804-2.047 1.69 0 1.58 2.023 9.42 9.423 19.798 4.932 7.08 11.878 10.922 18.208 10.922 3.79 0 4.261-.855 4.261-2.322v-5.36c0-1.705.365-2.057 1.562-2.057.887 0 2.404.457 5.951 3.87 4.047 4.052 4.71 5.869 6.982 5.869h5.968c1.707 0 2.56-.855 2.074-2.536-.537-1.682-2.473-4.106-5.038-6.99-1.395-1.643-3.486-3.42-4.112-4.307-.88-1.14-.631-1.645 0-2.656 0 0 7.28-10.251 8.034-13.723z",
                            fill: "gray"
                        }
                    })]) : c._e(), c._v(" "), "tiktok" === t.class ? l("svg", {
                        class: "tiktok icon",
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "tiktok",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            d: "M21.55 6.661c0-.096 0-.096-.11-.096-.246 0-.493-.027-.74-.062-.892-.13-3.787-1.565-4.274-3.913-.007-.048-.116-.632-.116-.879 0-.11 0-.11-.116-.11h-3.476c-.225 0-.195-.027-.195.192v13.945c0 .171-.008.343-.037.515-.174.899-.66 1.6-1.48 2.087-.711.419-1.488.535-2.315.384-.26-.048-.5-.144-.747-.233-.022-.014-.036-.035-.058-.048-.08-.062-.174-.117-.261-.179-1.052-.686-1.546-1.64-1.394-2.835.153-1.209.893-2.033 2.105-2.458.363-.124.74-.179 1.132-.158.246.014.493.041.74.11.087.02.13-.007.13-.09v-.089c0-.837-.036-2.657-.036-2.664 0-.24 0-.48.007-.72 0-.07-.036-.083-.094-.09a7.63 7.63 0 00-1.371-.027 7.128 7.128 0 00-1.85.37 6.955 6.955 0 00-2.519 1.497 6.468 6.468 0 00-1.465 1.991 6.302 6.302 0 00-.595 2.26c-.022.342-.022.679.014 1.022.044.474.138.934.29 1.387.436 1.297 1.227 2.355 2.351 3.2.117.082.225.178.363.233l.174.144c.182.13.378.24.58.336 1.256.59 2.584.831 3.984.666 1.815-.212 3.324-.968 4.514-2.28 1.117-1.235 1.661-2.677 1.676-4.297.014-2.314 0-4.627.007-6.941 0-.055-.036-.13.03-.165.05-.02.1.041.144.069a9.424 9.424 0 002.954 1.208c.616.137 1.24.213 1.879.213.203 0 .225-.007.225-.2-.007-.83-.05-3.075-.05-3.295z",
                            fill: "#999"
                        }
                    })]) : c._e(), c._v(" "), "telegram" === t.class ? l("svg", {
                        class: "telegram icon",
                        attrs: {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            "svg-inline": "",
                            alt: "telegram",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [l("path", {
                        attrs: {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M2.516 10.847c5.906-2.573 9.843-4.269 11.812-5.088C19.953 3.42 21.116 3.013 21.884 3c.28-.006.555.077.785.236.162.14.265.337.288.55.041.264.053.532.035.798-.305 3.202-1.623 10.975-2.296 14.561-.284 1.518-.844 2.027-1.384 2.078-1.177.108-2.07-.778-3.208-1.524-1.784-1.173-2.79-1.9-4.52-3.04-2-1.319-.704-2.043.436-3.226.299-.315 5.48-5.028 5.58-5.452a.413.413 0 00-.093-.358.472.472 0 00-.42-.041c-.179.04-3.027 1.923-8.544 5.647-.63.492-1.4.776-2.2.81a14.446 14.446 0 01-3.142-.745c-1.27-.41-2.28-.628-2.196-1.329.046-.364.548-.737 1.507-1.118",
                            fill: "#B3B3B3"
                        }
                    })]) : c._e(), c._v(" "), l("span", {
                        staticClass: "sr-only"
                    }, [c._v(c._s(t.class))])])])
                })), 0) : c._e()]), c._v(" "), c.noCRM ? c._e() : l("div", {
                    class: c.$style.crmWrapper
                }, [l("label", {
                    class: [{
                        jpFont: "jp" === c.lang
                    }],
                    attrs: {
                        for: ""
                    }
                }, [c._v(c._s(c.translation.crm_title))]), c._v(" "), l("div", {
                    class: c.$style.crmInputWrapper
                }, [l("span", {
                    ref: "measureSpan",
                    class: c.$style.measureSpan
                }, [c._v("\n            " + c._s(c.translation.crm_emailplaceholder) + "\n          ")]), c._v(" "), l("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: c.crmValue,
                        expression: "crmValue"
                    }],
                    class: [c.$style.crmInput, (n = {}, Object(r.a)(n, c.$style.warn, c.showWarn), Object(r.a)(n, "jpFont", "jp" === c.lang), n)],
                    attrs: {
                        type: "email",
                        placeholder: c.translation.crm_emailplaceholder
                    },
                    domProps: {
                        value: c.crmValue
                    },
                    on: {
                        input: function(t) {
                            t.target.composing || (c.crmValue = t.target.value)
                        }
                    }
                }), c._v(" "), l("div", {
                    class: c.$style.crmButton
                }, [l("ButtonRed", {
                    attrs: {
                        buttonData: c.crmButtonData,
                        isMaxWidth: !0,
                        isCrmButton: !0
                    },
                    on: {
                        click: c.crmHandler
                    }
                })], 1)]), c._v(" "), l("p", {
                    class: [c.$style.warnText, Object(r.a)({}, c.$style.show, c.showWarn)]
                }, [l("svg", {
                    class: "icon",
                    attrs: {
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "warn",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [l("path", {
                    attrs: {
                        d: "M6 0a6 6 0 110 12A6 6 0 016 0z",
                        fill: "#000"
                    }
                }), l("path", {
                    attrs: {
                        d: "M6 0a6 6 0 106 6 6.018 6.018 0 00-6-6zm.692 9H5.308V7.846h1.384V9zm0-2.538H5.308V2.769h1.384v3.693z",
                        fill: "#FA5C00"
                    }
                })]), c._v("\n\n        " + c._s(c.warnText))])])]), c._v(" "), l("div", {
                    class: c.$style.footerLine
                }, [l("div", {
                    class: c.$style.left
                }), c._v(" "), l("div", {
                    class: c.$style.right
                })]), c._v(" "), "vn" !== c.lang && "kr" !== c.lang && "tw" !== c.lang || "" === c.translation.Footer_Legal_Info ? c._e() : l("div", {
                    class: c.$style.legalInfoContent
                }, [l("p", {
                    domProps: {
                        innerHTML: c._s(c.translation.Footer_Legal_Info)
                    }
                }), c._v(" "), "vn" === c.lang ? l("a", {
                    attrs: {
                        href: "http://online.gov.vn/Home/WebDetails/115530"
                    }
                }, [l("img", {
                    class: c.$style.legalInfoContentIcon,
                    attrs: {
                        src: o(650),
                        alt: "trademark"
                    }
                })]) : c._e()]), c._v(" "), c.footerApi.region || c.footerApi.copyright || c.rogCategoryStatus ? l("div", {
                    class: [c.$style.privateContent, Object(r.a)({}, c.$style.cnSite, "cn" === c.lang)]
                }, [l("div", {
                    class: c.$style.footerLeftBottomContent
                }, [c.footerApi.region && "cn" !== c.lang && "ru" !== c.lang && "mm" !== c.lang ? l("button", {
                    class: [c.$style.language, c.$style.footerItemName, c.$style.footerRegionButton, {
                        jpFont: "jp" === c.lang
                    }],
                    attrs: {
                        tabindex: "0",
                        type: "button",
                        "aria-label": "".concat(c.translation.Aria_entry).concat(c.footerApi.region.name)
                    },
                    on: {
                        click: function(t) {
                            return t.stopPropagation(), t.preventDefault(), c.footerRegionClick(c.footerApi.region)
                        }
                    }
                }, [l("svg", {
                    class: c.$style.languageIcon,
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "language change",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [l("path", {
                    attrs: {
                        d: "M16 0a16 16 0 1016 16A16 16 0 0016 0zm14.28 16h-5.85a29.25 29.25 0 00-.65-6.25 18.25 18.25 0 004.08-1.7 14.21 14.21 0 012.42 8zm-21 0a27.59 27.59 0 01.61-5.83 29.15 29.15 0 005.24.61V16H9.29zm13.42 0h-5.84v-5.22a29.15 29.15 0 005.24-.61 27.59 27.59 0 01.61 5.83zm-7.56 14.14c-1.67-.48-3.17-2.32-4.23-5a26.22 26.22 0 014.23-.45zm1.72-5.42a26.22 26.22 0 014.23.45c-1.06 2.65-2.56 4.49-4.23 5zm0-1.72v-5.25h5.79a25.52 25.52 0 01-1 5.76 29.41 29.41 0 00-4.79-.51zm0-13.94v-7.2c2 .57 3.75 3.11 4.81 6.64a27.42 27.42 0 01-4.81.56zm-1.72-7.2v7.2a27.42 27.42 0 01-4.81-.56c1.06-3.5 2.81-6.07 4.81-6.64zm0 15.89V23a29.41 29.41 0 00-4.8.51 25.52 25.52 0 01-1-5.76zm-6.5 6.15a20.36 20.36 0 00-3.53 1.31 14.26 14.26 0 01-3.27-7.46h5.78a27.14 27.14 0 001.02 6.15zm.56 1.64a14.1 14.1 0 002.25 4 14.19 14.19 0 01-5.08-3 19.55 19.55 0 012.83-1zm13.6 0a19.55 19.55 0 012.83 1 14.19 14.19 0 01-5.08 3 14.1 14.1 0 002.25-4zm.56-1.64a27.14 27.14 0 001-6.15h5.78a14.26 14.26 0 01-3.27 7.46 20.36 20.36 0 00-3.51-1.31zM26.8 6.68a17.25 17.25 0 01-3.45 1.4 15.46 15.46 0 00-2.8-5.6 14.3 14.3 0 016.25 4.2zm-15.35-4.2a15.46 15.46 0 00-2.8 5.6 17.25 17.25 0 01-3.45-1.4 14.3 14.3 0 016.25-4.2zM4.14 8.05a18.25 18.25 0 004.08 1.7A29.25 29.25 0 007.57 16H1.72a14.21 14.21 0 012.42-7.95z"
                    }
                })]), c._v(" "), l("p", [c._v(c._s(c.footerApi.region.name))])]) : c._e()]), c._v(" "), c.translation.copyRight || c.rogCategoryStatus ? l("div", {
                    class: c.$style.personalContent
                }, ["pe" === c.lang ? l("a", {
                    class: c.$style.reclamacioneLink,
                    attrs: {
                        href: "https://pe.store.asus.com/libro-de-reclamaciones/"
                    }
                }, [l("svg", {
                    class: c.$style.reclamacione,
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "185",
                        height: "14.001",
                        viewBox: "0 0 185 14.001",
                        "svg-inline": "",
                        alt: "icon-reclamaciones",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [l("defs", [l("clipPath", {
                    attrs: {
                        id: "a"
                    }
                }, [l("path", {
                    attrs: {
                        "data-name": "矩形 581",
                        fill: "none",
                        d: "M0 0h185v14.001H0z"
                    }
                })])]), l("g", {
                    attrs: {
                        "data-name": "组 1262"
                    }
                }, [l("g", {
                    attrs: {
                        "data-name": "组 1261",
                        "clip-path": "url(#a)",
                        fill: "#b3b3b3"
                    }
                }, [l("path", {
                    attrs: {
                        "data-name": "联合 33",
                        d: "M1.656 10.17V.1c3.37-.612 6.74 1.724 7.926 3.831V14C8.4 11.895 5.026 9.559 1.656 10.17zM0 14V3.388h.874v7.76l.915-.167a5.578 5.578 0 01.98-.086 7.717 7.717 0 015.87 3.1zM10.419 3.93c1.186-2.107 4.556-4.442 7.926-3.831v10.069c-3.37-.611-6.74 1.724-7.926 3.83zm.943 10.065a7.714 7.714 0 015.87-3.1 5.58 5.58 0 01.98.086l.914.167v-7.76h.875V14z"
                    }
                }), l("path", {
                    attrs: {
                        "data-name": "联合 34",
                        d: "M178.05 11.701v-2.3a4.729 4.729 0 001.166.624 3.417 3.417 0 001.189.238 1.184 1.184 0 00.645-.149.49.49 0 00.228-.437.586.586 0 00-.113-.36 1.126 1.126 0 00-.347-.291 6.423 6.423 0 00-.858-.368 2.659 2.659 0 01-2.029-2.521 2.355 2.355 0 01.926-1.948 3.9 3.9 0 012.485-.73 8.706 8.706 0 011.48.123c.202.035.481.1.846.2v2.137a4.324 4.324 0 00-2.086-.58 1.285 1.285 0 00-.679.158.484.484 0 00-.258.434.545.545 0 00.207.436 3.909 3.909 0 00.869.449 4.833 4.833 0 011.85 1.154 2.208 2.208 0 01.541 1.489 2.425 2.425 0 01-.447 1.459 2.66 2.66 0 01-1.257.926 5.539 5.539 0 01-1.944.3 6.349 6.349 0 01-2.414-.443zm-23.739-.091a3.785 3.785 0 01-1.51-1.507 4.44 4.44 0 01-.539-2.193 4.855 4.855 0 01.545-2.309 3.871 3.871 0 011.529-1.585 4.456 4.456 0 012.238-.559 4.323 4.323 0 012.159.536 3.657 3.657 0 011.471 1.529 4.8 4.8 0 01.518 2.253 4.658 4.658 0 01-.544 2.264 3.89 3.89 0 01-1.523 1.553 4.368 4.368 0 01-2.192.553 4.37 4.37 0 01-2.153-.535zm1.063-5.423a2.708 2.708 0 00-.422 1.624 2.68 2.68 0 00.418 1.6 1.34 1.34 0 001.14.574 1.3 1.3 0 00.791-.257 1.668 1.668 0 00.545-.738 3.059 3.059 0 00.193-1.144 2.915 2.915 0 00-.4-1.633 1.245 1.245 0 00-1.09-.6 1.379 1.379 0 00-1.176.574zm-12.855 5.446a3.5 3.5 0 01-1.487-1.459 4.516 4.516 0 01-.511-2.182 4.8 4.8 0 01.573-2.367 3.974 3.974 0 011.624-1.6 5.005 5.005 0 012.414-.565 8.384 8.384 0 012.109.263v2.338a2.982 2.982 0 00-.837-.329 4.232 4.232 0 00-.985-.116 2.2 2.2 0 00-1.626.591 2.165 2.165 0 00-.595 1.605 2.127 2.127 0 00.595 1.59 2.171 2.171 0 001.591.583 4.114 4.114 0 001.857-.469v2.256a7.115 7.115 0 01-2.407.375 4.9 4.9 0 01-2.316-.514zm-43.893 0a3.506 3.506 0 01-1.487-1.459 4.524 4.524 0 01-.511-2.182 4.8 4.8 0 01.573-2.367 3.974 3.974 0 011.624-1.6 5.005 5.005 0 012.414-.565 8.384 8.384 0 012.109.263v2.338a2.982 2.982 0 00-.837-.329 4.232 4.232 0 00-.985-.116 2.2 2.2 0 00-1.626.591 2.165 2.165 0 00-.595 1.605 2.127 2.127 0 00.595 1.59 2.172 2.172 0 001.591.583 4.114 4.114 0 001.857-.469v2.256a7.114 7.114 0 01-2.407.375 4.893 4.893 0 01-2.315-.514zm-46.069-.67a4.323 4.323 0 01-1.094-3.064 4.583 4.583 0 011.113-3.234A3.908 3.908 0 0155.6 3.458a3.694 3.694 0 012.85 1.171 4.342 4.342 0 011.081 3.065 4.6 4.6 0 01-1.107 3.252 3.842 3.842 0 01-2.959 1.2 3.776 3.776 0 01-2.909-1.184zm1.1-5.419a3.407 3.407 0 00-.723 2.267 3.436 3.436 0 00.7 2.255 2.265 2.265 0 001.84.855 2.376 2.376 0 001.9-.813 3.4 3.4 0 00.7-2.28 3.562 3.562 0 00-.676-2.325 2.292 2.292 0 00-1.868-.821 2.337 2.337 0 00-1.878.861zm118.005 6.457v-8.4h5.232v1.981h-2.7v1.225h2.537v1.98h-2.537v1.236h2.9v1.981zm-3.874 0l-2.966-4.054a9.755 9.755 0 01-.574-.867h-.022c.022.414.035.879.035 1.394v3.528h-2.344v-8.4h2.39l2.841 3.856.129.182c.051.07.1.142.153.216l.143.217a1.4 1.4 0 01.1.188h.023a7.793 7.793 0 01-.035-.891V3.602h2.344v8.4zm-19.237 0v-8.4h2.532v8.4zm-11.291 0l-.369-1.547h-2.508l-.4 1.547h-2.736l2.894-8.4h3.142l2.723 8.4zm-1.734-6.112q-.07.323-.709 2.766h1.606l-.585-2.285a7 7 0 01-.17-.943h-.059a3.891 3.891 0 01-.087.461zm-7.681 6.112v-4.6q0-.652.041-1.43l.018-.388h-.069q-.188.992-.287 1.373l-1.238 5.05h-2.379l-1.3-4.991c-.035-.125-.126-.6-.275-1.431h-.07q.082 1.971.083 2.462v3.961h-2.221v-8.4h3.791l1.154 4.565a5.316 5.316 0 01.109.572c.046.287.073.509.085.665h.035c.043-.355.111-.776.205-1.26l1.077-4.542h3.733v8.4zm-11.427 0l-.369-1.547h-2.507l-.4 1.547h-2.736l2.894-8.4h3.141l2.724 8.4zm-1.734-6.112q-.07.323-.708 2.766h1.6l-.585-2.285a7.155 7.155 0 01-.17-.943h-.058a3.988 3.988 0 01-.083.461zm-10.025 6.112v-8.4h2.532v6.422h2.894v1.98zm-14.179 0v-8.4h5.232v1.981h-2.7v1.225h2.537v1.98h-2.537v1.236h2.9v1.981zm-3.826 0l-.627-1.811a2.24 2.24 0 00-.471-.838.86.86 0 00-.63-.3h-.1v2.953h-2.532v-8.4h3.363a4.668 4.668 0 012.6.578 1.958 1.958 0 01.841 1.732 2.192 2.192 0 01-.489 1.453 2.792 2.792 0 01-1.456.85v.022a2.041 2.041 0 01.887.534 3.284 3.284 0 01.635 1.1l.826 2.138zm-1.828-4.729h.457a1.163 1.163 0 00.82-.287.94.94 0 00.31-.721.882.882 0 00-.257-.669 1.144 1.144 0 00-.809-.246h-.521zm-11.843 4.729v-8.4h4.531v1.184h-3.136v2.379h2.889v1.178h-2.889v2.484H77.7v1.178zm-8.607 0v-8.4h2.426q4.645 0 4.646 4.1a4.031 4.031 0 01-1.289 3.126 4.921 4.921 0 01-3.457 1.18zm1.389-1.177h1.113a3.115 3.115 0 002.288-.809 3.071 3.071 0 00.817-2.284q0-2.948-3.053-2.947h-1.166zm-16.248 1.177l-1.343-2.25a4.564 4.564 0 00-.355-.531 2.156 2.156 0 00-.351-.36 1.194 1.194 0 00-.39-.205 1.648 1.648 0 00-.474-.065h-.567v3.411h-1.39v-8.4h2.767a4 4 0 011.089.141 2.533 2.533 0 01.868.425 1.962 1.962 0 01.577.709 2.232 2.232 0 01.208.993 2.42 2.42 0 01-.132.817 2.083 2.083 0 01-.375.662 2.269 2.269 0 01-.586.495 2.9 2.9 0 01-.77.317v.023a2.161 2.161 0 01.4.283c.114.1.221.211.323.32a3.767 3.767 0 01.3.372c.1.138.21.3.33.483l1.5 2.362zm-3.48-4.544h1.159a1.719 1.719 0 00.595-.1 1.343 1.343 0 00.473-.286 1.3 1.3 0 00.31-.457 1.563 1.563 0 00.113-.6 1.2 1.2 0 00-.382-.943 1.591 1.591 0 00-1.1-.34h-1.168zm-8.636 4.54v-8.4h2.666a3.149 3.149 0 011.93.534 1.659 1.659 0 01.712 1.389 1.978 1.978 0 01-.4 1.242 2.178 2.178 0 01-1.119.75v.024a2.19 2.19 0 011.385.641 1.958 1.958 0 01.519 1.41 2.121 2.121 0 01-.849 1.746 3.372 3.372 0 01-2.146.668zm1.388-1.114h1.19a1.808 1.808 0 001.2-.36 1.229 1.229 0 00.425-.993q0-1.307-1.811-1.307h-1.008zm0-3.779h.9a1.727 1.727 0 001.139-.343 1.185 1.185 0 00.414-.969q0-1.078-1.442-1.079h-1.014zm-4.891 4.893v-8.4h1.435v8.4zm-5.861 0v-8.4h1.4v7.225h3.258v1.177z"
                    }
                })])])])]) : c._e(), c._v(" "), c.rogCategoryStatus ? l("ul", {
                    class: c.$style.termsContent,
                    attrs: {
                        role: "list"
                    }
                }, ["jp" === c.lang ? l("li", {
                    attrs: {
                        role: "listitem"
                    }
                }, [l("a", {
                    class: [c.$style.footerItemName, c.$style.footerItemLink, {
                        jpFont: "jp" === c.lang
                    }],
                    attrs: {
                        href: "https://store.asus.com/jp/commerce-disclosure-page"
                    }
                }, [c._v("特定商取引法に基づく表記")])]) : c._e(), c._v(" "), c._l(c.footerApi.termsOfUseData, (function(t, e) {
                    return l("li", {
                        key: "category".concat(e),
                        attrs: {
                            role: "listitem"
                        }
                    }, [l("a", {
                        class: [c.$style.footerItemName, c.$style.footerItemLink, {
                            jpFont: "jp" === c.lang
                        }],
                        attrs: {
                            href: t.link
                        },
                        on: {
                            click: function(e) {
                                return e.stopPropagation(), e.preventDefault(), c.categoryClick(t)
                            }
                        }
                    }, [c._v(c._s(t.name))])])
                }))], 2) : c._e(), c._v(" "), l("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: c.isShowSettingCookie,
                        expression: "isShowSettingCookie"
                    }],
                    class: c.$style.cookieSettingButton,
                    on: {
                        click: c.showCookieSettingHandler
                    }
                }, [c._v("\n          " + c._s(c.translation.Footer_CookieSettings) + "\n        ")]), c._v(" "), c.translation.Footer_CopyRight ? l("p", {
                    class: [c.$style.copyRightContent, c.$style.footerItemName, {
                        jpFont: "jp" === c.lang
                    }],
                    domProps: {
                        innerHTML: c._s(c.translation.Footer_CopyRight)
                    }
                }) : c._e()]) : c._e()]) : c._e(), c._v(" "), l("ClientOnly", [c.isPCMode ? l("svg", {
                    class: c.$style.footerLogo,
                    attrs: {
                        width: "32",
                        height: "18",
                        viewBox: "0 0 32 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [l("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M12.143 11.094c-2.552 1.888-2.936 2.676-2.627 3.273a20.501 20.501 0 002.58 3.2v.023a11.358 11.358 0 01-4.046-3.097c-.935-1.264-3.596-5.474-3.596-5.474.297.142.634.314.992.495 1.573.799 3.54 1.796 4.173 1.443 5.736-5.593 8.835-8.558 10.954-9.222C26.517-.139 30.677.54 30.677.54 23.67 2.194 16.384 7.825 13.19 10.294c-.425.328-.777.6-1.046.8zm-.445 3.575a8.9 8.9 0 01-1.158-.645s8.482-6.043 13.5-8.429A24.683 24.683 0 0132 3.292a2.404 2.404 0 01-.949 1.622h-.047c-11.95 4.874-16.992 8.657-17.395 8.966 0 .007 4.862 1.918 7.59 1.37 2.727-.547 4.824-5.469 4.824-5.469l1.758-.54-9.578 2.893.525-.266.033-.011c.797-.409 2.504-1.253 5.313-2.567 3.348-1.575 6.669-2.893 6.669-2.893-1.11 3.083-4.653 9.767-7.789 10.791-1.167.375-7.158-.72-11.256-2.519zm7.03-2.8l.009-.005-.142.052.133-.048zm9.975-6.217zM1.812 11.596A17.537 17.537 0 010 7.996s4.478 4.178 6.662 5.703l-.059-.028c-.484-.112-3.928-.956-4.791-2.075z",
                        fill: "#B3B3B3"
                    }
                })]) : c._e()])], 1) : c._e()])
            }), [], !1, (function(t) {
                this.$style = L.default.locals || L.default
            }), null, null);
            e.a = component.exports
        }
    }
]);