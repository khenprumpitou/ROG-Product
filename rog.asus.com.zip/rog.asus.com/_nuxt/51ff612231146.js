(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [2], {
        1033: function(t, e, o) {
            "use strict";
            var n = o(764),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1036: function(t, e, o) {
            "use strict";
            var n = o(767),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1038: function(t, e, o) {
            "use strict";
            var n = o(769),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1039: function(t, e, o) {
            "use strict";
            var n = o(770),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1075: function(t, e, o) {
            "use strict";
            var n = o(802),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1190: function(t, e, o) {
            "use strict";
            var n = o(862),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        1212: function(t, e, o) {
            "use strict";
            var n = o(881),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        685: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = (o(26), o(9)),
                c = (o(54), o(41), o(10), o(60), o(18), o(29), o(3)),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), Object.defineProperty(e.prototype, "buttonLink", {
                        get: function() {
                            return this.buttonData.link ? this.buttonData.link : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.callEvent = function(t) {
                        var e = this.buttonData.disabled ? "disabled" : "default";
                        "disabled" === e && t.preventDefault(), this.updateDownButton ? this.$emit("click", this.buttonData.link) : (this.isCompare || (this.isWTB && !this.isWhereToBuy && (this.isComparePage ? window.location.assign(this.buttonLink) : this.$router.push({
                            path: this.buttonLink.replace(encodeURI(window.location.origin), "")
                        })), this.isModelLink || this.isWTB || this.isLearnMore || this.buttonLink && this.$router.push({
                            path: this.buttonLink
                        }), this.isModelLink && window.location.assign(this.buttonLink)), this.$emit("click", e))
                    }, m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isBuy", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isModelLink", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isWTB", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isLogOut", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isWhereToBuy", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isSpecButton", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isProductResultWhereToBuyButton", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "autoWidth", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "bgShadow", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isCompare", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isComparePage", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isMaxWidth", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isFilter", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "updateDownButton", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isLearnMore", void 0), m([Object(c.Prop)({
                        default: 0
                    })], e.prototype, "tabindexValue", void 0), m([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "otherName", void 0), m([Object(c.Prop)()], e.prototype, "buttonData", void 0), e = m([c.Component], e)
                }(c.Vue),
                f = h,
                _ = o(1033),
                y = o(25);
            var component = Object(y.a)(f, (function() {
                var t, e, o, n = this,
                    l = n._self._c;
                n._self._setupProxy;
                return l("div", {
                    class: [n.$style.borderRedButton, (t = {}, Object(r.a)(t, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(t, n.$style.isProductResultWhereToBuyButton, n.isProductResultWhereToBuyButton), Object(r.a)(t, n.$style.isLearnMore, n.isLearnMore), t)]
                }, ["" !== n.buttonLink ? [l("a", {
                    staticClass: "btn",
                    class: [n.$style.btnBorderRed, n.$style.isRed, (e = {}, Object(r.a)(e, n.$style.disabled, n.buttonData.disabled), Object(r.a)(e, n.$style.logOut, n.isLogOut), Object(r.a)(e, n.$style.buyBtn, n.isBuy), Object(r.a)(e, n.$style.compareButton, n.isCompare), Object(r.a)(e, n.$style.maxWidth, n.isMaxWidth), Object(r.a)(e, n.$style.isFilter, n.isFilter), Object(r.a)(e, n.$style.updateDownButton, n.updateDownButton), Object(r.a)(e, n.$style.whereToBuyButton, n.isWhereToBuy), Object(r.a)(e, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(e, n.$style.isProductResultWhereToBuyButton, n.isProductResultWhereToBuyButton), Object(r.a)(e, n.$style.autoWidth, n.autoWidth), Object(r.a)(e, n.$style.bgShadow, n.bgShadow), Object(r.a)(e, n.$style.isLearnMore, n.isLearnMore), e)],
                    attrs: {
                        href: n.buttonLink,
                        "aria-label": n.buttonData.ariaLabel
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), n.callEvent.apply(null, arguments)
                        }
                    }
                }, [l("div", {
                    class: n.$style.inner
                }, [n.buttonData && n.buttonData.name ? l("span", {
                    staticClass: "buttonName",
                    class: [Object(r.a)({}, n.$style.smallFont, n.buttonData.name.length > 15)]
                }, [n._v(n._s(n.buttonData.name))]) : n._e(), n._v(" "), "" !== n.otherName ? l("span", {
                    style: "width:0;height:0;opacity:0;"
                }, [n._v(n._s(n.otherName))]) : n._e()]), n._v(" "), l("div", {
                    class: n.$style.hoverColor
                })])] : [l("div", {
                    staticClass: "btn",
                    class: [n.$style.btnBorderRed, n.$style.isRed, (o = {}, Object(r.a)(o, n.$style.disabled, n.buttonData.disabled), Object(r.a)(o, n.$style.logOut, n.isLogOut), Object(r.a)(o, n.$style.buyBtn, n.isBuy), Object(r.a)(o, n.$style.compareButton, n.isCompare), Object(r.a)(o, n.$style.maxWidth, n.isMaxWidth), Object(r.a)(o, n.$style.isFilter, n.isFilter), Object(r.a)(o, n.$style.updateDownButton, n.updateDownButton), Object(r.a)(o, n.$style.whereToBuyButton, n.isWhereToBuy), Object(r.a)(o, n.$style.isSpecButton, n.isSpecButton), Object(r.a)(o, n.$style.isProductResultWhereToBuyButton, n.isProductResultWhereToBuyButton), Object(r.a)(o, n.$style.autoWidth, n.autoWidth), Object(r.a)(o, n.$style.bgShadow, n.bgShadow), Object(r.a)(o, n.$style.isLearnMore, n.isLearnMore), o)],
                    attrs: {
                        role: n.buttonData.role ? n.buttonData.role : "button",
                        tabindex: 0,
                        "aria-label": n.buttonData.ariaLabel
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && n._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : n.callEvent.apply(null, arguments)
                        },
                        click: function(t) {
                            return t.preventDefault(), n.callEvent.apply(null, arguments)
                        }
                    }
                }, [l("div", {
                    class: n.$style.inner
                }, [l("span", [n._v(n._s(n.buttonData.name))])]), n._v(" "), l("div", {
                    class: n.$style.hoverColor
                })])]], 2)
            }), [], !1, (function(t) {
                this.$style = _.default.locals || _.default
            }), null, null);
            e.a = component.exports
        },
        687: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(516), o(20), o(3)),
                d = o(7),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.sitePath = "", e
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? (this.routeInfo.websitePath, this.routeInfo.websitePath) : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "toLocaleLowerCaseMoreLink", {
                        get: function() {
                            return "" !== this.moreLink ? this.moreLink.toLocaleLowerCase() : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.beforeMount = function() {
                        this.sitePath = encodeURI(window.location.pathname)
                    }, e.prototype.moreAction = function(t, e) {
                        this.isRouterPush ? t.endsWith("/") ? this.$router.push({
                            path: "".concat(t).concat(e.toLowerCase(), "/all")
                        }) : this.$router.push({
                            path: "".concat(t, "/").concat(e.toLowerCase(), "/all")
                        }) : this.$emit("click")
                    }, e.prototype.unFocusHandler = function() {
                        this.$emit("unfocus")
                    }, h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(c.Prop)()], e.prototype, "moreName", void 0), h([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "moreLink", void 0), h([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "morePath", void 0), h([Object(c.Prop)({
                        default: !0
                    })], e.prototype, "isRouterPush", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isMessageDisplayAll", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isLargerFontSize", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isSpotLightButton", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isArticleLastButton", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isBlackBackground", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isWhiteText", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isL2", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isArticle", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isActiveMoreButton", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isGoToSeries", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isHotProduct", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isArticleRecommend", void 0), h([Object(c.Prop)({
                        default: "click link more"
                    })], e.prototype, "ariaLabel", void 0), h([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "otherName", void 0), e = h([c.Component], e)
                }(c.Vue),
                _ = f,
                y = o(973),
                v = o(25);
            var component = Object(v.a)(_, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return e.moreName ? o("a", {
                    class: [e.$style.moreButton, (t = {}, Object(r.a)(t, e.$style.useMessageButton, e.isMessageDisplayAll), Object(r.a)(t, e.$style.largerFontSize, e.isLargerFontSize), Object(r.a)(t, e.$style.spotLightButton, e.isSpotLightButton), Object(r.a)(t, e.$style.isBlackBackground, e.isBlackBackground), Object(r.a)(t, e.$style.isWhiteText, e.isWhiteText), Object(r.a)(t, e.$style.hotProductLearnMore, e.isL2), Object(r.a)(t, e.$style.articleRelated, e.isArticle), Object(r.a)(t, e.$style.isActiveMoreButton, e.isActiveMoreButton), Object(r.a)(t, e.$style.isGoToSeries, e.isGoToSeries), Object(r.a)(t, e.$style.isHotProduct, e.isHotProduct), Object(r.a)(t, e.$style.isArticleRecommend, e.isArticleRecommend), t)],
                    attrs: {
                        href: e.toLocaleLowerCaseMoreLink,
                        tabindex: "0",
                        "aria-label": e.ariaLabel
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), e.moreAction(e.sitePath, e.morePath)
                        },
                        blur: function(t) {
                            return e.unFocusHandler()
                        }
                    }
                }, [o("div", {
                    class: [e.$style.linkIcon, {
                        jpMoreButton: "jp" === e.lang
                    }]
                }, [e._v("\n    " + e._s(e.moreName) + " \n    "), "" !== e.otherName ? o("span", {
                    staticClass: "sr-only"
                }, [e._v(e._s(e.otherName))]) : e._e(), e._v(" "), o("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "more link",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M23.07 13.77L9.06 0v6.7l9.18 8.94-9.18 9.66V32l14.01-14.49 1.87-1.87-1.87-1.87z"
                    }
                })])])]) : e._e()
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        693: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(20), o(18), o(29), o(59), o(121), o(78), o(26), o(3)),
                d = o(7),
                m = o(685),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                _ = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return h(e, t), e.prototype.cancelHandle = function() {
                        document.getElementsByTagName("html")[0].classList.remove("fixScroll"), this.CompareCancel(this.compareData)
                    }, f([Object(d.Action)("CompareCancel")], e.prototype, "CompareCancel", void 0), f([Object(d.Getter)("translation")], e.prototype, "translation", void 0), f([Object(c.Prop)()], e.prototype, "compareData", void 0), e = f([Object(c.Component)({})], e)
                }(c.Vue),
                y = _,
                v = o(1038),
                w = o(25);
            var component = Object(w.a)(y, (function() {
                    var t = this,
                        e = t._self._c;
                    t._self._setupProxy;
                    return e("li", {
                        class: t.$style.compareItem,
                        attrs: {
                            role: "listitem"
                        }
                    }, [e("img", {
                        attrs: {
                            src: "".concat(t.compareData.productImgUrl || t.compareData.skuImg, "/w110"),
                            alt: ""
                        }
                    }), t._v(" "), t.compareData.mktName ? e("p", [t._v(t._s(t.compareData.mktName))]) : t._e(), t._v(" "), t.compareData.name ? e("p", [t._v(t._s(t.compareData.name))]) : t._e(), t._v(" "), e("button", {
                        class: t.$style.closeButton,
                        attrs: {
                            tabindex: "0",
                            type: "button",
                            "aria-label": "".concat(t.translation.Aria_Cancel_Compare, " ").concat(t.compareData.mktName, " ").concat(t.compareData.name)
                        },
                        on: {
                            click: t.cancelHandle,
                            keydown: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.cancelHandle.apply(null, arguments)
                            }
                        }
                    }, [e("span", {
                        class: t.$style.closeLine
                    })])])
                }), [], !1, (function(t) {
                    this.$style = v.default.locals || v.default
                }), null, null),
                B = component.exports,
                P = o(79),
                O = o(0),
                j = o(4),
                k = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                I = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                S = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.isOpen = !1, e.isHide = !1, e.panelHeight = 165, e.isChatBot = !1, e
                    }
                    return k(e, t), Object.defineProperty(e.prototype, "btnData", {
                        get: function() {
                            return {
                                name: this.compareButtonName,
                                disabled: !1,
                                ariaLabel: "".concat(this.translation.Compare_View_Comparison, " ").concat(this.translation.Search_Result)
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareButtonName", {
                        get: function() {
                            return this.translation ? this.translation.Compare_View_Comparison : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "routeType", {
                        get: function() {
                            return !(!this.routeInfo || !this.routeInfo.productLine || "Model" !== this.routeInfo.type)
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareType", {
                        get: function() {
                            if (this.routeInfo.fullPath) {
                                var t = this.routeInfo.fullPath;
                                return "global" === this.routeInfo.websitePath ? t.split("/")[0].replace("-group", "") : "cn" === this.routeInfo.websitePath ? t.indexOf("cn/") > -1 ? t.split("/")[1].replace("-group", "") : t.split("/")[0].replace("-group", "") : t.split("/")[1].replace("-group", "")
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareAmount", {
                        get: function() {
                            if (this.compareType && this.compareSelect[this.compareType]) return this.compareSelect[this.compareType].length
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "compareData", {
                        get: function() {
                            if (this.compareType && this.compareSelect[this.compareType]) return this.compareSelect[this.compareType]
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getProductLine", {
                        get: function() {
                            if (this.routeInfo.fullPath) {
                                var t = this.routeInfo.fullPath;
                                return "global" === this.routeInfo.websitePath ? t.split("/")[0].replace("-group", "") : "cn" === this.routeInfo.websitePath ? t.indexOf("cn/") > -1 ? t.split("/")[1].replace("-group", "") : t.split("/")[0].replace("-group", "") : t.split("/")[1].replace("-group", "")
                            }
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getIsChatBot", {
                        get: function() {
                            if ("undefined" != typeof window) return "function" == typeof window.brandAssistantGetStatus && window.brandAssistantGetStatus().display
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchCompareData = function(t, e) {
                        t && 0 === t.length ? (this.isOpen = !1, this.compareStorePanelStatus({
                            productLine: this.getProductLine,
                            comparePanelStatus: !1
                        }), this.isHide = !1) : t && t.length > 0 && Object(P.a)().width > 1024 && (this.isOpen = !0, this.compareStorePanelStatus({
                            productLine: this.getProductLine,
                            comparePanelStatus: !0
                        }), this.isHide = !0)
                    }, e.prototype.watchIsOpen = function() {
                        var t, e;
                        this.isOpen ? "function" == typeof(null === (t = window.top) || void 0 === t ? void 0 : t.brandAssistantRenderDisplay) && (window.top.brandAssistantRenderDisplay(!1), this.isChatBot = !1) : "function" == typeof(null === (e = window.top) || void 0 === e ? void 0 : e.brandAssistantRenderDisplay) && (window.top.brandAssistantRenderDisplay(!0), this.isChatBot = !0)
                    }, e.prototype.watchTriggerPanelIsOpen = function(t, e) {
                        this.isOpen = t, this.isHide = t
                    }, e.prototype.toggleComparePanel = function(t) {
                        var e, o = this;
                        this.isOpen = t;
                        var n = document.getElementsByTagName("html")[0];
                        this.getPanelHeightHandler(), t ? setTimeout((function() {
                            o.isHide = t, o.compareStorePanelStatus({
                                productLine: o.getProductLine,
                                comparePanelStatus: t
                            }), window.innerWidth <= 780 && (n.classList.add("fixScroll"), setTimeout((function() {
                                o.getPanelHeightHandler()
                            }), 100))
                        }), 200) : (this.$emit("closeCompare"), this.isHide = t, this.compareStorePanelStatus({
                            productLine: this.getProductLine,
                            comparePanelStatus: t
                        }), window.innerWidth <= 780 && n.classList.remove("fixScroll")), null === (e = window.top) || void 0 === e || e.brandAssistantRenderDisplay(!0)
                    }, e.prototype.mounted = function() {
                        var t = this,
                            e = this;
                        this.getPanelHeightHandler(), window.addEventListener("resize", (function() {
                            t.getPanelHeightHandler()
                        })), setInterval((function() {
                            var t;
                            Object(P.a)().width <= 1024 && "function" == typeof(null === (t = window.top) || void 0 === t ? void 0 : t.brandAssistantRenderDisplay) && (e.isChatBot = !0)
                        }), 800)
                    }, e.prototype.getPanelHeightHandler = function() {
                        window.innerWidth <= 768 ? this.panelHeight = window.innerHeight : window.innerWidth <= 1300 ? this.panelHeight = 320 : this.panelHeight = 188
                    }, e.prototype.regexProductName = function(t) {
                        return encodeURIComponent(t.replace(/\s+/g, "-"))
                    }, e.prototype.getQueryVariable = function(t) {
                        var e = "";
                        if ("undefined" != typeof window)
                            for (var o = 0, n = window.location.search.substring(1).split("&"); o < n.length; o++) {
                                var r = n[o].split("=");
                                if (decodeURIComponent(r[0]).toLowerCase() === t.toLowerCase()) {
                                    e = decodeURIComponent(r[1]);
                                    break
                                }
                            }
                        return e
                    }, e.prototype.goToCompareResult = function() {
                        var t = this,
                            e = this.compareType ? this.compareType : this.routeInfo.productLine.toLowerCase(),
                            o = "",
                            n = "",
                            r = this.compareSelect[e].length;
                        this.routeInfo.filterInfo && this.routeInfo.filterInfo.modelBaseFlag;
                        (this.compareSelect[e].map((function(e, l) {
                            l < r - 1 ? (o = o + t.regexProductName(e.name || e.skuName || e.mktName) + ",", n = n + e.partNo + ",") : (o += t.regexProductName(e.name || e.skuName || e.mktName), n += e.partNo)
                        })), "rog.asus.com.cn" !== window.location.host ? window.innerWidth > 1024 ? window.dataLayer.push({
                            event: "data_layer_event",
                            event_category_DL: "select-compare-L3",
                            event_action_DL: "clicked",
                            event_label_DL: "compare-compare",
                            event_value_DL: "0"
                        }) : setTimeout((function() {
                            window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "select-compare-L3",
                                event_action_DL: "clicked",
                                event_label_DL: "compare-compare",
                                event_value_DL: "0"
                            })
                        }), 200) : this.hmtHandler(), "object" === Object(l.a)(window._satellite) && window._satellite.track("spa-pageview"), this.isOpen = !1, this.isHide = !1, this.compareStorePanelStatus({
                            productLine: this.getProductLine,
                            comparePanelStatus: !1
                        }), Object(j.c)("returnProductResultPath", window.location.pathname + window.location.search, "36000"), window.innerWidth <= 780) && document.getElementsByTagName("html")[0].classList.remove("fixScroll");
                        "global" !== this.routeInfo.websitePath ? "cn" === this.routeInfo.websitePath && "rog.asus.com.cn" === window.location.host ? this.$router.push({
                            path: "/compareresult?productline=".concat(e, "&partno=").concat(n)
                        }).catch((function(t) {})) : this.$router.push({
                            path: "/".concat(this.routeInfo.websitePath, "/compareresult?productline=").concat(e, "&partno=").concat(n)
                        }).catch((function(t) {})) : this.$router.push({
                            path: "/compareresult?productline=".concat(e, "&partno=").concat(n)
                        }).catch((function(t) {}))
                    }, e.prototype.hmtHandler = function() {
                        void 0 !== window._hmt && window._hmt && window._hmt.push(["_trackEvent", "select-compare-L3", "clicked", "compare-compare"]), void 0 !== window._hmt && window._hmt && window._hmt.push(["_requirePlugin", "UrlChangeTracker", {
                            shouldTrackUrlChange: function(t, e) {
                                return t && e
                            }
                        }])
                    }, I([Object(d.Action)("getCompareSelect")], e.prototype, "getCompareSelect", void 0), I([Object(d.Getter)("compareSelect")], e.prototype, "compareSelect", void 0), I([Object(d.Getter)("websitePath")], e.prototype, "websitePath", void 0), I([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), I([Object(d.Getter)("translation")], e.prototype, "translation", void 0), I([Object(d.Getter)("comparePanelStatus")], e.prototype, "comparePanelStatus", void 0), I([Object(d.Mutation)(O.COMPARE_STORE_PANEL_STATUS)], e.prototype, "compareStorePanelStatus", void 0), I([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "triggerPanelIsOpen", void 0), I([Object(c.Watch)("compareData", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchCompareData", null), I([Object(c.Watch)("isOpen")], e.prototype, "watchIsOpen", null), I([Object(c.Watch)("triggerPanelIsOpen")], e.prototype, "watchTriggerPanelIsOpen", null), e = I([Object(c.Component)({
                        components: {
                            ButtonBorderRed: m.a,
                            CompareItem: B
                        }
                    })], e)
                }(c.Vue),
                C = S,
                x = o(1039);
            var D = Object(w.a)(C, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    attrs: {
                        id: "compare"
                    }
                }, [o("div", {
                    class: [e.$style.comparePanel, Object(r.a)({}, e.$style.active, e.isOpen || e.comparePanelStatus)],
                    style: "height:".concat(e.panelHeight, "px;")
                }, [o("div", {
                    class: [e.$style.arrowIcon],
                    on: {
                        click: function(t) {
                            return e.toggleComparePanel(!1)
                        },
                        keydown: function(t) {
                            return !t.type.indexOf("key") && e._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : e.toggleComparePanel(!1)
                        }
                    }
                }, [o("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "panel down",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M18.23 23.01L32 9h-6.7l-8.94 9.19L6.7 9H0l14.49 14.01 1.87 1.88 1.87-1.88z"
                    }
                })])]), e._v(" "), e.compareData && e.compareData.length > 0 ? o("div", {
                    class: e.$style.compareWrapper
                }, [o("div", {
                    class: e.$style.compareText
                }, [o("span", [e._v(e._s(e.translation.Compare_Product_Comparison))]), e._v(" "), o("p", [e._v(e._s(e.translation.Compare_Comparison_Description))])]), e._v(" "), o("ul", {
                    class: e.$style.compareProduct,
                    attrs: {
                        role: e.compareData.length > 0 ? "list" : "none"
                    }
                }, e._l(e.compareData, (function(t) {
                    return o("CompareItem", {
                        key: t.partNo,
                        attrs: {
                            "compare-data": t
                        }
                    })
                })), 1), e._v(" "), o("ButtonBorderRed", {
                    attrs: {
                        "button-data": e.btnData,
                        isCompare: !0,
                        tabindexValue: e.isOpen ? 0 : -1
                    },
                    on: {
                        click: e.goToCompareResult
                    }
                })], 1) : e._e()]), e._v(" "), e.compareAmount ? o("div", {
                    class: [e.$style.closeComparePanelButton, (t = {}, Object(r.a)(t, e.$style.active, e.isOpen), Object(r.a)(t, e.$style.hide, e.isHide), Object(r.a)(t, e.$style.isModelPage, e.routeType), Object(r.a)(t, e.$style.isChatBot, e.isChatBot), t)],
                    attrs: {
                        tabindex: e.isHide ? -1 : 0
                    },
                    on: {
                        click: function(t) {
                            return e.toggleComparePanel(!0)
                        },
                        keydown: function(t) {
                            return !t.type.indexOf("key") && e._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : e.toggleComparePanel(!0)
                        }
                    }
                }, [o("svg", {
                    attrs: {
                        width: "32",
                        height: "32",
                        viewBox: "0 0 32 32",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "compare panel button open",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("g", {
                    attrs: {
                        fill: "#fff"
                    }
                }, [o("path", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        d: "M13.333 5.333H2.667v21.334h10.666V5.333zM1.333 4v24h13.334V4H1.333zM17.333 5.333V4h1.482v1.333h-1.482zM23.26 4h-2.963v1.333h2.963V4zm1.482 0v1.333h2.963V4H24.74zm4.444 0v1.333h1.482V4h-1.482zm1.482 2.667h-1.334v2.666h1.334V6.667zm0 4h-1.334v2.666h1.334v-2.666zm0 4h-1.334v2.666h1.334v-2.666zm0 4h-1.334v2.666h1.334v-2.666zm0 4h-1.334v2.666h1.334v-2.666zm0 4h-1.482V28h1.482v-1.333zM27.704 28v-1.333H24.74V28h2.963zm-4.445 0v-1.333h-2.963V28h2.963zm-4.444 0v-1.333h-1.482V28h1.482zm-1.482-2.667h1.334v-2.666h-1.334v2.666zm0-4h1.334v-2.666h-1.334v2.666zm0-4h1.334v-2.666h-1.334v2.666zm0-4h1.334v-2.666h-1.334v2.666zm0-4h1.334V6.667h-1.334v2.666z"
                    }
                }), o("path", {
                    attrs: {
                        d: "M21.35 18.636V12h2.465c.886 0 1.563.156 2.014.467.45.312.693.763.693 1.371a1.6 1.6 0 01-.242.888c-.161.25-.403.42-.725.545.354.093.628.265.822.514.193.25.29.56.29.92 0 .653-.21 1.136-.645 1.463-.435.327-1.063.499-1.901.499h-2.788l.016-.032zm1.659-3.879h.87c.355 0 .612-.062.773-.187.162-.125.226-.311.226-.56 0-.281-.08-.483-.258-.608-.177-.125-.435-.187-.805-.187h-.806v1.542zm0 2.632h1.08c.306 0 .531-.062.692-.202a.706.706 0 00.242-.56c0-.562-.29-.826-.854-.842h-1.16v1.604zM9.143 17.387H6.856l-.405 1.248H4.667l2.53-6.666H8.77l2.563 6.667H9.55l-.406-1.25zm-1.881-1.234h1.492l-.746-2.31-.746 2.31z"
                    }
                })])]), e._v(" "), o("div", {
                    class: e.$style.compareAmount
                }, [e._v(e._s(e.compareAmount))])]) : e._e()])
            }), [], !1, (function(t) {
                this.$style = x.default.locals || x.default
            }), null, null);
            e.a = D.exports
        },
        694: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(3)),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                h = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.active = !1, e
                    }
                    return d(e, t), e.prototype.toggleHandler = function() {
                        this.active = !this.active, this.$emit("clickMore")
                    }, m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "horizontal", void 0), m([Object(c.Prop)()], e.prototype, "moreName", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isFilter", void 0), e = m([Object(c.Component)({})], e)
                }(c.Vue),
                f = h,
                _ = o(991),
                y = o(25);
            var component = Object(y.a)(f, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("button", {
                    class: [e.$style.expandMoreButton, (t = {}, Object(r.a)(t, e.$style.active, this.active), Object(r.a)(t, e.$style.horizontal, this.horizontal), Object(r.a)(t, e.$style.filterMoreButton, e.isFilter), t)],
                    attrs: {
                        type: "button",
                        tabindex: "0",
                        "aria-label": e.active ? "close filter button" : "open filter button"
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && e._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : e.toggleHandler.apply(null, arguments)
                        },
                        click: e.toggleHandler
                    }
                }, [o("div", {
                    class: e.$style.circle
                }, [e._v("\n    " + e._s(e.moreName) + "\n  ")])])
            }), [], !1, (function(t) {
                this.$style = _.default.locals || _.default
            }), null, null);
            e.a = component.exports
        },
        696: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(59), o(3)),
                d = o(7),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.active = !1, e.isProductCardActive = !0, e
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.toggleHandler = function() {
                        var t = this;
                        setTimeout((function() {
                            t.isProductCard ? (t.isProductCardActive = !t.isProductCardActive, t.$emit("clickMore", t.isProductCardActive)) : (t.active = !t.active, t.$emit("clickMore"))
                        }), 100)
                    }, h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(c.Prop)()], e.prototype, "moreName", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "horizontal", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isFilter", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isProductCard", void 0), h([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "buttonAriaLabel", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "seeMoreActive", void 0), h([Object(c.Prop)({
                        default: !0
                    })], e.prototype, "isShowSeeAllButton", void 0), e = h([Object(c.Component)({})], e)
                }(c.Vue),
                _ = f,
                y = o(1036),
                v = o(25);
            var component = Object(v.a)(_, (function() {
                var t, e, o = this,
                    n = o._self._c;
                o._self._setupProxy;
                return n("div", {
                    class: [o.$style.seeAllButton, (t = {}, Object(r.a)(t, o.$style.productCardSeeMore, o.isProductCard), Object(r.a)(t, o.$style.visible, o.isShowSeeAllButton), Object(r.a)(t, o.$style.hidden, !o.isShowSeeAllButton), t)]
                }, [n("button", {
                    staticClass: "robotoFont",
                    class: [o.$style.text, Object(r.a)({}, o.$style.jp, "jp" === o.lang)],
                    attrs: {
                        tabindex: "0",
                        "aria-label": o.buttonAriaLabel
                    },
                    on: {
                        keydown: function(t) {
                            return !t.type.indexOf("key") && o._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : o.toggleHandler.apply(null, arguments)
                        },
                        click: o.toggleHandler
                    }
                }, [n("span", [o._v("\n      " + o._s(o.moreName) + "\n    ")]), o._v(" "), n("svg", {
                    class: (e = {}, Object(r.a)(e, o.$style.horizontal, o.horizontal), Object(r.a)(e, o.$style.more, o.seeMoreActive), e),
                    attrs: {
                        width: "12",
                        height: "12",
                        viewBox: "0 0 12 12",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        alt: "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M6 9.55l-5-5V2.5l5 5 5-5v2.05l-5 5z",
                        fill: "#181818"
                    }
                })])])])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        702: function(t, e, o) {
            t.exports = {
                bannerPromotionBarBody: "BannerPromotionBar__bannerPromotionBarBody__2Fgp-",
                final: "BannerPromotionBar__final__664At",
                bannerPromotionBarWrapper: "BannerPromotionBar__bannerPromotionBarWrapper__HTMQo",
                show: "BannerPromotionBar__show__Uh+h-",
                bannerPromotionBarContainer: "BannerPromotionBar__bannerPromotionBarContainer__fGwxb",
                defaultBannerPromotion: "BannerPromotionBar__defaultBannerPromotion__AOwSy",
                button: "BannerPromotionBar__button__5slh5",
                light: "BannerPromotionBar__light__M8PnJ",
                dark: "BannerPromotionBar__dark__54ZnM",
                white: "BannerPromotionBar__white__OfX2N",
                gray: "BannerPromotionBar__gray__oLGen",
                bannerPromotionBarContent: "BannerPromotionBar__bannerPromotionBarContent__SDXTV",
                moreDescription: "BannerPromotionBar__moreDescription__nvqLj"
            }
        },
        703: function(t, e, o) {
            t.exports = {
                bannerWrapper: "BannerSlideShow__bannerWrapper__M5MQ2",
                showPromotionBanner: "BannerSlideShow__showPromotionBanner__fBvvY",
                bannerSlideContent: "BannerSlideShow__bannerSlideContent__QKzUf",
                bannerContent: "BannerSlideShow__bannerContent__Hzqyq",
                bannerContainer: "BannerSlideShow__bannerContainer__pWCz0",
                noFullSize: "BannerSlideShow__noFullSize__hJ0O8",
                show: "BannerSlideShow__show__rXVWd",
                bannerLink: "BannerSlideShow__bannerLink__kKdJb",
                active: "BannerSlideShow__active__UqHcw",
                bannerImageWrapper: "BannerSlideShow__bannerImageWrapper__t5Wqc",
                MDA: "BannerSlideShow__MDA__P1oKG",
                textContent: "BannerSlideShow__textContent__Pukzh",
                top: "BannerSlideShow__top__JHhPE",
                bottom: "BannerSlideShow__bottom__hAgLr",
                center: "BannerSlideShow__center__Hm8jX",
                left: "BannerSlideShow__left__t9fLw",
                right: "BannerSlideShow__right__7eaME",
                buttonGroup: "BannerSlideShow__buttonGroup__W8p1x",
                mobileBanner: "BannerSlideShow__mobileBanner__3ovSL",
                bannerImage: "BannerSlideShow__bannerImage__o9+wK",
                bannerHoverLeft: "BannerSlideShow__bannerHoverLeft__d07Yb",
                bannerHoverRight: "BannerSlideShow__bannerHoverRight__wucAe",
                leftButton: "BannerSlideShow__leftButton__bbfbW",
                rightButton: "BannerSlideShow__rightButton__l4Wt5",
                bannerPoints: "BannerSlideShow__bannerPoints__X-zPo",
                lineContent: "BannerSlideShow__lineContent__B8a81",
                line: "BannerSlideShow__line__OgeiM",
                progress: "BannerSlideShow__progress__k7X0M",
                slideController: "BannerSlideShow__slideController__ktXY4",
                play: "BannerSlideShow__play__8PrKH",
                pause: "BannerSlideShow__pause__UTfJU"
            }
        },
        706: function(t, e, o) {
            t.exports = {
                actionsItemContent: "ActionContent__actionsItemContent__M69iZ",
                reviewType: "ActionContent__reviewType__VFlYX",
                actionTitle: "ActionContent__actionTitle__TFIhY",
                actionText: "ActionContent__actionText__I4+d2",
                blackText: "ActionContent__blackText__UTP6u",
                whiteText: "ActionContent__whiteText__CgRpc"
            }
        },
        708: function(t, e, o) {
            t.exports = {
                actionsItem: "ActionItem__actionsItem__do2Lu",
                itemCenter: "ActionItem__itemCenter__FPmIL",
                active: "ActionItem__active__MRVrL",
                articleContentImage: "ActionItem__articleContentImage__WzNvF",
                hoverOut: "ActionItem__hoverOut__KZH8S",
                isProductPage: "ActionItem__isProductPage__RmXB5",
                horizontal: "ActionItem__horizontal__EGtTI",
                postProductHome: "ActionItem__postProductHome__jLH4J",
                hoverIn: "ActionItem__hoverIn__3UBOi",
                blackText: "ActionItem__blackText__C-y45",
                whiteText: "ActionItem__whiteText__ZTo8j"
            }
        },
        709: function(t, e, o) {
            t.exports = {
                moreButton: "MoreButton__moreButton__c16n8",
                linkIcon: "MoreButton__linkIcon__-jKNv",
                useMessageButton: "MoreButton__useMessageButton__+ylFi",
                isActiveMoreButton: "MoreButton__isActiveMoreButton__xqUPJ",
                spotLightButton: "MoreButton__spotLightButton__yNKui",
                hotProductLearnMore: "MoreButton__hotProductLearnMore__cdJlI",
                articleRelated: "MoreButton__articleRelated__eKKEh",
                isArticleRecommend: "MoreButton__isArticleRecommend__sqSlz",
                isBlackBackground: "MoreButton__isBlackBackground__ZbmFL",
                isWhiteText: "MoreButton__isWhiteText__KRTn6",
                isGoToSeries: "MoreButton__isGoToSeries__jZZaW",
                largerFontSize: "MoreButton__largerFontSize__BmxsE",
                isHotProduct: "MoreButton__isHotProduct__x6TAf"
            }
        },
        727: function(t, e, o) {
            t.exports = {
                expandMoreButton: "ExpandMoreButton__expandMoreButton__RfRQ+",
                circle: "ExpandMoreButton__circle__n9yth",
                text: "ExpandMoreButton__text__Y18H1",
                active: "ExpandMoreButton__active__XqWDK",
                horizontal: "ExpandMoreButton__horizontal__zcVic",
                filterMoreButton: "ExpandMoreButton__filterMoreButton__FuZJ4"
            }
        },
        764: function(t, e, o) {
            t.exports = {
                borderRedButton: "ButtonBorderRed__borderRedButton__mg7A9",
                isSpecButton: "ButtonBorderRed__isSpecButton__WTrSd",
                isProductResultWhereToBuyButton: "ButtonBorderRed__isProductResultWhereToBuyButton__qfn--",
                isLearnMore: "ButtonBorderRed__isLearnMore__RFCmc",
                btnBorderRed: "ButtonBorderRed__btnBorderRed__zkcIA",
                isRed: "ButtonBorderRed__isRed__NoKph",
                inner: "ButtonBorderRed__inner__-s0h8",
                disabled: "ButtonBorderRed__disabled__Go+mO",
                hoverColor: "ButtonBorderRed__hoverColor__CfY9D",
                maxWidth: "ButtonBorderRed__maxWidth__3+GoD",
                isFilter: "ButtonBorderRed__isFilter__SONNI",
                compareButton: "ButtonBorderRed__compareButton__fGOtu",
                updateDownButton: "ButtonBorderRed__updateDownButton__f3xG0",
                buyBtn: "ButtonBorderRed__buyBtn__wvetS",
                logOut: "ButtonBorderRed__logOut__madua",
                autoWidth: "ButtonBorderRed__autoWidth__Da6-6",
                smallFont: "ButtonBorderRed__smallFont__nYc-F",
                bgShadow: "ButtonBorderRed__bgShadow__ozt8u",
                whereToBuyButton: "ButtonBorderRed__whereToBuyButton__MBD5C"
            }
        },
        767: function(t, e, o) {
            t.exports = {
                seeAllButton: "seeAllButton__seeAllButton__dIrKX",
                visible: "seeAllButton__visible__OJDnB",
                hidden: "seeAllButton__hidden__uiL3a",
                productCardSeeMore: "seeAllButton__productCardSeeMore__URrIn",
                text: "seeAllButton__text__TNQDv",
                horizontal: "seeAllButton__horizontal__Km1Ge",
                more: "seeAllButton__more__twUy+",
                jp: "seeAllButton__jp__INtrF",
                active: "seeAllButton__active__0347T",
                expandMoreButton: "seeAllButton__expandMoreButton__Wd9pr"
            }
        },
        769: function(t, e, o) {
            t.exports = {
                compareItem: "CompareItem__compareItem__cv1AL",
                closeButton: "CompareItem__closeButton__TaNtT",
                closeLine: "CompareItem__closeLine__T8sHA",
                productImg: "CompareItem__productImg__aw+-P"
            }
        },
        770: function(t, e, o) {
            t.exports = {
                comparePanel: "ComparePanel__comparePanel__BycQ3",
                active: "ComparePanel__active__RqFfs",
                arrowIcon: "ComparePanel__arrowIcon__3dKwb",
                compareWrapper: "ComparePanel__compareWrapper__+4SaG",
                compareText: "ComparePanel__compareText__XmMzl",
                compareProduct: "ComparePanel__compareProduct__JLK7d",
                closeComparePanelButton: "ComparePanel__closeComparePanelButton__Xq2e7",
                isChatBot: "ComparePanel__isChatBot__dEz+K",
                isModelPage: "ComparePanel__isModelPage__mydkJ",
                hide: "ComparePanel__hide__AvZ+1",
                compareAmount: "ComparePanel__compareAmount__h7nq8"
            }
        },
        802: function(t, e, o) {
            t.exports = {
                videoButton: "VideoButton__videoButton__XVz9e",
                overviewVideoButton: "VideoButton__overviewVideoButton__d9DBl",
                isActive: "VideoButton__isActive__Xg4gI"
            }
        },
        862: function(t, e, o) {
            t.exports = {
                compareResultItem: "CompareResultItem__compareResultItem__Sh4aV",
                active: "CompareResultItem__active__EPe8+",
                firstItem: "CompareResultItem__firstItem__vwpUG",
                compareResultItemImage: "CompareResultItem__compareResultItemImage__tECEH",
                compareProduct: "CompareResultItem__compareProduct__Q7hNe",
                compareResultItemButton: "CompareResultItem__compareResultItemButton__6yE+W",
                compareResultItemRow: "CompareResultItem__compareResultItemRow__PYIGn",
                compareProductName: "CompareResultItem__compareProductName__4t-Tj",
                compareProductPrice: "CompareResultItem__compareProductPrice__EYAsj",
                compareResultItemButtonWrapper: "CompareResultItem__compareResultItemButtonWrapper__pTF++",
                productSpecCheckBox: "CompareResultItem__productSpecCheckBox__2jClb",
                isCheck: "CompareResultItem__isCheck__BXLcU",
                checkBoxIcon: "CompareResultItem__checkBoxIcon__asKz1",
                compareResultItemTitle: "CompareResultItem__compareResultItemTitle__kdUvo",
                rowDescriptionItem: "CompareResultItem__rowDescriptionItem__af7in",
                rowDescriptionItemName: "CompareResultItem__rowDescriptionItemName__HHYD6"
            }
        },
        881: function(t, e, o) {
            t.exports = {
                articleItem: "ArticleItem__articleItem__+Qu30",
                corner1: "ArticleItem__corner1__E6M+k",
                corner2: "ArticleItem__corner2__1Ptg0",
                corner3: "ArticleItem__corner3__-Ui4U",
                corner4: "ArticleItem__corner4__ToK2s",
                title: "ArticleItem__title__CTnaw",
                photo: "ArticleItem__photo__0fHHU",
                category: "ArticleItem__category__7uNGt",
                description: "ArticleItem__description__2SON7"
            }
        },
        928: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = (o(43), o(46), o(9)),
                c = (o(54), o(41), o(10), o(3)),
                d = o(903),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                f = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "tagName", {
                        get: function() {
                            return "product" === this.pageType ? this.categoryType : this.actionItemContentData.titleTag
                        },
                        enumerable: !1,
                        configurable: !0
                    }), h([Object(c.Prop)()], e.prototype, "videoType", void 0), h([Object(c.Prop)()], e.prototype, "pageType", void 0), h([Object(c.Prop)()], e.prototype, "categoryType", void 0), h([Object(c.Prop)()], e.prototype, "actionItemContentData", void 0), h([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isBlackText", void 0), e = h([Object(c.Component)({
                        components: {
                            Tag: d.a
                        }
                    })], e)
                }(c.Vue),
                _ = f,
                y = o(971),
                v = o(25);
            var component = Object(v.a)(_, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("div", {
                    class: [e.$style.actionsItemContent, (t = {}, Object(r.a)(t, e.$style.reviewType, "review" === e.videoType), Object(r.a)(t, e.$style.blackText, e.isBlackText), Object(r.a)(t, e.$style.whiteText, !e.isBlackText), t)]
                }, [o("p", {
                    class: e.$style.actionTitle
                }, [e._v(e._s(e.actionItemContentData.title))]), e._v(" "), "review" !== e.videoType ? o("span", {
                    class: e.$style.actionText
                }, [e._v(e._s(e.actionItemContentData.description))]) : e._e()])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        930: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = o(9),
                c = (o(54), o(41), o(10), o(60), o(3)),
                d = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                m = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                h = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return d(e, t), e.prototype.tabHandler = function() {
                        window.location.assign(this.link)
                    }, e.prototype.playVideo = function() {}, m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "videoType", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isHoverStatus", void 0), m([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isLink", void 0), m([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "link", void 0), m([Object(c.Prop)({
                        default: ""
                    })], e.prototype, "buttonAriaLabel", void 0), m([Object(c.Prop)({
                        default: !0
                    })], e.prototype, "tabIndexStatus", void 0), e = m([Object(c.Component)({})], e)
                }(c.Vue),
                f = h,
                _ = o(1075),
                y = o(25);
            var component = Object(y.a)(f, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("button", {
                    class: [e.$style.videoButton, (t = {}, Object(r.a)(t, e.$style.overviewVideoButton, e.videoType), Object(r.a)(t, e.$style.isActive, e.isHoverStatus), t)],
                    attrs: {
                        type: e.isLink ? "link" : "button",
                        tabindex: e.tabIndexStatus ? 0 : -1
                    },
                    on: {
                        click: e.playVideo,
                        keydown: function(t) {
                            return !t.type.indexOf("key") && e._k(t.keyCode, "enter", 13, t.key, "Enter") ? null : e.tabHandler.apply(null, arguments)
                        }
                    }
                }, [o("span", {
                    staticClass: "sr-only"
                }, [e._v("play")]), e._v(" "), o("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [o("path", {
                    attrs: {
                        d: "M2.24 12a14.32 14.32 0 0127.52 0h1.74a16 16 0 00-31 0zm27.52 8a14.32 14.32 0 01-27.52 0H.5a16 16 0 0031 0z"
                    }
                })])])
            }), [], !1, (function(t) {
                this.$style = _.default.locals || _.default
            }), null, null);
            e.a = component.exports
        },
        937: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = (o(43), o(46), o(60), o(20), o(9)),
                c = (o(54), o(41), o(10), o(28), o(59), o(44), o(32), o(18), o(29), o(3)),
                d = o(7),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                f = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.activeNumber = 0, e.activeMoveNumber = 0, e.moveDistance = 500, e.final = !1, e.show = !1, e.bannerGAStatus = !1, e.bannerType = "", e.showStatus = !1, e
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "getBannerPromotionBar", {
                        get: function() {
                            return Object.keys(this.bannerPromotionBar).length > 0 ? (this.$emit("showPromotion", !0), this.checkImageData(), this.bannerPromotionBar) : (this.$emit("showPromotion", !1), [])
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "target", {
                        get: function() {
                            return this.getBannerPromotionBar
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "listNumber", {
                        get: function() {
                            return this.activeMoveNumber === this.bannerPromotionBarNumber ? 0 : -1 === this.activeMoveNumber ? this.bannerPromotionBarNumber - 1 : this.activeNumber
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "bannerPromotionBarNumber", {
                        get: function() {
                            return Object.keys(this.getBannerPromotionBar).length > 0 ? Object.keys(this.getBannerPromotionBar).length : 5
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo && Object.keys(this.routeInfo).length > 0 ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "isRtlArea", {
                        get: function() {
                            return "eg" === this.lang || "me-ar" === this.lang || "il" === this.lang || "sa-ar" === this.lang
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.watchBannerPromotionBar = function(t, e) {
                        var o;
                        (null === (o = this.bannerPromotionBar[t]) || void 0 === o ? void 0 : o.class) ? this.bannerType = this.bannerPromotionBar[t].class: this.bannerType = "Default"
                    }, e.prototype.beforeMount = function() {
                        var t = this;
                        window.innerWidth < 500 && (this.moveDistance = window.innerWidth - 60), setTimeout((function() {
                            t.showStatus = !0
                        }), 500)
                    }, e.prototype.mounted = function() {
                        var t = this;
                        window.addEventListener("resize", (function() {
                            window.innerWidth < 500 ? t.moveDistance = window.innerWidth - 60 : t.moveDistance = 500
                        }))
                    }, e.prototype.hideDescription = function(t) {
                        return t.length > 80 ? t.substring(0, 80) + "..." : t
                    }, e.prototype.allDescription = function(t) {
                        return t
                    }, e.prototype.showDescriptionHandler = function() {
                        var t = this;
                        setTimeout((function() {
                            t.show = !0
                        }), 100)
                    }, e.prototype.hideDescriptionHandler = function() {
                        this.show = !1
                    }, e.prototype.prev = function() {
                        var t = this;
                        this.final = !1, this.activeNumber > 0 ? (this.activeNumber--, this.activeMoveNumber--) : 0 === this.activeNumber && (this.activeMoveNumber--, setTimeout((function() {
                            t.final = !0, t.activeMoveNumber = t.bannerPromotionBarNumber - 1, t.activeNumber = t.bannerPromotionBarNumber - 1
                        }), 500))
                    }, e.prototype.next = function() {
                        var t = this;
                        this.final = !1, this.activeNumber < this.bannerPromotionBarNumber - 1 ? (this.activeNumber++, this.activeMoveNumber++) : this.activeNumber === this.bannerPromotionBarNumber - 1 && (this.activeMoveNumber++, setTimeout((function() {
                            t.final = !0, t.activeMoveNumber = 0, t.activeNumber = 0
                        }), 500))
                    }, e.prototype.checkImageData = function() {
                        "undefined" == typeof window || this.bannerGAStatus || this.gaHandler()
                    }, e.prototype.gaHandler = function() {
                        var t = this,
                            e = [];
                        this.bannerPromotionBar.forEach((function(t, o) {
                            e.push({
                                id: "promotionBanner_".concat(o),
                                name: t.description.replace(/-/g, "_").replace(/ /g, "_"),
                                position: "hero_banner"
                            })
                        })), setTimeout((function() {
                            window.dataLayer.push({
                                event: "promotionView",
                                ecommerce: {
                                    promoView: {
                                        promotions: e
                                    }
                                }
                            }), t.bannerGAStatus = !0
                        }), 200)
                    }, e.prototype.gaClickHandler = function(t, e, o) {
                        "rog.asus.com.cn" !== window.location.host ? (setTimeout((function() {
                            window.dataLayer.push({
                                event: "promotionClick",
                                ecommerce: {
                                    promoClick: {
                                        promotions: [{
                                            id: "promotionBanner_".concat(o),
                                            name: t.description.replace(/-/g, "_").replace(/ /g, "_"),
                                            position: "hero_banner"
                                        }]
                                    }
                                },
                                eventCallback: function() {}
                            })
                        }), 200), e ? window.open(t.link, e) : window.location.assign(t.link)) : e ? window.open(t.link, e) : window.location.assign(t.link)
                    }, h([Object(d.Getter)("bannerPromotionBar")], e.prototype, "bannerPromotionBar", void 0), h([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(c.Prop)({
                        default: "pc"
                    })], e.prototype, "userDeviceValue", void 0), h([Object(d.Getter)("getUserDeviceWidth")], e.prototype, "getUserDeviceWidth", void 0), h([Object(c.Watch)("listNumber", {
                        immediate: !0
                    })], e.prototype, "watchBannerPromotionBar", null), e = h([Object(c.Component)({})], e)
                }(c.Vue),
                _ = f,
                y = o(967),
                v = o(25);
            var w = Object(v.a)(_, (function() {
                    var t, e = this,
                        o = e._self._c;
                    e._self._setupProxy;
                    return Object.keys(e.getBannerPromotionBar).length > 0 && e.bannerPromotionBarNumber > 0 ? o("div", {
                        class: [e.$style.bannerPromotionBarContainer, (t = {}, Object(r.a)(t, e.$style.defaultBannerPromotion, "Default" === e.bannerPromotionBar[e.listNumber].class || !1 === e.getBannerPromotionBar[e.listNumber].hasOwnProperty("class")), Object(r.a)(t, e.$style.dark, "Dark" === e.bannerPromotionBar[e.listNumber].class), Object(r.a)(t, e.$style.light, "Light" === e.bannerPromotionBar[e.listNumber].class), Object(r.a)(t, e.$style.white, "White" === e.bannerPromotionBar[e.listNumber].class), Object(r.a)(t, e.$style.gray, "Deep Gray" === e.bannerPromotionBar[e.listNumber].class), t)]
                    }, [o("button", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: e.bannerPromotionBarNumber > 1,
                            expression: "bannerPromotionBarNumber > 1"
                        }],
                        class: e.$style.button,
                        attrs: {
                            "aria-label": "prev banner"
                        },
                        on: {
                            click: function(t) {
                                return e.prev()
                            }
                        }
                    }, [o("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            "data-name": "圖層 1",
                            viewBox: "0 0 32 32",
                            "svg-inline": "",
                            alt: "slide prev",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [o("path", {
                        attrs: {
                            d: "M8.93 13.77L22.94 0v6.7l-9.18 8.94 9.18 9.66V32L8.93 17.51l-1.87-1.87 1.87-1.87z"
                        }
                    })])]), e._v(" "), o("div", {
                        class: [e.$style.bannerPromotionBarContent],
                        on: {
                            mouseenter: e.showDescriptionHandler,
                            mouseleave: e.hideDescriptionHandler
                        }
                    }, [o("div", {
                        class: [e.$style.bannerPromotionBarBody, Object(r.a)({}, e.$style.final, e.final)],
                        style: "width:".concat(e.bannerPromotionBarNumber * e.moveDistance + 2 * e.moveDistance, "px; transform:translateX(").concat((e.isRtlArea ? 1 : -1) * (e.activeMoveNumber + 1) * e.moveDistance, "px);")
                    }, [o("a", {
                        class: [e.$style.bannerPromotionBarWrapper],
                        attrs: {
                            href: e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].link ? e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].link : null,
                            target: e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].target ? e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].target : "_self",
                            rel: "_blank" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].target ? "noopener noreferrer" : ""
                        },
                        on: {
                            click: function(t) {
                                return t.preventDefault(), t.stopPropagation(), e.gaClickHandler(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1], e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].target, e.bannerPromotionBarNumber - 1)
                            }
                        }
                    }, [e.getBannerPromotionBar && "Default" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].class && e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop || e.getBannerPromotionBar && "White" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].class && e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop),
                            alt: "loudspeaker"
                        }
                    }) : e.getBannerPromotionBar && "Light" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].class && e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop || e.getBannerPromotionBar && "Deep Gray" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].class && e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop),
                            alt: "gift"
                        }
                    }) : e.getBannerPromotionBar && "Dark" === e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].class && e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].item[0].content.desktop),
                            alt: "tree"
                        }
                    }) : e._e(), e._v(" "), o("span", {
                        attrs: {
                            title: e.allDescription(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].description)
                        }
                    }, [e._v(e._s(e.hideDescription(e.getBannerPromotionBar[e.bannerPromotionBarNumber - 1].description)))])]), e._v(" "), e._l(e.getBannerPromotionBar, (function(t, n) {
                        var l;
                        return o("a", {
                            key: n,
                            class: [e.$style.bannerPromotionBarWrapper, (l = {}, Object(r.a)(l, "active", n === e.activeNumber), Object(r.a)(l, e.$style.show, e.showStatus), l)],
                            attrs: {
                                href: t.link ? t.link : null,
                                target: t.target ? t.target : "_self",
                                rel: "_blank" === t.target ? "noopener noreferrer" : ""
                            },
                            on: {
                                click: function(o) {
                                    return o.preventDefault(), o.stopPropagation(), e.gaClickHandler(t, t.target, n)
                                }
                            }
                        }, ["Default" === t.class && t.item[0].content.desktop || "White" === t.class && t.item[0].content.desktop ? o("img", {
                            attrs: {
                                src: "".concat(t.item[0].content.desktop),
                                alt: "loudspeaker"
                            }
                        }) : "Light" === t.class && t.item[0].content.desktop || "Deep Gray" === t.class && t.item[0].content.desktop ? o("img", {
                            attrs: {
                                src: "".concat(t.item[0].content.desktop),
                                alt: "gift"
                            }
                        }) : "Dark" === t.class && t.item[0].content.desktop ? o("img", {
                            attrs: {
                                src: "".concat(t.item[0].content.desktop),
                                alt: "tree"
                            }
                        }) : e._e(), e._v(" "), o("span", {
                            attrs: {
                                title: e.allDescription(t.description)
                            }
                        }, [e._v("\n          " + e._s(e.hideDescription(t.description)))])])
                    })), e._v(" "), o("a", {
                        staticClass: "final",
                        class: [e.$style.bannerPromotionBarWrapper],
                        attrs: {
                            href: e.getBannerPromotionBar[0].link ? e.getBannerPromotionBar[0].link : null,
                            target: e.getBannerPromotionBar[0].target ? e.getBannerPromotionBar[0].target : "_self",
                            rel: "_blank" === e.getBannerPromotionBar[0].target ? "noopener noreferrer" : ""
                        },
                        on: {
                            click: function(t) {
                                return t.preventDefault(), t.stopPropagation(), e.gaClickHandler(e.getBannerPromotionBar[0], e.getBannerPromotionBar[0].target, 0)
                            }
                        }
                    }, [e.getBannerPromotionBar && "Default" === e.getBannerPromotionBar[0].class && e.getBannerPromotionBar[0].item[0].content.desktop || e.getBannerPromotionBar && "White" === e.getBannerPromotionBar[0].class && e.getBannerPromotionBar[0].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[0].item[0].content.desktop),
                            alt: "loudspeaker"
                        }
                    }) : e.getBannerPromotionBar && "Light" === e.getBannerPromotionBar[0].class && e.getBannerPromotionBar[0].item[0].content.desktop || e.getBannerPromotionBar && "Deep Gray" === e.getBannerPromotionBar[0].class && e.getBannerPromotionBar[0].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[0].item[0].content.desktop),
                            alt: "gift"
                        }
                    }) : e.getBannerPromotionBar && "Dark" === e.getBannerPromotionBar[0].class && e.getBannerPromotionBar[0].item[0].content.desktop ? o("img", {
                        attrs: {
                            src: "".concat(e.getBannerPromotionBar[0].item[0].content.desktop),
                            alt: "tree"
                        }
                    }) : e._e(), e._v(" "), o("span", {
                        attrs: {
                            title: e.allDescription(e.getBannerPromotionBar[0].description)
                        }
                    }, [e._v(e._s(e.hideDescription(e.getBannerPromotionBar[0].description)))])])], 2)]), e._v(" "), o("button", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: e.bannerPromotionBarNumber > 1,
                            expression: "bannerPromotionBarNumber > 1"
                        }],
                        class: e.$style.button,
                        attrs: {
                            "aria-label": "next banner"
                        },
                        on: {
                            click: function(t) {
                                return e.next()
                            }
                        }
                    }, [o("svg", {
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            "data-name": "圖層 1",
                            viewBox: "0 0 32 32",
                            "svg-inline": "",
                            alt: "slide next",
                            role: "presentation",
                            focusable: "false"
                        }
                    }, [o("path", {
                        attrs: {
                            d: "M23.07 13.77L9.06 0v6.7l9.18 8.94-9.18 9.66V32l14.01-14.49 1.87-1.87-1.87-1.87z"
                        }
                    })])])]) : e._e()
                }), [], !1, (function(t) {
                    this.$style = y.default.locals || y.default
                }), null, null).exports,
                B = o(79),
                P = function() {
                    var t = function(e, b) {
                        return t = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(t, b) {
                            t.__proto__ = b
                        } || function(t, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                        }, t(e, b)
                    };
                    return function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function o() {
                            this.constructor = e
                        }
                        t(e, b), e.prototype = null === b ? Object.create(b) : (o.prototype = b.prototype, new o)
                    }
                }(),
                O = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                j = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.bannerGAStatus = !1, e.isShowContent = !1, e.isMobile = !1, e.isShowRightButton = !1, e.isShowLeftButton = !1, e.isShowPlayButton = !1, e.slideController = !1, e.progressTimer = null, e.progressTime = 0, e.progressPercent = 0, e.nowNumber = 0, e.nowPointNumber = -1, e.autoStatus = null, e.reAutoInterval = null, e.reAutoStatus = !1, e.promotionBannerStatus = !0, e.mainImage = "", e.moveDelta = 0, e.randomTime = 5e3, e.defaultX = 0, e.showImage = !1, e
                    }
                    return P(e, t), e.prototype.watchProgressPercent = function(t) {
                        100 === t && this.nextButton()
                    }, e.prototype.watchBannerPromotionBart = function(t) {
                        Object.keys(t).length > 0 ? this.promotionBannerStatus = !0 : this.promotionBannerStatus = !1
                    }, Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "bannerLength", {
                        get: function() {
                            return this.banner && Object.keys(this.banner).length > 0 ? (this.checkImageData(), Object.keys(this.banner).length) : 0
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "widthSize", {
                        get: function() {
                            return "undefined" != typeof window ? Object(B.a)().width : 1520
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.mounted = function() {
                        var t = this;
                        window.addEventListener("resize", (function() {
                            t.checkMobileStatus()
                        })), this.checkMobileStatus(), setTimeout((function() {
                            t.nowPointNumber = 0, t.autoSlideShowHandler(), t.progressBarHandler()
                        }), 150), this.defaultX = window.innerWidth / 2
                    }, e.prototype.moreButton = function(t) {
                        return t.filter((function(t) {
                            return "more" === t.flag
                        }))[0]
                    }, e.prototype.buyButton = function(t) {
                        return t.filter((function(t) {
                            return "buy" === t.flag
                        }))[0]
                    }, e.prototype.positionSetting = function(t) {
                        return t.filter((function(t) {
                            return "position" === t.flag
                        })).length > 0 ? t.filter((function(t) {
                            return "position" === t.flag
                        }))[0].content : ""
                    }, e.prototype.progressBarHandler = function() {
                        var t = this;
                        this.progressTimer = 0, this.slideController = !0, this.randomTime = 5e3, this.progressTime = this.randomTime / 100, this.progressPercent = 0, this.progressTimer = setInterval((function() {
                            !0 === t.slideController && t.progressPercent < 100 && t.progressPercent++, t.progressPercent >= 100 ? clearInterval(t.progressTimer) : t.progressTimer = null
                        }), this.progressTime)
                    }, e.prototype.reAutoHandler = function() {
                        var t = this;
                        this.reAutoInterval = setInterval((function() {
                            t.reAutoStatus && (t.autoSlideShowHandler(), t.reAutoStatus = !1)
                        }), 0)
                    }, e.prototype.autoSlideShowHandler = function() {
                        var t = this,
                            e = Object.keys(this.banner).length;
                        this.randomTime = 5e3, this.autoStatus = setInterval((function() {
                            1 === t.bannerLength && (clearInterval(t.autoStatus), clearInterval(t.progressTimer), t.reAutoStatus = !1, t.slideController = !1), t.nowPointNumber === e - 1 ? (t.moveDelta = 0, t.nowNumber = 0, t.nowPointNumber = t.nowNumber, t.progressBarHandler(), clearInterval(t.progressTimer)) : (t.moveDelta = t.moveDelta - 100, t.nowNumber++, t.nowPointNumber = t.nowNumber, t.progressBarHandler(), clearInterval(t.progressTimer))
                        }), this.randomTime)
                    }, e.prototype.checkMobileStatus = function() {
                        Object(B.a)().width > 1024 ? this.isMobile = !1 : this.isMobile = !0
                    }, e.prototype.checkImageData = function() {
                        "undefined" == typeof window || this.bannerGAStatus || this.gaHandler()
                    }, e.prototype.startHandler = function(t) {
                        this.defaultX = t.touches[0].clientX
                    }, e.prototype.endHandler = function(t) {
                        var e = t.changedTouches[0].clientX - this.defaultX;
                        Math.abs(e) > 20 && (e < 0 ? this.nextButton() : this.prevButton())
                    }, e.prototype.showPromotionHandler = function(t) {
                        this.promotionBannerStatus = t
                    }, e.prototype.showButtonHandler = function(t, e) {
                        "right" === t ? this.isShowRightButton = !0 : this.isShowLeftButton = !0
                    }, e.prototype.hideButtonHandler = function(t, e) {
                        "right" === t ? this.isShowRightButton = !1 : this.isShowLeftButton = !1
                    }, e.prototype.prevButton = function() {
                        clearInterval(this.autoStatus), this.progressPercent = 0, this.playSlide(), 0 === this.moveDelta ? (this.moveDelta = 100 * (Object.keys(this.banner).length - 1) * -1, this.nowNumber = Object.keys(this.banner).length - 1, this.nowPointNumber = this.nowNumber) : (this.moveDelta = this.moveDelta + 100, this.nowNumber--, this.nowPointNumber = this.nowNumber)
                    }, e.prototype.nextButton = function() {
                        clearInterval(this.autoStatus), this.progressPercent = 0, this.playSlide(), this.nowPointNumber === Object.keys(this.banner).length - 1 ? (this.moveDelta = 0, this.nowNumber = 0, this.nowPointNumber = this.nowNumber) : (this.moveDelta = this.moveDelta - 100, this.nowNumber++, this.nowPointNumber = this.nowNumber)
                    }, e.prototype.clickBannerPoint = function(t, e) {
                        e.preventDefault(), clearInterval(this.autoStatus), this.progressPercent = 0, this.playSlide(), this.moveDelta = 100 * t * -1, this.nowNumber = t, this.nowPointNumber = this.nowNumber
                    }, e.prototype.switchSlide = function() {
                        this.isShowPlayButton ? this.playSlide() : this.pauseSlide()
                    }, e.prototype.playSlide = function() {
                        this.reAutoHandler(), this.reAutoStatus = !0, this.slideController = !0, this.isShowPlayButton = !1
                    }, e.prototype.pauseSlide = function() {
                        clearInterval(this.autoStatus), this.reAutoStatus = !1, this.slideController = !1, this.isShowPlayButton = !0
                    }, e.prototype.windowHandler = function(t) {
                        var e = t,
                            o = document.createElement("div");
                        o.innerHTML = e;
                        var n = o.querySelector("a").getAttribute("href");
                        window.location.assign(n)
                    }, Object.defineProperty(e.prototype, "MDAUrl", {
                        get: function() {
                            if ("undefined" != typeof window && this.banner && Object.keys(this.banner).length > 0) {
                                var t = document.createElement("div"),
                                    e = !1,
                                    o = "";
                                return this.banner.forEach((function(n) {
                                    !e && n.mdaTag && n.mdaTag.taglineImgUrl && "" !== n.mdaTag.taglineImgUrl && (e = !0, t.innerHTML = n.mdaTag.taglineImgUrl, o = t.querySelector("img").getAttribute("src"))
                                })), "background:url(".concat(o, ")")
                            }
                            return ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.gaHandler = function() {
                        var t = this;
                        if (this.banner && Object.keys(this.banner).length > 0) {
                            var e = [];
                            this.banner.forEach((function(o) {
                                e.push({
                                    id: t.isMobile ? o.mobileItem[0].content.mobile : o.item[0].content.desktop,
                                    name: o.bannerName.replace(/-/g, "_").replace(/ /g, "_"),
                                    position: t.getBannerPosition()
                                })
                            })), "cn" !== this.routeInfo.websitePath && setTimeout((function() {
                                window.dataLayer.push({
                                    event: "promotionView",
                                    ecommerce: {
                                        promoView: {
                                            promotions: e
                                        }
                                    }
                                })
                            }), 100)
                        }
                        this.bannerGAStatus = !0
                    }, e.prototype.gaClickHandler = function(t, e, o) {
                        var n = this;
                        o.srcElement.offsetParent.className.indexOf("MDA") > -1 ? window.location.assign(o.srcElement.offsetParent.children[0].href) : "rog.asus.com.cn" !== window.location.host ? (setTimeout((function() {
                            window.dataLayer.push({
                                event: "promotionClick",
                                ecommerce: {
                                    promoClick: {
                                        promotions: [{
                                            id: n.isMobile ? t.mobileItem[0].content.mobile : t.item[0].content.desktop,
                                            name: t.bannerName.replace(/-/g, "_").replace(/ /g, "_"),
                                            position: n.getBannerPosition()
                                        }]
                                    }
                                },
                                eventCallback: function() {}
                            })
                        }), 100), e ? window.open(t.link, e) : window.location.assign(t.link)) : e ? window.open(t.link, e) : window.location.assign(t.link)
                    }, e.prototype.getBannerPosition = function() {
                        var t = this.routeInfo.levelTagId,
                            e = this.routeInfo.type;
                        return null == t ? "hero_banner" : "Group" === e ? "banner_1_L2" : "Series" === e ? "banner_1_L3" : void 0
                    }, e.prototype.bannerLearnMore = function(t) {
                        window.location.assign(t.link)
                    }, e.prototype.gotoBuyPage = function(t) {
                        window.location.assign(t.link)
                    }, e.prototype.gotoVideoPage = function(t) {
                        window.location.assign(t.link)
                    }, O([Object(d.Getter)("banner")], e.prototype, "banner", void 0), O([Object(d.Getter)("bannerMainImage")], e.prototype, "bannerMainImage", void 0), O([Object(d.Getter)("bannerMobileMainImage")], e.prototype, "bannerMobileMainImage", void 0), O([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), O([Object(d.Getter)("translation")], e.prototype, "translation", void 0), O([Object(d.Getter)("bannerPromotionBar")], e.prototype, "bannerPromotionBar", void 0), O([Object(d.Getter)("mappingWebsite")], e.prototype, "mappingWebsite", void 0), O([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "showBanner", void 0), O([Object(c.Prop)({
                        default: !0
                    })], e.prototype, "isFullSize", void 0), O([Object(c.Prop)({
                        default: 0
                    })], e.prototype, "bannerNumber", void 0), O([Object(c.Prop)({
                        default: "pc"
                    })], e.prototype, "userDeviceValue", void 0), O([Object(c.Watch)("progressPercent")], e.prototype, "watchProgressPercent", null), O([Object(c.Watch)("bannerPromotionBar", {
                        immediate: !0,
                        deep: !0
                    })], e.prototype, "watchBannerPromotionBart", null), e = O([Object(c.Component)({
                        components: {
                            BannerPromotionBar: w
                        }
                    })], e)
                }(c.Vue),
                k = j,
                I = o(968);
            var S = Object(v.a)(k, (function() {
                var t, e, o = this,
                    n = o._self._c;
                o._self._setupProxy;
                return o.banner.length > 0 ? n("div", {
                    class: [o.$style.bannerWrapper, Object(r.a)({}, o.$style.showPromotionBanner, o.promotionBannerStatus)],
                    on: {
                        touchstart: function(t) {
                            return o.startHandler(t)
                        },
                        touchend: function(t) {
                            return o.endHandler(t)
                        }
                    }
                }, [n("BannerPromotionBar", {
                    attrs: {
                        userDeviceValue: o.userDeviceValue
                    },
                    on: {
                        showPromotion: o.showPromotionHandler
                    }
                }), o._v(" "), n("div", {
                    class: o.$style.bannerSlideContent
                }, [n("div", {
                    class: o.$style.bannerContent,
                    style: "width:".concat(100 * o.banner.length, "vw;"),
                    attrs: {
                        role: "tree",
                        "aria-label": "banner content"
                    }
                }, o._l(o.banner, (function(t, e) {
                    var l, c, d, m, h;
                    return n("div", {
                        key: e,
                        class: [o.$style.bannerContainer, (l = {}, Object(r.a)(l, o.$style.active, e === o.nowNumber), Object(r.a)(l, o.$style.show, o.showBanner), Object(r.a)(l, o.$style.noFullSize, !o.isFullSize), l)],
                        attrs: {
                            role: "presentation"
                        }
                    }, [n("a", {
                        class: [o.$style.bannerLink, {
                            firstSlideShowItem: 0 === e
                        }],
                        attrs: {
                            role: "treeitem",
                            "aria-label": "".concat("" !== t.description ? t.description : null),
                            tabindex: e === o.nowNumber ? 0 : -1,
                            id: "rogContent".concat(0 === e ? "" : e),
                            href: t.link
                        },
                        on: {
                            click: function(e) {
                                return e.preventDefault(), e.stopPropagation(), o.gaClickHandler(t, "_blank", e)
                            }
                        }
                    }, [n("div", {
                        class: [o.$style.bannerImageWrapper]
                    }, [null != t && t.mdaTag && null != t && null !== (c = t.mdaTag) && void 0 !== c && c.taglineImgUrl && "" !== (null == t || null === (d = t.mdaTag) || void 0 === d ? void 0 : d.taglineImgUrl) ? n("div", {
                        class: o.$style.MDA,
                        style: "".concat(o.MDAUrl, ";background-size:contain;background-repeat:no-repeat;"),
                        attrs: {
                            role: "link",
                            "aria-label": "ASUS recommends Windows 11 Pro for business.",
                            tabindex: "0"
                        },
                        on: {
                            keydown: function(e) {
                                var n;
                                return !e.type.indexOf("key") && o._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : o.windowHandler(null == t || null === (n = t.mdaTag) || void 0 === n ? void 0 : n.taglineImgUrl)
                            },
                            click: function(e) {
                                var n;
                                return e.target !== e.currentTarget ? null : o.windowHandler(null == t || null === (n = t.mdaTag) || void 0 === n ? void 0 : n.taglineImgUrl)
                            }
                        }
                    }) : o._e(), o._v(" "), 0 === e ? [n("picture", [n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.mobileItem[0].content.mobile, "/w430/fwebp")),
                            media: "(max-width:430px)"
                        }
                    }), o._v(" "), n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.mobileItem[0].content.mobile)),
                            media: "(max-width:768px)"
                        }
                    }), o._v(" "), n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.item[0].content.desktop, "/fwebp"))
                        }
                    }), o._v(" "), n("img", {
                        class: o.$style.bannerImage,
                        attrs: {
                            fetchpriority: "high",
                            src: encodeURI("".concat(t.item[0].content.desktop)),
                            alt: t.alt,
                            tabindex: e === o.nowNumber ? 0 : -1,
                            loading: 0 === e ? "eager" : "lazy"
                        }
                    })])] : [n("ClientOnly", [n("picture", [n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.mobileItem[0].content.mobile, "/w430/fwebp")),
                            media: "(max-width:430px)"
                        }
                    }), o._v(" "), n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.mobileItem[0].content.mobile)),
                            media: "(max-width:768px)"
                        }
                    }), o._v(" "), n("source", {
                        attrs: {
                            srcset: encodeURI("".concat(t.item[0].content.desktop, "/fwebp"))
                        }
                    }), o._v(" "), n("img", {
                        class: o.$style.bannerImage,
                        attrs: {
                            src: encodeURI("".concat(t.item[0].content.desktop)),
                            alt: t.alt,
                            tabindex: e === o.nowNumber ? 0 : -1,
                            loading: 0 === e ? "eager" : "lazy"
                        }
                    })])])], o._v(" "), o.isMobile ? [n("div", {
                        staticClass: "mobileTextContent",
                        class: [o.$style.textContent, (h = {}, Object(r.a)(h, o.$style.active, e === o.nowNumber), Object(r.a)(h, o.$style.top, "Top" === o.positionSetting(null == t ? void 0 : t.mobileItem)), Object(r.a)(h, o.$style.bottom, "Bottom" === o.positionSetting(null == t ? void 0 : t.mobileItem)), Object(r.a)(h, o.$style.left, "Left" === o.positionSetting(null == t ? void 0 : t.mobileItem) || "" === o.positionSetting(null == t ? void 0 : t.mobileItem)), Object(r.a)(h, o.$style.right, "Right" === o.positionSetting(null == t ? void 0 : t.mobileItem)), Object(r.a)(h, o.$style.center, "Center" === o.positionSetting(null == t ? void 0 : t.mobileItem)), h)]
                    }, [n("h2", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.mobileItem[1].show,
                            expression: "objMain.mobileItem[1].show === 1"
                        }],
                        staticClass: "bannerTitle"
                    }, [o._v(o._s(t.mobileItem[1].content))]), o._v(" "), n("h3", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.mobileItem[2].show,
                            expression: "objMain.mobileItem[2].show === 1"
                        }],
                        staticClass: "subTitle"
                    }, [o._v(o._s(t.mobileItem[2].content))]), o._v(" "), n("p", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.mobileItem[3].show,
                            expression: "objMain.mobileItem[3].show === 1"
                        }],
                        staticClass: "description"
                    }, [o._v(o._s(t.mobileItem[3].content))]), o._v(" "), n("div", {
                        class: o.$style.buttonGroup
                    }, [1 === o.moreButton(t.mobileItem).show ? n("button", {
                        attrs: {
                            type: "button",
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                e.preventDefault(), e.stopPropagation(), o.bannerLearnMore(o.moreButton(t.mobileItem))
                            }
                        }
                    }, [o._v(o._s(o.moreButton(t.mobileItem).content))]) : o._e(), o._v(" "), 1 === o.buyButton(t.mobileItem).show ? n("button", {
                        attrs: {
                            type: "button",
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                e.preventDefault(), e.stopPropagation(), o.gotoVideoPage(o.buyButton(t.mobileItem))
                            }
                        }
                    }, [o._v(o._s(o.buyButton(t.mobileItem).content))]) : o._e()])])] : [n("div", {
                        class: [o.$style.textContent, (m = {}, Object(r.a)(m, o.$style.active, e === o.nowNumber), Object(r.a)(m, o.$style.top, "Top" === o.positionSetting(null == t ? void 0 : t.item)), Object(r.a)(m, o.$style.bottom, "Bottom" === o.positionSetting(null == t ? void 0 : t.item)), Object(r.a)(m, o.$style.left, "Left" === o.positionSetting(null == t ? void 0 : t.item) || "" === o.positionSetting(null == t ? void 0 : t.item)), Object(r.a)(m, o.$style.right, "Right" === o.positionSetting(null == t ? void 0 : t.item)), Object(r.a)(m, o.$style.center, "Center" === o.positionSetting(null == t ? void 0 : t.item)), m)]
                    }, [n("h2", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.item[1].show,
                            expression: "objMain.item[1].show === 1"
                        }],
                        staticClass: "bannerTitle"
                    }, [o._v(o._s(t.item[1].content))]), o._v(" "), n("h3", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.item[2].show,
                            expression: "objMain.item[2].show === 1"
                        }],
                        staticClass: "subTitle"
                    }, [o._v(o._s(t.item[2].content))]), o._v(" "), n("p", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 1 === t.item[3].show,
                            expression: "objMain.item[3].show === 1"
                        }],
                        staticClass: "description"
                    }, [o._v(o._s(t.item[3].content))]), o._v(" "), n("div", {
                        class: o.$style.buttonGroup
                    }, [1 === o.moreButton(t.item).show ? n("button", {
                        attrs: {
                            type: "button",
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                e.preventDefault(), e.stopPropagation(), o.bannerLearnMore(o.moreButton(t.item))
                            }
                        }
                    }, [o._v(o._s(o.moreButton(t.item).content))]) : o._e(), o._v(" "), 1 === o.buyButton(t.item).show ? n("button", {
                        attrs: {
                            type: "button",
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                e.preventDefault(), e.stopPropagation(), o.gotoVideoPage(o.buyButton(t.item))
                            }
                        }
                    }, [o._v(o._s(o.buyButton(t.item).content))]) : o._e()])])]], 2)])])
                })), 0), o._v(" "), n("a", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: o.bannerLength > 1 && !o.isMobile,
                        expression: "bannerLength > 1 && !isMobile"
                    }],
                    class: o.$style.bannerHoverLeft,
                    attrs: {
                        href: null === (t = o.banner[o.nowNumber]) || void 0 === t ? void 0 : t.link
                    },
                    on: {
                        mouseenter: function(t) {
                            return o.showButtonHandler("left", t)
                        },
                        mouseleave: function(t) {
                            return o.hideButtonHandler("left", t)
                        }
                    }
                }, [n("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !o.isMobile,
                        expression: "!isMobile"
                    }],
                    class: [o.$style.leftButton, Object(r.a)({}, o.$style.active, o.isShowLeftButton)],
                    attrs: {
                        "aria-label": "Previous slide",
                        type: "button",
                        tabindex: "0"
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), t.stopPropagation(), o.prevButton()
                        },
                        focus: function(t) {
                            return o.showButtonHandler("left", t)
                        },
                        blur: function(t) {
                            return o.hideButtonHandler("left", t)
                        }
                    }
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "slide prev",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M7.95 15.06L22.99 0v3.37L10.38 16.01l12.61 12.62V32L7.95 16.95l-.94-.94.94-.95z"
                    }
                })])])]), o._v(" "), n("a", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: o.bannerLength > 1 && !o.isMobile,
                        expression: "bannerLength > 1 && !isMobile"
                    }],
                    class: o.$style.bannerHoverRight,
                    attrs: {
                        href: null === (e = o.banner[o.nowNumber]) || void 0 === e ? void 0 : e.link
                    },
                    on: {
                        mouseenter: function(t) {
                            return o.showButtonHandler("right", t)
                        },
                        mouseleave: function(t) {
                            return o.hideButtonHandler("right", t)
                        }
                    }
                }, [n("button", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !o.isMobile,
                        expression: "!isMobile"
                    }],
                    class: [o.$style.rightButton, Object(r.a)({}, o.$style.active, o.isShowRightButton)],
                    attrs: {
                        "aria-label": "Next slide",
                        type: "button",
                        tabindex: "0"
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), t.stopPropagation(), o.nextButton()
                        },
                        focus: function(t) {
                            return o.showButtonHandler("right", t)
                        },
                        blur: function(t) {
                            return o.hideButtonHandler("right", t)
                        }
                    }
                }, [n("svg", {
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        alt: "slide next",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M24.05 15.06L9.01 0v3.37l12.61 12.64L9.01 28.63V32l15.04-15.05.94-.94-.94-.95z"
                    }
                })])])])]), o._v(" "), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: o.bannerLength > 1,
                        expression: "bannerLength > 1"
                    }],
                    class: o.$style.bannerPoints,
                    attrs: {
                        role: "navigation",
                        "aria-label": "banner nav"
                    }
                }, [o._l(o.banner, (function(t, e) {
                    return n("button", {
                        key: e,
                        class: o.$style.lineContent,
                        style: "width:".concat(o.widthSize > 1024 ? "60px" : "calc(100vw / " + (o.bannerLength + 2) + ")"),
                        attrs: {
                            role: "button",
                            "aria-label": "click ".concat(o.translation.Aria_Banner_Slide, " ").concat(e + 1)
                        },
                        on: {
                            keydown: function(t) {
                                return !t.type.indexOf("key") && o._k(t.keyCode, "space", 32, t.key, [" ", "Spacebar"]) ? null : o.clickBannerPoint(e, t)
                            },
                            click: function(t) {
                                return t.preventDefault(), t.stopPropagation(), o.clickBannerPoint(e, t)
                            }
                        }
                    }, [n("div", {
                        class: o.$style.line
                    }, [n("span", {
                        class: o.$style.progress,
                        style: e === o.nowPointNumber ? "width: ".concat(o.progressPercent, "%") : "width: 0%"
                    })])])
                })), o._v(" "), n("button", {
                    class: o.$style.slideController,
                    attrs: {
                        type: "button",
                        tabindex: "0",
                        role: "button",
                        "aria-label": o.isShowPlayButton ? "".concat(o.translation.Aria_Play, " ").concat(o.translation.Aria_Banner_Slide) : "".concat(o.translation.Aria_Pause, " ").concat(o.translation.Aria_Banner_Slide)
                    },
                    on: {
                        click: function(t) {
                            return t.preventDefault(), t.stopPropagation(), o.switchSlide.apply(null, arguments)
                        }
                    }
                }, [n("svg", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: o.isShowPlayButton,
                        expression: "isShowPlayButton"
                    }],
                    class: o.$style.play,
                    attrs: {
                        xmlns: "http://www.w3.org/2000/svg",
                        "data-name": "圖層 1",
                        viewBox: "0 0 32 32",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("path", {
                    attrs: {
                        d: "M26.7 15.24L6 3v26l20.7-12.23L28 16l-1.3-.76z"
                    }
                })]), o._v(" "), n("svg", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: !o.isShowPlayButton,
                        expression: "!isShowPlayButton"
                    }],
                    class: o.$style.pause,
                    attrs: {
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "svg-inline": "",
                        "aria-hidden": "true",
                        alt: "",
                        role: "presentation",
                        focusable: "false"
                    }
                }, [n("g", {
                    attrs: {
                        "fill-rule": "evenodd",
                        "clip-rule": "evenodd",
                        fill: "#999"
                    }
                }, [n("path", {
                    attrs: {
                        opacity: ".2",
                        d: "M6.37 4h4.5v16h-4.5V4zm6.75 0h4.5v16h-4.5V4z"
                    }
                }), n("path", {
                    attrs: {
                        d: "M9.88 19V5h-2.5v14h2.5zM6.38 4h4.5v16h-4.5V4zm10.24 15V5h-2.5v14h2.5zm-3.5-15h4.5v16h-4.5V4z",
                        "fill-opacity": ".5"
                    }
                })])])])], 2)], 1) : o._e()
            }), [], !1, (function(t) {
                this.$style = I.default.locals || I.default
            }), null, null);
            e.a = S.exports
        },
        949: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = (o(26), o(43), o(46), o(9)),
                c = (o(54), o(41), o(10), o(78), o(91), o(18), o(33), o(103), o(3)),
                d = o(144),
                m = o(7),
                h = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                f = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                _ = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.checked = !1, e.buyButtonData = {
                            name: "BUY NOW",
                            disabled: !1
                        }, e
                    }
                    return h(e, t), e.prototype.watchCompareData = function() {
                        var t = this,
                            e = !0;
                        this.compareSelect.map((function(o) {
                            o.key === t.productId && (e = !1)
                        })), e && (this.checked = !1)
                    }, e.prototype.hideNA = function(t) {
                        var e = new RegExp(/N\/A/gim);
                        return !t.match(e)
                    }, f([Object(m.Action)("getCompareSelect")], e.prototype, "getCompareSelect", void 0), f([Object(m.Getter)("compareSelect")], e.prototype, "compareSelect", void 0), f([Object(c.Prop)()], e.prototype, "productId", void 0), f([Object(c.Prop)()], e.prototype, "isDisable", void 0), f([Object(c.Prop)()], e.prototype, "skuData", void 0), f([Object(c.Watch)("compareSelect")], e.prototype, "watchCompareData", null), e = f([Object(c.Component)({
                        components: {
                            ButtonRed: d.a
                        }
                    })], e)
                }(c.Vue),
                y = _,
                v = o(1190),
                w = o(25);
            var component = Object(w.a)(y, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: [t.$style.compareResultItem, Object(r.a)({}, t.$style.firstItem, 1 === t.productId)]
                }, [e("div", {
                    class: t.$style.compareResultItemImage
                }, [e("img", {
                    attrs: {
                        src: encodeURI(t.skuData.productImgUrl),
                        alt: ""
                    }
                })]), t._v(" "), e("div", {
                    class: t.$style.compareProduct
                }, [e("p", {
                    class: t.$style.compareProductName
                }, [t._v(t._s(t.skuData.name))]), t._v(" "), e("p", {
                    class: t.$style.compareProductPrice
                })]), t._v(" "), e("div", {
                    class: t.$style.compareResultItemButton
                }, [e("div", {
                    class: t.$style.compareResultItemButtonWrapper
                }, [t.skuData.buyLink ? e("ButtonRed", {
                    attrs: {
                        "button-data": t.buyButtonData,
                        "is-max-width": !0
                    }
                }) : t._e()], 1)]), t._v(" "), t._l(t.skuData.specContent, (function(o, n) {
                    return e("div", {
                        key: n,
                        class: t.$style.compareResultItemRow
                    }, [e("div", {
                        class: t.$style.compareResultItemTitle
                    }, [e("p", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: 0 === t.productId,
                            expression: "productId === 0"
                        }]
                    }, [t._v(t._s(o.displayField))])]), t._v(" "), t._l(o.description, (function(o, n) {
                        return e("div", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: t.hideNA(o.displayDescription),
                                expression: "hideNA(description.displayDescription)"
                            }],
                            key: n,
                            class: t.$style.rowDescriptionItem
                        }, [e("span", {
                            class: t.$style.rowDescriptionItemName,
                            domProps: {
                                innerHTML: t._s(o.item)
                            }
                        }), t._v(" "), e("span", {
                            domProps: {
                                innerHTML: t._s(o.displayDescription)
                            }
                        })])
                    }))], 2)
                }))], 2)
            }), [], !1, (function(t) {
                this.$style = v.default.locals || v.default
            }), null, null);
            e.a = component.exports
        },
        953: function(t, e, o) {
            "use strict";
            o(60), o(43), o(46);
            var n, r = o(9),
                l = (o(54), o(41), o(10), o(28), o(26), o(18), o(29), o(20), o(22)),
                c = o(148),
                d = o(401),
                m = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                h = function(t, e, o, desc) {
                    var n, l = arguments.length,
                        c = l < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (l < 3 ? n(c) : l > 3 ? n(e, o, c) : n(e, o)) || c);
                    return l > 3 && c && Object.defineProperty(e, o, c), c
                },
                f = function(t) {
                    function e() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return m(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            var t, e = "";
                            return Object.keys(this.routeInfo).length > 0 ? e = null === (t = this.routeInfo) || void 0 === t ? void 0 : t.websitePath : "undefined" != typeof window && (null === window || void 0 === window ? void 0 : window.AsusAPIConfig) && (e = window.AsusAPIConfig.websitePath), e
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "pageStatus", {
                        get: function() {
                            return "Article" === this.$route.name ? "article_home" : "ArticleProductCategory" === this.$route.name ? "article_category" : "ArticleTag" === this.$route.name ? "article_tag" : "article_home"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "getCategoryName", {
                        get: function() {
                            return "Article" === this.$route.name ? this.articleItemData.categoryName : "ArticleProductCategory" === this.$route.name || "ArticleTag" === this.$route.name ? this.articleCategory : this.articleItemData.categoryName
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "link", {
                        get: function() {
                            return "undefined" != typeof window && "localhost:8000" === encodeURI(window.location.host) ? this.articleItemData.link.replace("https://stage-rog.asus.com", "http://localhost:8000") : this.articleItemData.link
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.beforeMount = function() {}, e.prototype.mounted = function() {}, e.prototype.gaItemHandler = function() {
                        window.dataLayer.push({
                            event: "data_layer_event",
                            event_name_ga4: "click_article_card",
                            event_category_DL: "recent_article/".concat(this.pageStatus, "/rog"),
                            event_action_DL: "clicked",
                            event_label_DL: "".concat(this.articleItemData.title, "/").concat(this.articleNumber, "/").concat(this.articleCategory, "/recent_article/").concat(this.pageStatus, "/rog"),
                            event_value_DL: ""
                        }), window.location.href = this.link
                    }, h([Object(l.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), h([Object(l.Getter)("mappingWebsiteId")], e.prototype, "mappingWebsiteId", void 0), h([Object(l.Getter)("translation")], e.prototype, "translation", void 0), h([Object(l.Getter)("routeQuery")], e.prototype, "routeQuery", void 0), h([Object(l.Getter)("articleList")], e.prototype, "articleList", void 0), h([Object(l.Prop)({
                        default: []
                    })], e.prototype, "articleItemData", void 0), h([Object(l.Prop)({
                        default: 0
                    })], e.prototype, "articleNumber", void 0), h([Object(l.Prop)({
                        default: "default"
                    })], e.prototype, "articleCategory", void 0), e = h([c.Jsonld, Object(l.Component)({
                        components: {}
                    })], e)
                }(Object(l.mixins)(d.a)),
                _ = f,
                y = o(1212),
                v = o(25);
            var component = Object(v.a)(_, (function() {
                var t = this,
                    e = t._self._c;
                t._self._setupProxy;
                return e("div", {
                    class: t.$style.articleItem
                }, [e("a", {
                    attrs: {
                        href: t.link
                    },
                    on: {
                        click: function(e) {
                            return e.preventDefault(), t.gaItemHandler.apply(null, arguments)
                        }
                    }
                }, [e("div", {
                    class: t.$style.photo
                }, [e("img", {
                    attrs: {
                        src: t.articleItemData.imageUrl ? t.articleItemData.imageUrl : "/dist/img/rog-404.jpg",
                        alt: t.articleItemData.title
                    }
                })]), t._v(" "), e("div", {
                    class: t.$style.category
                }, [e("span", [t._v("//")]), t._v(" "), e("span", [t._v(t._s(t.getCategoryName))])]), t._v(" "), e("div", {
                    class: t.$style.title
                }, [e("h2", {
                    class: [{
                        jpFont: "jp" === t.lang
                    }]
                }, [t._v(t._s(t.articleItemData.title))])]), t._v(" "), e("div", {
                    class: t.$style.description
                }, [e("p", [t._v(t._s(t.articleItemData.description))])])]), t._v(" "), e("div", {
                    class: t.$style.corner1
                }), t._v(" "), e("div", {
                    class: t.$style.corner2
                }), t._v(" "), e("div", {
                    class: t.$style.corner3
                }), t._v(" "), e("div", {
                    class: t.$style.corner4
                })])
            }), [], !1, (function(t) {
                this.$style = y.default.locals || y.default
            }), null, null);
            e.a = component.exports
        },
        954: function(t, e, o) {
            "use strict";
            var n, r = o(2),
                l = (o(20), o(60), o(9)),
                c = (o(54), o(41), o(10), o(59), o(3)),
                d = o(7),
                m = o(928),
                h = o(707),
                f = (n = function(t, b) {
                    return n = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(t, b) {
                        t.__proto__ = b
                    } || function(t, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (t[p] = b[p])
                    }, n(t, b)
                }, function(t, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function e() {
                        this.constructor = t
                    }
                    n(t, b), t.prototype = null === b ? Object.create(b) : (e.prototype = b.prototype, new e)
                }),
                _ = function(t, e, o, desc) {
                    var n, r = arguments.length,
                        c = r < 3 ? e : null === desc ? desc = Object.getOwnPropertyDescriptor(e, o) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(l.a)(Reflect)) && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, desc);
                    else
                        for (var i = t.length - 1; i >= 0; i--)(n = t[i]) && (c = (r < 3 ? n(c) : r > 3 ? n(e, o, c) : n(e, o)) || c);
                    return r > 3 && c && Object.defineProperty(e, o, c), c
                },
                y = function(t) {
                    function e() {
                        var e = null !== t && t.apply(this, arguments) || this;
                        return e.showAction = !0, e.isMobile = !1, e
                    }
                    return f(e, t), Object.defineProperty(e.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), Object.defineProperty(e.prototype, "area", {
                        get: function() {
                            return this.actionItemData.link.indexOf("https") > -1 || this.lang && "global" === this.lang.toLowerCase() ? "" : "/"
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.prototype.mounted = function() {
                        var t = this;
                        window.addEventListener("resize", (function() {
                            window.innerWidth <= 820 ? t.isMobile = !0 : t.isMobile = !1
                        }))
                    }, e.prototype.checkAction = function() {
                        var t, e, o;
                        (null === (t = this.$refs) || void 0 === t ? void 0 : t.actionItem) && Object(h.a)() > (null === (o = null === (e = this.$refs) || void 0 === e ? void 0 : e.actionItem) || void 0 === o ? void 0 : o.offsetTop) - window.screen.height && (this.showAction = !0)
                    }, e.prototype.gaDataLayer = function(t) {
                        setTimeout((function() {
                            "rog.asus.com.cn" !== window.location.host ? window.innerWidth > 1024 ? window.dataLayer.push({
                                event: "data_layer_event",
                                event_category_DL: "internal-links",
                                event_action_DL: "clicked",
                                event_label_DL: "".concat(t),
                                event_value_DL: "0"
                            }) : setTimeout((function() {
                                window.dataLayer.push({
                                    event: "data_layer_event",
                                    event_category_DL: "internal-links",
                                    event_action_DL: "clicked",
                                    event_label_DL: "".concat(t),
                                    event_value_DL: "0"
                                })
                            }), 200) : window._hmt && window._hmt.push(["_trackEvent", "internal-links", "clicked", "".concat(t)])
                        }), 100)
                    }, _([Object(d.Getter)("routeInfo")], e.prototype, "routeInfo", void 0), _([Object(d.Getter)("translation")], e.prototype, "translation", void 0), _([Object(c.Prop)()], e.prototype, "categoryType", void 0), _([Object(c.Prop)()], e.prototype, "actionItemData", void 0), _([Object(c.Prop)()], e.prototype, "actionPostContentType", void 0), _([Object(c.Prop)()], e.prototype, "itemNumber", void 0), _([Object(c.Prop)()], e.prototype, "itemTotalNumber", void 0), _([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isActive", void 0), _([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isBlackText", void 0), _([Object(c.Prop)({
                        default: !1
                    })], e.prototype, "isProductPage", void 0), e = _([Object(c.Component)({
                        components: {
                            ActionContent: m.a
                        }
                    })], e)
                }(c.Vue),
                v = y,
                w = o(972),
                B = o(25);
            var component = Object(B.a)(v, (function() {
                var t, e = this,
                    o = e._self._c;
                e._self._setupProxy;
                return o("a", {
                    ref: "actionItem",
                    class: [e.$style.actionsItem, (t = {}, Object(r.a)(t, e.$style.postProductHome, "product" === e.actionPostContentType), Object(r.a)(t, e.$style.active, e.showAction), Object(r.a)(t, e.$style.itemCenter, e.itemTotalNumber < 3 && e.itemTotalNumber > 1), Object(r.a)(t, e.$style.blackText, e.isBlackText), Object(r.a)(t, e.$style.whiteText, !e.isBlackText), Object(r.a)(t, e.$style.isProductPage, e.isProductPage), t)],
                    attrs: {
                        href: "".concat(e.area).concat(e.actionItemData.link)
                    },
                    on: {
                        click: function(t) {
                            return e.gaDataLayer(e.actionItemData.title)
                        }
                    }
                }, [o("div", {
                    class: e.$style.articleContentImage
                }, [o("ClientOnly", [o("img", {
                    staticClass: "recentStoryImage",
                    attrs: {
                        src: encodeURI("".concat(e.actionItemData.imageUrl)),
                        role: "presentation",
                        alt: "",
                        loading: "lazy"
                    }
                })])], 1), e._v(" "), o("ActionContent", {
                    attrs: {
                        pageType: e.actionPostContentType,
                        categoryType: e.categoryType,
                        actionItemContentData: e.actionItemData,
                        isBlackText: e.isBlackText
                    }
                })], 1)
            }), [], !1, (function(t) {
                this.$style = w.default.locals || w.default
            }), null, null);
            e.a = component.exports
        },
        967: function(t, e, o) {
            "use strict";
            var n = o(702),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        968: function(t, e, o) {
            "use strict";
            var n = o(703),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        971: function(t, e, o) {
            "use strict";
            var n = o(706),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        972: function(t, e, o) {
            "use strict";
            var n = o(708),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        973: function(t, e, o) {
            "use strict";
            var n = o(709),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        },
        991: function(t, e, o) {
            "use strict";
            var n = o(727),
                r = o.n(n);
            o.d(e, "default", (function() {
                return r.a
            }))
        }
    }
]);