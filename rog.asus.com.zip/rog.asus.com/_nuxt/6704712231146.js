(window.webpackJsonp_cj86gji4 = window.webpackJsonp_cj86gji4 || []).push([
    [11], {
        174: function(e, t, n) {
            e.exports = {
                errorContainer: "error__errorContainer__Qzd+B",
                rogLogoIcon: "error__rogLogoIcon__mpF0j",
                errorWrapper: "error__errorWrapper__pcbhN",
                errorContent: "error__errorContent__UsBN7",
                errorPatten: "error__errorPatten__HM52v",
                errorSlogan: "error__errorSlogan__Dkrbf",
                errorInfo: "error__errorInfo__oQncd",
                errorReturnLink: "error__errorReturnLink__DGG2q",
                returnIcon: "error__returnIcon__W50SR"
            }
        },
        186: function(e, t, n) {
            e.exports = {
                defaultWrapper: "default__defaultWrapper__ku4fA",
                showReminder: "default__showReminder__ZtGBO",
                showCookie: "default__showCookie__+LKUP"
            }
        },
        187: function(e, t, n) {
            "use strict";
            (function(e) {
                var o, r = n(9),
                    c = (n(54), n(41), n(10), n(43), n(46), n(52), n(37), n(38), n(26), n(47), n(70), n(20), n(33), n(59), n(146), n(18), n(121), n(29), n(22)),
                    d = n(405),
                    l = n(406),
                    h = n(200),
                    f = n(486),
                    m = n(88),
                    v = n(487),
                    w = n(488),
                    y = n(4),
                    W = n(1),
                    I = (o = function(e, b) {
                        return o = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, b) {
                            e.__proto__ = b
                        } || function(e, b) {
                            for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (e[p] = b[p])
                        }, o(e, b)
                    }, function(e, b) {
                        if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                        function t() {
                            this.constructor = e
                        }
                        o(e, b), e.prototype = null === b ? Object.create(b) : (t.prototype = b.prototype, new t)
                    }),
                    _ = function(e, t, n, desc) {
                        var o, c = arguments.length,
                            d = c < 3 ? t : null === desc ? desc = Object.getOwnPropertyDescriptor(t, n) : desc;
                        if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) d = Reflect.decorate(e, t, n, desc);
                        else
                            for (var i = e.length - 1; i >= 0; i--)(o = e[i]) && (d = (c < 3 ? o(d) : c > 3 ? o(t, n, d) : o(t, n)) || d);
                        return c > 3 && d && Object.defineProperty(t, n, d), d
                    },
                    A = function(e, t, n, o) {
                        return new(n || (n = Promise))((function(r, c) {
                            function d(e) {
                                try {
                                    h(o.next(e))
                                } catch (e) {
                                    c(e)
                                }
                            }

                            function l(e) {
                                try {
                                    h(o.throw(e))
                                } catch (e) {
                                    c(e)
                                }
                            }

                            function h(e) {
                                var t;
                                e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                                    e(t)
                                }))).then(d, l)
                            }
                            h((o = o.apply(e, t || [])).next())
                        }))
                    },
                    P = function(e, body) {
                        var t, n, o, g, r = {
                            label: 0,
                            sent: function() {
                                if (1 & o[0]) throw o[1];
                                return o[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return g = {
                            next: c(0),
                            throw: c(1),
                            return: c(2)
                        }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                            return this
                        }), g;

                        function c(c) {
                            return function(d) {
                                return function(c) {
                                    if (t) throw new TypeError("Generator is already executing.");
                                    for (; g && (g = 0, c[0] && (r = 0)), r;) try {
                                        if (t = 1, n && (o = 2 & c[0] ? n.return : c[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, c[1])).done) return o;
                                        switch (n = 0, o && (c = [2 & c[0], o.value]), c[0]) {
                                            case 0:
                                            case 1:
                                                o = c;
                                                break;
                                            case 4:
                                                return r.label++, {
                                                    value: c[1],
                                                    done: !1
                                                };
                                            case 5:
                                                r.label++, n = c[1], c = [0];
                                                continue;
                                            case 7:
                                                c = r.ops.pop(), r.trys.pop();
                                                continue;
                                            default:
                                                if (!(o = r.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                    r = 0;
                                                    continue
                                                }
                                                if (3 === c[0] && (!o || c[1] > o[0] && c[1] < o[3])) {
                                                    r.label = c[1];
                                                    break
                                                }
                                                if (6 === c[0] && r.label < o[1]) {
                                                    r.label = o[1], o = c;
                                                    break
                                                }
                                                if (o && r.label < o[2]) {
                                                    r.label = o[2], r.ops.push(c);
                                                    break
                                                }
                                                o[2] && r.ops.pop(), r.trys.pop();
                                                continue
                                        }
                                        c = body.call(e, r)
                                    } catch (e) {
                                        c = [6, e], n = 0
                                    } finally {
                                        t = o = 0
                                    }
                                    if (5 & c[0]) throw c[1];
                                    return {
                                        value: c[0] ? c[1] : void 0,
                                        done: !0
                                    }
                                }([c, d])
                            }
                        }
                    },
                    L = function(t) {
                        function n() {
                            var e = null !== t && t.apply(this, arguments) || this;
                            return e.isRTL = !1, e.isCN = !1, e.websiteCode = "", e.timer = !1, e.bvLocale = v.a, e.languageCode = w.a, e.isProductLine = !0, e
                        }
                        return I(n, t), n.prototype.head = function() {
                            var t, n, o, r, c, d, l, h, f, v, w, y, W, I, _, A, P, L, j = this.$route.params.area || "global",
                                C = this.$nuxt.$route.fullPath,
                                x = {},
                                O = {},
                                S = {},
                                k = "",
                                T = {},
                                R = {},
                                E = {},
                                $ = {};
                            _ = {
                                rel: "preconnect",
                                href: "https://dlcdnrog.asus.com"
                            }, A = {
                                rel: "preconnect",
                                href: "https://dlcdnwebimgs.asus.com"
                            }, P = {
                                rel: "preconnect",
                                href: "https://asus-brand-assistant.asus.com"
                            }, L = {
                                rel: "preconnect",
                                href: "https://dlcdnimgs.asus.com"
                            }, "/laptops/rog-flow-series/?FilterLevelTagId=1065&items=20392&inStock=0&outStock=0&preOrder=0&all=0&sale=0" !== C && "/laptops/rog-flow/rog-flow-x16-2023-series/" !== C || (O = {
                                rel: "preconnect",
                                href: "https://dev.visualwebsiteoptimizer.com"
                            }), ("api-rog.asus.com".indexOf("localhost") > -1 || "api-rog.asus.com".indexOf("dev") > -1 || "api-rog.asus.com".indexOf("stage") > -1) && (this.isProductLine = !1), "api-rog.asus.com".indexOf(".cn") > -1 && (j = "cn"), "cn" === j ? (x = {
                                rel: "stylesheet",
                                href: "/rog/nuxtStatic/css/fontCN.css"
                            }, T = {
                                async: !1,
                                src: "https://www.asus.com.cn/vendor/cookie-banner/js/alert-info_cn.js",
                                body: !1
                            }, R = {
                                rel: "stylesheet",
                                href: "https://www.asus.com.cn/vendor/cookie-banner/css/alert-info_rog.css",
                                type: "text/css"
                            }) : (x = {
                                rel: "stylesheet",
                                href: "/rog/nuxtStatic/css/fontHQ.css"
                            }, R = {
                                rel: "stylesheet",
                                href: "https://dlcdnimgs.asus.com/vendor/cookie-banner/css/alert-info_rog.css",
                                type: "text/css"
                            }, {}, E = {
                                rel: "stylesheet",
                                href: "https://dlcdnimgs.asus.com/vendor/location-reminder/css/locationreminder_rog.css",
                                type: "text/css"
                            }), "jp" === j && ($ = {
                                async: !0,
                                src: "https://dlcdnimgs.asus.com/vendor/public/fonts/js/biz_udgothic.js",
                                body: !1
                            }), "in" === j && (k = "https://asus.oriserve.com/chatbot-rog/static/js/asusrogProd.js"), (null === (n = null === (t = null == e ? void 0 : e.env) || void 0 === t ? void 0 : t.SITE) || void 0 === n ? void 0 : n.indexOf("localhost")) > -1 && (x = {
                                rel: "stylesheet",
                                href: "/rog/nuxtStatic/css/fontLocal.css"
                            });
                            var G = this.$route.fullPath,
                                M = {},
                                U = G.substring(G.indexOf("rog") + 6).split("/")[1];
                            U = U ? "-" + U : "-index", this.$route.name, M = this.$nuxt.nuxt.err && 404 === this.$nuxt.nuxt.err.statusCode || "ErrorPage" === this.$route.name ? {
                                innerHTML: "var mPulsePageGroup = '".concat(j, "-error' "),
                                body: !0
                            } : "Region" === this.$route.name ? {
                                innerHTML: "var mPulsePageGroup = '".concat(j, "-entry' "),
                                body: !0
                            } : {
                                innerHTML: "var mPulsePageGroup = '".concat(this.routeInfo.configValue.mPulsePageGroup, "' "),
                                body: !0
                            };
                            var N = {};
                            if (this.bvLocale[j]) {
                                (null === (o = "api-rog.asus.com") ? void 0 : o.includes("stage-")) || (null === (r = "api-rog.asus.com") || r.includes("dev-"));
                                N = {
                                    async: !0,
                                    src: "https://apps.bazaarvoice.com/deployments/asustek/rog/production/" + this.bvLocale[j] + "/bv.js",
                                    body: !0
                                }
                            }
                            var H = {},
                                z = {},
                                D = "/rog/nuxtStatic/js/mPulse/global.js"; - 1 !== m.b.indexOf(j.toLowerCase()) ? this.isRTL = !0 : this.isRTL = !1, "cn" === j ? (D = "/rog/nuxtStatic/js/mPulse/cn.js", H = {
                                type: "text/javascript",
                                innerHTML: 'var _hmt = _hmt || [];\n            (function() {\n            var hm = document.createElement("script");\n            hm.src = "https://hm.baidu.com/hm.js?b4671500ff917b268437ff5be30c0ff0";\n            var s = document.getElementsByTagName("script")[0];\n            s.parentNode.insertBefore(hm, s);\n            })();\n          '
                            }) : ("/laptops/rog-flow-series/?FilterLevelTagId=1065&items=20392&inStock=0&outStock=0&preOrder=0&all=0&sale=0" !== C && "/laptops/rog-flow/rog-flow-x16-2023-series/" !== C || (z = {
                                id: "vwoCode",
                                type: "text/javascript",
                                innerHTML: "window._vwo_code=window._vwo_code || (function() {\n            var account_id=734173,\n            version = 1.5,\n            settings_tolerance=2000,\n            library_tolerance=2500,\n            use_existing_jquery=false,\n            is_spa=1,\n            hide_element='body',\n            hide_element_style = 'opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important',\n            /* DO NOT EDIT BELOW THIS LINE */\n            f=false,w=window,d=document,vwoCodeEl=d.querySelector('#vwoCode'),code={use_existing_jquery:function(){return use_existing_jquery},library_tolerance:function(){return library_tolerance},hide_element_style:function(){return'{'+hide_element_style+'}'},finish:function(){if(!f){f=true;var e=d.getElementById('_vis_opt_path_hides');if(e)e.parentNode.removeChild(e)}},finished:function(){return f},load:function(e){var t=d.createElement('script');t.fetchPriority='high';t.src=e;t.type='text/javascript';t.onerror=function(){_vwo_code.finish()};d.getElementsByTagName('head')[0].appendChild(t)},getVersion:function(){return version},getMatchedCookies:function(e){var t=[];if(document.cookie){t=document.cookie.match(e)||[]}return t},getCombinationCookie:function(){var e=code.getMatchedCookies(/(?:^|;)s?(_vis_opt_exp_d+_combi=[^;$]*)/gi);e=e.map(function(e){try{var t=decodeURIComponent(e);if(!/_vis_opt_exp_d+_combi=(?:d+,?)+s*$/.test(t)){return''}return t}catch(e){return''}});var i=[];e.forEach(function(e){var t=e.match(/([d,]+)/g);t&&i.push(t.join('-'))});return i.join('|')},init:function(){if(d.URL.indexOf('__vwo_disable__')>-1)return;w.settings_timer=setTimeout(function(){_vwo_code.finish()},settings_tolerance);var e=d.currentScript,t=d.createElement('style'),i=e&&!e.async?hide_element?hide_element+'{'+hide_element_style+'}':'':code.lA=1,n=d.getElementsByTagName('head')[0];t.setAttribute('id','_vis_opt_path_hides');vwoCodeEl&&t.setAttribute('nonce',vwoCodeEl.nonce);t.setAttribute('type','text/css');if(t.styleSheet)t.styleSheet.cssText=i;else t.appendChild(d.createTextNode(i));n.appendChild(t);var o=this.getCombinationCookie();this.load('https://dev.visualwebsiteoptimizer.com/j.php?a='+account_id+'&u='+encodeURIComponent(d.URL)+'&f='+ +is_spa+'&vn='+version+(o?'&c='+o:''));return settings_timer}};w._vwo_settings_timer = code.init();return code;}());\n          "
                            }), H = {
                                type: "text/javascript",
                                innerHTML: '(function (w, d, s, l, i) {\n          w[l] = w[l] || [];\n          w[l].push({\'gtm.start\': new Date().getTime(), event: \'gtm.js\' });\n          var f = d.getElementsByTagName(s)[0],\n          j = d.createElement(s),\n          dl = l != "dataLayer" ? "&l=" + l : "";\n          j.defer = true;\n          j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;\n          f.parentNode.insertBefore(j, f);\n          })(window, document, "script", "dataLayer", "GTM-NJRLM8");\n          '
                            }), S = this.getAIStatus ? {
                                type: "text/javascript",
                                innerHTML: 'window.AsusAPIConfig = {\n          system: "rog",\n          websitePath: \''.concat(j, '\',\n          theme: "rog",\n          campaignId: "3f8bcb17-b07f-4992-bcf7-72cdfcf704f9",\n          zIndex: 11900,\n          brandAssistantDefaultExpand: false,\n          brandAssistantDefaultDisplay: true,\n          brandAssistantZIndex: 10200,\n          brandAssistantPanelZIndex: 12000,\n          brandAssistantOffsetX: 32,\n          brandAssistantOffsetY: 64,\n          brandAssistantTheme: "rog",\n          brandAssistantSystemCode: "rog",\n          brandAssistantModel1Id: ').concat(3 === this.routeInfo.type ? this.routeInfo.m1Id : 0, ',\n          brandAssistantModel1Name: "').concat(3 === this.routeInfo.type ? this.routeInfo.brandingName.toString() : "", '",\n        }; ')
                            } : {
                                type: "text/javascript",
                                innerHTML: 'window.AsusAPIConfig = {\n          system: "rog",\n          websitePath: \''.concat(j, '\',\n          theme: "rog",\n          campaignId: "3f8bcb17-b07f-4992-bcf7-72cdfcf704f9",\n          zIndex: 11900,\n        }; ')
                            }, this.getAIStatus;
                            var B = {},
                                Q = {},
                                F = {},
                                V = "bdcf349f-e918-4b8f-b333-00cf2fd7eebc";
                            "co" === j ? V = "19168e41-f539-4294-be9c-4b765a2aeb0e" : "pe" === j && (V = "edac2453-476a-4329-bf66-12e68994abb9"), "cl" !== j && "co" !== j && "pe" !== j || (Q = {
                                async: !1,
                                src: "https://snippets.freshchat.com/js/fc-pre-chat-form-v2.min.js",
                                body: !1
                            }, F = {
                                async: !0,
                                src: "https://asus5.freshchat.com/js/widget.js",
                                body: !1
                            }, B = {
                                type: "text/javascript",
                                innerHTML: "\n        var preChatTemplate = {\n          mainbgColor: '#dc213c',\n          maintxColor: '#fff',\n          heading: 'Aviso de Privacidad de Datos',\n          textBanner: '¡Bienvenido al chat de la tienda oficial de ASUS! Para acceder al servicio de chat, es necesario que aceptes nuestra política de privacidad. Al hacer clic en “Aceptar” estás permitiendo que ASUS recopile tus datos bajo el <a href=\"https://cl.store.asus.com/recoleccion-datos-cl\" target=\"_blank\">Aviso de Privacidad de Datos</a>.<br><br>Haz clic en aceptar para que iniciemos la conversación, ¡Te esperamos! &#128512',\n          SubmitLabel: '¡Acepto!',\n          fields : {}\n        };\n        window.fcSettings = {\n          token: \"86ac4556-900f-4e8b-a6fb-81950b357513\",\n          host: \"https://asus5.freshchat.com\",\n          widgetUuid:  \"".concat(V, "\",\n          config: {\n            cssNames:{ \n              widget: 'custom_fc_frame', \n              expanded: 'custom_fc_expanded',\n            },\n          },\n          onInit: function(){ \n            fcPreChatform.fcWidgetInit(preChatTemplate);\n          }\n        };\n\n        ")
                            });
                            var meta = null === (c = this.routeInfo) || void 0 === c ? void 0 : c.metaInfo;
                            return {
                                title: null === (d = meta[0]) || void 0 === d ? void 0 : d.metaTitle,
                                meta: [{
                                    hid: "description",
                                    name: "description",
                                    content: null === (l = meta[0]) || void 0 === l ? void 0 : l.description
                                }, {
                                    hid: "og:title",
                                    property: "og:title",
                                    content: null === (h = meta[1]) || void 0 === h ? void 0 : h.metaTitle
                                }, {
                                    hid: "og:type",
                                    property: "og:type",
                                    content: "website"
                                }, {
                                    hid: "og:site_name",
                                    property: "og:site_name",
                                    content: "@ROG"
                                }, {
                                    hid: "og:description",
                                    property: "og:description",
                                    content: null === (f = meta[0]) || void 0 === f ? void 0 : f.description
                                }, {
                                    hid: "og:url",
                                    property: "og:url",
                                    content: null === (v = meta[0]) || void 0 === v ? void 0 : v.url
                                }, {
                                    hid: "og:image",
                                    property: "og:image",
                                    content: null === (w = meta[0]) || void 0 === w ? void 0 : w.mediaPC
                                }, {
                                    hid: "twitter:title",
                                    property: "twitter:title",
                                    content: null === (y = meta[2]) || void 0 === y ? void 0 : y.metaTitle
                                }, {
                                    hid: "twitter:site",
                                    property: "twitter:site",
                                    content: "@ROG"
                                }, {
                                    hid: "twitter:description",
                                    property: "twitter:description",
                                    content: null === (W = meta[2]) || void 0 === W ? void 0 : W.description
                                }, {
                                    hid: "twitter:card",
                                    property: "twitter:card",
                                    content: "summary_large_image"
                                }, {
                                    hid: "twitter:image",
                                    property: "twitter:image",
                                    content: null === (I = meta[2]) || void 0 === I ? void 0 : I.mediaPC
                                }],
                                htmlAttrs: {
                                    dir: this.isRTL ? "rtl" : "ltr",
                                    lang: this.languageCode[j]
                                },
                                link: [A, _, P, L, x, R, E, O],
                                script: [$, S, M, T, {
                                    src: k,
                                    defer: !0
                                }, {
                                    src: D,
                                    defer: !0,
                                    body: !0
                                }, H, N, z, {}, Q, B, F, {}]
                            }
                        }, n.prototype.setRTLGetter = function() {
                            this.isRTL = this.RTLGetter
                        }, n.prototype.watchGetAIStatus = function() {
                            if (this.getAIStatus) {
                                var e = this;
                                setTimeout((function() {
                                    window.AsusAPIConfig.reminderElement = document.getElementById("defaultWrapper"), window.AsusAPIConfig.reminder = function(t) {
                                        return A(this, void 0, void 0, (function() {
                                            return P(this, (function(n) {
                                                return [2, {
                                                    reminderURL: e.changeWebsiteCode(t)
                                                }]
                                            }))
                                        }))
                                    }
                                }), 500), "function" == typeof window.top.brandAssistantSetMounted && window.top.brandAssistantSetMounted(!0)
                            }
                        }, Object.defineProperty(n.prototype, "lang", {
                            get: function() {
                                var e, t, n;
                                return this.$route && this.$route.params.area ? null === (n = null === (t = null === (e = this.$route) || void 0 === e ? void 0 : e.params) || void 0 === t ? void 0 : t.area) || void 0 === n ? void 0 : n.toLowerCase() : "global"
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(n.prototype, "isErrorPage", {
                            get: function() {
                                var e;
                                if (this.$route && this.$route.name) return "ErrorPage" === (null === (e = this.$route) || void 0 === e ? void 0 : e.name)
                            },
                            enumerable: !1,
                            configurable: !0
                        }), Object.defineProperty(n.prototype, "dirType", {
                            get: function() {
                                var e, t, n, o;
                                if (this.$route && (null === (e = this.$route.params) || void 0 === e ? void 0 : e.area)) switch (null === (t = this.$route.params) || void 0 === t ? void 0 : t.area.toLowerCase()) {
                                    case "il":
                                    case "me-ar":
                                    case "sa-ar":
                                    case "eg":
                                    case "nafr-ar":
                                        return "rtl";
                                    default:
                                        return "ltr"
                                } else if (this.$route && this.$route.fullPath) {
                                    switch (null === (o = null === (n = this.$route) || void 0 === n ? void 0 : n.fullPath) || void 0 === o ? void 0 : o.split("/")[1].toLowerCase()) {
                                        case "il":
                                        case "me-ar":
                                        case "sa-ar":
                                        case "eg":
                                        case "nafr-ar":
                                            return "rtl";
                                        default:
                                            return "ltr"
                                    }
                                }
                                return "ltr"
                            },
                            enumerable: !1,
                            configurable: !0
                        }), n.prototype.created = function() {
                            var e, t, n, o, r, c, d, l, h, m = this;
                            this.websiteCode = Object(f.a)(this.$route.params.area), this.isRTL = this.RTLGetter, null === this.$route.name && (this.websiteCode = this.$route.fullPath.split("/")[1].toLowerCase());
                            var v = null === (t = null === (e = this.routeInfo) || void 0 === e ? void 0 : e.configValue) || void 0 === t ? void 0 : t.componentsPageKey;
                            this.getAIStatus ? window.AsusAPIConfig = {
                                system: "rog",
                                websitePath: m.websiteCode,
                                websiteId: m.mappingWebsiteId,
                                reminderElement: document.getElementById("defaultWrapper"),
                                pageKey: v,
                                reminder: function(e) {
                                    return A(this, void 0, void 0, (function() {
                                        return P(this, (function(t) {
                                            return [2, {
                                                reminderURL: m.changeWebsiteCode(e)
                                            }]
                                        }))
                                    }))
                                },
                                theme: "rog",
                                campaignId: "3f8bcb17-b07f-4992-bcf7-72cdfcf704f9",
                                zIndex: 11900,
                                brandAssistantDefaultExpand: !1,
                                brandAssistantDefaultDisplay: !0,
                                brandAssistantZIndex: 10200,
                                brandAssistantPanelZIndex: 12e3,
                                brandAssistantAlignment: "right",
                                brandAssistantOffsetX: 32,
                                brandAssistantOffsetY: 64,
                                brandAssistantTheme: "rog",
                                brandAssistantSystemCode: "rog",
                                brandAssistantAppID: "0000000003",
                                brandAssistantLang: null === (n = this.routeInfo) || void 0 === n ? void 0 : n.metaInfo[0].htmlLang.toLowerCase(),
                                brandAssistantModel1Id: 0,
                                brandAssistantModel1Name: ""
                            } : window.AsusAPIConfig = {
                                system: "rog",
                                websitePath: m.websiteCode,
                                theme: "rog",
                                campaignId: "3f8bcb17-b07f-4992-bcf7-72cdfcf704f9",
                                zIndex: 11900,
                                websiteId: m.mappingWebsiteId,
                                reminderElement: document.getElementById("defaultWrapper"),
                                pageKey: v,
                                reminder: function(e) {
                                    return A(this, void 0, void 0, (function() {
                                        return P(this, (function(t) {
                                            return [2, {
                                                reminderURL: m.changeWebsiteCode(e)
                                            }]
                                        }))
                                    }))
                                }
                            };
                            var w = "https://dlcdnimgs.asus.com/vendor/subscribe-form/js/subscribeform.min.js";
                            if (((null === (o = window.location.host) || void 0 === o ? void 0 : o.indexOf("localhost")) > -1 || (null === (r = window.location.host) || void 0 === r ? void 0 : r.indexOf("dev")) > -1 || (null === (c = window.location.host) || void 0 === c ? void 0 : c.indexOf("stage")) > -1) && (w = "https://stage-asgard.asus.com/vendor/subscribe-form/js/subscribeform.min.js", this.isProductLine = !1), "Region" !== this.$route.name && "AccountRegion" !== this.$route.name) {
                                var y = "https://dlcdnimgs.asus.com/vendor/location-reminder/js/locationreminder.min.js";
                                y = this.isProductLine ? "https://dlcdnimgs.asus.com/vendor/location-reminder/js/locationreminder.min.js" : "https://stage-asgard.asus.com/vendor/location-reminder/js/locationreminder.min.js";
                                var W = document.createElement("script");
                                W.type = "text/javascript", W.src = y, W.defer = !0, "cn" === this.websiteCode && (W.src = "https://www.asus.com.cn/vendor/location-reminder/js/locationreminder.min.js"), document.body.appendChild(W)
                            }
                            var I = document.createElement("script");
                            if (I.type = "text/javascript", I.src = "https://dlcdnimgs.asus.com/vendor/promotion-banner/js/promotionbanner.min.js", I.defer = !0, "cn" === this.websiteCode && (I.src = "https://www.asus.com.cn/vendor/promotion-banner/js/promotionbanner.min.js"), document.body.appendChild(I), "cn" !== this.websiteCode) {
                                var _ = document.createElement("script");
                                _.type = "text/javascript", _.src = "https://dlcdnimgs.asus.com/vendor/cookie-banner/js/alert-info.js", _.defer = !0, document.body.appendChild(_);
                                var L = document.createElement("script");
                                L.type = "text/javascript", L.src = w, L.defer = !0, document.body.appendChild(L)
                            }
                            document.querySelector("body").classList.add(this.websiteCode);
                            var j = document.createElement("link");
                            j.rel = "stylesheet", j.type = "text/css", j.href = "/rog/nuxtStatic/css/chat.css", document.body.appendChild(j);
                            var C = document.createElement("link");
                            C.rel = "stylesheet", C.type = "text/css", C.href = "/rog/nuxtStatic/css/rating.css", document.body.appendChild(C);
                            var x = document.createElement("link");
                            if (x.rel = "stylesheet", x.type = "text/css", x.href = "/dist/overview/css/review.css", document.body.appendChild(x), (null === (d = window.location.host) || void 0 === d ? void 0 : d.indexOf("localhost")) > -1 || (null === (l = window.location.host) || void 0 === l ? void 0 : l.indexOf("dev")) > -1 || (null === (h = window.location.host) || void 0 === h ? void 0 : h.indexOf("stage")) > -1) {
                                var O = document.querySelector('link[href="https://dlcdnimgs.asus.com/vendor/cookie-banner/css/alert-info_rog.css?v2"]');
                                O && O.parentNode.removeChild(O);
                                var S = document.querySelector('link[href="https://dlcdnimgs.asus.com/vendor/location-reminder/css/locationreminder_rog.css"]');
                                S && S.parentNode.removeChild(S)
                            }
                        }, n.prototype.beforeMount = function() {
                            c.Vue.config.errorHandler = function(e, t, n) {
                                console.error("".concat(n, ": ").concat(e.toString()))
                            }
                        }, n.prototype.getAiAssistantStatusHandler = function() {
                            return A(this, void 0, Promise, (function() {
                                var e, t, n;
                                return P(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            return {
                                                dev: {
                                                    username: "chatbot",
                                                    password: "E))CTBSk)fpJaMk*"
                                                },
                                                stage: {
                                                    username: "chatbot",
                                                    password: "y2&YvU47sQqv4k34"
                                                },
                                                prod: {
                                                    username: "chatbot",
                                                    password: "axyyme6&(R7ftrDI"
                                                }
                                            }, {
                                                dev: "https://dev-accountmw.asus.com",
                                                stage: "https://stage-accountmw.asus.com",
                                                prod: "https://accountmw.asus.com"
                                            }, e = {
                                                dev: "https://dev-mwservice.asus.com",
                                                stage: "https://stage-mwservice.asus.com",
                                                prod: "https://mwservice.asus.com"
                                            }, "prod", t = function(t) {
                                                return A(this, void 0, void 0, (function() {
                                                    return P(this, (function(n) {
                                                        switch (n.label) {
                                                            case 0:
                                                                return [4, W.a.getAiAssistantStatus({
                                                                    baseUrl: e.prod,
                                                                    websiteCode: t,
                                                                    systemId: 2
                                                                }).then((function(e) {
                                                                    return e.data.result.status
                                                                }))];
                                                            case 1:
                                                                return [2, n.sent()]
                                                        }
                                                    }))
                                                }))
                                            }, [4, t(this.routeInfo.websitePath)];
                                        case 1:
                                            return n = o.sent(), [4, this.setAIStatus(n)];
                                        case 2:
                                            return o.sent(), [4, this.setAIAScript()];
                                        case 3:
                                            return o.sent(), [2]
                                    }
                                }))
                            }))
                        }, n.prototype.setAIAScript = function() {
                            var e, t, n;
                            return A(this, void 0, Promise, (function() {
                                var o, r;
                                return P(this, (function(c) {
                                    return this.getAIStatus && (o = "https://asus-brand-assistant.asus.com/brand-assistant.js?rog", (null === (e = window.location.host) || void 0 === e ? void 0 : e.includes("dev-")) ? o = "https://dev-asus-brand-assistant.asus.com/brand-assistant.js?dev-rog" : (null === (t = window.location.host) || void 0 === t ? void 0 : t.includes("stage-")) ? o = "https://stage-asus-brand-assistant.asus.com/brand-assistant.js?stage-rog" : (null === (n = window.location.host) || void 0 === n ? void 0 : n.includes("rogmars")) && (o = "https://asus-brand-assistant.asus.com/brand-assistant.js?rogmars"), (r = document.createElement("script")).type = "module", r.src = o, document.body.appendChild(r)), [2]
                                }))
                            }))
                        }, n.prototype.mounted = function() {
                            var e = this;
                            "localhost" !== window.location.hostname && "rog.asus.com.cn" !== window.location.hostname && setTimeout((function() {
                                "Region" !== e.$route.name && "AccountRegion" !== e.$route.name && e.getAiAssistantStatusHandler()
                            }), 100), "lineshopping" === this.getQueryVariable("utm_source") && Object(y.c)("LineShopping_ECID", this.getQueryVariable("ecid"), "1"), "shopback" === this.getQueryVariable("utm_source") && "ph" === this.routeInfo.websitePath && (Object(y.c)("".concat(this.routeInfo.websitePath.toUpperCase(), "_redirect_source"), "shopback", "2"), Object(y.c)("".concat(this.routeInfo.websitePath.toUpperCase(), "_redirect_key"), this.getQueryVariable("transaction_id"), "2")), window.addEventListener("beforeunload", (function(e) {
                                e.target.domain !== window.location.hostname && Object(y.a)("locationReminder")
                            })), window.addEventListener("resize", (function() {
                                setTimeout((function() {
                                    "function" == typeof window.brandAssistantGetStatus && (window.innerWidth <= 1280 ? window.brandAssistantChangeOffsetX(16) : window.brandAssistantChangeOffsetX(32))
                                }), 500)
                            }));
                            var t = setInterval((function() {
                                "function" == typeof window.brandAssistantGetStatus && (window.innerWidth <= 1280 ? (clearInterval(t), window.brandAssistantChangeOffsetX(16)) : (clearInterval(t), window.brandAssistantChangeOffsetX(32)))
                            }), 100);
                            setTimeout((function() {
                                "function" == typeof window.brandAssistantGetStatus && (window.innerWidth <= 1280 ? window.brandAssistantChangeOffsetX(16) : window.brandAssistantChangeOffsetX(32))
                            }), 1e3)
                        }, n.prototype.getQueryVariable = function(e) {
                            return "undefined" == typeof window ? "" : new URLSearchParams(window.location.search).get(e) || ""
                        }, n.prototype.changeWebsiteCode = function(e) {
                            return "cn" === e ? "/" === window.location.pathname ? "https://rog.asus.com.cn/" : "https://rog.asus.com.cn" + ("global" !== this.websiteCode ? window.location.pathname.replace("/".concat(this.websiteCode, "/"), "/") : decodeURI(window.location.pathname)) + decodeURI(window.location.search) : "global" === this.websiteCode || "cn" === this.websiteCode ? "https://rog.asus.com/" + e + decodeURI(window.location.pathname) + decodeURI(window.location.search) : window.location.href.replace("/".concat(this.websiteCode, "/"), "/".concat(e, "/"))
                        }, _([Object(c.Getter)("routeInfo")], n.prototype, "routeInfo", void 0), _([Object(c.Getter)("RTLGetter")], n.prototype, "RTLGetter", void 0), _([Object(c.Getter)("mappingWebsiteId")], n.prototype, "mappingWebsiteId", void 0), _([Object(c.Getter)("getUserDevice")], n.prototype, "getUserDevice", void 0), _([Object(c.Getter)("getAIStatus")], n.prototype, "getAIStatus", void 0), _([Object(c.Action)("setAIStatus")], n.prototype, "setAIStatus", void 0), _([Object(c.Watch)("RTLGetter", {
                            immediate: !0
                        })], n.prototype, "setRTLGetter", null), _([Object(c.Watch)("getAIStatus", {
                            immediate: !1
                        })], n.prototype, "watchGetAIStatus", null), n = _([Object(c.Component)({
                            components: {
                                Header: d.a,
                                Footer: l.a,
                                PageLoading: h.a
                            }
                        })], n)
                    }(c.Vue);
                t.a = L
            }).call(this, n(74))
        },
        383: function(e, t, n) {
            "use strict";
            var o = n(174),
                r = n.n(o);
            n.d(t, "default", (function() {
                return r.a
            }))
        },
        395: function(e, t, n) {
            "use strict";
            var o = n(186),
                r = n.n(o);
            n.d(t, "default", (function() {
                return r.a
            }))
        },
        497: function(e, t, n) {
            "use strict";
            var o = n(2),
                r = n(187).a,
                c = n(395),
                d = n(25);
            var component = Object(d.a)(r, (function() {
                var e = this,
                    t = e._self._c;
                e._self._setupProxy;
                return t("div", {
                    staticClass: "rogApp",
                    class: [e.lang, e.$style.defaultWrapper],
                    attrs: {
                        id: "defaultWrapper",
                        "data-dirtype": e.dirType
                    }
                }, [e.isCN ? e._e() : t("noscript", [t("iframe", {
                    staticStyle: {
                        display: "none",
                        visibility: "hidden"
                    },
                    attrs: {
                        src: "//www.googletagmanager.com/ns.html?id=GTM-NJRLM8",
                        height: "0",
                        width: "0"
                    }
                })]), e._v(" "), t("div", [t("Header")], 1), e._v(" "), t("main", {
                    staticClass: "layout",
                    class: [e.$style.main, Object(o.a)({}, "error", e.isErrorPage)]
                }, [t("nuxt", {
                    class: e.$style.nuxtview
                })], 1), e._v(" "), t("div", [t("Footer")], 1)])
            }), [], !1, (function(e) {
                this.$style = c.default.locals || c.default
            }), null, null);
            t.a = component.exports
        },
        582: function(e, t) {},
        584: function(e, t) {},
        601: function(e, t) {},
        89: function(e, t, n) {
            "use strict";
            var o, r = n(9),
                c = (n(54), n(41), n(10), n(43), n(46), n(52), n(37), n(38), n(51), n(20), n(22)),
                d = n(148),
                l = n(401),
                h = n(79),
                f = n(4),
                m = (o = function(e, b) {
                    return o = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, b) {
                        e.__proto__ = b
                    } || function(e, b) {
                        for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (e[p] = b[p])
                    }, o(e, b)
                }, function(e, b) {
                    if ("function" != typeof b && null !== b) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

                    function t() {
                        this.constructor = e
                    }
                    o(e, b), e.prototype = null === b ? Object.create(b) : (t.prototype = b.prototype, new t)
                }),
                v = function(e, t, n, desc) {
                    var o, c = arguments.length,
                        d = c < 3 ? t : null === desc ? desc = Object.getOwnPropertyDescriptor(t, n) : desc;
                    if ("object" === ("undefined" == typeof Reflect ? "undefined" : Object(r.a)(Reflect)) && "function" == typeof Reflect.decorate) d = Reflect.decorate(e, t, n, desc);
                    else
                        for (var i = e.length - 1; i >= 0; i--)(o = e[i]) && (d = (c < 3 ? o(d) : c > 3 ? o(t, n, d) : o(t, n)) || d);
                    return c > 3 && d && Object.defineProperty(t, n, d), d
                },
                w = function(e, t, n, o) {
                    return new(n || (n = Promise))((function(r, c) {
                        function d(e) {
                            try {
                                h(o.next(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function l(e) {
                            try {
                                h(o.throw(e))
                            } catch (e) {
                                c(e)
                            }
                        }

                        function h(e) {
                            var t;
                            e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                                e(t)
                            }))).then(d, l)
                        }
                        h((o = o.apply(e, t || [])).next())
                    }))
                },
                y = function(e, body) {
                    var t, n, o, g, r = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return g = {
                        next: c(0),
                        throw: c(1),
                        return: c(2)
                    }, "function" == typeof Symbol && (g[Symbol.iterator] = function() {
                        return this
                    }), g;

                    function c(c) {
                        return function(d) {
                            return function(c) {
                                if (t) throw new TypeError("Generator is already executing.");
                                for (; g && (g = 0, c[0] && (r = 0)), r;) try {
                                    if (t = 1, n && (o = 2 & c[0] ? n.return : c[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, c[1])).done) return o;
                                    switch (n = 0, o && (c = [2 & c[0], o.value]), c[0]) {
                                        case 0:
                                        case 1:
                                            o = c;
                                            break;
                                        case 4:
                                            return r.label++, {
                                                value: c[1],
                                                done: !1
                                            };
                                        case 5:
                                            r.label++, n = c[1], c = [0];
                                            continue;
                                        case 7:
                                            c = r.ops.pop(), r.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = r.trys, (o = o.length > 0 && o[o.length - 1]) || 6 !== c[0] && 2 !== c[0])) {
                                                r = 0;
                                                continue
                                            }
                                            if (3 === c[0] && (!o || c[1] > o[0] && c[1] < o[3])) {
                                                r.label = c[1];
                                                break
                                            }
                                            if (6 === c[0] && r.label < o[1]) {
                                                r.label = o[1], o = c;
                                                break
                                            }
                                            if (o && r.label < o[2]) {
                                                r.label = o[2], r.ops.push(c);
                                                break
                                            }
                                            o[2] && r.ops.pop(), r.trys.pop();
                                            continue
                                    }
                                    c = body.call(e, r)
                                } catch (e) {
                                    c = [6, e], n = 0
                                } finally {
                                    t = o = 0
                                }
                                if (5 & c[0]) throw c[1];
                                return {
                                    value: c[0] ? c[1] : void 0,
                                    done: !0
                                }
                            }([c, d])
                        }
                    }
                },
                W = function(e) {
                    function t() {
                        var t = null !== e && e.apply(this, arguments) || this;
                        return t.windowSize = {
                            width: 0,
                            height: 0
                        }, t.refreshSlideShowStatus = !1, t.deviceType = "pc", t.websiteMapping = [{
                            WebsiteId: 1,
                            WebPath: "global",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 2,
                            WebPath: "mx",
                            AccountLang: "es-es"
                        }, {
                            WebsiteId: 3,
                            WebPath: "es",
                            AccountLang: "es-es"
                        }, {
                            WebsiteId: 4,
                            WebPath: "th",
                            AccountLang: "th-th"
                        }, {
                            WebsiteId: 5,
                            WebPath: "tw",
                            AccountLang: "zh-tw"
                        }, {
                            WebsiteId: 6,
                            WebPath: "us",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 7,
                            WebPath: "br",
                            AccountLang: "pt-br"
                        }, {
                            WebsiteId: 8,
                            WebPath: "ca-en",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 9,
                            WebPath: "ca-fr",
                            AccountLang: "fr-fr"
                        }, {
                            WebsiteId: 10,
                            WebPath: "latin",
                            AccountLang: "es-ar"
                        }, {
                            WebsiteId: 11,
                            WebPath: "tr",
                            AccountLang: "tr-tr"
                        }, {
                            WebsiteId: 12,
                            WebPath: "it",
                            AccountLang: "it-it"
                        }, {
                            WebsiteId: 13,
                            WebPath: "jp",
                            AccountLang: "ja-jp"
                        }, {
                            WebsiteId: 14,
                            WebPath: "me-en",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 15,
                            WebPath: "lk",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 16,
                            WebPath: "in",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 17,
                            WebPath: "bd",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 18,
                            WebPath: "cn",
                            AccountLang: "zh-cn"
                        }, {
                            WebsiteId: 19,
                            WebPath: "hk",
                            AccountLang: "zh-tw"
                        }, {
                            WebsiteId: 20,
                            WebPath: "vn",
                            AccountLang: "vi-vn"
                        }, {
                            WebsiteId: 21,
                            WebPath: "kr",
                            AccountLang: "ko-kr"
                        }, {
                            WebsiteId: 22,
                            WebPath: "ru",
                            AccountLang: "ru-ru"
                        }, {
                            WebsiteId: 23,
                            WebPath: "sg",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 24,
                            WebPath: "nz",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 25,
                            WebPath: "ph",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 26,
                            WebPath: "id",
                            AccountLang: "id-id"
                        }, {
                            WebsiteId: 27,
                            WebPath: "au",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 28,
                            WebPath: "my",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 29,
                            WebPath: "de",
                            AccountLang: "de-de"
                        }, {
                            WebsiteId: 30,
                            WebPath: "pl",
                            AccountLang: "pl-pl"
                        }, {
                            WebsiteId: 31,
                            WebPath: "no",
                            AccountLang: "no"
                        }, {
                            WebsiteId: 32,
                            WebPath: "se",
                            AccountLang: "sv-se"
                        }, {
                            WebsiteId: 33,
                            WebPath: "dk",
                            AccountLang: "da-dk"
                        }, {
                            WebsiteId: 34,
                            WebPath: "uk",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 35,
                            WebPath: "sk",
                            AccountLang: "sk-sk"
                        }, {
                            WebsiteId: 36,
                            WebPath: "cz",
                            AccountLang: "cs-cz"
                        }, {
                            WebsiteId: 37,
                            WebPath: "ch-fr",
                            AccountLang: "fr-fr"
                        }, {
                            WebsiteId: 39,
                            WebPath: "ch-de",
                            AccountLang: "de-de"
                        }, {
                            WebsiteId: 40,
                            WebPath: "ro",
                            AccountLang: "ro-ro"
                        }, {
                            WebsiteId: 41,
                            WebPath: "rs",
                            AccountLang: "sr"
                        }, {
                            WebsiteId: 42,
                            WebPath: "ua",
                            AccountLang: "ru-ua"
                        }, {
                            WebsiteId: 43,
                            WebPath: "hu",
                            AccountLang: "hu-hu"
                        }, {
                            WebsiteId: 44,
                            WebPath: "fi",
                            AccountLang: "fi-fi"
                        }, {
                            WebsiteId: 45,
                            WebPath: "pt",
                            AccountLang: "pt-pt"
                        }, {
                            WebsiteId: 46,
                            WebPath: "fr",
                            AccountLang: "fr-fr"
                        }, {
                            WebsiteId: 47,
                            WebPath: "be-nl",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 48,
                            WebPath: "be-fr",
                            AccountLang: "fr-fr"
                        }, {
                            WebsiteId: 49,
                            WebPath: "nl",
                            AccountLang: "nl-nl"
                        }, {
                            WebsiteId: 50,
                            WebPath: "gr",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 51,
                            WebPath: "za",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 52,
                            WebPath: "me-ar",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 53,
                            WebPath: "bg",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 54,
                            WebPath: "ie",
                            AccountLang: "he-il"
                        }, {
                            WebsiteId: 55,
                            WebPath: "il",
                            AccountLang: "he-il"
                        }, {
                            WebsiteId: 56,
                            WebPath: "ea",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 57,
                            WebPath: "middleeast-fa",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 58,
                            WebPath: "ua-ua",
                            AccountLang: "uk-ua"
                        }, {
                            WebsiteId: 59,
                            WebPath: "nafr-ar",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 60,
                            WebPath: "nafr-fr",
                            AccountLang: "fr-fr"
                        }, {
                            WebsiteId: 61,
                            WebPath: "np",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 62,
                            WebPath: "wa",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 64,
                            WebPath: "lt",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 65,
                            WebPath: "lv",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 66,
                            WebPath: "ee",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 67,
                            WebPath: "kz",
                            AccountLang: "ru-ru"
                        }, {
                            WebsiteId: 68,
                            WebPath: "mm",
                            AccountLang: "mm"
                        }, {
                            WebsiteId: 69,
                            WebPath: "hk-en",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 70,
                            WebPath: "co",
                            AccountLang: "es-ar"
                        }, {
                            WebsiteId: 71,
                            WebPath: "cl",
                            AccountLang: "es-ar"
                        }, {
                            WebsiteId: 72,
                            WebPath: "ar",
                            AccountLang: "es-ar"
                        }, {
                            WebsiteId: 73,
                            WebPath: "pe",
                            AccountLang: "es-ar"
                        }, {
                            WebsiteId: 74,
                            WebPath: "ea-sw",
                            AccountLang: "sw-ea"
                        }, {
                            WebsiteId: 78,
                            WebPath: "ch-en",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 81,
                            WebPath: "bn",
                            AccountLang: "en-us"
                        }, {
                            WebsiteId: 82,
                            WebPath: "gr-el",
                            AccountLang: "el"
                        }, {
                            WebsiteId: 85,
                            WebPath: "eg",
                            AccountLang: "ar-eg"
                        }, {
                            WebsiteId: 86,
                            WebPath: "eg-en",
                            AccountLang: "en-eg"
                        }, {
                            WebsiteId: 87,
                            WebPath: "bt",
                            AccountLang: "en-us"
                        }], t.siteId = "", t.siteName = "", t
                    }
                    return m(t, e), t.prototype.asyncData = function(e) {
                        e.query, e.params;
                        var t = e.route,
                            n = e.store;
                        e.req, e.error;
                        return w(this, void 0, Promise, (function() {
                            var e, o;
                            return y(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return e = "/" === t.fullPath ? t.fullPath : t.fullPath.slice(1), [4, n.dispatch("getRoute", {
                                            url: e
                                        })];
                                    case 1:
                                        return r.sent(), o = n.getters.routeInfo.websitePath, [4, Promise.all([n.dispatch("getHeader", {
                                            WebsiteCode: o
                                        }), n.dispatch("getFooterAPI", {
                                            WebsiteCode: o
                                        }), n.dispatch("getTranslation", {
                                            WebsiteCode: o
                                        }), n.dispatch("getAccountMenu", {
                                            WebsiteCode: o
                                        })])];
                                    case 2:
                                        return r.sent(), [2]
                                }
                            }))
                        }))
                    }, Object.defineProperty(t.prototype, "lang", {
                        get: function() {
                            return this.routeInfo ? this.routeInfo.websitePath : ""
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.head = function() {
                        var e, t, n, o, r, c, d, l, h, f, meta = null === (e = this.routeInfo) || void 0 === e ? void 0 : e.metaInfo;
                        return {
                            title: null === (t = meta[0]) || void 0 === t ? void 0 : t.metaTitle,
                            meta: [{
                                hid: "description",
                                name: "description",
                                content: null === (n = meta[0]) || void 0 === n ? void 0 : n.description
                            }, {
                                hid: "og:title",
                                property: "og:title",
                                content: null === (o = meta[1]) || void 0 === o ? void 0 : o.metaTitle
                            }, {
                                hid: "og:type",
                                property: "og:type",
                                content: "website"
                            }, {
                                hid: "og:site_name",
                                property: "og:site_name",
                                content: "@ROG"
                            }, {
                                hid: "og:description",
                                property: "og:description",
                                content: null === (r = meta[1]) || void 0 === r ? void 0 : r.description
                            }, {
                                hid: "og:url",
                                property: "og:url",
                                content: null === (c = meta[0]) || void 0 === c ? void 0 : c.url
                            }, {
                                hid: "og:image",
                                property: "og:image",
                                content: null === (d = meta[0]) || void 0 === d ? void 0 : d.mediaPC
                            }, {
                                hid: "twitter:title",
                                property: "twitter:title",
                                content: null === (l = meta[2]) || void 0 === l ? void 0 : l.metaTitle
                            }, {
                                hid: "twitter:site",
                                property: "twitter:site",
                                content: "@ROG"
                            }, {
                                hid: "twitter:description",
                                property: "twitter:description",
                                content: null === (h = meta[2]) || void 0 === h ? void 0 : h.description
                            }, {
                                hid: "twitter:card",
                                property: "twitter:card",
                                content: "summary_large_image"
                            }, {
                                hid: "twitter:image",
                                property: "twitter:image",
                                content: null === (f = meta[2]) || void 0 === f ? void 0 : f.mediaPC
                            }],
                            link: [{
                                rel: "canonical",
                                href: "https://rog.asus.com" + this.routeQuery
                            }],
                            script: []
                        }
                    }, t.prototype.beforeMount = function() {
                        this.windowSize = Object(h.a)(), this.windowSize.width <= 768 && (this.deviceType = "mobile")
                    }, t.prototype.mounted = function() {
                        if (window) {
                            this.siteId = "";
                            if ("rog.asus.com.cn" === encodeURI(window.location.host)) "https://rog.asus.com.cn";
                            else switch (encodeURI(window.location.host)) {
                                case "rogmars.asus.com":
                                    "https://rogmars.asus.com";
                                    break;
                                case "dev-rog.asus.com":
                                    "https://dev-rog.asus.com";
                                    break;
                                case "stage-rog.asus.com":
                                    "https://stage-rog.asus.com";
                                    break;
                                case "rog.asus.com":
                                    "https://rog.asus.com"
                            }
                            if ("undefined" != typeof window) {
                                var e = this.routeInfo.websitePath;
                                "error" !== e.toLowerCase() ? (this.getHeader({
                                    WebsiteCode: e
                                }), this.getFooterAPI({
                                    WebsiteCode: e
                                }), this.getTranslation({
                                    WebsiteCode: e
                                }), this.getAccountMenu({
                                    WebsiteCode: e
                                })) : this.siteId = Object(f.b)("rog_site_id")
                            }
                        }
                    }, t.prototype.redirectUrl = function() {
                        var area = "/";
                        return "undefined" != typeof window && (area = "rog.asus.com.cn" === window.location.host ? "/" : (Object(f.b)("rog_site_area"), "global" === this.lang ? "".concat(encodeURI(window.location.origin)) : "".concat(encodeURI(window.location.origin), "/").concat(this.lang, "/"))), area
                    }, v([Object(c.Getter)("routeInfo")], t.prototype, "routeInfo", void 0), v([Object(c.Getter)("mappingWebsiteId")], t.prototype, "mappingWebsiteId", void 0), v([Object(c.Getter)("translation")], t.prototype, "translation", void 0), v([Object(c.Getter)("routeQuery")], t.prototype, "routeQuery", void 0), v([Object(c.Action)("getTranslation")], t.prototype, "getTranslation", void 0), v([Object(c.Action)("getHeader")], t.prototype, "getHeader", void 0), v([Object(c.Action)("getFooterAPI")], t.prototype, "getFooterAPI", void 0), v([Object(c.Action)("getAccountMenu")], t.prototype, "getAccountMenu", void 0), t = v([d.Jsonld, Object(c.Component)({
                        components: {}
                    })], t)
                }(Object(c.mixins)(l.a)),
                I = W,
                _ = n(383),
                A = n(25);
            var component = Object(A.a)(I, (function() {
                var e = this,
                    t = e._self._c;
                e._self._setupProxy;
                return t("div", {
                    staticClass: "for404",
                    class: e.$style.errorContainer
                }, [t("div", {
                    class: e.$style.errorWrapper
                }, [t("div", {
                    class: e.$style.errorContent
                }, [t("i", {
                    class: e.$style.errorPatten
                }), e._v(" "), t("h1", {
                    class: e.$style.errorSlogan
                }, [e._v(e._s(e.translation["404_Sorry"]))]), e._v(" "), t("p", {
                    class: e.$style.errorInfo
                }, [e._v(e._s(e.translation["404_Not_Found"]))]), e._v(" "), t("ClientOnly", [t("a", {
                    attrs: {
                        href: e.redirectUrl()
                    }
                }, [t("p", {
                    class: [e.$style.errorInfo, e.$style.errorReturnLink]
                }, [e._v(e._s(e.translation["404_Back_to_Home"])), t("i", {
                    class: e.$style.returnIcon
                })])])])], 1)])])
            }), [], !1, (function(e) {
                this.$style = _.default.locals || _.default
            }), null, null);
            t.a = component.exports
        }
    }
]);