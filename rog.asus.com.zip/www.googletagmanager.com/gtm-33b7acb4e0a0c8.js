// Copyright 2012 Google Inc. All rights reserved.

(function(w, g) {
    w[g] = w[g] || {};
    w[g].e = function(s) {
        return eval(s);
    };
})(window, 'google_tag_manager');

(function() {

    var data = {
        "resource": {
            "version": "5",

            "macros": [{
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return g_multiparams.lang.split(\"_\")[1]})();"]
            }, {
                "function": "__c",
                "vtp_value": "(cl|co|pe|br|be-nl|be-fr|bg|bt|cz|dk|ee|fi|fr|de|gr|gr-el|hu|ie|it|lv|lt|nl|pl|pt|ro|sk|es|se|uk|si|hr|cn|us|ch-de|ch-fr|ch-it|ch-en|no)"
            }, {
                "function": "__c",
                "vtp_value": "(africa-fr|wa|aa|eg|eg-en|ea|ea-sw|il|ng|ae-ar|ae-en|middleeast-fa|nafr-ar|nafr-fr|sa-en|sa-ar|za|ar|ca-fr|ca-en|latin|mx|au|bd|hk|hk-en|in|id|jp|kr|my|mm|np|nz|ph|sg|lk|tw|th|tr|vn|kz|ru|rs|ua|ua-ua|kh|me-ar|me-en|bn|py|pk|ec|uy)"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": true,
                "vtp_input": ["macro", 0],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": false,
                "vtp_defaultValue": "global",
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", ["macro", 1], "value", "yes"],
                    ["map", "key", ["macro", 2], "value", "no"]
                ]
            }, {
                "function": "__c",
                "vtp_value": "krprod\\.store|local|((in|kr|id|uk|au|co|cl)stage\\.store)|(dev\\.asusstore)|((ukprod|instage)\\.store)|shopbeta-us1|stage-asgard|rogmars|bacchus|odinview|estorestage|(www(beta|dev)-(us|tw)1)|uploadandpray"
            }, {
                "function": "__c",
                "vtp_value": "asus\\.conrad\\.puxdesign\\.cz|http:\\\/\\\/in\\.asus\\.com|(13\\.251\\.34\\.17)|asus\\.kulturcreativestudio\\.com"
            }, {
                "function": "__j",
                "vtp_name": "_ASUS_Js_Api_Site"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": true,
                "vtp_input": ["macro", 6],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": false,
                "vtp_defaultValue": "global",
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", ["macro", 1], "value", "yes"],
                    ["map", "key", ["macro", 2], "value", "no"]
                ]
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": true,
                "vtp_input": ["macro", 8],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_defaultValue": "global",
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", ":\\\/\\\/account\\.asus\\.com", "value", ["macro", 7]],
                    ["map", "key", "www\\.asusromania\\.ro|sklepasus\\.pl", "value", "yes"],
                    ["map", "key", ["template", "(", ["macro", 4], ")\\.asus\\.com|", ["macro", 5]], "value", "no"],
                    ["map", "key", "(press|eventos|tinker-board)\\.asus\\.com", "value", "yes"],
                    ["map", "key", "(ehr|smb)\\.asus\\.com", "value", "no"],
                    ["map", "key", ["template", "\\.com\\\/", ["macro", 1], "(\\?|\\\/|$)|:\\\/\\\/", ["macro", 1], "\\.(store|shop)|:\\\/\\\/(shop|member)-", ["macro", 1], "1\\.asus"], "value", "yes"],
                    ["map", "key", ["template", "\\.com\\\/", ["macro", 2], "(\\?|\\\/|$)|:\\\/\\\/", ["macro", 2], "\\.(store|shop)|:\\\/\\\/(shop|member)-", ["macro", 2], "1\\.asus"], "value", "no"],
                    ["map", "key", ["template", "(www|rog)\\.asus\\.com\/(campaign|microsite|event|events)\\\/.*\\\/", ["macro", 2], "(\\?|\\\/|$)"], "value", "no"],
                    ["map", "key", "https:\\\/\\\/esurvey\\.asus\\.com\\\/\\?id=1079\u0026code=53cb2a43-598e-4d86-9b26-264222363c28\u0026lang=en_US", "value", "no"],
                    ["map", "key", "rogmasters\\.gg", "value", "yes"],
                    ["map", "key", "edtech.asus.com", "value", "no"],
                    ["map", "key", "csr\\.asus\\.com\\\/chinese", "value", "no"],
                    ["map", "key", "creatorsacademy\\.sg", "value", "no"],
                    ["map", "key", "stage-iotapi\\.asus\\.com\\\/healthcare720|stage-www\\.phda\\.global|iotapi\\.asus\\.com\\\/healthcare720|www\\.phda\\.global", "value", "no"]
                ]
            }, {
                "function": "__k",
                "vtp_decodeCookie": false,
                "vtp_name": "isReadCookiePolicyDNT"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": true,
                "vtp_input": ["macro", 9],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": true,
                "vtp_defaultValue": ["macro", 10],
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "yes|global", "value", ["macro", 10]],
                    ["map", "key", "no", "value", "Yes"]
                ]
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementClasses",
                "vtp_dataLayerVersion": 1
            }],
            "tags": [],
            "predicates": [],
            "rules": []
        },
        "runtime": [
            [50, "__c", [46, "a"],
                [36, [17, [15, "a"], "value"]]
            ],
            [50, "__e", [46, "a"],
                [36, [13, [41, "$0"],
                    [3, "$0", ["require", "internal.getEventData"]],
                    ["$0", "event"]
                ]]
            ],
            [50, "__f", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "getReferrerUrl"]],
                [52, "d", ["require", "makeString"]],
                [52, "e", ["require", "parseUrl"]],
                [52, "f", [15, "__module_legacyUrls"]],
                [52, "g", [30, ["b", "gtm.referrer", 1],
                    ["c"]
                ]],
                [22, [28, [15, "g"]],
                    [46, [36, ["d", [15, "g"]]]]
                ],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "C", [7, [15, "g"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "E", [7, [15, "g"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [22, [17, [15, "a"], "queryKey"],
                                [46, [53, [36, [2, [15, "f"], "H", [7, [15, "g"],
                                    [17, [15, "a"], "queryKey"]
                                ]]]]]
                            ],
                            [52, "h", ["e", [15, "g"]]],
                            [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]]
                        ]],
                        [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]]
                    ]
                ]
            ],
            [50, "__j", [46, "a"],
                [52, "b", ["require", "internal.copyKeyFromWindow"]],
                [36, ["b", [17, [15, "a"], "name"]]]
            ],
            [50, "__jsm", [46, "a"],
                [52, "b", ["require", "internal.executeJavascriptString"]],
                [22, [20, [17, [15, "a"], "javascript"],
                        [44]
                    ],
                    [46, [36]]
                ],
                [36, ["b", [17, [15, "a"], "javascript"]]]
            ],
            [50, "__k", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "getCookieValues"]],
                [52, "d", ["require", "internal.parseCookieValuesFromString"]],
                [52, "e", ["b", "gtm.cookie", 1]],
                [22, [15, "e"],
                    [46, [53, [36, [16, ["d", [15, "e"],
                        [17, [15, "a"], "name"],
                        [28, [28, [17, [15, "a"], "decodeCookie"]]]
                    ], 0]]]]
                ],
                [36, [16, ["c", [17, [15, "a"], "name"],
                    [28, [28, [17, [15, "a"], "decodeCookie"]]]
                ], 0]]
            ],
            [50, "__remm", [46, "a"],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "internal.testRegex"]],
                [52, "d", ["require", "makeString"]],
                [52, "e", ["d", [17, [15, "a"], "input"]]],
                [52, "f", [30, [17, [15, "a"], "map"],
                    [7]
                ]],
                [52, "g", [17, [15, "a"], "fullMatch"]],
                [52, "h", [39, [17, [15, "a"], "ignoreCase"], "gi", "g"]],
                [41, "i"],
                [3, "i", [17, [15, "a"], "defaultValue"]],
                [65, "j", [15, "f"],
                    [46, [53, [41, "k"],
                        [3, "k", [30, [16, [15, "j"], "key"], ""]],
                        [22, [15, "g"],
                            [46, [3, "k", [0, [0, "^", [15, "k"]], "$"]]]
                        ],
                        [52, "l", ["b", [15, "k"],
                            [15, "h"]
                        ]],
                        [22, ["c", [15, "l"],
                                [15, "e"]
                            ],
                            [46, [53, [41, "m"],
                                [3, "m", [16, [15, "j"], "value"]],
                                [22, [17, [15, "a"], "replaceAfterMatch"],
                                    [46, [3, "m", [2, [15, "e"], "replace", [7, [15, "l"],
                                        [15, "m"]
                                    ]]]]
                                ],
                                [3, "i", [15, "m"]],
                                [4]
                            ]]
                        ]
                    ]]
                ],
                [36, [15, "i"]]
            ],
            [50, "__u", [46, "a"],
                [50, "k", [46, "l", "m"],
                    [52, "n", [17, [15, "m"], "multiQueryKeys"]],
                    [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
                    [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
                    [22, [20, [15, "o"], ""],
                        [46, [53, [52, "r", [2, [17, ["i", [15, "l"]], "search"], "replace", [7, "?", ""]]],
                            [36, [39, [1, [28, [15, "r"]],
                                    [15, "p"]
                                ],
                                [44],
                                [15, "r"]
                            ]]
                        ]]
                    ],
                    [41, "q"],
                    [22, [15, "n"],
                        [46, [53, [22, [20, ["e", [15, "o"]], "array"],
                            [46, [53, [3, "q", [15, "o"]]]],
                            [46, [53, [52, "r", ["c", "\\s+", "g"]],
                                [3, "q", [2, [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]], "split", [7, ","]]]
                            ]]
                        ]]],
                        [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]]
                    ],
                    [65, "r", [15, "q"],
                        [46, [53, [52, "s", [2, [15, "h"], "H", [7, [15, "l"],
                                [15, "r"]
                            ]]],
                            [22, [29, [15, "s"],
                                    [44]
                                ],
                                [46, [53, [22, [1, [15, "p"],
                                            [20, [15, "s"], ""]
                                        ],
                                        [46, [53, [6]]]
                                    ],
                                    [36, [15, "s"]]
                                ]]
                            ]
                        ]]
                    ],
                    [36, [44]]
                ],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getUrl"]],
                [52, "e", ["require", "getType"]],
                [52, "f", ["require", "makeString"]],
                [52, "g", ["require", "parseUrl"]],
                [52, "h", [15, "__module_legacyUrls"]],
                [52, "i", ["require", "internal.legacyParseUrl"]],
                [41, "j"],
                [22, [17, [15, "a"], "customUrlSource"],
                    [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
                    [46, [53, [3, "j", ["b", "gtm.url", 1]]]]
                ],
                [3, "j", [30, [15, "j"],
                    ["d"]
                ]],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "EXTENSION", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "C", [7, [15, "j"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "E", [7, [15, "j"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
                        [5, [46, [36, ["k", [15, "j"],
                            [15, "a"]
                        ]]]],
                        [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]]
                    ]
                ]
            ],
            [50, "__v", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getType"]],
                [52, "e", [17, [15, "a"], "name"]],
                [22, [30, [28, [15, "e"]],
                        [21, ["d", [15, "e"]], "string"]
                    ],
                    [46, [36, false]]
                ],
                [52, "f", [2, [15, "e"], "replace", [7, ["c", "\\\\.", "g"], "."]]],
                [52, "g", ["b", [15, "f"],
                    [30, [17, [15, "a"], "dataLayerVersion"], 1]
                ]],
                [36, [39, [21, [15, "g"],
                        [44]
                    ],
                    [15, "g"],
                    [17, [15, "a"], "defaultValue"]
                ]]
            ],
            [52, "__module_legacyUrls", [13, [41, "$0"],
                [3, "$0", [51, "", [7],
                    [50, "a", [46],
                        [50, "h", [46, "p"],
                            [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                            [36, [39, [23, [15, "q"], 0],
                                [15, "p"],
                                [2, [15, "p"], "substring", [7, 0, [15, "q"]]]
                            ]]
                        ],
                        [50, "i", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                            [36, [39, [15, "q"],
                                [2, [15, "q"], "replace", [7, ":", ""]], ""
                            ]]
                        ],
                        [50, "j", [46, "p", "q"],
                            [41, "r"],
                            [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                            [22, [28, [15, "r"]],
                                [46, [36, ""]]
                            ],
                            [52, "s", ["b", ":[0-9]+"]],
                            [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                            [22, [15, "q"],
                                [46, [53, [52, "t", ["b", "^www\\d*\\."]],
                                    [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                                    [22, [1, [15, "u"],
                                            [16, [15, "u"], 0]
                                        ],
                                        [46, [3, "r", [2, [15, "r"], "substring", [7, [17, [16, [15, "u"], 0], "length"]]]]]
                                    ]
                                ]]
                            ],
                            [36, [15, "r"]]
                        ],
                        [50, "k", [46, "p"],
                            [52, "q", ["e", [15, "p"]]],
                            [41, "r"],
                            [3, "r", ["f", [17, [15, "q"], "port"]]],
                            [22, [28, [15, "r"]],
                                [46, [53, [22, [20, [17, [15, "q"], "protocol"], "http:"],
                                    [46, [53, [3, "r", 80]]],
                                    [46, [22, [20, [17, [15, "q"], "protocol"], "https:"],
                                        [46, [53, [3, "r", 443]]],
                                        [46, [53, [3, "r", ""]]]
                                    ]]
                                ]]]
                            ],
                            [36, ["g", [15, "r"]]]
                        ],
                        [50, "l", [46, "p", "q"],
                            [52, "r", ["e", [15, "p"]]],
                            [41, "s"],
                            [3, "s", [39, [20, [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]], 0],
                                [17, [15, "r"], "pathname"],
                                [0, "/", [17, [15, "r"], "pathName"]]
                            ]],
                            [22, [20, ["d", [15, "q"]], "array"],
                                [46, [53, [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                                    [22, [19, [2, [15, "q"], "indexOf", [7, [16, [15, "t"],
                                            [37, [17, [15, "t"], "length"], 1]
                                        ]]], 0],
                                        [46, [53, [43, [15, "t"],
                                                [37, [17, [15, "t"], "length"], 1], ""
                                            ],
                                            [3, "s", [2, [15, "t"], "join", [7, "/"]]]
                                        ]]
                                    ]
                                ]]
                            ],
                            [36, [15, "s"]]
                        ],
                        [50, "m", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                            [52, "r", [2, [15, "q"], "split", [7, "."]]],
                            [41, "s"],
                            [3, "s", [39, [18, [17, [15, "r"], "length"], 1],
                                [16, [15, "r"],
                                    [37, [17, [15, "r"], "length"], 1]
                                ], ""
                            ]],
                            [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]]
                        ],
                        [50, "n", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "hash"]],
                            [36, [2, [15, "q"], "replace", [7, "#", ""]]]
                        ],
                        [50, "o", [46, "p", "q"],
                            [50, "s", [46, "t"],
                                [36, ["c", [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]]]]
                            ],
                            [52, "r", [2, [17, ["e", [15, "p"]], "search"], "replace", [7, "?", ""]]],
                            [65, "t", [2, [15, "r"], "split", [7, "&"]],
                                [46, [53, [52, "u", [2, [15, "t"], "split", [7, "="]]],
                                    [22, [21, ["s", [16, [15, "u"], 0]],
                                            [15, "q"]
                                        ],
                                        [46, [6]]
                                    ],
                                    [36, ["s", [2, [2, [15, "u"], "slice", [7, 1]], "join", [7, "="]]]]
                                ]]
                            ],
                            [36]
                        ],
                        [52, "b", ["require", "internal.createRegex"]],
                        [52, "c", ["require", "decodeUriComponent"]],
                        [52, "d", ["require", "getType"]],
                        [52, "e", ["require", "internal.legacyParseUrl"]],
                        [52, "f", ["require", "makeNumber"]],
                        [52, "g", ["require", "makeString"]],
                        [36, [8, "F", [15, "m"], "H", [15, "o"], "G", [15, "n"], "C", [15, "j"], "E", [15, "l"], "D", [15, "k"], "B", [15, "i"], "A", [15, "h"]]]
                    ],
                    [36, ["a"]]
                ]],
                ["$0"]
            ]]

        ],
        "entities": {
            "__c": {
                "2": true,
                "5": true
            },
            "__e": {
                "2": true,
                "5": true
            },
            "__f": {
                "2": true,
                "5": true
            },
            "__j": {
                "2": true
            },
            "__k": {
                "2": true
            },
            "__remm": {
                "2": true,
                "5": true
            },
            "__u": {
                "2": true,
                "5": true
            },
            "__v": {
                "2": true,
                "5": true
            }


        },
        "blob": {
            "1": "5",
            "10": "GTM-PKPPD5T",
            "14": "5ca1",
            "15": "1",
            "16": "ChEIgOrIygYQ1bHrpt7gw57vARIcACncqKPOSZFK1W+qLYD8lnxcgM3JXzWqTurkXxoCR/w=",
            "19": "dataLayer",
            "20": "",
            "21": "www.googletagmanager.com",
            "22": "eyIwIjoiS0giLCIxIjoiS0gtMTIiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jb20ua2giLCI0IjoiIiwiNSI6dHJ1ZSwiNiI6ZmFsc2UsIjciOiJhZF9zdG9yYWdlfGFuYWx5dGljc19zdG9yYWdlfGFkX3VzZXJfZGF0YXxhZF9wZXJzb25hbGl6YXRpb24iLCI4IjoiIn0",
            "23": "google.tagmanager.debugui2.queue",
            "24": "tagassistant.google.com",
            "27": 0.005,
            "3": "www.googletagmanager.com",
            "30": "KH",
            "31": "KH-12",
            "32": true,
            "36": "https://adservice.google.com/pagead/regclk",
            "37": "__TAGGY_INSTALLED",
            "38": "cct.google",
            "39": "googTaggyReferrer",
            "40": "https://cct.google/taggy/agent.js",
            "41": "google.tagmanager.ta.prodqueue",
            "42": 0.01,
            "43": "{\"keys\":[{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BGOWXP6xH9KW32h4/jrWhhHMMb+B/r9Ad+ZPtfBnH6qe8AszqM3PJnR4GISWiTqxcPBNcoA335ApQEsEhsJ7d2Y=\",\"version\":0},\"id\":\"d9db2ca0-5cc8-47e6-9820-61203a69ce68\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BLwAGITSUeMYBZylN+61FOcu7mPVKWg2qWiNaB5O2o/DngGG7glzZIvoiz7LckzKT39BZM5Im5QaXHbw+xHiT4k=\",\"version\":0},\"id\":\"d9be0687-a7a4-49d3-9ae5-961a7bcdd515\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BN2UMip+zYZhwWxixJG695R1TgsY9aV6rlJmLDDDZOI8tWstMi1DENi20foqjQ/xRCpqBEZnVaFo4wdHXgYkGAk=\",\"version\":0},\"id\":\"c19c4657-ed23-4a5f-8e8a-89f9a27e2bb0\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BCPVt2pe/ulcRV6+EWHZxse4y1P7MfDsyrPwzvCDV77iYy0ZXYK7QoIo5DOQcUaoNtBHrLXrg8x3rIJ3gurZzn4=\",\"version\":0},\"id\":\"26755b6a-e2f6-4d9e-92bf-7ba6ebfbb5d8\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BC1ksRGa1b36CDfQLw+6/1NKcrR+1tpL0VNJtVpKpTecVAx1lB8W6UFAyF1u1f+IgzZ82oGp26YZ5C44W1BUxFc=\",\"version\":0},\"id\":\"1a85b826-d42a-4eff-92a2-c69e70bca571\"}]}",
            "44": "103116026~103200004~104684208~104684211~116184927~116184929~116251938~116251940",
            "46": {
                "1": "1000",
                "10": "5c20",
                "11": "5c20",
                "14": "1000",
                "16": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
                "17": "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD",
                "2": "9",
                "20": "5000",
                "21": "5000",
                "22": "4.0.0",
                "23": "0.0.0",
                "25": "1",
                "26": "4000",
                "27": "100",
                "3": "5",
                "4": "ad_storage|analytics_storage|ad_user_data|ad_personalization",
                "44": "15000",
                "48": "30000",
                "5": "ad_storage|analytics_storage|ad_user_data",
                "6": "1",
                "7": "10"
            },
            "48": true,
            "5": "GTM-PKPPD5T",
            "55": ["GTM-PKPPD5T"],
            "56": [{
                "1": 403,
                "3": 0.5,
                "4": 115938465,
                "5": 115938466,
                "6": 0,
                "7": 2
            }, {
                "1": 404,
                "3": 0.5,
                "4": 115938468,
                "5": 115938469,
                "6": 0,
                "7": 1
            }, {
                "1": 433,
                "3": 0.1,
                "4": 116682875,
                "5": 116682876,
                "6": 116682877,
                "7": 2
            }, {
                "1": 429,
                "2": true
            }, {
                "1": 409,
                "3": 0.1,
                "4": 116744866,
                "5": 116744867,
                "6": 0,
                "7": 2
            }, {
                "1": 434,
                "2": true
            }, {
                "1": 417,
                "2": true
            }, {
                "1": 420,
                "2": true
            }, {
                "1": 406,
                "2": true
            }, {
                "1": 414,
                "3": 0.01,
                "4": 115985661,
                "5": 115985660,
                "6": 0,
                "7": 2
            }, {
                "1": 415,
                "2": true
            }, {
                "1": 412,
                "2": true
            }],
            "59": ["GTM-PKPPD5T"],
            "6": "63376059"
        },
        "permissions": {
            "__c": {},
            "__e": {
                "read_event_data": {
                    "eventDataAccess": "specific",
                    "keyPatterns": ["event"]
                }
            },
            "__f": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.referrer"]
                },
                "get_referrer": {
                    "urlParts": "any"
                }
            },
            "__j": {
                "unsafe_access_globals": {},
                "access_globals": {}
            },
            "__jsm": {
                "unsafe_run_arbitrary_javascript": {}
            },
            "__k": {
                "get_cookies": {
                    "cookieAccess": "any"
                },
                "read_data_layer": {
                    "keyPatterns": ["gtm.cookie"]
                }
            },
            "__remm": {},
            "__u": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.url"]
                },
                "get_url": {
                    "urlParts": "any"
                }
            },
            "__v": {
                "read_data_layer": {
                    "allowedKeys": "any"
                }
            }


        }



        ,
        "security_groups": {
            "customScripts": [
                "__jsm"

            ],
            "google": [
                "__c",
                "__e",
                "__f",
                "__j",
                "__k",
                "__remm",
                "__u",
                "__v"

            ]


        }



    };




    var k, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        da = function(a) {
            for (var b = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global], c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d && d.Math == Math) return d
            }
            throw Error("Cannot find global object");
        },
        ea = da(this),
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ia = {},
        ka = {},
        na = function(a, b, c) {
            if (!c || a != null) {
                var d = ka[b];
                if (d == null) return a[b];
                var e = a[d];
                return e !== void 0 ? e : a[b]
            }
        },
        oa = function(a, b, c) {
            if (b) a: {
                var d = a.split("."),
                    e = d.length === 1,
                    f = d[0],
                    g;!e && f in ia ? g = ia : g = ea;
                for (var h = 0; h < d.length - 1; h++) {
                    var l = d[h];
                    if (!(l in g)) break a;
                    g = g[l]
                }
                var n = d[d.length - 1],
                    p = fa && c === "es6" ? g[n] : null,
                    q = b(p);
                if (q != null)
                    if (e) ca(ia, n, {
                        configurable: !0,
                        writable: !0,
                        value: q
                    });
                    else if (q !== p) {
                    if (ka[n] === void 0) {
                        var r =
                            Math.random() * 1E9 >>> 0;
                        ka[n] = fa ? ea.Symbol(n) : "$jscp$" + r + "$" + n
                    }
                    ca(g, ka[n], {
                        configurable: !0,
                        writable: !0,
                        value: q
                    })
                }
            }
        },
        qa;
    if (fa && typeof Object.setPrototypeOf == "function") qa = Object.setPrototypeOf;
    else {
        var ra;
        a: {
            var sa = {
                    a: !0
                },
                ua = {};
            try {
                ua.__proto__ = sa;
                ra = ua.a;
                break a
            } catch (a) {}
            ra = !1
        }
        qa = ra ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var va = qa,
        wa = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (va) va(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.ns = b.prototype
        },
        xa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        m = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: xa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        ya = function(a) {
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        za = function(a) {
            return a instanceof Array ? a : ya(m(a))
        },
        Ba = function(a) {
            return Aa(a, a)
        },
        Aa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        Ca = fa && typeof na(Object, "assign") == "function" ? na(Object, "assign") : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };
    oa("Object.assign", function(a) {
        return a || Ca
    }, "es6");
    var Da = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ea = this || self,
        Fa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.ns = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.vt = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Ga = function(a, b) {
        this.type = a;
        this.data = b
    };
    var Ha = function() {
        this.map = {};
        this.C = {}
    };
    Ha.prototype.get = function(a) {
        return this.map["dust." + a]
    };
    Ha.prototype.set = function(a, b) {
        var c = "dust." + a;
        this.C.hasOwnProperty(c) || (this.map[c] = b)
    };
    Ha.prototype.has = function(a) {
        return this.map.hasOwnProperty("dust." + a)
    };
    Ha.prototype.remove = function(a) {
        var b = "dust." + a;
        this.C.hasOwnProperty(b) || delete this.map[b]
    };
    var Ia = function(a, b) {
        var c = [],
            d;
        for (d in a.map)
            if (a.map.hasOwnProperty(d)) {
                var e = d.substring(5);
                switch (b) {
                    case 1:
                        c.push(e);
                        break;
                    case 2:
                        c.push(a.map[d]);
                        break;
                    case 3:
                        c.push([e, a.map[d]])
                }
            }
        return c
    };
    Ha.prototype.ya = function() {
        return Ia(this, 1)
    };
    Ha.prototype.wc = function() {
        return Ia(this, 2)
    };
    Ha.prototype.hc = function() {
        return Ia(this, 3)
    };
    var Ja = function() {};
    Ja.prototype.reset = function() {};
    var Ka = function(a, b) {
        this.T = a;
        this.parent = b;
        this.P = this.C = void 0;
        this.Bb = !1;
        this.H = function(c, d, e) {
            return c.apply(d, e)
        };
        this.values = new Ha
    };
    Ka.prototype.add = function(a, b) {
        La(this, a, b, !1)
    };
    Ka.prototype.Fh = function(a, b) {
        La(this, a, b, !0)
    };
    var La = function(a, b, c, d) {
        if (!a.Bb)
            if (d) {
                var e = a.values;
                e.set(b, c);
                e.C["dust." + b] = !0
            } else a.values.set(b, c)
    };
    k = Ka.prototype;
    k.set = function(a, b) {
        this.Bb || (!this.values.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.values.set(a, b))
    };
    k.get = function(a) {
        return this.values.has(a) ? this.values.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.values.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.ob = function() {
        var a = new Ka(this.T, this);
        this.C && a.Rb(this.C);
        a.Zc(this.H);
        a.Ud(this.P);
        return a
    };
    k.Ld = function() {
        return this.T
    };
    k.Rb = function(a) {
        this.C = a
    };
    k.kn = function() {
        return this.C
    };
    k.Zc = function(a) {
        this.H = a
    };
    k.kj = function() {
        return this.H
    };
    k.Va = function() {
        this.Bb = !0
    };
    k.Ud = function(a) {
        this.P = a
    };
    k.qb = function() {
        return this.P
    };
    var Na = function() {
        this.value = {};
        this.prefix = "gtm."
    };
    Na.prototype.set = function(a, b) {
        this.value[this.prefix + String(a)] = b
    };
    Na.prototype.get = function(a) {
        return this.value[this.prefix + String(a)]
    };
    Na.prototype.has = function(a) {
        return this.value.hasOwnProperty(this.prefix + String(a))
    };

    function Oa() {
        try {
            if (Map) return new Map
        } catch (a) {}
        return new Na
    };
    var Pa = function() {
        this.values = []
    };
    Pa.prototype.add = function(a) {
        this.values.indexOf(a) === -1 && this.values.push(a)
    };
    Pa.prototype.has = function(a) {
        return this.values.indexOf(a) > -1
    };
    var Qa = function(a, b) {
        this.la = a;
        this.parent = b;
        this.T = this.H = void 0;
        this.Bb = !1;
        this.P = function(d, e, f) {
            return d.apply(e, f)
        };
        this.C = Oa();
        var c;
        a: {
            try {
                if (Set) {
                    c = new Set;
                    break a
                }
            } catch (d) {}
            c = new Pa
        }
        this.V = c
    };
    Qa.prototype.add = function(a, b) {
        Ra(this, a, b, !1)
    };
    Qa.prototype.Fh = function(a, b) {
        Ra(this, a, b, !0)
    };
    var Ra = function(a, b, c, d) {
        a.Bb || a.V.has(b) || (d && a.V.add(b), a.C.set(b, c))
    };
    k = Qa.prototype;
    k.set = function(a, b) {
        this.Bb || (!this.C.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.V.has(a) || this.C.set(a, b))
    };
    k.get = function(a) {
        return this.C.has(a) ? this.C.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.C.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.ob = function() {
        var a = new Qa(this.la, this);
        this.H && a.Rb(this.H);
        a.Zc(this.P);
        a.Ud(this.T);
        return a
    };
    k.Ld = function() {
        return this.la
    };
    k.Rb = function(a) {
        this.H = a
    };
    k.kn = function() {
        return this.H
    };
    k.Zc = function(a) {
        this.P = a
    };
    k.kj = function() {
        return this.P
    };
    k.Va = function() {
        this.Bb = !0
    };
    k.Ud = function(a) {
        this.T = a
    };
    k.qb = function() {
        return this.T
    };
    var Ta = function(a, b, c) {
        var d;
        d = Error.call(this, a.message);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.un = a;
        this.Zm = c === void 0 ? !1 : c;
        this.debugInfo = [];
        this.C = b
    };
    wa(Ta, Error);
    var Ua = function(a) {
        return a instanceof Ta ? a : new Ta(a, void 0, !0)
    };
    var Va = [];

    function Wa(a) {
        return Va[a] === void 0 ? !1 : Va[a]
    };
    var Xa = Oa();

    function Za(a, b) {
        for (var c, d = m(b), e = d.next(); !e.done && !(c = $a(a, e.value), c instanceof Ga); e = d.next());
        return c
    }

    function $a(a, b) {
        try {
            if (Wa(18)) {
                var c = b[0],
                    d = b.slice(1),
                    e = String(c),
                    f = Xa.has(e) ? Xa.get(e) : a.get(e);
                if (!f || typeof f.invoke !== "function") throw Ua(Error("Attempting to execute non-function " + b[0] + "."));
                return f.apply(a, d)
            }
            var g = m(b),
                h = g.next().value,
                l = ya(g),
                n = a.get(String(h));
            if (!n || typeof n.invoke !== "function") throw Ua(Error("Attempting to execute non-function " + b[0] + "."));
            return n.invoke.apply(n, [a].concat(za(l)))
        } catch (q) {
            var p = a.kn();
            p && p(q, b.context ? {
                id: b[0],
                line: b.context.line
            } : null);
            throw q;
        }
    };
    var ab = function() {
        this.H = new Ja;
        this.C = Wa(18) ? new Qa(this.H) : new Ka(this.H)
    };
    k = ab.prototype;
    k.Ld = function() {
        return this.H
    };
    k.Rb = function(a) {
        this.C.Rb(a)
    };
    k.Zc = function(a) {
        this.C.Zc(a)
    };
    k.execute = function(a) {
        return this.Kj([a].concat(za(Da.apply(1, arguments))))
    };
    k.Kj = function() {
        for (var a, b = m(Da.apply(0, arguments)), c = b.next(); !c.done; c = b.next()) a = $a(this.C, c.value);
        return a
    };
    k.Ip = function(a) {
        var b = Da.apply(1, arguments),
            c = this.C.ob();
        c.Ud(a);
        for (var d, e = m(b), f = e.next(); !f.done; f = e.next()) d = $a(c, f.value);
        return d
    };
    k.Va = function() {
        this.C.Va()
    };
    var bb = function() {
        this.Ha = !1;
        this.da = new Ha
    };
    k = bb.prototype;
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ha || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ha || this.da.remove(a)
    };
    k.ya = function() {
        return this.da.ya()
    };
    k.wc = function() {
        return this.da.wc()
    };
    k.hc = function() {
        return this.da.hc()
    };
    k.Va = function() {
        this.Ha = !0
    };
    k.Bb = function() {
        return this.Ha
    };

    function db() {
        for (var a = eb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function fb() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var eb, gb;

    function hb(a) {
        eb = eb || fb();
        gb = gb || db();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                g = d ? a.charCodeAt(c + 1) : 0,
                h = e ? a.charCodeAt(c + 2) : 0,
                l = f >> 2,
                n = (f & 3) << 4 | g >> 4,
                p = (g & 15) << 2 | h >> 6,
                q = h & 63;
            e || (q = 64, d || (p = 64));
            b.push(eb[l], eb[n], eb[p], eb[q])
        }
        return b.join("")
    }

    function ib(a) {
        function b(l) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = gb[n];
                if (p != null) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return l
        }
        eb = eb || fb();
        gb = gb || db();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (h === 64 && e === -1) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            g !== 64 && (c += String.fromCharCode(f << 4 & 240 | g >> 2), h !== 64 && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var jb = {};

    function kb(a, b) {
        var c = jb[a];
        c || (c = jb[a] = []);
        c[b] = !0
    }

    function lb() {
        delete jb.GA4_EVENT
    }

    function nb() {
        var a = ob.slice();
        jb.GTAG_EVENT_FEATURE_CHANNEL = a
    }

    function pb(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), c = 0), a[d] && (c |= 1 << d % 8);
        c > 0 && b.push(String.fromCharCode(c));
        return hb(b.join("")).replace(/\.+$/, "")
    };

    function qb() {}

    function rb(a) {
        return typeof a === "function"
    }

    function sb(a) {
        return typeof a === "string"
    }

    function tb(a) {
        return typeof a === "number" && !isNaN(a)
    }

    function ub(a) {
        return Array.isArray(a) ? a : [a]
    }

    function vb(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function wb(a, b) {
        if (!tb(a) || !tb(b) || a > b) a = 0, b = 2147483647;
        return Math.floor(Math.random() * (b - a + 1) + a)
    }

    function xb(a, b) {
        for (var c = new yb, d = 0; d < a.length; d++) c.set(a[d], !0);
        for (var e = 0; e < b.length; e++)
            if (c.get(b[e])) return !0;
        return !1
    }

    function zb(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    }

    function Ab(a) {
        return !!a && (Object.prototype.toString.call(a) === "[object Arguments]" || Object.prototype.hasOwnProperty.call(a, "callee"))
    }

    function Bb(a) {
        return Math.round(Number(a)) || 0
    }

    function Cb(a) {
        return "false" === String(a).toLowerCase() ? !1 : !!a
    }

    function Db(a) {
        var b = [];
        if (Array.isArray(a))
            for (var c = 0; c < a.length; c++) b.push(String(a[c]));
        return b
    }

    function Eb(a) {
        return a ? a.replace(/^\s+|\s+$/g, "") : ""
    }

    function Fb() {
        return new Date(Date.now())
    }

    function Gb() {
        return Fb().getTime()
    }
    var yb = function() {
        this.prefix = "gtm.";
        this.values = {}
    };
    yb.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    yb.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    yb.prototype.contains = function(a) {
        return this.get(a) !== void 0
    };

    function Hb(a, b, c) {
        return a && a.hasOwnProperty(b) ? a[b] : c
    }

    function Ib(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = void 0;
                try {
                    c()
                } catch (d) {}
            }
        }
    }

    function Jb(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
    }

    function Kb(a, b) {
        for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
        return c
    }

    function Lb(a, b) {
        return a.length >= b.length && a.substring(0, b.length) === b
    }

    function Mb(a, b) {
        return a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    }

    function Nb(a, b, c) {
        c = c || [];
        for (var d = a, e = 0; e < b.length - 1; e++) {
            if (!d.hasOwnProperty(b[e])) return;
            d = d[b[e]];
            if (c.indexOf(d) >= 0) return
        }
        return d
    }

    function Ob(a, b) {
        for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
        d[e[e.length - 1]] = b;
        return c
    }
    var Rb = /^\w{1,9}$/;

    function Sb(a, b) {
        a = a || {};
        b = b || ",";
        var c = [];
        zb(a, function(d, e) {
            Rb.test(d) && e && c.push(d)
        });
        return c.join(b)
    }

    function Tb(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            d < 128 ? b.push(d) : d < 2048 ? b.push(192 | d >> 6, 128 | d & 63) : d < 55296 || d >= 57344 ? b.push(224 | d >> 12, 128 | d >> 6 & 63, 128 | d & 63) : (d = 65536 + ((d & 1023) << 10 | a.charCodeAt(++c) & 1023), b.push(240 | d >> 18, 128 | d >> 12 & 63, 128 | d >> 6 & 63, 128 | d & 63))
        }
        return new Uint8Array(b)
    }

    function Ub(a, b) {
        function c() {
            e && ++d === b && (e(), e = null, c.done = !0)
        }
        var d = 0,
            e = a;
        c.done = !1;
        return c
    }

    function Vb(a) {
        if (!a) return a;
        var b = a;
        try {
            b = decodeURIComponent(a)
        } catch (d) {}
        var c = b.split(",");
        return c.length === 2 && c[0] === c[1] ? c[0] : a
    }

    function Wb(a, b, c) {
        function d(n) {
            var p = n.split("=")[0];
            if (a.indexOf(p) < 0) return n;
            if (c !== void 0) return p + "=" + c
        }

        function e(n) {
            return n.split("&").map(d).filter(function(p) {
                return p !== void 0
            }).join("&")
        }
        var f = b.href.split(/[?#]/)[0],
            g = b.search,
            h = b.hash;
        g[0] === "?" && (g = g.substring(1));
        h[0] === "#" && (h = h.substring(1));
        g = e(g);
        h = e(h);
        g !== "" && (g = "?" + g);
        h !== "" && (h = "#" + h);
        var l = "" + f + g + h;
        l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
        return l
    }

    function Xb(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    }

    function Yb() {
        var a = w,
            b;
        a: {
            var c = a.crypto || a.msCrypto;
            if (c && c.getRandomValues) try {
                var d = new Uint8Array(25);
                c.getRandomValues(d);
                b = btoa(String.fromCharCode.apply(String, za(d))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
                break a
            } catch (e) {}
            b = void 0
        }
        return b
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Zb = globalThis.trustedTypes,
        $b;

    function ac() {
        var a = null;
        if (!Zb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Zb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function bc() {
        $b === void 0 && ($b = ac());
        return $b
    };
    var cc = function(a) {
        this.C = a
    };
    cc.prototype.toString = function() {
        return this.C + ""
    };

    function dc(a) {
        var b = a,
            c = bc(),
            d = c ? c.createScriptURL(b) : b;
        return new cc(d)
    }

    function ec(a) {
        if (a instanceof cc) return a.C;
        throw Error("");
    };
    var fc = Ba([""]),
        hc = Aa(["\x00"], ["\\0"]),
        ic = Aa(["\n"], ["\\n"]),
        jc = Aa(["\x00"], ["\\u0000"]);

    function kc(a) {
        return a.toString().indexOf("`") === -1
    }
    kc(function(a) {
        return a(fc)
    }) || kc(function(a) {
        return a(hc)
    }) || kc(function(a) {
        return a(ic)
    }) || kc(function(a) {
        return a(jc)
    });
    var lc = function(a) {
        this.C = a
    };
    lc.prototype.toString = function() {
        return this.C
    };
    var mc = function(a) {
        this.yr = a
    };

    function nc(a) {
        return new mc(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var oc = [nc("data"), nc("http"), nc("https"), nc("mailto"), nc("ftp"), new mc(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function pc(a) {
        var b;
        b = b === void 0 ? oc : b;
        if (a instanceof lc) return a;
        for (var c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof mc && d.yr(a)) return new lc(a)
        }
    }
    var qc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function rc(a) {
        var b;
        if (a instanceof lc)
            if (a instanceof lc) b = a.C;
            else throw Error("");
        else b = qc.test(a) ? a : void 0;
        return b
    };

    function sc(a, b) {
        var c = rc(b);
        c !== void 0 && (a.action = c)
    };

    function tc(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var uc = function(a) {
        this.C = a
    };
    uc.prototype.toString = function() {
        return this.C + ""
    };
    var wc = function() {
        this.C = vc[0].toLowerCase()
    };
    wc.prototype.toString = function() {
        return this.C
    };

    function xc(a, b) {
        var c = [new wc];
        if (c.length === 0) throw Error("");
        var d = c.map(function(f) {
                var g;
                if (f instanceof wc) g = f.C;
                else throw Error("");
                return g
            }),
            e = b.toLowerCase();
        if (d.every(function(f) {
                return e.indexOf(f) !== 0
            })) throw Error('Attribute "' + b + '" does not match any of the allowed prefixes.');
        a.setAttribute(b, "true")
    };
    var yc = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function zc(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var w = window,
        Ac = window.history,
        z = document,
        Bc = navigator;

    function Cc() {
        var a;
        try {
            a = Bc.serviceWorker
        } catch (b) {
            return
        }
        return a
    }
    var Dc = z.currentScript,
        Ec = Dc && Dc.src;

    function Fc(a, b) {
        var c = w,
            d = c[a];
        c[a] = d === void 0 ? b : d;
        return c[a]
    }

    function Gc(a) {
        return (Bc.userAgent || "").indexOf(a) !== -1
    }

    function Hc() {
        return Gc("Firefox") || Gc("FxiOS")
    }

    function Ic() {
        return (Gc("GSA") || Gc("GoogleApp")) && (Gc("iPhone") || Gc("iPad"))
    }

    function Jc() {
        return Gc("Edg/") || Gc("EdgA/") || Gc("EdgiOS/")
    }
    var Kc = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Lc = {
            height: 1,
            onload: 1,
            src: 1,
            style: 1,
            width: 1
        };

    function Mc(a, b, c) {
        b && zb(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function Nc(a, b, c, d, e) {
        var f = z.createElement("script");
        Mc(f, d, Kc);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        var g;
        g = dc(zc(a));
        f.src = ec(g);
        var h, l = f.ownerDocument;
        l = l === void 0 ? document : l;
        var n, p, q = (p = (n = l).querySelector) == null ? void 0 : p.call(n, "script[nonce]");
        (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") && f.setAttribute("nonce", h);
        b && (f.onload = b);
        c && (f.onerror = c);
        if (e) e.appendChild(f);
        else {
            var r = z.getElementsByTagName("script")[0] || z.body || z.head;
            r.parentNode.insertBefore(f, r)
        }
        return f
    }

    function Oc() {
        if (Ec) {
            var a = Ec.toLowerCase();
            if (a.indexOf("https://") === 0) return 2;
            if (a.indexOf("http://") === 0) return 3
        }
        return 1
    }

    function Pc(a, b, c, d, e, f) {
        f = f === void 0 ? !0 : f;
        var g = e,
            h = !1;
        g || (g = z.createElement("iframe"), h = !0);
        Mc(g, c, Lc);
        d && zb(d, function(n, p) {
            g.dataset[n] = p
        });
        f && (g.height = "0", g.width = "0", g.style.display = "none", g.style.visibility = "hidden");
        a !== void 0 && (g.src = a);
        if (h) {
            var l = z.body && z.body.lastChild || z.body || z.head;
            l.parentNode.insertBefore(g, l)
        }
        b && (g.onload = b);
        return g
    }

    function Qc(a, b, c, d) {
        return Rc(a, b, c, d)
    }

    function Sc(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, !!d)
    }

    function Tc(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    }

    function Uc(a) {
        w.setTimeout(a, 0)
    }

    function Vc(a, b) {
        return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
    }

    function Wc(a) {
        var b = a.innerText || a.textContent || "";
        b && b !== " " && (b = b.replace(/^[\s\xa0]+/g, ""), b = b.replace(/[\s\xa0]+$/g, ""));
        b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
        return b
    }

    function Xc(a) {
        var b = z.createElement("div"),
            c = b,
            d, e = zc("A<div>" + a + "</div>"),
            f = bc(),
            g = f ? f.createHTML(e) : e;
        d = new uc(g);
        if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName)) throw Error("");
        var h;
        if (d instanceof uc) h = d.C;
        else throw Error("");
        c.innerHTML = h;
        b = b.lastChild;
        for (var l = []; b && b.firstChild;) l.push(b.removeChild(b.firstChild));
        return l
    }

    function Yc(a, b, c) {
        c = c || 100;
        for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
        for (var f = a, g = 0; f && g <= c; g++) {
            if (d[String(f.tagName).toLowerCase()]) return f;
            f = f.parentElement
        }
        return null
    }

    function Zc(a, b, c) {
        var d;
        try {
            d = Bc.sendBeacon && Bc.sendBeacon(a)
        } catch (e) {
            kb("TAGGING", 15)
        }
        d ? b == null || b() : Rc(a, b, c)
    }

    function $c(a, b) {
        try {
            return Bc.sendBeacon(a, b)
        } catch (c) {
            kb("TAGGING", 15)
        }
        return !1
    }
    var ad = Object.freeze({
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    });

    function bd(a, b, c, d, e) {
        if (cd()) {
            var f = na(Object, "assign").call(Object, {}, ad);
            b && (f.body = b);
            c && (c.attributionReporting && (f.attributionReporting = c.attributionReporting), c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics), c.credentials && (f.credentials = c.credentials), c.keepalive !== void 0 && (f.keepalive = c.keepalive), c.method && (f.method = c.method), c.mode && (f.mode = c.mode));
            try {
                var g = w.fetch(a, f);
                if (g) return g.then(function(l) {
                    l && (l.ok || l.status === 0) ? d == null || d() : e == null || e()
                }).catch(function() {
                    e ==
                        null || e()
                }), !0
            } catch (l) {}
        }
        if ((c == null ? 0 : c.Re) || (c == null ? 0 : c.credentials) && c.credentials !== "include") return e == null || e(), !1;
        if (b) {
            var h = $c(a, b);
            h ? d == null || d() : e == null || e();
            return h
        }
        dd(a, d, e);
        return !0
    }

    function cd() {
        return typeof w.fetch === "function"
    }

    function ed(a, b) {
        var c = a[b];
        c && typeof c.animVal === "string" && (c = c.animVal);
        return c
    }

    function fd() {
        var a = w.performance;
        if (a && rb(a.now)) return a.now()
    }

    function gd() {
        var a, b = w.performance;
        if (b && b.getEntriesByType) try {
            var c = b.getEntriesByType("navigation");
            c && c.length > 0 && (a = c[0].type)
        } catch (d) {
            return "e"
        }
        if (!a) return "u";
        switch (a) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }

    function hd() {
        return w.performance || void 0
    }

    function id() {
        var a = w.webPixelsManager;
        return a ? a.createShopifyExtend !== void 0 : !1
    }
    var Rc = function(a, b, c, d) {
            var e = new Image(1, 1);
            Mc(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a;
            return e
        },
        dd = Zc;

    function jd(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function kd(a, b) {
        return this.evaluate(a) === this.evaluate(b)
    }

    function ld(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function md(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        return String(c).indexOf(String(d)) > -1
    }

    function nd(a, b) {
        var c = String(this.evaluate(a)),
            d = String(this.evaluate(b));
        return c.substring(0, d.length) === d
    }

    function od(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        switch (c) {
            case "pageLocation":
                var e = w.location.href;
                d instanceof bb && d.get("stripProtocol") && (e = e.replace(/^https?:\/\//, ""));
                return e
        }
    };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
    */
    var pd = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        qd = function(a) {
            if (a == null) return String(a);
            var b = pd.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        rd = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        sd = function(a) {
            if (!a || qd(a) != "object" || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !rd(a, "constructor") && !rd(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return b === void 0 ||
                rd(a, b)
        },
        td = function(a, b) {
            var c = b || (qd(a) == "array" ? [] : {}),
                d;
            for (d in a)
                if (rd(a, d)) {
                    var e = a[d];
                    qd(e) == "array" ? (qd(c[d]) != "array" && (c[d] = []), c[d] = td(e, c[d])) : sd(e) ? (sd(c[d]) || (c[d] = {}), c[d] = td(e, c[d])) : c[d] = e
                }
            return c
        };

    function ud(a) {
        if (a == void 0 || Array.isArray(a) || sd(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    }

    function vd(a) {
        return typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0 || typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a)
    };
    var wd = function(a) {
        a = a === void 0 ? [] : a;
        this.da = new Ha;
        this.values = [];
        this.Ha = !1;
        for (var b in a) a.hasOwnProperty(b) && (vd(b) ? this.values[Number(b)] = a[Number(b)] : this.da.set(b, a[b]))
    };
    k = wd.prototype;
    k.toString = function(a) {
        if (a && a.indexOf(this) >= 0) return "";
        for (var b = [], c = 0; c < this.values.length; c++) {
            var d = this.values[c];
            d === null || d === void 0 ? b.push("") : d instanceof wd ? (a = a || [], a.push(this), b.push(d.toString(a)), a.pop()) : b.push(String(d))
        }
        return b.join(",")
    };
    k.set = function(a, b) {
        if (!this.Ha)
            if (a === "length") {
                if (!vd(b)) throw Ua(Error("RangeError: Length property must be a valid integer."));
                this.values.length = Number(b)
            } else vd(a) ? this.values[Number(a)] = b : this.da.set(a, b)
    };
    k.get = function(a) {
        return a === "length" ? this.length() : vd(a) ? this.values[Number(a)] : this.da.get(a)
    };
    k.length = function() {
        return this.values.length
    };
    k.ya = function() {
        for (var a = this.da.ya(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(String(b));
        return a
    };
    k.wc = function() {
        for (var a = this.da.wc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(this.values[b]);
        return a
    };
    k.hc = function() {
        for (var a = this.da.hc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
        return a
    };
    k.remove = function(a) {
        vd(a) ? delete this.values[Number(a)] : this.Ha || this.da.remove(a)
    };
    k.pop = function() {
        return this.values.pop()
    };
    k.push = function() {
        return this.values.push.apply(this.values, za(Da.apply(0, arguments)))
    };
    k.shift = function() {
        return this.values.shift()
    };
    k.splice = function(a, b) {
        var c = Da.apply(2, arguments);
        return b === void 0 && c.length === 0 ? new wd(this.values.splice(a)) : new wd(this.values.splice.apply(this.values, [a, b || 0].concat(za(c))))
    };
    k.unshift = function() {
        return this.values.unshift.apply(this.values, za(Da.apply(0, arguments)))
    };
    k.has = function(a) {
        return vd(a) && this.values.hasOwnProperty(a) || this.da.has(a)
    };
    k.Va = function() {
        this.Ha = !0;
        Object.freeze(this.values)
    };
    k.Bb = function() {
        return this.Ha
    };

    function xd(a) {
        for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
        return b
    };
    var yd = function(a, b) {
        this.functionName = a;
        this.Kd = b;
        this.da = new Ha;
        this.Ha = !1
    };
    k = yd.prototype;
    k.toString = function() {
        return this.functionName
    };
    k.getName = function() {
        return this.functionName
    };
    k.getKeys = function() {
        return new wd(this.ya())
    };
    k.invoke = function(a) {
        return this.Kd.call.apply(this.Kd, [new zd(this, a)].concat(za(Da.apply(1, arguments))))
    };
    k.apply = function(a, b) {
        return this.Kd.apply(new zd(this, a), b)
    };
    k.Pb = function(a) {
        var b = Da.apply(1, arguments);
        try {
            return this.invoke.apply(this, [a].concat(za(b)))
        } catch (c) {}
    };
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ha || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ha || this.da.remove(a)
    };
    k.ya = function() {
        return this.da.ya()
    };
    k.wc = function() {
        return this.da.wc()
    };
    k.hc = function() {
        return this.da.hc()
    };
    k.Va = function() {
        this.Ha = !0
    };
    k.Bb = function() {
        return this.Ha
    };
    var Ad = function(a, b) {
        yd.call(this, a, b)
    };
    wa(Ad, yd);
    var Bd = function(a, b) {
        yd.call(this, a, b)
    };
    wa(Bd, yd);
    var zd = function(a, b) {
        this.Kd = a;
        this.K = b
    };
    zd.prototype.evaluate = function(a) {
        var b = this.K;
        return Array.isArray(a) ? $a(b, a) : a
    };
    zd.prototype.getName = function() {
        return this.Kd.getName()
    };
    zd.prototype.Ld = function() {
        return this.K.Ld()
    };
    var Cd = function() {
        this.map = new Map
    };
    Cd.prototype.set = function(a, b) {
        this.map.set(a, b)
    };
    Cd.prototype.get = function(a) {
        return this.map.get(a)
    };
    var Dd = function() {
        this.keys = [];
        this.values = []
    };
    Dd.prototype.set = function(a, b) {
        this.keys.push(a);
        this.values.push(b)
    };
    Dd.prototype.get = function(a) {
        var b = this.keys.indexOf(a);
        if (b > -1) return this.values[b]
    };

    function Ed() {
        try {
            return Map ? new Cd : new Dd
        } catch (a) {
            return new Dd
        }
    };
    var Fd = function(a) {
        if (a instanceof Fd) return a;
        if (ud(a)) throw Error("Type of given value has an equivalent Pixie type.");
        this.value = a
    };
    Fd.prototype.getValue = function() {
        return this.value
    };
    Fd.prototype.toString = function() {
        return String(this.value)
    };
    var Hd = function(a) {
        this.promise = a;
        this.Ha = !1;
        this.da = new Ha;
        this.da.set("then", Gd(this));
        this.da.set("catch", Gd(this, !0));
        this.da.set("finally", Gd(this, !1, !0))
    };
    k = Hd.prototype;
    k.get = function(a) {
        return this.da.get(a)
    };
    k.set = function(a, b) {
        this.Ha || this.da.set(a, b)
    };
    k.has = function(a) {
        return this.da.has(a)
    };
    k.remove = function(a) {
        this.Ha || this.da.remove(a)
    };
    k.ya = function() {
        return this.da.ya()
    };
    k.wc = function() {
        return this.da.wc()
    };
    k.hc = function() {
        return this.da.hc()
    };
    var Gd = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        c = c === void 0 ? !1 : c;
        return new Ad("", function(d, e) {
            b && (e = d, d = void 0);
            c && (e = d);
            d instanceof Ad || (d = void 0);
            e instanceof Ad || (e = void 0);
            var f = this.K.ob(),
                g = function(l) {
                    return function(n) {
                        try {
                            return c ? (l.invoke(f), a.promise) : l.invoke(f, n)
                        } catch (p) {
                            return Promise.reject(p instanceof Error ? new Fd(p) : String(p))
                        }
                    }
                },
                h = a.promise.then(d && g(d), e && g(e));
            return new Hd(h)
        })
    };
    Hd.prototype.Va = function() {
        this.Ha = !0
    };
    Hd.prototype.Bb = function() {
        return this.Ha
    };

    function B(a, b, c) {
        var d = Ed(),
            e = function(g, h) {
                for (var l = g.ya(), n = 0; n < l.length; n++) h[l[n]] = f(g.get(l[n]))
            },
            f = function(g) {
                if (g === null || g === void 0) return g;
                var h = d.get(g);
                if (h) return h;
                if (g instanceof wd) {
                    var l = [];
                    d.set(g, l);
                    for (var n = g.ya(), p = 0; p < n.length; p++) l[n[p]] = f(g.get(n[p]));
                    return l
                }
                if (g instanceof Hd) return g.promise.then(function(t) {
                    return B(t, b, 1)
                }, function(t) {
                    return Promise.reject(B(t, b, 1))
                });
                if (g instanceof bb) {
                    var q = {};
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                if (g instanceof Ad) {
                    var r = function() {
                        for (var t = [], v = 0; v < arguments.length; v++) t[v] = Id(arguments[v], b, c);
                        var x = new Ka(b ? b.Ld() : new Ja);
                        b && x.Ud(b.qb());
                        return f(Wa(18) ? g.apply(x, t) : g.invoke.apply(g, [x].concat(za(t))))
                    };
                    d.set(g, r);
                    e(g, r);
                    return r
                }
                var u = !1;
                switch (c) {
                    case 1:
                        u = !0;
                        break;
                    case 2:
                        u = !1;
                        break;
                    case 3:
                        u = !1;
                        break;
                    default:
                }
                if (g instanceof Fd && u) return g.getValue();
                switch (typeof g) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "undefined":
                        return g;
                    case "object":
                        if (g === null) return null
                }
            };
        return f(a)
    }

    function Id(a, b, c) {
        var d = Ed(),
            e = function(g, h) {
                for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]))
            },
            f = function(g) {
                var h = d.get(g);
                if (h) return h;
                if (Array.isArray(g) || Ab(g)) {
                    var l = new wd;
                    d.set(g, l);
                    for (var n in g) g.hasOwnProperty(n) && l.set(n, f(g[n]));
                    return l
                }
                if (sd(g)) {
                    var p = new bb;
                    d.set(g, p);
                    e(g, p);
                    return p
                }
                if (typeof g === "function") {
                    var q = new Ad("", function() {
                        for (var t = Da.apply(0, arguments), v = [], x = 0; x < t.length; x++) v[x] = B(this.evaluate(t[x]), b, c);
                        return f(this.K.kj()(g, g, v))
                    });
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                var r = typeof g;
                if (g === null || r === "string" || r === "number" || r === "boolean") return g;
                var u = !1;
                switch (c) {
                    case 1:
                        u = !0;
                        break;
                    case 2:
                        u = !1;
                        break;
                    default:
                }
                if (g !== void 0 && u) return new Fd(g)
            };
        return f(a)
    };
    var Jd = {
        supportedMethods: "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),
        concat: function(a) {
            for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
            for (var d = 1; d < arguments.length; d++)
                if (arguments[d] instanceof wd)
                    for (var e = arguments[d], f = 0; f < e.length(); f++) b.push(e.get(f));
                else b.push(arguments[d]);
            return new wd(b)
        },
        every: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() &&
                d < c; d++)
                if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
            return !0
        },
        filter: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
            return new wd(d)
        },
        forEach: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++) this.has(d) && b.invoke(a, this.get(d), d, this)
        },
        hasOwnProperty: function(a, b) {
            return this.has(b)
        },
        indexOf: function(a, b, c) {
            var d = this.length(),
                e = c === void 0 ? 0 : Number(c);
            e < 0 && (e = Math.max(d + e, 0));
            for (var f =
                    e; f < d; f++)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        join: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            return c.join(b)
        },
        lastIndexOf: function(a, b, c) {
            var d = this.length(),
                e = d - 1;
            c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
            for (var f = e; f >= 0; f--)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        map: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
            return new wd(d)
        },
        pop: function() {
            return this.pop()
        },
        push: function(a) {
            return this.push.apply(this,
                za(Da.apply(1, arguments)))
        },
        reduce: function(a, b, c) {
            var d = this.length(),
                e, f = 0;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ua(Error("TypeError: Reduce on List with no elements."));
                for (var g = 0; g < d; g++)
                    if (this.has(g)) {
                        e = this.get(g);
                        f = g + 1;
                        break
                    }
                if (g === d) throw Ua(Error("TypeError: Reduce on List with no elements."));
            }
            for (var h = f; h < d; h++) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reduceRight: function(a, b, c) {
            var d = this.length(),
                e, f = d - 1;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ua(Error("TypeError: ReduceRight on List with no elements."));
                for (var g = 1; g <= d; g++)
                    if (this.has(d - g)) {
                        e = this.get(d - g);
                        f = d - (g + 1);
                        break
                    }
                if (g > d) throw Ua(Error("TypeError: ReduceRight on List with no elements."));
            }
            for (var h = f; h >= 0; h--) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reverse: function() {
            for (var a = xd(this), b = a.length - 1, c = 0; b >= 0; b--, c++) a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
            return this
        },
        shift: function() {
            return this.shift()
        },
        slice: function(a, b, c) {
            var d = this.length();
            b === void 0 && (b = 0);
            b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
            c = c ===
                void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
            c = Math.max(b, c);
            for (var e = [], f = b; f < c; f++) e.push(this.get(f));
            return new wd(e)
        },
        some: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
                if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
            return !1
        },
        sort: function(a, b) {
            var c = xd(this);
            b === void 0 ? c.sort() : c.sort(function(e, f) {
                return Number(b.invoke(a, e, f))
            });
            for (var d = 0; d < c.length; d++) c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
            return this
        },
        splice: function(a, b, c) {
            return this.splice.apply(this, [b, c].concat(za(Da.apply(3, arguments))))
        },
        toString: function() {
            return this.toString()
        },
        unshift: function(a) {
            return this.unshift.apply(this, za(Da.apply(1, arguments)))
        }
    };
    var Kd = {
            charAt: 1,
            concat: 1,
            indexOf: 1,
            lastIndexOf: 1,
            match: 1,
            replace: 1,
            search: 1,
            slice: 1,
            split: 1,
            substring: 1,
            toLowerCase: 1,
            toLocaleLowerCase: 1,
            toString: 1,
            toUpperCase: 1,
            toLocaleUpperCase: 1,
            trim: 1
        },
        Ld = new Ga("break"),
        Md = new Ga("continue");

    function Nd(a, b) {
        return this.evaluate(a) + this.evaluate(b)
    }

    function Od(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function Pd(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!(f instanceof wd)) throw Error("Error: Non-List argument given to Apply instruction.");
        if (d === null || d === void 0) throw Ua(Error("TypeError: Can't read property " + e + " of " + d + "."));
        var g = typeof d === "number";
        if (typeof d === "boolean" || g) {
            if (e === "toString") {
                if (g && f.length()) {
                    var h = B(f.get(0));
                    try {
                        return d.toString(h)
                    } catch (x) {}
                }
                return d.toString()
            }
            if (Wa(22) && e === "toLocaleString" && g) {
                var l = B(f.get(0)),
                    n = B(f.get(1));
                return d.toLocaleString(l,
                    n)
            }
            throw Ua(Error("TypeError: " + d + "." + e + " is not a function."));
        }
        if (typeof d === "string") {
            if (Kd.hasOwnProperty(e)) {
                var p = B(f, void 0, 1);
                return Id(d[e].apply(d, p), this.K)
            }
            throw Ua(Error("TypeError: " + e + " is not a function"));
        }
        if (d instanceof wd) {
            if (d.has(e)) {
                var q = d.get(String(e));
                if (q instanceof Ad) {
                    var r = xd(f);
                    return Wa(18) ? q.apply(this.K, r) : q.invoke.apply(q, [this.K].concat(za(r)))
                }
                throw Ua(Error("TypeError: " + e + " is not a function"));
            }
            if (Jd.supportedMethods.indexOf(e) >= 0) {
                var u = xd(f);
                return Jd[e].call.apply(Jd[e], [d, this.K].concat(za(u)))
            }
        }
        if (d instanceof Ad || d instanceof bb || d instanceof Hd) {
            if (d.has(e)) {
                var t = d.get(e);
                if (t instanceof Ad) {
                    var v = xd(f);
                    return Wa(18) ? t.apply(this.K, v) : t.invoke.apply(t, [this.K].concat(za(v)))
                }
                throw Ua(Error("TypeError: " + e + " is not a function"));
            }
            if (e === "toString") return d instanceof Ad ? d.getName() : d.toString();
            if (e === "hasOwnProperty") return d.has(f.get(0))
        }
        if (d instanceof Fd && e === "toString") return d.toString();
        throw Ua(Error("TypeError: Object has no '" + e + "' property."));
    }

    function Qd(a, b) {
        a = this.evaluate(a);
        if (typeof a !== "string") throw Error("Invalid key name given for assignment.");
        var c = this.K;
        if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
        var d = this.evaluate(b);
        c.set(a, d);
        return d
    }

    function Rd() {
        var a = Da.apply(0, arguments),
            b = this.K.ob(),
            c = Za(b, a);
        if (c instanceof Ga) return c
    }

    function Sd() {
        return Ld
    }

    function Td(a) {
        for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
            var d = this.evaluate(b[c]);
            if (d instanceof Ga) return d
        }
    }

    function Ud() {
        for (var a = this.K, b = 0; b < arguments.length - 1; b += 2) {
            var c = arguments[b];
            if (typeof c === "string") {
                var d = this.evaluate(arguments[b + 1]);
                a.Fh(c, d)
            }
        }
    }

    function Vd() {
        return Md
    }

    function Wd(a, b) {
        return new Ga(a, this.evaluate(b))
    }

    function Xd(a, b) {
        var c = Da.apply(2, arguments),
            d;
        d = new wd;
        for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
        var g = [51, a, d].concat(za(c));
        this.K.add(a, this.evaluate(g))
    }

    function Yd(a, b) {
        return this.evaluate(a) / this.evaluate(b)
    }

    function Zd(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b),
            e = c instanceof Fd,
            f = d instanceof Fd;
        return e || f ? e && f ? c.getValue() === d.getValue() : !1 : c == d
    }

    function $d() {
        for (var a, b = 0; b < arguments.length; b++) a = this.evaluate(arguments[b]);
        return a
    }

    function ae(a, b, c, d) {
        for (var e = 0; e < b(); e++) {
            var f = a(c(e)),
                g = Za(f, d);
            if (g instanceof Ga) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
        }
    }

    function be(a, b, c) {
        if (typeof b === "string") return ae(a, function() {
            return b.length
        }, function(f) {
            return f
        }, c);
        if (b instanceof bb || b instanceof Hd || b instanceof wd || b instanceof Ad) {
            var d = b.ya(),
                e = d.length;
            return ae(a, function() {
                return e
            }, function(f) {
                return d[f]
            }, c)
        }
    }

    function ce(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return be(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function de(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return be(function(h) {
            var l = g.ob();
            l.Fh(d, h);
            return l
        }, e, f)
    }

    function ee(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return be(function(h) {
            var l = g.ob();
            l.add(d, h);
            return l
        }, e, f)
    }

    function fe(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return ge(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function he(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return ge(function(h) {
            var l = g.ob();
            l.Fh(d, h);
            return l
        }, e, f)
    }

    function ie(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.K;
        return ge(function(h) {
            var l = g.ob();
            l.add(d, h);
            return l
        }, e, f)
    }

    function ge(a, b, c) {
        if (typeof b === "string") return ae(a, function() {
            return b.length
        }, function(d) {
            return b[d]
        }, c);
        if (b instanceof wd) return ae(a, function() {
            return b.length()
        }, function(d) {
            return b.get(d)
        }, c);
        throw Ua(Error("The value is not iterable."));
    }

    function je(a, b, c, d) {
        function e(q, r) {
            for (var u = 0; u < f.length(); u++) {
                var t = f.get(u);
                r.add(t, q.get(t))
            }
        }
        var f = this.evaluate(a);
        if (!(f instanceof wd)) throw Error("TypeError: Non-List argument given to ForLet instruction.");
        var g = this.K,
            h = this.evaluate(d),
            l = g.ob();
        for (e(g, l); $a(l, b);) {
            var n = Za(l, h);
            if (n instanceof Ga) {
                if (n.type === "break") break;
                if (n.type === "return") return n
            }
            var p = g.ob();
            e(l, p);
            $a(p, c);
            l = p
        }
    }

    function me(a, b) {
        var c = Da.apply(2, arguments),
            d = this.K,
            e = this.evaluate(b);
        if (!(e instanceof wd)) throw Error("Error: non-List value given for Fn argument names.");
        return new Ad(a, function() {
            return function() {
                var f = Da.apply(0, arguments),
                    g = d.ob();
                g.qb() === void 0 && g.Ud(this.K.qb());
                for (var h = [], l = 0; l < f.length; l++) {
                    var n = this.evaluate(f[l]);
                    h[l] = n
                }
                for (var p = e.get("length"), q = 0; q < p; q++) q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
                g.add("arguments", new wd(h));
                var r = Za(g, c);
                if (r instanceof Ga) return r.type ===
                    "return" ? r.data : r
            }
        }())
    }

    function ne(a) {
        var b = this.evaluate(a),
            c = this.K;
        if (oe && !c.has(b)) throw new ReferenceError(b + " is not defined.");
        return c.get(b)
    }

    function pe(a, b) {
        var c, d = this.evaluate(a),
            e = this.evaluate(b);
        if (d === void 0 || d === null) throw Ua(Error("TypeError: Cannot read properties of " + d + " (reading '" + e + "')"));
        if (d instanceof bb || d instanceof Hd || d instanceof wd || d instanceof Ad) c = d.get(e);
        else if (typeof d === "string") e === "length" ? c = d.length : vd(e) && (c = d[e]);
        else if (d instanceof Fd) return;
        return c
    }

    function qe(a, b) {
        return this.evaluate(a) > this.evaluate(b)
    }

    function re(a, b) {
        return this.evaluate(a) >= this.evaluate(b)
    }

    function se(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        c instanceof Fd && (c = c.getValue());
        d instanceof Fd && (d = d.getValue());
        return c === d
    }

    function te(a, b) {
        return !se.call(this, a, b)
    }

    function ue(a, b, c) {
        var d = [];
        this.evaluate(a) ? d = this.evaluate(b) : c && (d = this.evaluate(c));
        var e = Za(this.K, d);
        if (e instanceof Ga) return e
    }
    var oe = !1;

    function ve(a, b) {
        return this.evaluate(a) < this.evaluate(b)
    }

    function we(a, b) {
        return this.evaluate(a) <= this.evaluate(b)
    }

    function xe() {
        for (var a = new wd, b = 0; b < arguments.length; b++) {
            var c = this.evaluate(arguments[b]);
            a.push(c)
        }
        return a
    }

    function ye() {
        for (var a = new bb, b = 0; b < arguments.length - 1; b += 2) {
            var c = String(this.evaluate(arguments[b])),
                d = this.evaluate(arguments[b + 1]);
            a.set(c, d)
        }
        return a
    }

    function ze(a, b) {
        return this.evaluate(a) % this.evaluate(b)
    }

    function Ae(a, b) {
        return this.evaluate(a) * this.evaluate(b)
    }

    function Be(a) {
        return -this.evaluate(a)
    }

    function Ce(a) {
        return !this.evaluate(a)
    }

    function De(a, b) {
        return !Zd.call(this, a, b)
    }

    function Ee() {
        return null
    }

    function Fe(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function Ge(a, b) {
        var c = this.evaluate(a);
        this.evaluate(b);
        return c
    }

    function He(a) {
        return this.evaluate(a)
    }

    function Ie() {
        return Da.apply(0, arguments)
    }

    function Je(a) {
        return new Ga("return", this.evaluate(a))
    }

    function Ke(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (d === null || d === void 0) throw Ua(Error("TypeError: Can't set property " + e + " of " + d + "."));
        (d instanceof Ad || d instanceof wd || d instanceof bb) && d.set(String(e), f);
        return f
    }

    function Le(a, b) {
        return this.evaluate(a) - this.evaluate(b)
    }

    function Me(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!Array.isArray(e) || !Array.isArray(f)) throw Error("Error: Malformed switch instruction.");
        for (var g, h = !1, l = 0; l < e.length; l++)
            if (h || d === this.evaluate(e[l]))
                if (g = this.evaluate(f[l]), g instanceof Ga) {
                    var n = g.type;
                    if (n === "break") return;
                    if (n === "return" || n === "continue") return g
                } else h = !0;
        if (f.length === e.length + 1 && (g = this.evaluate(f[f.length - 1]), g instanceof Ga && (g.type === "return" || g.type === "continue"))) return g
    }

    function Ne(a, b, c) {
        return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c)
    }

    function Oe(a) {
        var b = this.evaluate(a);
        return b instanceof Ad ? "function" : typeof b
    }

    function Pe() {
        for (var a = this.K, b = 0; b < arguments.length; b++) {
            var c = arguments[b];
            typeof c !== "string" || a.add(c, void 0)
        }
    }

    function Re(a, b, c, d) {
        var e = this.evaluate(d);
        if (this.evaluate(c)) {
            var f = Za(this.K, e);
            if (f instanceof Ga) {
                if (f.type === "break") return;
                if (f.type === "return") return f
            }
        }
        for (; this.evaluate(a);) {
            var g = Za(this.K, e);
            if (g instanceof Ga) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
            this.evaluate(b)
        }
    }

    function Se(a) {
        return ~Number(this.evaluate(a))
    }

    function Te(a, b) {
        return Number(this.evaluate(a)) << Number(this.evaluate(b))
    }

    function Ue(a, b) {
        return Number(this.evaluate(a)) >> Number(this.evaluate(b))
    }

    function Ve(a, b) {
        return Number(this.evaluate(a)) >>> Number(this.evaluate(b))
    }

    function We(a, b) {
        return Number(this.evaluate(a)) & Number(this.evaluate(b))
    }

    function Xe(a, b) {
        return Number(this.evaluate(a)) ^ Number(this.evaluate(b))
    }

    function Ye(a, b) {
        return Number(this.evaluate(a)) | Number(this.evaluate(b))
    }

    function Ze() {}

    function $e(a, b, c) {
        try {
            var d = this.evaluate(b);
            if (d instanceof Ga) return d
        } catch (h) {
            if (!(h instanceof Ta && h.Zm)) throw h;
            var e = this.K.ob();
            a !== "" && (h instanceof Ta && (h = h.un), e.add(a, new Fd(h)));
            var f = this.evaluate(c),
                g = Za(e, f);
            if (g instanceof Ga) return g
        }
    }

    function af(a, b) {
        var c, d;
        try {
            d = this.evaluate(a)
        } catch (f) {
            if (!(f instanceof Ta && f.Zm)) throw f;
            c = f
        }
        var e = this.evaluate(b);
        if (e instanceof Ga) return e;
        if (c) throw c;
        if (d instanceof Ga) return d
    };
    var cf = function() {
        this.C = new ab;
        bf(this)
    };
    cf.prototype.execute = function(a) {
        return this.C.Kj(a)
    };
    var bf = function(a) {
        var b = function(c, d) {
            var e = new Bd(String(c), d);
            e.Va();
            var f = String(c);
            a.C.C.set(f, e);
            Xa.set(f, e)
        };
        b("map", ye);
        b("and", jd);
        b("contains", md);
        b("equals", kd);
        b("or", ld);
        b("startsWith", nd);
        b("variable", od)
    };
    cf.prototype.Rb = function(a) {
        this.C.Rb(a)
    };
    var ef = function() {
        this.H = !1;
        this.C = new ab;
        df(this);
        this.H = !0
    };
    ef.prototype.execute = function(a) {
        return ff(this.C.Kj(a))
    };
    var gf = function(a, b, c) {
        return ff(a.C.Ip(b, c))
    };
    ef.prototype.Va = function() {
        this.C.Va()
    };
    var df = function(a) {
        var b = function(c, d) {
            var e = String(c),
                f = new Bd(e, d);
            f.Va();
            a.C.C.set(e, f);
            Xa.set(e, f)
        };
        b(0, Nd);
        b(1, Od);
        b(2, Pd);
        b(3, Qd);
        b(56, We);
        b(57, Te);
        b(58, Se);
        b(59, Ye);
        b(60, Ue);
        b(61, Ve);
        b(62, Xe);
        b(53, Rd);
        b(4, Sd);
        b(5, Td);
        b(68, $e);
        b(52, Ud);
        b(6, Vd);
        b(49, Wd);
        b(7, xe);
        b(8, ye);
        b(9, Td);
        b(50, Xd);
        b(10, Yd);
        b(12, Zd);
        b(13, $d);
        b(67, af);
        b(51, me);
        b(47, ce);
        b(54, de);
        b(55, ee);
        b(63, je);
        b(64, fe);
        b(65, he);
        b(66, ie);
        b(15, ne);
        b(16, pe);
        b(17, pe);
        b(18, qe);
        b(19, re);
        b(20, se);
        b(21, te);
        b(22, ue);
        b(23, ve);
        b(24, we);
        b(25, ze);
        b(26,
            Ae);
        b(27, Be);
        b(28, Ce);
        b(29, De);
        b(45, Ee);
        b(30, Fe);
        b(32, Ge);
        b(33, Ge);
        b(34, He);
        b(35, He);
        b(46, Ie);
        b(36, Je);
        b(43, Ke);
        b(37, Le);
        b(38, Me);
        b(39, Ne);
        b(40, Oe);
        b(44, Ze);
        b(41, Pe);
        b(42, Re)
    };
    ef.prototype.Ld = function() {
        return this.C.Ld()
    };
    ef.prototype.Rb = function(a) {
        this.C.Rb(a)
    };
    ef.prototype.Zc = function(a) {
        this.C.Zc(a)
    };

    function ff(a) {
        if (a instanceof Ga || a instanceof Ad || a instanceof wd || a instanceof bb || a instanceof Hd || a instanceof Fd || a === null || a === void 0 || typeof a === "string" || typeof a === "number" || typeof a === "boolean") return a
    };
    var hf = function(a) {
        this.message = a
    };

    function jf(a) {
        a.Bt = !0;
        return a
    };
    var kf = jf(function(a) {
        return typeof a === "string"
    });

    function lf(a) {
        var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [a];
        return b === void 0 ? new hf("Value " + a + " can not be encoded in web-safe base64 dictionary.") : b
    };

    function mf(a) {
        switch (a) {
            case 1:
                return "1";
            case 2:
            case 4:
                return "0";
            default:
                return "-"
        }
    };
    var nf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;

    function of (a, b) {
        for (var c = "", d = !0; a > 7;) {
            var e = a & 31;
            a >>= 5;
            d ? d = !1 : e |= 32;
            c = "" + lf(e) + c
        }
        a <<= 2;
        d || (a |= 32);
        return c = "" + lf(a | b) + c
    }

    function pf(a, b) {
        var c;
        var d = a.Th,
            e = a.yj;
        d === void 0 ? c = "" : (e || (e = 0), c = "" + of (1, 1) + lf(d << 2 | e));
        var f = a.qq,
            g = "4" + c + (f ? "" + of (2, 1) + lf(f) : ""),
            h, l = a.Gn;
        h = l && nf.test(l) ? "" + of (3, 2) + l : "";
        var n, p = a.Bn;
        n = p ? "" + of (4, 1) + lf(p) : "";
        var q;
        var r = a.ctid;
        if (r && b) {
            var u = of (5, 3),
                t = r.split("-"),
                v = t[0].toUpperCase();
            if (v !== "GTM" && v !== "OPT") q = "";
            else {
                var x = t[1];
                q = "" + u + lf(1 + x.length) + (a.zr || 0) + x
            }
        } else q = "";
        var y = a.ks,
            A = a.canonicalId,
            C = a.Ra,
            E = a.Ft,
            H = g + h + n + q + (y ? "" + of (6, 1) + lf(y) : "") + (A ? "" + of (7, 3) + lf(A.length) + A : "") + (C ? "" + of (8, 3) +
                lf(C.length) + C : "") + (E ? "" + of (9, 3) + lf(E.length) + E : ""),
            J;
        var O = a.xq;
        O = O === void 0 ? {} : O;
        for (var ba = [], W = m(Object.keys(O)), N = W.next(); !N.done; N = W.next()) {
            var S = N.value;
            ba[Number(S)] = O[S]
        }
        if (ba.length) {
            var la = of (10, 3),
                ja;
            if (ba.length === 0) ja = lf(0);
            else {
                for (var V = [], U = 0, ha = !1, ta = 0; ta < ba.length; ta++) {
                    ha = !0;
                    var pa = ta % 6;
                    ba[ta] && (U |= 1 << pa);
                    pa === 5 && (V.push(lf(U)), U = 0, ha = !1)
                }
                ha && V.push(lf(U));
                ja = V.join("")
            }
            var Ma = ja;
            J = "" + la + lf(Ma.length) + Ma
        } else J = "";
        var Sa = a.Gr,
            mb = a.Ur,
            cb = a.ls;
        return H + J + (Sa ? "" + of (11, 3) + lf(Sa.length) +
            Sa : "") + (mb ? "" + of (13, 3) + lf(mb.length) + mb : "") + (cb ? "" + of (14, 1) + lf(cb) : "")
    };

    function qf(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        return b
    };

    function rf(a, b) {
        for (var c = ib(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++) d[e] = c.charCodeAt(e);
        if (d.length !== 32) throw Error("Key is not 32 bytes.");
        return sf(a, d)
    }

    function sf(a, b) {
        if (a === "") return "";
        var c = Tb(a),
            d = b.slice(-2),
            e = [].concat(za(d), za(c)).map(function(g, h) {
                return g ^ b[h % b.length]
            }),
            f = new Uint8Array([].concat(za(e), za(d)));
        return hb(String.fromCharCode.apply(String, za(f))).replace(/\.+$/, "")
    };
    var tf = function() {
        function a(b) {
            return {
                toString: function() {
                    return b
                }
            }
        }
        return {
            Zn: a("consent"),
            lk: a("convert_case_to"),
            mk: a("convert_false_to"),
            nk: a("convert_null_to"),
            pk: a("convert_true_to"),
            qk: a("convert_undefined_to"),
            Ds: a("debug_mode_metadata"),
            Ta: a("function"),
            sh: a("instance_name"),
            Mp: a("live_only"),
            Np: a("malware_disabled"),
            METADATA: a("metadata"),
            Qp: a("original_activity_id"),
            Zs: a("original_vendor_template_id"),
            Ys: a("once_on_load"),
            Pp: a("once_per_event"),
            sm: a("once_per_load"),
            ct: a("priority_override"),
            ht: a("respected_consent_types"),
            Bm: a("setup_tags"),
            Eh: a("tag_id"),
            Nm: a("teardown_tags")
        }
    }();
    var Pf;
    var Qf = [],
        Rf = [],
        Sf = [],
        Tf = [],
        Uf = [],
        Vf, Wf, Xf;

    function Yf(a) {
        Xf = Xf || a
    }

    function Zf() {
        for (var a = data.resource || {}, b = a.macros || [], c = 0; c < b.length; c++) Qf.push(b[c]);
        for (var d = a.tags || [], e = 0; e < d.length; e++) Tf.push(d[e]);
        for (var f = a.predicates || [], g = 0; g < f.length; g++) Sf.push(f[g]);
        for (var h = a.rules || [], l = 0; l < h.length; l++) {
            for (var n = h[l], p = {}, q = 0; q < n.length; q++) {
                var r = n[q][0];
                p[r] = Array.prototype.slice.call(n[q], 1);
                r !== "if" && r !== "unless" || $f(p[r])
            }
            Rf.push(p)
        }
    }

    function $f(a) {}
    var ag, bg = [],
        cg = [];

    function dg(a, b) {
        var c = {};
        c[tf.Ta] = "__" + a;
        for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
        return c
    }

    function eg(a, b, c) {
        try {
            return Wf(fg(a, b, c))
        } catch (d) {
            JSON.stringify(a)
        }
        return 2
    }
    var fg = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = gg(a[e], b, c));
            return d
        },
        gg = function(a, b, c) {
            if (Array.isArray(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(gg(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = Qf[f];
                        if (!g || b.isBlocked(g)) return;
                        c[f] = !0;
                        var h = String(g[tf.sh]);
                        try {
                            var l = fg(g, b, c);
                            l.vtp_gtmEventId = b.id;
                            b.priorityId && (l.vtp_gtmPriorityId = b.priorityId);
                            d = hg(l, {
                                event: b,
                                index: f,
                                type: 2,
                                name: h
                            });
                            ag && (d = ag.yq(d, l))
                        } catch (A) {
                            b.logMacroError && b.logMacroError(A, Number(f), h), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[gg(a[n], b, c)] = gg(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var r = gg(a[q], b, c);
                            Xf && (p = p || Xf.vr(r));
                            d.push(r)
                        }
                        return Xf && p ? Xf.Dq(d) : d.join("");
                    case "escape":
                        d = gg(a[1], b, c);
                        if (Xf && Array.isArray(a[1]) && a[1][0] === "macro" && Xf.wr(a)) return Xf.Mr(d);
                        d = String(d);
                        for (var u = 2; u < a.length; u++) Af[a[u]] && (d = Af[a[u]](d));
                        return d;
                    case "tag":
                        var t = a[1];
                        if (!Tf[t]) throw Error("Unable to resolve tag reference " + t + ".");
                        return {
                            gn: a[2],
                            index: t
                        };
                    case "zb":
                        var v = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        v[tf.Ta] = a[1];
                        var x = eg(v, b, c),
                            y = !!a[4];
                        return y || x !== 2 ? y !== (x === 1) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        hg = function(a, b) {
            var c = a[tf.Ta],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = Vf[c],
                f = b && b.type === 2 && (d == null ? void 0 : d.reportMacroDiscrepancy) &&
                e && bg.indexOf(c) !== -1,
                g = {},
                h = {},
                l;
            for (l in a) a.hasOwnProperty(l) && Lb(l, "vtp_") && (e && (g[l] = a[l]), !e || f) && (h[l.substring(4)] = a[l]);
            e && d && d.cachedModelValues && (g.vtp_gtmCachedValues = d.cachedModelValues);
            if (b) {
                if (b.name == null) {
                    var n;
                    a: {
                        var p = b.type,
                            q = b.index;
                        if (q == null) n = "";
                        else {
                            var r;
                            switch (p) {
                                case 2:
                                    r = Qf[q];
                                    break;
                                case 1:
                                    r = Tf[q];
                                    break;
                                default:
                                    n = "";
                                    break a
                            }
                            var u = r && r[tf.sh];
                            n = u ? String(u) : ""
                        }
                    }
                    b.name = n
                }
                e && (g.vtp_gtmEntityIndex = b.index, g.vtp_gtmEntityName = b.name)
            }
            var t, v, x;
            if (f && cg.indexOf(c) === -1) {
                cg.push(c);
                var y = Gb();
                t = e(g);
                var A = Gb() - y,
                    C = Gb();
                v = Pf(c, h, b);
                x = A - (Gb() - C)
            } else if (e && (t = e(g)), !e || f) v = Pf(c, h, b);
            if (f && d) {
                d.reportMacroDiscrepancy(d.id, c, void 0, !0);
                if (ud(t)) {
                    var E = !1;
                    if (Array.isArray(t)) E = !Array.isArray(v);
                    else if (sd(t))
                        if (sd(v)) {
                            if (c === "__gas") a: {
                                for (var H = t, J = v, O = m(Object.keys(H)), ba = O.next(); !ba.done; ba = O.next()) {
                                    var W = ba.value;
                                    if (W === "vtp_fieldsToSet" || W === "vtp_contentGroup" || W === "vtp_dimension" || W === "vtp_metric") {
                                        var N = H[W],
                                            S = J[W.substring(4)];
                                        if (ig(W, N, J[W]) && ig(W, N, S)) continue;
                                        else {
                                            E = !0;
                                            break a
                                        }
                                    }
                                    if (W !== "vtp_gtmCachedValues" && W !== "vtp_gtmEntityIndex" && W !== "vtp_gtmEntityName" && W !== "function" && W !== "instance_name") {
                                        var la = H[W];
                                        if (!jg(J[W], la) || !jg(J[W.substring(4)], la)) {
                                            E = !0;
                                            break a
                                        }
                                    }
                                }
                                E = !1
                            }
                        } else E = !0;
                    else E = typeof t === "function" ? typeof v !== "function" : t !== v;
                    E && d.reportMacroDiscrepancy(d.id, c)
                } else t !== v && d.reportMacroDiscrepancy(d.id, c);
                x !== void 0 && d.reportMacroDiscrepancy(d.id, c, x)
            }
            return e ? t : v
        };

    function ig(a, b, c) {
        if (b.length !== c.length) return !1;
        var d, e;
        a === "vtp_fieldsToSet" ? (d = "fieldName", e = "value") : (d = "index", e = a === "vtp_contentGroup" ? "group" : a === "vtp_dimension" ? "dimension" : "metric");
        for (var f = 0; f < b.length; f++)
            if (!jg(b[f][d], c[f][d]) || !jg(b[f][e], c[f][e])) return !1;
        return !0
    }

    function jg(a, b) {
        return typeof a === "number" ? typeof b !== "number" ? !1 : String(a).length === 13 ? Math.abs(a - b) < 1E3 : a === b : typeof a === "function" ? typeof b === "function" : Array.isArray(a) ? Array.isArray(b) && a.length === b.length ? !0 : !1 : sd(a) ? sd(b) : a === b
    };

    function kg(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? !!data.blob[a] : b
    }

    function D(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? String(data.blob[a]) : b
    }

    function lg(a) {
        var b, c;
        return ((b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)) ? Number(data.blob[a]) : 0
    }

    function mg(a) {
        var b;
        b = b === void 0 ? [] : b;
        var c, d, e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
        return Array.isArray(e) ? e : b
    }

    function ng(a) {
        var b;
        b = b === void 0 ? "" : b;
        var c = og(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b
    }

    function pg(a, b) {
        var c = og(46);
        return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b
    }

    function og(a) {
        var b, c;
        return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a]
    };
    var qg = function(a, b, c) {
        var d;
        d = Error.call(this, c);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.permissionId = a;
        this.parameters = b;
        this.name = "PermissionError"
    };
    wa(qg, Error);
    qg.prototype.getMessage = function() {
        return this.message
    };

    function rg(a, b) {
        if (Array.isArray(a)) {
            Object.defineProperty(a, "context", {
                value: {
                    line: b[0]
                }
            });
            for (var c = 1; c < a.length; c++) rg(a[c], b[c])
        }
    };

    function sg() {
        return function(a, b) {
            var c;
            var d = tg;
            a instanceof Ta ? (a.C = d, c = a) : c = new Ta(a, d);
            var e = c;
            b && e.debugInfo.push(b);
            throw e;
        }
    }

    function tg(a) {
        if (!a.length) return a;
        a.push({
            id: "main",
            line: 0
        });
        for (var b = a.length - 1; b > 0; b--) tb(a[b].id) && a.splice(b++, 1);
        for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
        a.splice(0, 1);
        return a
    };

    function ug(a) {
        function b(r) {
            for (var u = 0; u < r.length; u++) d[r[u]] = !0
        }
        for (var c = [], d = [], e = vg(a), f = 0; f < Rf.length; f++) {
            var g = Rf[f],
                h = wg(g, e);
            if (h) {
                for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
                b(g.block || [])
            } else h === null && b(g.block || []);
        }
        for (var p = [], q = 0; q < Tf.length; q++) c[q] && !d[q] && (p[q] = !0);
        return p
    }

    function wg(a, b) {
        for (var c = a["if"] || [], d = 0; d < c.length; d++) {
            var e = b(c[d]);
            if (e === 0) return !1;
            if (e === 2) return null
        }
        for (var f = a.unless || [], g = 0; g < f.length; g++) {
            var h = b(f[g]);
            if (h === 2) return null;
            if (h === 1) return !1
        }
        return !0
    }

    function vg(a) {
        var b = [];
        return function(c) {
            b[c] === void 0 && (b[c] = eg(Sf[c], a));
            return b[c]
        }
    };

    function xg(a, b) {
        b[tf.lk] && typeof a === "string" && (a = b[tf.lk] === 1 ? a.toLowerCase() : a.toUpperCase());
        b.hasOwnProperty(tf.nk) && a === null && (a = b[tf.nk]);
        b.hasOwnProperty(tf.qk) && a === void 0 && (a = b[tf.qk]);
        b.hasOwnProperty(tf.pk) && a === !0 && (a = b[tf.pk]);
        b.hasOwnProperty(tf.mk) && a === !1 && (a = b[tf.mk]);
        return a
    };
    var yg = function() {
            this.C = {}
        },
        Ag = function(a, b) {
            var c = zg.C,
                d;
            (d = c.C)[a] != null || (d[a] = []);
            c.C[a].push(function() {
                return b.apply(null, za(Da.apply(0, arguments)))
            })
        };

    function Bg(a, b, c, d) {
        if (a)
            for (var e = 0; e < a.length; e++) {
                var f = void 0,
                    g = "A policy function denied the permission request";
                try {
                    f = a[e](b, c, d), g += "."
                } catch (h) {
                    g = typeof h === "string" ? g + (": " + h) : h instanceof Error ? g + (": " + h.message) : g + "."
                }
                if (!f) throw new qg(c, d, g);
            }
    }

    function Cg(a, b, c) {
        return function(d) {
            if (d) {
                var e = a.C[d],
                    f = a.C.all;
                if (e || f) {
                    var g = c.apply(void 0, [d].concat(za(Da.apply(1, arguments))));
                    Bg(e, b, d, g);
                    Bg(f, b, d, g)
                }
            }
        }
    };
    var Fg = function(a, b) {
            var c = this;
            this.H = {};
            this.C = new yg;
            var d = {},
                e = {},
                f = Cg(this.C, a, function(g) {
                    return g && d[g] ? d[g].apply(void 0, [g].concat(za(Da.apply(1, arguments)))) : {}
                });
            zb(b, function(g, h) {
                function l(p) {
                    var q = Da.apply(1, arguments);
                    if (!n[p]) throw Dg(p, {}, "The requested additional permission " + p + " is not configured.");
                    f.apply(null, [p].concat(za(q)))
                }
                var n = {};
                zb(h, function(p, q) {
                    var r = Eg(p, q);
                    n[p] = r.assert;
                    d[p] || (d[p] = r.U);
                    r.Xm && !e[p] && (e[p] = r.Xm)
                });
                c.H[g] = function(p, q) {
                    var r = n[p];
                    if (!r) throw Dg(p, {}, "The requested permission " + p + " is not configured.");
                    var u = Array.prototype.slice.call(arguments, 0);
                    r.apply(void 0, u);
                    f.apply(void 0, u);
                    var t = e[p];
                    t && t.apply(null, [l].concat(za(u.slice(1))))
                }
            })
        },
        Gg = function(a) {
            return zg.H[a] || function() {}
        };

    function Eg(a, b) {
        var c = dg(a, b);
        c.vtp_permissionName = a;
        c.vtp_createPermissionError = Dg;
        try {
            return hg(c)
        } catch (d) {
            return {
                assert: function(e) {
                    throw new qg(e, {}, "Permission " + e + " is unknown.");
                },
                U: function() {
                    throw new qg(a, {}, "Permission " + a + " is unknown.");
                }
            }
        }
    }

    function Dg(a, b, c) {
        return new qg(a, b, c)
    };
    var Hg = D(5),
        Jg = D(20),
        Kg = D(1),
        Lg = !1;
    var Mg = {};
    Mg.Nn = kg(29);
    Mg.Jq = kg(28);
    var F = {
        M: {
            jo: 1,
            mo: 2,
            Om: 3,
            wm: 4,
            xk: 5,
            yk: 6,
            Dp: 7,
            no: 8,
            Cp: 9,
            io: 10,
            ho: 11,
            Gm: 12,
            Cm: 13,
            fk: 14,
            Sn: 15,
            Un: 16,
            qm: 17,
            zk: 18,
            km: 19,
            ko: 20,
            Op: 21,
            Xn: 22,
            Tn: 23,
            Vn: 24,
            vk: 25,
            dk: 26,
            Xp: 27,
            Ql: 28,
            Yl: 29,
            Xl: 30,
            Wl: 31,
            Tl: 32,
            Rl: 33,
            Sl: 34,
            Pl: 35,
            Ol: 36,
            zp: 37,
            Ap: 38,
            yp: 39
        }
    };
    F.M[F.M.jo] = "CREATE_EVENT_SOURCE";
    F.M[F.M.mo] = "EDIT_EVENT";
    F.M[F.M.Om] = "TRAFFIC_TYPE";
    F.M[F.M.wm] = "REFERRAL_EXCLUSION";
    F.M[F.M.xk] = "ECOMMERCE_FROM_GTM_TAG";
    F.M[F.M.yk] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
    F.M[F.M.Dp] = "GA_SEND";
    F.M[F.M.no] = "EM_FORM";
    F.M[F.M.Cp] = "GA_GAM_LINK";
    F.M[F.M.io] = "CREATE_EVENT_AUTO_PAGE_PATH";
    F.M[F.M.ho] = "CREATED_EVENT";
    F.M[F.M.Gm] = "SIDELOADED";
    F.M[F.M.Cm] = "SGTM_LEGACY_CONFIGURATION";
    F.M[F.M.fk] = "CCD_EM_EVENT";
    F.M[F.M.Sn] = "AUTO_REDACT_EMAIL";
    F.M[F.M.Un] = "AUTO_REDACT_QUERY_PARAM";
    F.M[F.M.qm] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
    F.M[F.M.zk] = "EM_EVENT_SENT_BEFORE_CONFIG";
    F.M[F.M.km] = "LOADED_VIA_CST_OR_SIDELOADING";
    F.M[F.M.ko] = "DECODED_PARAM_MATCH";
    F.M[F.M.Op] = "NON_DECODED_PARAM_MATCH";
    F.M[F.M.Xn] = "CCD_EVENT_SGTM";
    F.M[F.M.Tn] = "AUTO_REDACT_EMAIL_SGTM";
    F.M[F.M.Vn] = "AUTO_REDACT_QUERY_PARAM_SGTM";
    F.M[F.M.vk] = "DAILY_LIMIT_REACHED";
    F.M[F.M.dk] = "BURST_LIMIT_REACHED";
    F.M[F.M.Xp] = "SHARED_USER_ID_SET_AFTER_REQUEST";
    F.M[F.M.Ql] = "GA4_MULTIPLE_SESSION_COOKIES";
    F.M[F.M.Yl] = "INVALID_GA4_SESSION_COUNT";
    F.M[F.M.Xl] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
    F.M[F.M.Wl] = "INVALID_GA4_JOIN_TIMER";
    F.M[F.M.Tl] = "GA4_STALE_SESSION_COOKIE_SELECTED";
    F.M[F.M.Rl] = "GA4_SESSION_COOKIE_GS1_READ";
    F.M[F.M.Sl] = "GA4_SESSION_COOKIE_GS2_READ";
    F.M[F.M.Pl] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
    F.M[F.M.Ol] = "GA4_DL_PARAM_RECOVERY_APPLIED";
    F.M[F.M.zp] = "GA4_GOOGLE_SIGNALS_ALLOWED";
    F.M[F.M.Ap] = "GA4_GOOGLE_SIGNALS_ENABLED";
    F.M[F.M.yp] = "GA4_FALLBACK_REQUEST";
    var Sg = {},
        Tg = (Sg.uaa = !0, Sg.uab = !0, Sg.uafvl = !0, Sg.uamb = !0, Sg.uam = !0, Sg.uap = !0, Sg.uapv = !0, Sg.uaw = !0, Sg);
    var ah = function(a, b) {
            for (var c = 0; c < b.length; c++) {
                var d = a,
                    e = b[c];
                if (!Zg.exec(e)) throw Error("Invalid key wildcard");
                var f = e.indexOf(".*"),
                    g = f !== -1 && f === e.length - 2,
                    h = g ? e.slice(0, e.length - 2) : e,
                    l;
                a: if (d.length === 0) l = !1;
                    else {
                        for (var n = d.split("."), p = 0; p < n.length; p++)
                            if (!$g.exec(n[p])) {
                                l = !1;
                                break a
                            }
                        l = !0
                    }
                if (!l || h.length > d.length || !g && d.length !== e.length ? 0 : g ? Lb(d, h) && (d === h || d.charAt(h.length) === ".") : d === h) return !0
            }
            return !1
        },
        $g = /^[a-z$_][\w-$]*$/i,
        Zg = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
    var bh = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];

    function ch(a, b) {
        var c = String(a),
            d = String(b),
            e = c.length - d.length;
        return e >= 0 && c.indexOf(d, e) === e
    }

    function dh(a, b) {
        return String(a).split(",").indexOf(String(b)) >= 0
    }
    var eh = new yb;

    function fh(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + String(d),
                f = eh.get(e);
            f || (f = new RegExp(b, d), eh.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function gh(a, b) {
        return String(a).indexOf(String(b)) >= 0
    }

    function hh(a, b) {
        return String(a) === String(b)
    }

    function ih(a, b) {
        return Number(a) >= Number(b)
    }

    function jh(a, b) {
        return Number(a) <= Number(b)
    }

    function kh(a, b) {
        return Number(a) > Number(b)
    }

    function lh(a, b) {
        return Number(a) < Number(b)
    }

    function mh(a, b) {
        return Lb(String(a), String(b))
    };
    var th = /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
        uh = {
            Fn: "function",
            PixieMap: "Object",
            List: "Array"
        };

    function vh(a, b) {
        for (var c = ["input:!*"], d = 0; d < c.length; d++) {
            var e = th.exec(c[d]);
            if (!e) throw Error("Internal Error in " + a);
            var f = e[1],
                g = e[2] === "!",
                h = e[3],
                l = b[d];
            if (l == null) {
                if (g) throw Error("Error in " + a + ". Required argument " + f + " not supplied.");
            } else if (h !== "*") {
                var n = typeof l;
                l instanceof Ad ? n = "Fn" : l instanceof wd ? n = "List" : l instanceof bb ? n = "PixieMap" : l instanceof Hd ? n = "PixiePromise" : l instanceof Fd && (n = "OpaqueValue");
                if (n !== h) throw Error("Error in " + a + ". Argument " + f + " has type " + ((uh[n] || n) + ", which does not match required type ") +
                    ((uh[h] || h) + "."));
            }
        }
    }

    function G(a, b, c) {
        for (var d = [], e = m(c), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            g instanceof Ad ? d.push("function") : g instanceof wd ? d.push("Array") : g instanceof bb ? d.push("Object") : g instanceof Hd ? d.push("Promise") : g instanceof Fd ? d.push("OpaqueValue") : d.push(typeof g)
        }
        return Error("Argument error in " + a + ". Expected argument types [" + (b.join(",") + "], but received [") + (d.join(",") + "]."))
    }

    function wh(a) {
        return a instanceof bb
    }

    function xh(a) {
        return wh(a) || a === null || yh(a)
    }

    function zh(a) {
        return a instanceof Ad
    }

    function Ah(a) {
        return zh(a) || a === null || yh(a)
    }

    function Bh(a) {
        return a instanceof wd
    }

    function Ch(a) {
        return a instanceof Fd
    }

    function Dh(a) {
        return typeof a === "string"
    }

    function Eh(a) {
        return Dh(a) || a === null || yh(a)
    }

    function Fh(a) {
        return typeof a === "boolean"
    }

    function Gh(a) {
        return Fh(a) || yh(a)
    }

    function Hh(a) {
        return Fh(a) || a === null || yh(a)
    }

    function Ih(a) {
        return typeof a === "number"
    }

    function yh(a) {
        return a === void 0
    };

    function Jh(a) {
        return "" + a
    }

    function Kh(a, b) {
        var c = [];
        return c
    };

    function Lh(a, b) {
        var c = new Ad(a, function() {
            for (var d = Array.prototype.slice.call(arguments, 0), e = 0; e < d.length; e++) d[e] = this.evaluate(d[e]);
            try {
                return b.apply(this, d)
            } catch (g) {
                throw Ua(g);
            }
        });
        c.Va();
        return c
    }

    function Mh(a, b) {
        var c = new bb,
            d;
        for (d in b)
            if (b.hasOwnProperty(d)) {
                var e = b[d];
                rb(e) ? c.set(d, Lh(a + "_" + d, e)) : sd(e) ? c.set(d, Mh(a + "_" + d, e)) : (tb(e) || sb(e) || typeof e === "boolean") && c.set(d, e)
            }
        c.Va();
        return c
    };

    function Nh(a, b) {
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        if (!Eh(b)) throw G(this.getName(), ["string", "undefined"], arguments);
        var c = {},
            d = new bb;
        return d = Mh("AssertApiSubject",
            c)
    };

    function Oh(a, b) {
        if (!Eh(b)) throw G(this.getName(), ["string", "undefined"], arguments);
        if (a instanceof Hd) throw Error("Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.");
        var c = {},
            d = new bb;
        return d = Mh("AssertThatSubject", c)
    };

    function Ph(a) {
        return function() {
            for (var b = Da.apply(0, arguments), c = [], d = this.K, e = 0; e < b.length; ++e) c.push(B(b[e], d));
            return Id(a.apply(null, c))
        }
    }

    function Qh() {
        for (var a = Math, b = Rh, c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            a.hasOwnProperty(e) && (c[e] = Ph(a[e].bind(a)))
        }
        return c
    };

    function Sh(a) {
        return a != null && Lb(a, "__cvt_")
    };

    function Th(a) {
        var b;
        return b
    };

    function Uh(a) {
        var b;
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    };

    function Vh(a) {
        try {
            return encodeURI(a)
        } catch (b) {}
    };

    function Wh(a) {
        try {
            return encodeURIComponent(String(a))
        } catch (b) {}
    };

    function ai(a) {
        if (!Eh(a)) throw G(this.getName(), ["string|undefined"], arguments);
    };

    function bi(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; d >= 0; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = c !== 0 ? b ^ c >> 21 : b;
        return b
    };

    function ci(a) {
        var b = B(a);
        return bi(b ? "" + b : "")
    };

    function di(a, b) {
        if (!Ih(a) || !Ih(b)) throw G(this.getName(), ["number", "number"], arguments);
        return wb(a, b)
    };

    function ei() {
        return (new Date).getTime()
    };

    function fi(a) {
        if (a === null) return "null";
        if (a instanceof wd) return "array";
        if (a instanceof Ad) return "function";
        if (a instanceof Fd) {
            var b = a.getValue();
            if ((b == null ? void 0 : b.constructor) === void 0 || b.constructor.name === void 0) {
                var c = String(b);
                return c.substring(8, c.length - 1)
            }
            return String(b.constructor.name)
        }
        return typeof a
    };

    function gi(a) {
        function b(c) {
            return function(d) {
                try {
                    return c(d)
                } catch (e) {
                    (Lg || Mg.Nn) && a.call(this, e.message)
                }
            }
        }
        return {
            parse: b(function(c) {
                return Id(JSON.parse(c))
            }),
            stringify: b(function(c) {
                return JSON.stringify(B(c))
            }),
            publicName: "JSON"
        }
    };

    function hi(a) {
        return Bb(B(a, this.K))
    };

    function ii(a) {
        return Number(B(a, this.K))
    };

    function ji(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a.toString()
    };

    function ki(a, b, c) {
        var d = null,
            e = !1;
        return e ? d : null
    };
    var Rh = "floor ceil round max min abs pow sqrt".split(" ");

    function li() {
        var a = {};
        return {
            Sq: function(b) {
                return a.hasOwnProperty(b) ? a[b] : void 0
            },
            Jn: function(b, c) {
                a[b] = c
            },
            reset: function() {
                a = {}
            }
        }
    }

    function mi(a, b) {
        return function() {
            return Ad.prototype.invoke.apply(a, [b].concat(za(Da.apply(0, arguments))))
        }
    }

    function ni(a, b) {
        if (!Dh(a)) throw G(this.getName(), ["string", "any"], arguments);
    }

    function oi(a, b) {
        if (!Dh(a) || !wh(b)) throw G(this.getName(), ["string", "PixieMap"], arguments);
    };
    var pi = {};
    pi.keys = function(a) {
        return new wd
    };
    pi.values = function(a) {
        return new wd
    };
    pi.entries = function(a) {
        return new wd
    };
    pi.freeze = function(a) {
        return a
    };
    pi.delete = function(a, b) {
        return !1
    };

    function I(a, b) {
        var c = Da.apply(2, arguments),
            d = a.K.qb();
        if (!d) throw Error("Missing program state.");
        if (d.Sr) {
            try {
                d.Ym.apply(null, [b].concat(za(c)))
            } catch (e) {
                throw kb("TAGGING", 21), e;
            }
            return
        }
        d.Ym.apply(null, [b].concat(za(c)))
    };
    var ri = function() {
        this.H = {};
        this.C = {};
        this.P = !0;
    };
    ri.prototype.get = function(a, b) {
        var c = this.contains(a) ? this.H[a] : void 0;
        return c
    };
    ri.prototype.contains = function(a) {
        return this.H.hasOwnProperty(a)
    };
    ri.prototype.add = function(a, b, c) {
        if (this.contains(a)) throw Error("Attempting to add a function which already exists: " + a + ".");
        if (this.C.hasOwnProperty(a)) throw Error("Attempting to add an API with an existing private API name: " + a + ".");
        this.H[a] = c ? void 0 : rb(b) ? Lh(a, b) : Mh(a, b)
    };

    function si(a, b) {
        var c = void 0;
        return c
    };

    function ti() {
        var a = {};
        return a
    };
    var K = {
        m: {
            Na: "ad_personalization",
            W: "ad_storage",
            X: "ad_user_data",
            ja: "analytics_storage",
            oc: "region",
            ia: "consent_updated",
            Ig: "wait_for_update",
            oo: "app_remove",
            po: "app_store_refund",
            qo: "app_store_subscription_cancel",
            ro: "app_store_subscription_convert",
            so: "app_store_subscription_renew",
            uo: "consent_update",
            vo: "conversion",
            Bk: "add_payment_info",
            Ck: "add_shipping_info",
            ee: "add_to_cart",
            fe: "remove_from_cart",
            Dk: "view_cart",
            fd: "begin_checkout",
            Hs: "generate_lead",
            he: "select_item",
            qc: "view_item_list",
            zc: "select_promotion",
            rc: "view_promotion",
            Cb: "purchase",
            ie: "refund",
            sc: "view_item",
            Ek: "add_to_wishlist",
            wo: "exception",
            xo: "first_open",
            yo: "first_visit",
            ma: "gtag.config",
            Db: "gtag.get",
            zo: "in_app_purchase",
            gd: "page_view",
            Ao: "screen_view",
            Bo: "session_start",
            Co: "source_update",
            Do: "timing_complete",
            Eo: "track_social",
            je: "user_engagement",
            Fo: "user_id_update",
            bf: "gclid_link_decoration_source",
            cf: "gclid_storage_source",
            uc: "gclgb",
            tb: "gclid",
            Fk: "gclid_len",
            ke: "gclgs",
            me: "gcllp",
            ne: "gclst",
            Ia: "ads_data_redaction",
            df: "gad_source",
            ef: "gad_source_src",
            hd: "gclid_url",
            Gk: "gclsrc",
            ff: "gbraid",
            oe: "wbraid",
            Tb: "allow_ad_personalization_signals",
            hf: "allow_custom_scripts",
            jf: "allow_direct_google_requests",
            Og: "allow_display_features",
            di: "allow_enhanced_conversions",
            Ub: "allow_google_signals",
            ei: "allow_interest_groups",
            Go: "app_id",
            Ho: "app_installer_id",
            Io: "app_name",
            Jo: "app_version",
            jd: "auid",
            Is: "auto_detection_enabled",
            Ko: "auto_event",
            Hk: "aw_remarketing",
            fi: "aw_remarketing_only",
            kf: "discount",
            lf: "aw_feed_country",
            nf: "aw_feed_language",
            Ba: "items",
            pf: "aw_merchant_id",
            gi: "aw_basket_type",
            qf: "campaign_content",
            rf: "campaign_id",
            tf: "campaign_medium",
            uf: "campaign_name",
            vf: "campaign",
            wf: "campaign_source",
            xf: "campaign_term",
            Vb: "client_id",
            Ik: "rnd",
            hi: "consent_update_type",
            Lo: "content_group",
            Mo: "content_type",
            Eb: "conversion_cookie_prefix",
            ii: "conversion_id",
            ub: "conversion_linker",
            Pg: "conversion_linker_disabled",
            kd: "conversion_api",
            Qg: "cookie_deprecation",
            wb: "cookie_domain",
            xb: "cookie_expires",
            Fb: "cookie_flags",
            ld: "cookie_name",
            Wb: "cookie_path",
            Xa: "cookie_prefix",
            Ac: "cookie_update",
            Bc: "country",
            kb: "currency",
            Rg: "customer_buyer_stage",
            qe: "customer_lifetime_value",
            Sg: "customer_loyalty",
            Tg: "customer_ltv_bucket",
            se: "custom_map",
            Ug: "gcldc",
            md: "dclid",
            Jk: "debug_mode",
            Ga: "developer_id",
            No: "disable_merchant_reported_purchases",
            Cc: "dc_custom_params",
            Kk: "dc_natural_search",
            Oo: "dynamic_event_settings",
            Lk: "affiliation",
            Vg: "checkout_option",
            ji: "checkout_step",
            Mk: "coupon",
            yf: "item_list_name",
            ki: "list_name",
            Po: "promotions",
            nd: "shipping",
            Nk: "tax",
            Wg: "engagement_time_msec",
            Xg: "enhanced_client_id",
            Qo: "enhanced_conversions",
            Js: "enhanced_conversions_automatic_settings",
            te: "estimated_delivery_date",
            zf: "event_callback",
            Ro: "event_category",
            Dc: "event_developer_id_string",
            So: "event_label",
            Ec: "event",
            li: "event_settings",
            Yg: "event_timeout",
            To: "description",
            Uo: "fatal",
            Vo: "experiments",
            mi: "firebase_id",
            Af: "first_party_collection",
            Zg: "_x_20",
            vc: "_x_19",
            Wo: "flight_error_code",
            Xo: "flight_error_message",
            Ok: "fl_activity_category",
            Pk: "fl_activity_group",
            ni: "fl_advertiser_id",
            Qk: "fl_ar_dedupe",
            Bf: "match_id",
            Rk: "fl_random_number",
            Sk: "tran",
            Tk: "u",
            ah: "gac_gclid",
            ue: "gac_wbraid",
            Uk: "gac_wbraid_multiple_conversions",
            Yo: "ga_restrict_domain",
            Vk: "ga_temp_client_id",
            Zo: "ga_temp_ecid",
            ve: "gdpr_applies",
            Wk: "geo_granularity",
            Cf: "value_callback",
            Df: "value_key",
            Gc: "google_analysis_params",
            we: "_google_ng",
            Ef: "google_signals",
            ap: "google_tld",
            bh: "gpp_sid",
            eh: "gpp_string",
            fh: "groups",
            Xk: "gsa_experiment_id",
            Ff: "gtag_event_feature_usage",
            Yk: "gtm_up",
            pd: "iframe_state",
            Gf: "ignore_referrer",
            Zk: "internal_traffic_results",
            al: "_is_fpm",
            Hc: "is_legacy_converted",
            Ic: "is_legacy_loaded",
            oi: "is_passthrough",
            xe: "_lps",
            lb: "language",
            gh: "legacy_developer_id_string",
            cb: "linker",
            Hf: "accept_incoming",
            Jc: "decorate_forms",
            ra: "domains",
            rd: "url_position",
            Kc: "merchant_feed_label",
            Lc: "merchant_feed_language",
            Mc: "merchant_id",
            bl: "method",
            bp: "name",
            fl: "navigation_type",
            ye: "new_customer",
            hh: "non_interaction",
            cp: "optimize_id",
            il: "page_hostname",
            If: "page_path",
            Ya: "page_referrer",
            Gb: "page_title",
            ep: "passengers",
            jl: "phone_conversion_callback",
            fp: "phone_conversion_country_code",
            kl: "phone_conversion_css_class",
            hp: "phone_conversion_ids",
            ml: "phone_conversion_number",
            nl: "phone_conversion_options",
            jp: "_platinum_request_status",
            kp: "_protected_audience_enabled",
            ze: "quantity",
            ih: "redact_device_info",
            ol: "referral_exclusion_definition",
            Ks: "_request_start_time",
            Xb: "restricted_data_processing",
            lp: "retoken",
            mp: "sample_rate",
            ri: "screen_name",
            Nc: "screen_resolution",
            pl: "_script_source",
            np: "search_term",
            sd: "send_page_view",
            ud: "send_to",
            vd: "server_container_url",
            op: "session_attributes_encoded",
            jh: "session_duration",
            kh: "session_engaged",
            si: "session_engaged_time",
            Yb: "session_id",
            mh: "session_number",
            Jf: "_shared_user_id",
            wd: "delivery_postal_code",
            Ls: "_tag_firing_delay",
            Ms: "_tag_firing_time",
            Ns: "temporary_client_id",
            pp: "_timezone",
            ui: "topmost_url",
            nh: "tracking_id",
            wi: "traffic_type",
            Ja: "transaction_id",
            ql: "transaction_id_source",
            Oc: "transport_url",
            qp: "trip_type",
            xd: "update",
            Hb: "url_passthrough",
            rl: "uptgs",
            Kf: "_user_agent_architecture",
            Lf: "_user_agent_bitness",
            Mf: "_user_agent_full_version_list",
            Nf: "_user_agent_mobile",
            Of: "_user_agent_model",
            Pf: "_user_agent_platform",
            Qf: "_user_agent_platform_version",
            Rf: "_user_agent_wow64",
            Ib: "user_data",
            sl: "user_data_auto_latency",
            tl: "user_data_auto_meta",
            vl: "user_data_auto_multi",
            wl: "user_data_auto_selectors",
            xl: "user_data_auto_status",
            Jb: "user_data_mode",
            yl: "user_data_settings",
            Oa: "user_id",
            yd: "user_properties",
            zl: "_user_region",
            Sf: "us_privacy_string",
            Ka: "value",
            Al: "wbraid_multiple_conversions",
            Pc: "_fpm_parameters",
            Ci: "_host_name",
            Zl: "_in_page_command",
            Ei: "_ip_override",
            gm: "_is_passthrough_cid",
            zh: "_measurement_type",
            Hd: "non_personalized_ads",
            Ri: "_sst_parameters",
            Wp: "sgtm_geo_user_country",
            pe: "conversion_label",
            xa: "page_location",
            od: "_extracted_data",
            Fc: "global_developer_id_string",
            Ae: "tc_privacy_string"
        }
    };
    var ui = {},
        zi = (ui[K.m.ia] = "gcu", ui[K.m.uc] = "gclgb", ui[K.m.tb] = "gclaw", ui[K.m.Fk] = "gclid_len", ui[K.m.ke] = "gclgs", ui[K.m.me] = "gcllp", ui[K.m.ne] = "gclst", ui[K.m.jd] = "auid", ui[K.m.Ko] = "ae", ui[K.m.kf] = "dscnt", ui[K.m.lf] = "fcntr", ui[K.m.nf] = "flng", ui[K.m.pf] = "mid", ui[K.m.gi] = "bttype", ui[K.m.Vb] = "gacid", ui[K.m.pe] = "label", ui[K.m.kd] = "capi", ui[K.m.Qg] = "pscdl", ui[K.m.kb] = "currency_code", ui[K.m.Rg] = "clobs", ui[K.m.qe] = "vdltv", ui[K.m.Sg] = "clolo", ui[K.m.Tg] = "clolb", ui[K.m.Jk] = "_dbg", ui[K.m.te] = "oedeld", ui[K.m.Dc] =
            "edid", ui[K.m.ah] = "gac", ui[K.m.ue] = "gacgb", ui[K.m.Uk] = "gacmcov", ui[K.m.ve] = "gdpr", ui[K.m.Fc] = "gdid", ui[K.m.we] = "_ng", ui[K.m.bh] = "gpp_sid", ui[K.m.eh] = "gpp", ui[K.m.Xk] = "gsaexp", ui[K.m.Ff] = "_tu", ui[K.m.pd] = "frm", ui[K.m.oi] = "gtm_up", ui[K.m.xe] = "lps", ui[K.m.gh] = "did", ui[K.m.Kc] = "fcntr", ui[K.m.Lc] = "flng", ui[K.m.Mc] = "mid", ui[K.m.ye] = void 0, ui[K.m.Gb] = "tiba", ui[K.m.Xb] = "rdp", ui[K.m.Yb] = "ecsid", ui[K.m.Jf] = "ga_uid", ui[K.m.wd] = "delopc", ui[K.m.Ae] = "gdpr_consent", ui[K.m.Ja] = "oid", ui[K.m.ql] = "oidsrc", ui[K.m.rl] =
            "uptgs", ui[K.m.Kf] = "uaa", ui[K.m.Lf] = "uab", ui[K.m.Mf] = "uafvl", ui[K.m.Nf] = "uamb", ui[K.m.Of] = "uam", ui[K.m.Pf] = "uap", ui[K.m.Qf] = "uapv", ui[K.m.Rf] = "uaw", ui[K.m.sl] = "ec_lat", ui[K.m.tl] = "ec_meta", ui[K.m.vl] = "ec_m", ui[K.m.wl] = "ec_sel", ui[K.m.xl] = "ec_s", ui[K.m.Jb] = "ec_mode", ui[K.m.Oa] = "userId", ui[K.m.Sf] = "us_privacy", ui[K.m.Ka] = "value", ui[K.m.Al] = "mcov", ui[K.m.Ci] = "hn", ui[K.m.Zl] = "gtm_ee", ui[K.m.Ei] = "uip", ui[K.m.zh] = "mt", ui[K.m.Hd] = "npa", ui[K.m.Wp] = "sg_uc", ui[K.m.ii] = null, ui[K.m.Nc] = null, ui[K.m.lb] = null, ui[K.m.Ba] =
            null, ui[K.m.xa] = null, ui[K.m.Ya] = null, ui[K.m.ui] = null, ui[K.m.Pc] = null, ui[K.m.bf] = null, ui[K.m.cf] = null, ui[K.m.Gc] = null, ui[K.m.od] = null, ui);

    function Ai(a, b) {
        if (a) {
            var c = a.split("x");
            c.length === 2 && (Bi(b, "u_w", c[0]), Bi(b, "u_h", c[1]))
        }
    }

    function Ci(a) {
        var b = Di;
        b = b === void 0 ? Ei : b;
        var c;
        var d = b;
        if (a && a.length) {
            for (var e = [], f = 0; f < a.length; ++f) {
                var g = a[f];
                g && e.push({
                    item_id: d(g),
                    quantity: g.quantity,
                    value: g.price,
                    start_date: g.start_date,
                    end_date: g.end_date
                })
            }
            c = e
        } else c = [];
        var h;
        var l = c;
        if (l) {
            for (var n = [], p = 0; p < l.length; p++) {
                var q = l[p],
                    r = [];
                q && (r.push(Fi(q.value)), r.push(Fi(q.quantity)), r.push(Fi(q.item_id)), r.push(Fi(q.start_date)), r.push(Fi(q.end_date)), n.push("(" + r.join("*") + ")"))
            }
            h = n.length > 0 ? n.join("") : ""
        } else h = "";
        return h
    }

    function Ei(a) {
        return Gi(a.item_id, a.id, a.item_name)
    }

    function Gi() {
        for (var a = m(Da.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            if (c !== null && c !== void 0) return c
        }
    }

    function Hi(a) {
        if (a && a.length) {
            for (var b = [], c = 0; c < a.length; ++c) {
                var d = a[c];
                d && d.estimated_delivery_date ? b.push("" + d.estimated_delivery_date) : b.push("")
            }
            return b.join(",")
        }
    }

    function Bi(a, b, c) {
        c === void 0 || c === null || c === "" && !Tg[b] || (a[b] = c)
    }

    function Fi(a) {
        return typeof a !== "number" && typeof a !== "string" ? "" : a.toString()
    };
    var Ii = {},
        Ji = function() {
            for (var a = !1, b = !1, c = 0; a === b;)
                if (a = wb(0, 1) === 0, b = wb(0, 1) === 0, c++, c > 30) return;
            return a
        },
        Li = {
            Xr: Ki
        };

    function Ki(a, b) {
        var c = Ii[b];
        if (!(wb(0, 9999) < c.probability * (c.controlId2 ? 4 : 2) * 1E4)) return a;
        a: {
            var d = c.studyId,
                e = c.experimentId,
                f = c.controlId,
                g = c.controlId2;
            if (!((a.exp || {})[e] || (a.exp || {})[f] || g && (a.exp || {})[g])) {
                var h = Ji();
                if (h !== void 0) {
                    var l = h ? 0 : 1;
                    if (g) {
                        var n = Ji();
                        if (n === void 0) break a;
                        l |= (n ? 0 : 1) << 1
                    }
                    l === 0 ? Mi(a, e, d) : l === 1 ? Mi(a, f, d) : l === 2 && Mi(a, g, d)
                }
            }
        }
        return a
    }

    function Ni(a, b) {
        return Ii[b] ? !!Ii[b].active || Ii[b].probability > .5 || !!(a.exp || {})[Ii[b].experimentId] : !1
    }

    function Oi(a, b) {
        for (var c = a.exp || {}, d = m(Object.keys(c).map(Number)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (c[f] === b) return f
        }
    }

    function Mi(a, b, c) {
        var d = a.exp || {};
        d[b] = c;
        a.exp = d
    };
    var Pi = {
        N: {
            ek: "call_conversion",
            ae: "ccm_conversion",
            Aa: "conversion",
            tp: "floodlight",
            Uf: "ga_conversion",
            Bd: "gcp_remarketing",
            jm: "landing_page",
            Ca: "page_view",
            Ge: "fpm_test_hit",
            Lb: "remarketing",
            Zb: "user_data_lead",
            zb: "user_data_web"
        }
    };
    var Qi = function() {
            this.C = new Set;
            this.H = new Set
        },
        Si = function(a) {
            var b = Ri.C;
            a = a === void 0 ? [] : a;
            var c = [].concat(za(b.C)).concat([].concat(za(b.H))).concat(a);
            c.sort(function(d, e) {
                return d - e
            });
            return c
        },
        Ti = function() {
            var a = [].concat(za(Ri.C.C));
            a.sort(function(b, c) {
                return b - c
            });
            return a
        },
        Ui = function() {
            var a = Ri.C,
                b = D(44);
            a.C = new Set;
            if (b !== "")
                for (var c = m(b.split("~")), d = c.next(); !d.done; d = c.next()) {
                    var e = Number(d.value);
                    isNaN(e) || a.C.add(e)
                }
        };
    var Vi = {},
        Wi = {
            __cl: 1,
            __ecl: 1,
            __ehl: 1,
            __evl: 1,
            __fal: 1,
            __fil: 1,
            __fsl: 1,
            __hl: 1,
            __jel: 1,
            __lcl: 1,
            __sdl: 1,
            __tl: 1,
            __ytl: 1
        },
        Xi = {
            __paused: 1,
            __tg: 1
        },
        Yi;
    for (Yi in Wi) Wi.hasOwnProperty(Yi) && (Xi[Yi] = 1);
    var Zi = kg(45),
        $i, aj = !1;
    $i = aj;
    var bj = null,
        cj = {},
        dj = "";
    Vi.Si = dj;
    var Ri = new function() {
        this.C = new Qi;
        this.H = !1
    };
    var ej = /:[0-9]+$/,
        fj = /^\d+\.fls\.doubleclick\.net$/;

    function gj(a, b, c, d) {
        var e = hj(a, !!d, b),
            f, g;
        return c ? (g = e[b]) != null ? g : [] : (f = e[b]) == null ? void 0 : f[0]
    }

    function hj(a, b, c) {
        for (var d = {}, e = m(a.split("&")), f = e.next(); !f.done; f = e.next()) {
            var g = m(f.value.split("=")),
                h = g.next().value,
                l = ya(g),
                n = decodeURIComponent(h.replace(/\+/g, " "));
            if (c === void 0 || n === c) {
                var p = l.join("=");
                d[n] || (d[n] = []);
                d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")))
            }
        }
        return d
    }

    function ij(a) {
        try {
            return decodeURIComponent(a)
        } catch (b) {}
    }

    function jj(a, b, c, d, e) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = kj(a.protocol) || kj(w.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : w.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || w.location.hostname).replace(ej, "").toLowerCase());
        return lj(a, b, c, d, e)
    }

    function lj(a, b, c, d, e) {
        var f, g = kj(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                f = mj(a);
                break;
            case "protocol":
                f = g;
                break;
            case "host":
                f = a.hostname.replace(ej, "").toLowerCase();
                if (c) {
                    var h = /^www\d*\./.exec(f);
                    h && h[0] && (f = f.substring(h[0].length))
                }
                break;
            case "port":
                f = String(Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || kb("TAGGING", 1);
                f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
                var l = f.split("/");
                (d || []).indexOf(l[l.length -
                    1]) >= 0 && (l[l.length - 1] = "");
                f = l.join("/");
                break;
            case "query":
                f = a.search.replace("?", "");
                e && (f = gj(f, e, !1));
                break;
            case "extension":
                var n = a.pathname.split(".");
                f = n.length > 1 ? n[n.length - 1] : "";
                f = f.split("/")[0];
                break;
            case "fragment":
                f = a.hash.replace("#", "");
                break;
            default:
                f = a && a.href
        }
        return f
    }

    function kj(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }

    function mj(a) {
        var b = "";
        if (a && a.href) {
            var c = a.href.indexOf("#");
            b = c < 0 ? a.href : a.href.substring(0, c)
        }
        return b
    }
    var nj = {},
        oj = 0;

    function pj(a) {
        var b = nj[a];
        if (!b) {
            var c = z.createElement("a");
            a && (c.href = a);
            var d = c.pathname;
            d[0] !== "/" && (a || kb("TAGGING", 1), d = "/" + d);
            var e = c.hostname.replace(ej, "");
            b = {
                href: c.href,
                protocol: c.protocol,
                host: c.host,
                hostname: e,
                pathname: d,
                search: c.search,
                hash: c.hash,
                port: c.port
            };
            oj < 5 && (nj[a] = b, oj++)
        }
        return b
    }

    function qj(a, b, c) {
        var d = pj(a);
        return Wb(b, d, c)
    }

    function rj(a) {
        var b = pj(w.location.href),
            c = jj(b, "host", !1);
        if (c && c.match(fj)) {
            var d = jj(b, "path");
            if (d) {
                var e = d.split(a + "=");
                if (e.length > 1) return e[1].split(";")[0].split("?")[0]
            }
        }
    };
    var sj = {
            "https://www.google.com": "/g",
            "https://www.googleadservices.com": "/as",
            "https://pagead2.googlesyndication.com": "/gs"
        },
        tj = ["/as/d/ccm/conversion", "/g/d/ccm/conversion", "/gs/ccm/conversion", "/d/ccm/form-data"];

    function uj() {
        return kg(47) ? lg(54) !== 1 : !1
    }

    function vj() {
        var a = D(18),
            b = a.length;
        return a[b - 1] === "/" ? a.substring(0, b - 1) : a
    }

    function wj(a, b) {
        if (a) {
            var c = "" + a;
            c.indexOf("http://") !== 0 && c.indexOf("https://") !== 0 && (c = "https://" + c);
            c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
            return pj("" + c + b).href
        }
    }

    function xj(a, b) {
        if (uj() || kg(50)) return wj(a, b)
    }

    function yj() {
        return !!Vi.Si && Vi.Si.split("@@").join("") !== "SGTM_TOKEN"
    }

    function zj(a) {
        for (var b = m([K.m.vd, K.m.Oc]), c = b.next(); !c.done; c = b.next()) {
            var d = L(a, c.value);
            if (d) return d
        }
    }

    function Aj(a, b, c) {
        c = c === void 0 ? "" : c;
        if (!uj()) return a;
        var d = b ? sj[a] || "" : "";
        d === "/gs" && (c = "");
        return "" + vj() + d + c
    }

    function Bj(a) {
        if (!uj()) return a;
        for (var b = m(tj), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            if (Lb(a, "" + vj() + d)) return a + "&_uip=" + encodeURIComponent("::")
        }
        return a
    };
    var Cj = /gtag[.\/]js/,
        Dj = /gtm[.\/]js/,
        Ej = !1;

    function Fj(a) {
        if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    for (var e = kg(47), f = pj(d), g = e ? f.pathname : "" + f.hostname + f.pathname, h = z.scripts, l = "", n = 0; n < h.length; ++n) {
                        var p = h[n];
                        if (!(p.innerHTML.length === 0 || !e && p.innerHTML.indexOf(a.scriptContainerId || "SHOULD_NOT_BE_SET") < 0 || p.innerHTML.indexOf(g) < 0)) {
                            if (p.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                                b = String(n);
                                break a
                            }
                            l = String(n)
                        }
                    }
                    if (l) {
                        b = l;
                        break a
                    }
                }
                b = void 0
            }
            var q = b;
            if (q) return Ej = !0,
                q
        }
        var r = [].slice.call(z.scripts);
        return a.scriptElement ? String(r.indexOf(a.scriptElement)) : "-1"
    }

    function Gj(a) {
        if (Ej) return "1";
        var b, c = (b = a.scriptElement) == null ? void 0 : b.src;
        if (c) {
            if (Cj.test(c)) return "3";
            if (Dj.test(c)) return "2"
        }
        return "0"
    };

    function M(a) {
        kb("GTM", a)
    };

    function Hj(a) {
        var b = Ij().destinationArray[a],
            c = Ij().destination[a];
        return b && b.length > 0 ? b[0] : c
    }

    function Jj(a, b) {
        var c = Ij();
        c.pending || (c.pending = []);
        vb(c.pending, function(d) {
            return d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
        }) || c.pending.push({
            target: a,
            onLoad: b
        })
    }

    function Kj() {
        var a = w.google_tags_first_party;
        Array.isArray(a) || (a = []);
        for (var b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return Object.freeze(b)
    }
    var Lj = function() {
        this.container = {};
        this.destination = {};
        this.destinationArray = {};
        this.canonical = {};
        this.pending = [];
        this.injectedFirstPartyContainers = {};
        this.injectedFirstPartyContainers = Kj()
    };

    function Ij() {
        var a = Fc("google_tag_data", {}),
            b = a.tidr;
        b && typeof b === "object" || (b = new Lj, a.tidr = b);
        var c = b;
        c.container || (c.container = {});
        c.destination || (c.destination = {});
        c.destinationArray || (c.destinationArray = {});
        c.canonical || (c.canonical = {});
        c.pending || (c.pending = []);
        c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = Kj());
        return c
    };

    function Mj() {
        return kg(7) && Nj().some(function(a) {
            return a === D(5)
        })
    }

    function Oj() {
        var a;
        return (a = mg(55)) != null ? a : []
    }

    function Pj() {
        return D(6) || "_" + D(5)
    }

    function Qj() {
        var a = D(10);
        return a ? a.split("|") : [D(5)]
    }

    function Nj() {
        var a = mg(59);
        return Array.isArray(a) ? a.filter(function(b) {
            return typeof b === "string"
        }).filter(function(b) {
            return b.indexOf("GTM-") !== 0
        }) : []
    }

    function Rj() {
        var a = Sj(Tj()),
            b = a && a.parent;
        if (b) return Sj(b)
    }

    function Uj() {
        var a = Sj(Tj());
        if (a) {
            for (; a.parent;) {
                var b = Sj(a.parent);
                if (!b) break;
                a = b
            }
            return a
        }
    }

    function Sj(a) {
        var b = Ij();
        return a.isDestination ? Hj(a.ctid) : b.container[a.ctid]
    }

    function Vj() {
        var a = Ij();
        if (a.pending) {
            for (var b, c = [], d = !1, e = Qj(), f = Nj(), g = {}, h = 0; h < a.pending.length; g = {
                    Cg: void 0
                }, h++) g.Cg = a.pending[h], vb(g.Cg.target.isDestination ? f : e, function(l) {
                return function(n) {
                    return n === l.Cg.target.ctid
                }
            }(g)) ? d || (b = g.Cg.onLoad, d = !0) : c.push(g.Cg);
            a.pending = c;
            if (b) try {
                b(Pj())
            } catch (l) {}
        }
    }

    function Wj() {
        for (var a = D(5), b = Qj(), c = Nj(), d = Oj(), e = function(q, r) {
                var u = {
                    canonicalContainerId: D(6),
                    scriptContainerId: a,
                    state: 2,
                    containers: b.slice(),
                    destinations: c.slice()
                };
                Dc && (u.scriptElement = Dc);
                Ec && (u.scriptSource = Ec);
                Rj() === void 0 && (u.htmlLoadOrder = Fj(u), u.loadScriptType = Gj(u));
                var t, v;
                switch (r) {
                    case 0:
                        t = function(A) {
                            f.container[q] = A
                        };
                        v = f.container[q];
                        break;
                    case 1:
                        t = function(A) {
                            f.destinationArray[q] = f.destinationArray[q] || [];
                            f.destinationArray[q].unshift(A)
                        };
                        var x, y = ((x = f.destinationArray[q]) ==
                            null ? void 0 : x[0]) || f.destination[q];
                        !y || y.state !== 0 && y.state !== 1 || (v = y);
                        break;
                    case 2:
                        t = function(A) {
                            f.destinationArray[q] = f.destinationArray[q] || [];
                            f.destinationArray[q].push(A)
                        }, v = void 0
                }
                t && (v ? (v.state === 0 && M(93), na(Object, "assign").call(Object, v, u)) : t(u))
            }, f = Ij(), g = m(b), h = g.next(); !h.done; h = g.next()) e(h.value, 0);
        for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
            var p = n.value;
            d.includes(p) ? e(p, 1) : e(p, 2)
        }
        f.canonical[Pj()] = {};
        Vj()
    }

    function Xj() {
        var a = Pj();
        return !!Ij().canonical[a]
    }

    function Yj(a) {
        return !!Ij().container[a]
    }

    function Zj() {
        var a = Tj(),
            b = Sj(a);
        return b && b.context
    }

    function ak(a) {
        var b = Hj(a);
        return b ? b.state !== 0 : !1
    }

    function Tj() {
        return {
            ctid: D(5),
            isDestination: kg(7)
        }
    }

    function bk(a, b, c) {
        var d = Tj(),
            e = Ij().container[a];
        e && e.state !== 3 || (Ij().container[a] = {
            state: 1,
            context: b,
            parent: d
        }, Jj({
            ctid: a,
            isDestination: !1
        }, c))
    }

    function ck() {
        var a = Ij().container,
            b;
        for (b in a)
            if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
        return !1
    }

    function dk() {
        var a = {};
        zb(Ij().destination, function(b, c) {
            (c == null ? void 0 : c.state) === 0 && (a[b] = c)
        });
        zb(Ij().destinationArray, function(b, c) {
            var d = c[0];
            (d == null ? void 0 : d.state) === 0 && (a[b] = d)
        });
        return a
    }

    function ek(a) {
        return !!(a && a.parent && a.context && a.context.source === 1 && a.parent.ctid.indexOf("GTM-") !== 0)
    }

    function fk() {
        for (var a = Ij(), b = m(Qj()), c = b.next(); !c.done; c = b.next())
            if (a.injectedFirstPartyContainers[c.value]) return !0;
        return !1
    };
    var gk = {},
        hk = (gk.tdp = 1, gk.exp = 1, gk.pid = 1, gk.dl = 1, gk.seq = 1, gk.t = 1, gk.v = 1, gk),
        ik = {};

    function jk() {
        return Object.keys(ik).filter(function(a) {
            return ik[a]
        })
    }
    var kk = {};

    function lk(a, b, c) {
        kk[a] = b;
        (c === void 0 || c) && mk(a)
    }

    function mk(a, b) {
        ik[a] !== void 0 && (b === void 0 || !b) || Lb(D(5), "GTM-") && a === "mcc" || (ik[a] = !0)
    }

    function nk(a) {
        a.forEach(function(b) {
            hk[b] || (ik[b] = !1)
        })
    };

    function ok(a) {
        a = a === void 0 ? [] : a;
        return Si(a).join("~")
    };
    var pk = [];

    function qk(a) {
        switch (a) {
            case 1:
                return 0;
            case 421:
                return 21;
            case 436:
                return 22;
            case 235:
                return 19;
            case 38:
                return 14;
            case 287:
                return 12;
            case 288:
                return 13;
            case 285:
                return 10;
            case 286:
                return 11;
            case 219:
                return 8;
            case 220:
                return 9;
            case 53:
                return 1;
            case 54:
                return 2;
            case 52:
                return 5;
            case 203:
                return 18;
            case 75:
                return 3;
            case 103:
                return 15;
            case 197:
                return 16;
            case 109:
                return 20;
            case 116:
                return 4;
            case 135:
                return 7
        }
    }

    function rk(a, b) {
        pk[a] = b;
        var c = qk(a);
        c !== void 0 && (Va[c] = b)
    }

    function sk(a) {
        rk(a, !0)
    }
    sk(120);
    sk(87);
    sk(132);
    sk(20);
    sk(72);
    sk(113);
    sk(116);
    rk(23, !1), sk(24);
    pg(6, 6E4);
    pg(7, 1);
    pg(35, 50);
    sk(37);
    sk(9);
    sk(123);
    sk(158);
    sk(71);

    sk(135);
    sk(38);
    sk(103);

    sk(101);
    sk(435);
    sk(21);

    sk(141);
    sk(183);
    sk(185);
    sk(197);
    sk(200);
    sk(206);
    sk(218);
    sk(232);
    sk(252);

    sk(275);

    function P(a) {
        return !!pk[a]
    };

    function wk() {
        return {
            total: 0,
            jb: 0,
            Se: {}
        }
    }

    function xk(a, b, c, d) {
        var e = Object.keys(a.Te).sort(function(f, g) {
            return Number(f) - Number(g)
        }).map(function(f) {
            return [f, b(a.Te[f])]
        }).filter(function(f) {
            return f[1] !== void 0
        }).map(function(f) {
            return f.join(c)
        }).join(d);
        return e ? e : void 0
    }

    function yk(a, b) {
        var c, d, e;
        c = c === void 0 ? "_" : c;
        d = d === void 0 ? ";" : d;
        e = e === void 0 ? "~" : e;
        for (var f = [], g = m(Object.keys(a.Se).sort()), h = g.next(); !h.done; h = g.next()) {
            var l = h.value,
                n = xk(a.Se[l], b, c, d);
            if (n) {
                var p = void 0;
                f.push("" + ((p = l) != null ? p : "") + d + n)
            }
        }
        return f.length ? f.join(e) : void 0
    }

    function zk(a) {
        a.jb = 0;
        for (var b = m(Object.keys(a.Se)), c = b.next(); !c.done; c = b.next()) {
            var d = a.Se[c.value];
            d.jb = 0;
            for (var e = m(Object.keys(d.Te)), f = e.next(); !f.done; f = e.next()) d.Te[f.value].jb = 0
        }
    }

    function Ak(a, b, c) {
        var d;
        d = d === void 0 ? 1 : d;
        a.total += d;
        a.jb += d;
        var e, f = b === void 0 ? "" : b;
        e = a.Se[f] || (a.Se[f] = {
            total: 0,
            jb: 0,
            Te: {}
        });
        e.total += d;
        e.jb += d;
        var g, h = String(c);
        g = e.Te[h] || (e.Te[h] = {
            total: 0,
            jb: 0
        });
        g.total += d;
        g.jb += d
    };
    var Bk = wk();
    var Ck = {},
        Dk = (Ck[1] = {}, Ck[2] = {}, Ck[3] = {}, Ck[4] = {}, Ck);

    function Ek(a, b, c) {
        var d = Fk(b, c);
        if (d) {
            var e = Dk[b][d];
            e || (e = Dk[b][d] = []);
            e.push(na(Object, "assign").call(Object, {}, a));
            Ak(Bk, a.destinationId, a.endpoint);
            a.endpoint !== 56 && a.endpoint !== 61 && mk("mde", !0)
        }
    }

    function Gk(a, b) {
        var c = Fk(a, b);
        if (c) {
            var d = Dk[a][c];
            d && (Dk[a][c] = d.filter(function(e) {
                return !e.Cn
            }))
        }
    }

    function Hk(a) {
        switch (a) {
            case "script-src":
            case "script-src-elem":
                return 1;
            case "frame-src":
                return 4;
            case "connect-src":
                return 2;
            case "img-src":
                return 3
        }
    }

    function Fk(a, b) {
        var c = b;
        if (b[0] === "/") {
            var d;
            c = ((d = w.location) == null ? void 0 : d.origin) + b
        }
        try {
            var e = new URL(c);
            return a === 4 ? e.origin : e.origin + e.pathname
        } catch (f) {}
    };

    function Ik(a) {
        var b = String(a[tf.Ta] || "").replace(/_/g, "");
        return Lb(b, "cvt") ? "cvt" : b
    }
    var Jk = w.location.search.indexOf("?gtm_latency=") >= 0 || w.location.search.indexOf("&gtm_latency=") >= 0;
    var Kk = Math.random(),
        Lk, Mk = lg(27);
    Lk = Jk || Kk < Mk;
    var Nk, Ok = lg(42);
    Nk = Jk || Kk >= 1 - Ok;

    function Pk(a, b, c) {
        var d, e = a.GooglebQhCsO;
        e || (e = {}, a.GooglebQhCsO = e);
        d = e;
        if (d[b]) return !1;
        d[b] = [];
        d[b][0] = c;
        return !0
    };
    var Qk, Rk;
    a: {
        for (var Sk = ["CLOSURE_FLAGS"], Tk = Ea, Uk = 0; Uk < Sk.length; Uk++)
            if (Tk = Tk[Sk[Uk]], Tk == null) {
                Rk = null;
                break a
            }
        Rk = Tk
    }
    var Vk = Rk && Rk[610401301];
    Qk = Vk != null ? Vk : !1;

    function Wk() {
        var a = Ea.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }
    var al, bl = Ea.navigator;
    al = bl ? bl.userAgentData || null : null;

    function cl(a) {
        if (!Qk || !al) return !1;
        for (var b = 0; b < al.brands.length; b++) {
            var c = al.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function dl(a) {
        return Wk().indexOf(a) != -1
    };

    function el() {
        return Qk ? !!al && al.brands.length > 0 : !1
    }

    function fl() {
        return el() ? !1 : dl("Opera")
    }

    function gl() {
        return dl("Firefox") || dl("FxiOS")
    }

    function hl() {
        return el() ? cl("Chromium") : (dl("Chrome") || dl("CriOS")) && !(el() ? 0 : dl("Edge")) || dl("Silk")
    };

    function il() {
        return Qk ? !!al && !!al.platform : !1
    }

    function jl() {
        return dl("iPhone") && !dl("iPod") && !dl("iPad")
    }

    function kl() {
        jl() || dl("iPad") || dl("iPod")
    };
    var ll = function(a) {
        ll[" "](a);
        return a
    };
    ll[" "] = function() {};
    fl();
    el() || dl("Trident") || dl("MSIE");
    dl("Edge");
    !dl("Gecko") || Wk().toLowerCase().indexOf("webkit") != -1 && !dl("Edge") || dl("Trident") || dl("MSIE") || dl("Edge");
    Wk().toLowerCase().indexOf("webkit") != -1 && !dl("Edge") && dl("Mobile");
    il() || dl("Macintosh");
    il() || dl("Windows");
    (il() ? al.platform === "Linux" : dl("Linux")) || il() || dl("CrOS");
    il() || dl("Android");
    jl();
    dl("iPad");
    dl("iPod");
    kl();
    Wk().toLowerCase().indexOf("kaios");
    gl();
    jl() || dl("iPod");
    dl("iPad");
    !dl("Android") || hl() || gl() || fl() || dl("Silk");
    hl();
    !dl("Safari") || hl() || (el() ? 0 : dl("Coast")) || fl() || (el() ? 0 : dl("Edge")) || (el() ? cl("Microsoft Edge") : dl("Edg/")) || (el() ? cl("Opera") : dl("OPR")) || gl() || dl("Silk") || dl("Android") || kl();
    var ml = {},
        nl = null;

    function ol(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        var f = 4;
        f === void 0 && (f = 0);
        if (!nl) {
            nl = {};
            for (var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), h = ["+/=", "+/", "-_=", "-_.", "-_"], l = 0; l < 5; l++) {
                var n = g.concat(h[l].split(""));
                ml[l] = n;
                for (var p = 0; p < n.length; p++) {
                    var q = n[p];
                    nl[q] === void 0 && (nl[q] = p)
                }
            }
        }
        for (var r = ml[f], u = Array(Math.floor(b.length / 3)), t = r[64] || "", v = 0, x = 0; v < b.length - 2; v += 3) {
            var y = b[v],
                A = b[v + 1],
                C = b[v + 2],
                E = r[y >> 2],
                H = r[(y & 3) << 4 | A >> 4],
                J = r[(A & 15) << 2 | C >> 6],
                O = r[C & 63];
            u[x++] = "" + E + H + J + O
        }
        var ba = 0,
            W = t;
        switch (b.length - v) {
            case 2:
                ba = b[v + 1], W = r[(ba & 15) << 2] || t;
            case 1:
                var N = b[v];
                u[x] = "" + r[N >> 2] + r[(N & 3) << 4 | ba >> 4] + W + t
        }
        return u.join("")
    };
    var pl = function(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    };

    function ql(a, b, c, d) {
        for (var e = b, f = c.length;
            (e = a.indexOf(c, e)) >= 0 && e < d;) {
            var g = a.charCodeAt(e - 1);
            if (g == 38 || g == 63) {
                var h = a.charCodeAt(e + f);
                if (!h || h == 61 || h == 38 || h == 35) return e
            }
            e += f + 1
        }
        return -1
    }
    var rl = /#|$/;

    function sl(a, b) {
        var c = a.search(rl),
            d = ql(a, 0, b, c);
        if (d < 0) return null;
        var e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return pl(a.slice(d, e !== -1 ? e : 0))
    }
    var tl = /[?&]($|#)/;

    function ul(a, b, c) {
        for (var d, e = a.search(rl), f = 0, g, h = [];
            (g = ql(a, f, b, e)) >= 0;) h.push(a.substring(f, g)), f = Math.min(a.indexOf("&", g) + 1 || e, e);
        h.push(a.slice(f));
        d = h.join("").replace(tl, "$1");
        var l, n = c != null ? "=" + encodeURIComponent(String(c)) : "";
        var p = b + n;
        if (p) {
            var q, r = d.indexOf("#");
            r < 0 && (r = d.length);
            var u = d.indexOf("?"),
                t;
            u < 0 || u > r ? (u = r, t = "") : t = d.substring(u + 1, r);
            q = [d.slice(0, u), t, d.slice(r)];
            var v = q[1];
            q[1] = p ? v ? v + "&" + p : p : v;
            l = q[0] + (q[1] ? "?" + q[1] : "") + q[2]
        } else l = d;
        return l
    };

    function vl(a, b, c, d, e, f, g) {
        var h = sl(c, "fmt");
        if (d) {
            var l = sl(c, "random"),
                n = sl(c, "label") || "";
            if (!l) return !1;
            var p = ol(pl(n) + ":" + pl(l));
            if (!Pk(a, p, d)) return !1
        }
        h && Number(h) !== 4 && (c = ul(c, "rfmt", h));
        var q = ul(c, "fmt", 4),
            r = b.getElementsByTagName("script")[0].parentElement;
        g == null || wl(g);
        Nc(q, function() {
            g == null || xl(g);
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, function() {
            g == null || xl(g);
            e == null || e()
        }, f, r || void 0);
        return !0
    };

    function yl(a) {
        var b = Da.apply(1, arguments);
        Nk && (Ek(a, 2, b[0]), Ek(a, 3, b[0]));
        Zc.apply(null, za(b))
    }

    function zl(a) {
        var b = Da.apply(1, arguments);
        Nk && Ek(a, 2, b[0]);
        return $c.apply(null, za(b))
    }

    function Al(a) {
        var b = Da.apply(1, arguments);
        Nk && Ek(a, 3, b[0]);
        Qc.apply(null, za(b))
    }

    function Bl(a) {
        var b = Da.apply(1, arguments),
            c = b[0];
        Nk && (Ek(a, 2, c), Ek(a, 3, c));
        return bd.apply(null, za(b))
    }

    function Cl(a) {
        var b = Da.apply(1, arguments);
        Nk && Ek(a, 1, b[0]);
        Nc.apply(null, za(b))
    }

    function Dl(a) {
        var b = Da.apply(1, arguments);
        b[0] && Nk && Ek(a, 4, b[0]);
        Pc.apply(null, za(b))
    }

    function El(a) {
        var b = Da.apply(1, arguments);
        Nk && Ek(a, 1, b[2]);
        return vl.apply(null, za(b))
    };
    var Fl = {
        Ma: {
            Ce: 0,
            Fe: 1,
            Ki: 2
        }
    };
    Fl.Ma[Fl.Ma.Ce] = "FULL_TRANSMISSION";
    Fl.Ma[Fl.Ma.Fe] = "LIMITED_TRANSMISSION";
    Fl.Ma[Fl.Ma.Ki] = "NO_TRANSMISSION";
    var Gl = {
        aa: {
            Sc: 0,
            Sa: 1,
            dd: 2,
            Qc: 3
        }
    };
    Gl.aa[Gl.aa.Sc] = "NO_QUEUE";
    Gl.aa[Gl.aa.Sa] = "ADS";
    Gl.aa[Gl.aa.dd] = "ANALYTICS";
    Gl.aa[Gl.aa.Qc] = "MONITORING";

    function Hl() {
        var a = Fc("google_tag_data", {});
        return a.ics = a.ics || new Il
    }
    var Il = function() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.C = []
    };
    Il.prototype.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        kb("TAGGING", 19);
        b == null ? kb("TAGGING", 18) : Jl(this, a, b === "granted", c, d, e, f, g)
    };
    Il.prototype.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) Jl(this, a[d], void 0, void 0, "", "", b, c)
    };
    var Jl = function(a, b, c, d, e, f, g, h) {
        var l = a.entries,
            n = l[b] || {},
            p = n.region,
            q = d && sb(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
            var r = !!(g && g > 0 && n.update === void 0),
                u = {
                    region: q,
                    declare_region: n.declare_region,
                    implicit: n.implicit,
                    default: c !== void 0 ? c : n.default,
                    declare: n.declare,
                    update: n.update,
                    quiet: r
                };
            if (e !== "" || n.default !== !1) l[b] = u;
            r && w.setTimeout(function() {
                l[b] === u && u.quiet && (kb("TAGGING", 2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h),
                    a.notifyListeners())
            }, g)
        }
    };
    k = Il.prototype;
    k.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        var g = this.entries[a] || {},
            h = this.getConsentState(a, c);
        if (g.quiet) {
            g.quiet = !1;
            for (var l = m(d), n = l.next(); !n.done; n = l.next()) Kl(this, n.value)
        } else if (b !== void 0 && h !== b)
            for (var p = m(d), q = p.next(); !q.done; q = p.next()) Kl(this, q.value)
    };
    k.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = this.entries;
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    k.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = this.entries,
            g = f[a] || {},
            h = g.declare_region,
            l = c && sb(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
            var n = {
                region: g.region,
                declare_region: l,
                declare: b === "granted",
                implicit: g.implicit,
                default: g.default,
                update: g.update,
                quiet: g.quiet
            };
            if (d !== "" || g.declare !== !1) f[a] = n
        }
    };
    k.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = this.entries,
            d = c[a] = c[a] || {};
        d.implicit !== !1 && (d.implicit = b === "granted")
    };
    k.getConsentState = function(a, b) {
        var c = this.entries,
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            var f = b.containerScopedDefaults[a];
            if (f === 3) return 1;
            if (f === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            var g = b.delegatedConsentTypes[a],
                h = c[g] || {};
            e = h.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                var l = b.containerScopedDefaults[g];
                if (l === 3) return 1;
                if (l === 2) return 2
            } else if (e =
                h.default, e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    k.addListener = function(a, b) {
        this.C.push({
            consentTypes: a,
            Kd: b
        })
    };
    var Kl = function(a, b) {
        for (var c = 0; c < a.C.length; ++c) {
            var d = a.C[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.xn = !0)
        }
    };
    Il.prototype.notifyListeners = function(a, b) {
        for (var c = 0; c < this.C.length; ++c) {
            var d = this.C[c];
            if (d.xn) {
                d.xn = !1;
                try {
                    d.Kd({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var Ll = !1,
        Ml = !1,
        Nl = {},
        Ol = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (Nl.ad_storage = 1, Nl.analytics_storage = 1, Nl.ad_user_data = 1, Nl.ad_personalization = 1, Nl),
            usedContainerScopedDefaults: !1
        };

    function Pl(a) {
        var b = Hl();
        b.accessedAny = !0;
        return (sb(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, Ol)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function Ql(a) {
        var b = Hl();
        b.accessedAny = !0;
        return b.getConsentState(a, Ol)
    }

    function Rl(a) {
        var b = Hl();
        b.accessedAny = !0;
        return !(b.entries[a] || {}).quiet
    }

    function Sl() {
        if (!Wa(6)) return !1;
        var a = Hl();
        a.accessedAny = !0;
        if (a.active) return !0;
        if (!Ol.usedContainerScopedDefaults) return !1;
        for (var b = m(Object.keys(Ol.containerScopedDefaults)), c = b.next(); !c.done; c = b.next())
            if (Ol.containerScopedDefaults[c.value] !== 1) return !0;
        return !1
    }

    function Tl(a, b) {
        Hl().addListener(a, b)
    }

    function Ul(a, b) {
        Hl().notifyListeners(a, b)
    }

    function Vl(a, b) {
        function c() {
            for (var e = 0; e < b.length; e++)
                if (!Rl(b[e])) return !0;
            return !1
        }
        if (c()) {
            var d = !1;
            Tl(b, function(e) {
                d || c() || (d = !0, a(e))
            })
        } else a({})
    }

    function Wl(a, b) {
        function c() {
            for (var h = [], l = 0; l < e.length; l++) {
                var n = e[l];
                Pl(n) && !f[n] && h.push(n)
            }
            return h
        }

        function d(h) {
            for (var l = 0; l < h.length; l++) f[h[l]] = !0
        }
        var e = sb(b) ? [b] : b,
            f = {},
            g = c();
        g.length !== e.length && (d(g), Tl(e, function(h) {
            function l(q) {
                q.length !== 0 && (d(q), h.consentTypes = q, a(h))
            }
            var n = c();
            if (n.length !== 0) {
                var p = Object.keys(f).length;
                n.length + p >= e.length ? l(n) : w.setTimeout(function() {
                    l(c())
                }, 500)
            }
        }))
    };
    var Xl = {},
        Yl = (Xl[Gl.aa.Sc] = Fl.Ma.Ce, Xl[Gl.aa.Sa] = Fl.Ma.Ce, Xl[Gl.aa.dd] = Fl.Ma.Ce, Xl[Gl.aa.Qc] = Fl.Ma.Ce, Xl),
        Zl = function(a, b) {
            this.C = a;
            this.consentTypes = b
        };
    Zl.prototype.isConsentGranted = function() {
        switch (this.C) {
            case 0:
                return this.consentTypes.every(function(a) {
                    return Pl(a)
                });
            case 1:
                return this.consentTypes.some(function(a) {
                    return Pl(a)
                });
            default:
                tc(this.C, "consentsRequired had an unknown type")
        }
    };
    var $l = {},
        am = ($l[Gl.aa.Sc] = new Zl(0, []), $l[Gl.aa.Sa] = new Zl(0, ["ad_storage"]), $l[Gl.aa.dd] = new Zl(0, ["analytics_storage"]), $l[Gl.aa.Qc] = new Zl(1, ["ad_storage", "analytics_storage"]), $l);
    var cm = function(a) {
        var b = this;
        this.type = a;
        this.C = [];
        Tl(am[a].consentTypes, function() {
            bm(b) || b.flush()
        })
    };
    cm.prototype.flush = function() {
        for (var a = m(this.C), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            c()
        }
        this.C = []
    };
    var bm = function(a) {
            return Yl[a.type] === Fl.Ma.Ki && !am[a.type].isConsentGranted()
        },
        dm = function(a, b) {
            bm(a) ? a.C.push(b) : b()
        },
        em = new Map;

    function fm(a) {
        em.has(a) || em.set(a, new cm(a));
        return em.get(a)
    };
    var gm = {
        Z: {
            Rn: "aw_user_data_cache",
            Zh: "cookie_deprecation_label",
            Ng: "diagnostics_page_id",
            Gs: "em_registry",
            xi: "eab",
            up: "fl_user_data_cache",
            Bp: "ga4_user_data_cache",
            De: "ip_geo_data_cache",
            Di: "ip_geo_fetch_in_progress",
            rm: "nb_data",
            Mi: "page_experiment_ids",
            tm: "pld",
            He: "pt_data",
            vm: "pt_listener_set",
            Am: "service_worker_endpoint",
            Dm: "shared_user_id",
            Em: "shared_user_id_requested",
            Dh: "shared_user_id_source"
        }
    };
    var hm = function(a) {
        return jf(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }(gm.Z);

    function im(a, b) {
        b = b === void 0 ? !1 : b;
        if (hm(a)) {
            var c, d, e = (d = (c = Fc("google_tag_data", {})).xcd) != null ? d : c.xcd = {};
            if (e[a]) return e[a];
            if (b) {
                var f = void 0,
                    g = 1,
                    h = {},
                    l = {
                        set: function(n) {
                            f = n;
                            l.notify()
                        },
                        get: function() {
                            return f
                        },
                        subscribe: function(n) {
                            h[String(g)] = n;
                            return g++
                        },
                        unsubscribe: function(n) {
                            var p = String(n);
                            return h.hasOwnProperty(p) ? (delete h[p], !0) : !1
                        },
                        notify: function() {
                            for (var n = m(Object.keys(h)), p = n.next(); !p.done; p = n.next()) {
                                var q = p.value;
                                try {
                                    h[q](a, f)
                                } catch (r) {}
                            }
                        }
                    };
                return e[a] = l
            }
        }
    }

    function jm(a, b) {
        var c = im(a, !0);
        c && c.set(b)
    }

    function km(a) {
        var b;
        return (b = im(a)) == null ? void 0 : b.get()
    }

    function lm(a, b) {
        var c = im(a);
        if (!c) {
            c = im(a, !0);
            if (!c) return;
            c.set(b)
        }
        return c.get()
    }

    function mm(a, b) {
        if (typeof b === "function") {
            var c;
            return (c = im(a, !0)) == null ? void 0 : c.subscribe(b)
        }
    }

    function nm(a, b) {
        var c = im(a);
        return c ? c.unsubscribe(b) : !1
    };
    var om = ["fin", "mcc"],
        pm = !1;

    function qm(a) {
        a = a === void 0 ? !1 : a;
        var b = jk().filter(function(c) {
            return kk[c] !== void 0 && (a || !om.includes(c))
        });
        nk(b);
        return b.map(function(c) {
            var d = kk[c];
            typeof d === "function" && (d = d());
            return d ? "&" + c + "=" + d : ""
        }).join("") + "&z=0"
    }

    function rm(a) {
        var b = "https://" + D(21),
            c = "/td?id=" + D(5);
        return "" + Aj(b) + c + a
    }

    function sm(a) {
        a = a === void 0 ? !1 : a;
        if (Ri.H && Nk && D(5)) {
            var b = fm(Gl.aa.Qc);
            if (bm(b)) pm || (pm = !0, dm(b, sm));
            else {
                a && lk("fin", "1");
                var c = qm(a),
                    d = rm(c),
                    e = {
                        destinationId: D(5),
                        endpoint: 61
                    };
                a ? Bl(e, d, void 0, {
                    Re: !0
                }, void 0, function() {
                    Al(e, d + "&img=1")
                }) : Al(e, d);
                pm = !1;
                tm(c)
            }
        }
    }

    function tm(a) {
        if (P(426) && !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)) {
            var b;
            a: {
                try {
                    if (Ec) {
                        b = new URL(Ec);
                        break a
                    }
                } catch (c) {}
                b = void 0
            }
            b && Nc("" + Ec + (Ec.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a)
        }
    }

    function um() {
        jk().some(function(a) {
            return !hk[a]
        }) && sm(!0)
    }
    var vm;

    function wm() {
        if (km(gm.Z.Ng) === void 0) {
            var a = function() {
                jm(gm.Z.Ng, wb());
                vm = 0
            };
            a();
            w.setInterval(a, 864E5)
        } else mm(gm.Z.Ng, function() {
            vm = 0
        });
        vm = 0
    }

    function xm() {
        wm();
        lk("v", "3");
        lk("t", "t");
        lk("pid", function() {
            return String(km(gm.Z.Ng))
        });
        lk("seq", function() {
            return String(++vm)
        });
        lk("exp", ok());
        Sc(w, "pagehide", um)
    };
    var ym = ["ad_storage", "analytics_storage", "ad_user_data", "ad_personalization"],
        zm = [K.m.vd, K.m.Oc, K.m.Af, K.m.Vb, K.m.Yb, K.m.Oa, K.m.cb, K.m.Xa, K.m.wb, K.m.Wb],
        Am = !1,
        Bm = !1,
        Cm = {},
        Dm = {};

    function Em() {
        !Bm && Am && (ym.some(function(a) {
            return Ol.containerScopedDefaults[a] !== 1
        }) || Fm("mbc"));
        Bm = !0
    }

    function Fm(a) {
        Nk && (lk(a, "1"), sm())
    }

    function Gm(a, b) {
        if (!Cm[b] && (Cm[b] = !0, Dm[b]))
            for (var c = m(zm), d = c.next(); !d.done; d = c.next())
                if (L(a, d.value)) {
                    Fm("erc");
                    break
                }
    };

    function Hm(a) {
        kb("HEALTH", a)
    };
    var Im = {},
        Jm = !1;

    function Km() {
        function a() {
            c !== void 0 && nm(gm.Z.De, c);
            try {
                var e = km(gm.Z.De);
                Im = JSON.parse(e)
            } catch (f) {
                M(123), Hm(2), Im = {}
            }
            Jm = !0;
            b()
        }
        var b = Lm,
            c = void 0,
            d = km(gm.Z.De);
        d ? a(d) : (c = mm(gm.Z.De, a), Mm())
    }

    function Mm() {
        function a(b) {
            jm(gm.Z.De, b || "{}");
            jm(gm.Z.Di, !1)
        }
        if (!km(gm.Z.Di)) {
            jm(gm.Z.Di, !0);
            try {
                w.fetch("https://www.google.com/ccm/geo", {
                    method: "GET",
                    cache: "no-store",
                    mode: "cors",
                    credentials: "omit"
                }).then(function(b) {
                    b.ok ? b.text().then(function(c) {
                        a(c)
                    }, function() {
                        a()
                    }) : a()
                }, function() {
                    a()
                })
            } catch (b) {
                a()
            }
        }
    }

    function Nm() {
        var a = D(22);
        try {
            return JSON.parse(ib(a))
        } catch (b) {
            return M(123), Hm(2), {}
        }
    }

    function Om() {
        return Im["0"] || ""
    }

    function Pm() {
        return Im["1"] || ""
    }

    function Qm() {
        var a = !1;
        return a
    }

    function Rm() {
        return Im["6"] !== !1
    }

    function Sm() {
        var a = "";
        return a
    }

    function Tm() {
        var a = "";
        return a
    };
    var Um = {},
        Vm = Object.freeze((Um[K.m.Tb] = 1, Um[K.m.Og] = 1, Um[K.m.di] = 1, Um[K.m.Ub] = 1, Um[K.m.Ba] = 1, Um[K.m.wb] = 1, Um[K.m.xb] = 1, Um[K.m.Fb] = 1, Um[K.m.ld] = 1, Um[K.m.Wb] = 1, Um[K.m.Xa] = 1, Um[K.m.Ac] = 1, Um[K.m.se] = 1, Um[K.m.Ga] = 1, Um[K.m.Oo] = 1, Um[K.m.zf] = 1, Um[K.m.li] = 1, Um[K.m.Yg] = 1, Um[K.m.od] = 1, Um[K.m.Af] = 1, Um[K.m.Yo] = 1, Um[K.m.Gc] = 1, Um[K.m.Ef] = 1, Um[K.m.ap] = 1, Um[K.m.fh] = 1, Um[K.m.Zk] = 1, Um[K.m.Hc] = 1, Um[K.m.Ic] = 1, Um[K.m.cb] = 1, Um[K.m.ol] = 1, Um[K.m.Xb] = 1, Um[K.m.sd] = 1, Um[K.m.ud] = 1, Um[K.m.vd] = 1, Um[K.m.jh] = 1, Um[K.m.si] = 1, Um[K.m.wd] =
            1, Um[K.m.Oc] = 1, Um[K.m.xd] = 1, Um[K.m.yl] = 1, Um[K.m.yd] = 1, Um[K.m.Pc] = 1, Um[K.m.Ri] = 1, Um));
    Object.freeze([K.m.xa, K.m.Ya, K.m.Gb, K.m.lb, K.m.ri, K.m.Oa, K.m.mi, K.m.Lo]);
    var Wm = {},
        Xm = Object.freeze((Wm[K.m.oo] = 1, Wm[K.m.po] = 1, Wm[K.m.qo] = 1, Wm[K.m.ro] = 1, Wm[K.m.so] = 1, Wm[K.m.xo] = 1, Wm[K.m.yo] = 1, Wm[K.m.zo] = 1, Wm[K.m.Bo] = 1, Wm[K.m.je] = 1, Wm)),
        Ym = {},
        Zm = Object.freeze((Ym[K.m.Bk] = 1, Ym[K.m.Ck] = 1, Ym[K.m.ee] = 1, Ym[K.m.fe] = 1, Ym[K.m.Dk] = 1, Ym[K.m.fd] = 1, Ym[K.m.he] = 1, Ym[K.m.qc] = 1, Ym[K.m.zc] = 1, Ym[K.m.rc] = 1, Ym[K.m.Cb] = 1, Ym[K.m.ie] = 1, Ym[K.m.sc] = 1, Ym[K.m.Ek] = 1, Ym)),
        $m = Object.freeze([K.m.Tb, K.m.jf, K.m.Ub, K.m.Ac, K.m.Af, K.m.Gf, K.m.sd, K.m.xd]),
        an = Object.freeze([].concat(za($m))),
        bn = Object.freeze([K.m.xb,
            K.m.Yg, K.m.jh, K.m.si, K.m.Wg
        ]),
        cn = Object.freeze([].concat(za(bn))),
        dn = {},
        en = (dn[K.m.W] = "1", dn[K.m.ja] = "2", dn[K.m.X] = "3", dn[K.m.Na] = "4", dn),
        fn = {},
        gn = Object.freeze((fn.search = "s", fn.youtube = "y", fn.playstore = "p", fn.shopping = "h", fn.ads = "a", fn.maps = "m", fn));

    function hn(a) {
        return typeof a !== "object" || a === null ? {} : a
    }

    function jn(a) {
        return a === void 0 || a === null ? "" : typeof a === "object" ? a.toString() : String(a)
    }

    function kn(a) {
        if (a !== void 0 && a !== null) return jn(a)
    }

    function ln(a) {
        return typeof a === "number" ? a : kn(a)
    };

    function mn(a) {
        return a && a.indexOf("pending:") === 0 ? nn(a.substr(8)) : !1
    }

    function nn(a) {
        if (a == null || a.length === 0) return !1;
        var b = Number(a),
            c = Gb();
        return b < c + 3E5 && b > c - 9E5
    };
    var on = !1,
        pn = !1,
        qn = !1,
        rn = 0,
        sn = !1,
        tn = [];

    function un(a) {
        if (rn === 0) sn && tn && (tn.length >= 100 && tn.shift(), tn.push(a));
        else if (vn()) {
            var b = D(41),
                c = Fc(b, []);
            c.length >= 50 && c.shift();
            c.push(a)
        }
    }

    function wn() {
        xn();
        Tc(z, "TAProdDebugSignal", wn)
    }

    function xn() {
        if (!pn) {
            pn = !0;
            yn();
            var a = tn;
            tn = void 0;
            a == null || a.forEach(function(b) {
                un(b)
            })
        }
    }

    function yn() {
        var a = z.documentElement.getAttribute("data-tag-assistant-prod-present");
        nn(a) ? rn = 1 : !mn(a) || on || qn ? rn = 2 : (qn = !0, Sc(z, "TAProdDebugSignal", wn, !1), w.setTimeout(function() {
            xn();
            on = !0
        }, 200))
    }

    function vn() {
        if (!sn) return !1;
        switch (rn) {
            case 1:
            case 0:
                return !0;
            case 2:
                return !1;
            default:
                return !1
        }
    };
    var zn = !1;

    function An(a, b) {
        var c = Qj(),
            d = Nj();
        D(26);
        var e = kg(47) ? 0 : kg(50) ? 1 : 3,
            f = vj();
        if (vn()) {
            var g = Bn("INIT");
            g.containerLoadSource = a != null ? a : 0;
            b && (g.parentTargetReference = b);
            g.aliases = c;
            g.destinations = d;
            e !== void 0 && (g.gtg = {
                source: e,
                mPath: f != null ? f : ""
            });
            un(g)
        }
    }

    function Cn(a) {
        var b, c, d, e;
        b = a.targetId;
        c = a.request;
        d = a.hb;
        e = a.isBatched;
        var f;
        if (f = vn()) {
            var g;
            a: switch (c.endpoint) {
                case 19:
                case 47:
                    g = !0;
                    break a;
                default:
                    g = !1
            }
            f = !g
        }
        if (f) {
            var h = Bn("GTAG_HIT", {
                eventId: d.eventId,
                priorityId: d.priorityId
            });
            h.target = b;
            h.url = c.url;
            c.postBody && (h.postBody = c.postBody);
            h.parameterEncoding = c.parameterEncoding;
            h.endpoint = c.endpoint;
            e !== void 0 && (h.isBatched = e);
            un(h)
        }
    }

    function Dn(a) {
        vn() && Cn(a())
    }

    function Bn(a, b) {
        b = b === void 0 ? {} : b;
        b.groupId = En;
        var c, d = b,
            e = Fn,
            f = {
                publicId: Gn
            };
        d.eventId != null && (f.eventId = d.eventId);
        d.priorityId != null && (f.priorityId = d.priorityId);
        d.eventName && (f.eventName = d.eventName);
        d.groupId && (f.groupId = d.groupId);
        d.tagName && (f.tagName = d.tagName);
        c = {
            containerProduct: "GTM",
            key: f,
            version: e,
            messageType: a
        };
        c.containerProduct = zn ? "OGT" : "GTM";
        c.key.targetRef = Hn;
        return c
    }
    var Gn = "",
        Fn = "",
        Hn = {
            ctid: "",
            isDestination: !1
        },
        En;

    function In(a) {
        var b = D(5),
            c = Mj(),
            d = D(6),
            e = D(1);
        D(23);
        rn = 0;
        sn = !0;
        yn();
        En = a;
        Gn = b;
        Fn = e;
        zn = Zi;
        Hn = {
            ctid: b,
            isDestination: c,
            canonicalId: d
        }
    };
    var Jn = [K.m.W, K.m.ja, K.m.X, K.m.Na],
        Kn, Ln;

    function Mn(a) {
        var b = a[K.m.oc];
        b || (b = [""]);
        for (var c = {
                qg: 0
            }; c.qg < b.length; c = {
                qg: c.qg
            }, ++c.qg) zb(a, function(d) {
            return function(e, f) {
                if (e !== K.m.oc) {
                    var g = jn(f),
                        h = b[d.qg],
                        l = Om(),
                        n = Pm();
                    Ml = !0;
                    Ll && kb("TAGGING", 20);
                    Hl().declare(e, g, h, l, n)
                }
            }
        }(c))
    }

    function Nn(a) {
        Em();
        !Ln && Kn && Fm("crc");
        Ln = !0;
        var b = a[K.m.Ig];
        b && M(41);
        var c = a[K.m.oc];
        c ? M(40) : c = [""];
        for (var d = {
                rg: 0
            }; d.rg < c.length; d = {
                rg: d.rg
            }, ++d.rg) zb(a, function(e) {
            return function(f, g) {
                if (f !== K.m.oc && f !== K.m.Ig) {
                    var h = kn(g),
                        l = c[e.rg],
                        n = Number(b),
                        p = Om(),
                        q = Pm();
                    n = n === void 0 ? 0 : n;
                    Ll = !0;
                    Ml && kb("TAGGING", 20);
                    Hl().default(f, h, l, p, q, n, Ol)
                }
            }
        }(d))
    }

    function On(a) {
        Ol.usedContainerScopedDefaults = !0;
        var b = a[K.m.oc];
        if (b) {
            var c = Array.isArray(b) ? b : [b];
            if (!c.includes(Pm()) && !c.includes(Om())) return
        }
        zb(a, function(d, e) {
            switch (d) {
                case "ad_storage":
                case "analytics_storage":
                case "ad_user_data":
                case "ad_personalization":
                    break;
                default:
                    return
            }
            Ol.usedContainerScopedDefaults = !0;
            Ol.containerScopedDefaults[d] = e === "granted" ? 3 : 2
        })
    }

    function Pn(a, b) {
        Em();
        Kn = !0;
        zb(a, function(c, d) {
            var e = jn(d);
            Ll = !0;
            Ml && kb("TAGGING", 20);
            Hl().update(c, e, Ol)
        });
        Ul(b.eventId, b.priorityId)
    }

    function Qn(a) {
        a.hasOwnProperty("all") && (Ol.selectedAllCorePlatformServices = !0, zb(gn, function(b) {
            Ol.corePlatformServices[b] = a.all === "granted";
            Ol.usedCorePlatformServices = !0
        }));
        zb(a, function(b, c) {
            b !== "all" && (Ol.corePlatformServices[b] = c === "granted", Ol.usedCorePlatformServices = !0)
        })
    }

    function Rn(a) {
        Array.isArray(a) || (a = [a]);
        return a.every(function(b) {
            return Pl(b)
        })
    }

    function Sn(a, b) {
        Tl(a, b)
    }

    function Tn(a, b) {
        Wl(a, b)
    }

    function Un(a, b) {
        Vl(a, b)
    }

    function Vn() {
        var a = [K.m.W, K.m.Na, K.m.X];
        Hl().waitForUpdate(a, 500, Ol)
    }

    function Wn(a) {
        for (var b = m(a), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            Hl().clearTimeout(d, void 0, Ol)
        }
        Ul()
    }

    function Xn() {
        if (!$i)
            for (var a = Rm() ? Yn(ng(5)) : Yn(ng(4)), b = 0; b < Jn.length; b++) {
                var c = Jn[b],
                    d = c,
                    e = a[c] ? "granted" : "denied";
                Hl().implicit(d, e)
            }
    }

    function Yn(a) {
        for (var b = {}, c = m(a.split("|")), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return b
    };
    var Zn = w.google_tag_manager = w.google_tag_manager || {};

    function $n(a, b) {
        return Zn[a] = Zn[a] || b()
    }

    function ao() {
        var a = D(5),
            b = bo;
        Zn[a] = Zn[a] || b
    }

    function co() {
        var a = D(19);
        return Zn[a] = Zn[a] || {}
    }

    function eo() {
        var a = D(19);
        return Zn[a]
    }

    function fo() {
        var a = Zn.sequence || 1;
        Zn.sequence = a + 1;
        return a
    }
    w.google_tag_data = w.google_tag_data || {};
    var go = !1,
        ho = [];

    function io() {
        if (!go) {
            go = !0;
            for (var a = ho.length - 1; a >= 0; a--) ho[a]();
            ho = []
        }
    };
    var jo = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
        ko = /\s/;

    function lo(a, b) {
        if (sb(a)) {
            a = Eb(a);
            var c = a.indexOf("-");
            if (!(c < 0)) {
                var d = a.substring(0, c);
                if (jo.test(d)) {
                    var e = a.substring(c + 1),
                        f;
                    if (b) {
                        var g = function(n) {
                            var p = n.indexOf("/");
                            return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)]
                        };
                        f = g(e);
                        if (d === "DC" && f.length === 2) {
                            var h = g(f[1]);
                            h.length === 2 && (f[1] = h[0], f.push(h[1]))
                        }
                    } else {
                        f = e.split("/");
                        for (var l = 0; l < f.length; l++)
                            if (!f[l] || ko.test(f[l]) && (d !== "AW" || l !== 1)) return
                    }
                    return {
                        id: a,
                        prefix: d,
                        destinationId: d + "-" + f[0],
                        ids: f
                    }
                }
            }
        }
    }

    function mo(a, b) {
        for (var c = {}, d = 0; d < a.length; ++d) {
            var e = lo(a[d], b);
            e && (c[e.id] = e)
        }
        var f = [],
            g;
        for (g in c)
            if (c.hasOwnProperty(g)) {
                var h = c[g];
                h.prefix === "AW" && h.ids[no[1]] && f.push(h.destinationId)
            }
        for (var l = 0; l < f.length; ++l) delete c[f[l]];
        for (var n = [], p = m(Object.keys(c)), q = p.next(); !q.done; q = p.next()) n.push(c[q.value]);
        return n
    }
    var oo = {},
        no = (oo[0] = 0, oo[1] = 1, oo[2] = 2, oo[3] = 0, oo[4] = 1, oo[5] = 0, oo[6] = 0, oo[7] = 0, oo);
    var po = pg(34, 500),
        qo = {},
        ro = {},
        so = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        to = {},
        uo = Object.freeze((to[K.m.sd] = !0, to)),
        vo = void 0;

    function wo(a, b) {
        if (b.length && Nk) {
            var c;
            (c = qo)[a] != null || (c[a] = []);
            ro[a] != null || (ro[a] = []);
            var d = b.filter(function(e) {
                return !ro[a].includes(e)
            });
            qo[a].push.apply(qo[a], za(d));
            ro[a].push.apply(ro[a], za(d));
            !vo && d.length > 0 && (mk("tdc", !0), vo = w.setTimeout(function() {
                sm();
                qo = {};
                vo = void 0
            }, po))
        }
    }

    function xo(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function yo(a, b, c, d) {
        c = c === void 0 ? {} : c;
        d = d === void 0 ? "" : d;
        if (a === b) return [];
        var e = function(r, u) {
                var t;
                qd(u) === "object" ? t = u[r] : qd(u) === "array" && (t = u[r]);
                return t === void 0 ? uo[r] : t
            },
            f = xo(a, b),
            g;
        for (g in f)
            if (f.hasOwnProperty(g)) {
                var h = (d ? d + "." : "") + g,
                    l = e(g, a),
                    n = e(g, b),
                    p = qd(l) === "object" || qd(l) === "array",
                    q = qd(n) === "object" || qd(n) === "array";
                if (p && q) yo(l, n, c, h);
                else if (p || q || l !== n) c[h] = !0
            }
        return Object.keys(c)
    }

    function zo() {
        lk("tdc", function() {
            vo && (w.clearTimeout(vo), vo = void 0);
            var a = [],
                b;
            for (b in qo) qo.hasOwnProperty(b) && a.push(b + "*" + qo[b].join("."));
            return a.length ? a.join("!") : void 0
        }, !1)
    };
    var Ao = {
        R: {
            Zj: 1,
            Qi: 2,
            Vj: 3,
            tk: 4,
            Wj: 5,
            ed: 6,
            sk: 7,
            Lp: 8,
            zm: 9,
            Xj: 10,
            Yj: 11,
            rh: 12,
            Ml: 13,
            Jl: 14,
            Ll: 15,
            Il: 16,
            Kl: 17,
            Hl: 18,
            Qn: 19,
            vp: 20,
            wp: 21,
            Ji: 22
        }
    };
    Ao.R[Ao.R.Zj] = "ALLOW_INTEREST_GROUPS";
    Ao.R[Ao.R.Qi] = "SERVER_CONTAINER_URL";
    Ao.R[Ao.R.Vj] = "ADS_DATA_REDACTION";
    Ao.R[Ao.R.tk] = "CUSTOMER_LIFETIME_VALUE";
    Ao.R[Ao.R.Wj] = "ALLOW_CUSTOM_SCRIPTS";
    Ao.R[Ao.R.ed] = "ANY_COOKIE_PARAMS";
    Ao.R[Ao.R.sk] = "COOKIE_EXPIRES";
    Ao.R[Ao.R.Lp] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
    Ao.R[Ao.R.zm] = "RESTRICTED_DATA_PROCESSING";
    Ao.R[Ao.R.Xj] = "ALLOW_DISPLAY_FEATURES";
    Ao.R[Ao.R.Yj] = "ALLOW_GOOGLE_SIGNALS";
    Ao.R[Ao.R.rh] = "GENERATED_TRANSACTION_ID";
    Ao.R[Ao.R.Ml] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
    Ao.R[Ao.R.Jl] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
    Ao.R[Ao.R.Ll] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
    Ao.R[Ao.R.Il] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
    Ao.R[Ao.R.Kl] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
    Ao.R[Ao.R.Hl] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
    Ao.R[Ao.R.Qn] = "ADS_OGT_V1_USAGE";
    Ao.R[Ao.R.vp] = "FORM_INTERACTION_PERMISSION_DENIED";
    Ao.R[Ao.R.wp] = "FORM_SUBMIT_PERMISSION_DENIED";
    Ao.R[Ao.R.Ji] = "MICROTASK_NOT_SUPPORTED";
    var Bo = {},
        Co = (Bo[K.m.ei] = Ao.R.Zj, Bo[K.m.vd] = Ao.R.Qi, Bo[K.m.Oc] = Ao.R.Qi, Bo[K.m.Ia] = Ao.R.Vj, Bo[K.m.qe] = Ao.R.tk, Bo[K.m.hf] = Ao.R.Wj, Bo[K.m.Ac] = Ao.R.ed, Bo[K.m.Xa] = Ao.R.ed, Bo[K.m.wb] = Ao.R.ed, Bo[K.m.ld] = Ao.R.ed, Bo[K.m.Wb] = Ao.R.ed, Bo[K.m.Fb] = Ao.R.ed, Bo[K.m.xb] = Ao.R.sk, Bo[K.m.Xb] = Ao.R.zm, Bo[K.m.Og] = Ao.R.Xj, Bo[K.m.Ub] = Ao.R.Yj, Bo),
        Do = {},
        Eo = (Do.unknown = Ao.R.Ml, Do.standard = Ao.R.Jl, Do.unique = Ao.R.Ll, Do.per_session = Ao.R.Il, Do.transactions = Ao.R.Kl, Do.items_sold = Ao.R.Hl, Do);
    var ob = [];

    function Fo(a, b) {
        b = b === void 0 ? !1 : b;
        kb("GTAG_EVENT_FEATURE_CHANNEL", a);
        b && (ob[a] = !0)
    }

    function Go(a, b) {
        b = b === void 0 ? !1 : b;
        for (var c = Object.keys(a), d = m(Object.keys(Co)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) && Fo(Co[f], b)
        }
    };
    var Ho = function(a, b, c, d, e, f, g, h, l, n, p) {
            this.eventId = a;
            this.priorityId = b;
            this.C = c;
            this.V = d;
            this.H = e;
            this.T = f;
            this.P = g;
            this.eventMetadata = h;
            this.onSuccess = l;
            this.onFailure = n;
            this.isGtmEvent = p
        },
        Io = function(a, b) {
            var c = [];
            switch (b) {
                case 3:
                    c.push(a.C);
                    c.push(a.V);
                    c.push(a.H);
                    c.push(a.T);
                    c.push(a.P);
                    break;
                case 2:
                    c.push(a.C);
                    break;
                case 1:
                    c.push(a.V);
                    c.push(a.H);
                    c.push(a.T);
                    c.push(a.P);
                    break;
                case 4:
                    c.push(a.C), c.push(a.V), c.push(a.H), c.push(a.T)
            }
            return c
        },
        L = function(a, b, c, d) {
            for (var e = m(Io(a, d === void 0 ? 3 :
                    d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                if (g[b] !== void 0) return g[b]
            }
            return c
        },
        Jo = function(a) {
            for (var b = {}, c = Io(a, 4), d = m(c), e = d.next(); !e.done; e = d.next())
                for (var f = Object.keys(e.value), g = m(f), h = g.next(); !h.done; h = g.next()) b[h.value] = 1;
            return Object.keys(b)
        };
    Ho.prototype.getMergedValues = function(a, b, c) {
        function d(n) {
            sd(n) && zb(n, function(p, q) {
                f = !0;
                e[p] = q
            })
        }
        b = b === void 0 ? 3 : b;
        var e = {},
            f = !1;
        c && d(c);
        var g = Io(this, b);
        g.reverse();
        for (var h = m(g), l = h.next(); !l.done; l = h.next()) d(l.value[a]);
        return f ? e : void 0
    };
    var Ko = function(a) {
            for (var b = [K.m.vf, K.m.qf, K.m.rf, K.m.tf, K.m.uf, K.m.wf, K.m.xf], c = Io(a, 3), d = m(c), e = d.next(); !e.done; e = d.next()) {
                for (var f = e.value, g = {}, h = !1, l = m(b), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    f[p] !== void 0 && (g[p] = f[p], h = !0)
                }
                var q = h ? g : void 0;
                if (q) return q
            }
            return {}
        },
        Lo = function(a, b) {
            this.eventId = a;
            this.priorityId = b;
            this.H = {};
            this.V = {};
            this.C = {};
            this.P = {};
            this.la = {};
            this.T = {};
            this.eventMetadata = {};
            this.isGtmEvent = !1;
            this.onSuccess = function() {};
            this.onFailure = function() {}
        },
        Mo = function(a,
            b) {
            a.H = b;
            return a
        },
        No = function(a, b) {
            a.V = b;
            return a
        },
        Oo = function(a, b) {
            a.C = b;
            return a
        },
        Po = function(a, b) {
            a.P = b;
            return a
        },
        Qo = function(a, b) {
            a.la = b;
            return a
        },
        Ro = function(a, b) {
            a.T = b;
            return a
        },
        So = function(a, b) {
            a.eventMetadata = b || {};
            return a
        },
        dp = function(a, b) {
            a.onSuccess = b;
            return a
        },
        ep = function(a, b) {
            a.onFailure = b;
            return a
        },
        fp = function(a, b) {
            a.isGtmEvent = b;
            return a
        },
        gp = function(a) {
            return new Ho(a.eventId, a.priorityId, a.H, a.V, a.C, a.P, a.T, a.eventMetadata, a.onSuccess, a.onFailure, a.isGtmEvent)
        };
    var Q = {
        A: {
            Vh: "accept_by_default",
            Sj: "add_tag_timing",
            Zd: "ads_event_page_view",
            bd: "allow_ad_personalization",
            bk: "batch_on_navigation",
            gk: "client_id_source",
            Ye: "consent_event_id",
            Ze: "consent_priority_id",
            Cs: "consent_state",
            ia: "consent_updated",
            be: "conversion_linker_enabled",
            Fa: "cookie_options",
            Kg: "create_dc_join",
            Lg: "create_fpm_geo_join",
            Mg: "create_fpm_signals_join",
            ce: "create_google_join",
            wk: "dc_random",
            de: "em_event",
            Fs: "endpoint_for_debug",
            Ak: "enhanced_client_id_source",
            bi: "enhanced_match_result",
            Bl: "euid_logged_in_state",
            Be: "euid_mode_enabled",
            mb: "event_start_timestamp_ms",
            Fl: "event_usage",
            zi: "extra_tag_experiment_ids",
            Qs: "add_parameter",
            Ai: "attribution_reporting_experiment",
            Bi: "counting_method",
            ph: "send_as_iframe",
            Rs: "parameter_order",
            qh: "parsed_target",
            xp: "ga4_collection_subdomain",
            Ul: "gbraid_cookie_marked",
            eb: "handle_internally",
            ba: "hit_type",
            Cd: "hit_type_override",
            Vf: "ignore_hit_success_failure",
            Us: "is_config_command",
            th: "is_consent_update",
            Wf: "is_conversion",
            am: "is_ecommerce",
            bm: "is_ec_cm_split",
            Dd: "is_external_event",
            Fi: "is_fallback_aw_conversion_ping_allowed",
            Xf: "is_first_visit",
            dm: "is_first_visit_conversion",
            uh: "is_fl_fallback_conversion_flow_allowed",
            Ed: "is_fpm_encryption",
            Gi: "is_fpm_split",
            Kb: "is_gcp_conversion",
            fm: "is_google_signals_allowed",
            Fd: "is_merchant_center",
            wh: "is_new_to_site",
            xh: "is_personalization",
            yh: "is_server_side_destination",
            Ee: "is_session_start",
            hm: "is_session_start_conversion",
            Vs: "is_sgtm_ga_ads_conversion_study_control_group",
            Ws: "is_sgtm_prehit",
            im: "is_sgtm_service_worker",
            Hi: "is_split_conversion",
            Gp: "is_syn",
            Hp: "is_test_event",
            Yf: "join_id",
            Ii: "join_elapsed",
            Zf: "join_timer_sec",
            lm: "local_storage_aw_conversion_counters",
            Ie: "tunnel_updated",
            bt: "prehit_for_retry",
            et: "promises",
            ft: "record_aw_latency",
            Tc: "redact_ads_data",
            Je: "redact_click_ids",
            ym: "remarketing_only",
            Oi: "send_ccm_parallel_ping",
            it: "send_ccm_parallel_test_ping",
            fg: "send_to_destinations",
            Pi: "send_to_targets",
            Up: "send_user_data_hit",
            Pa: "source_canonical_id",
            wa: "speculative",
            Hm: "speculative_in_message",
            Jm: "suppress_script_load",
            Km: "syn_or_mod",
            Pm: "transient_ecsid",
            gg: "transmission_type",
            Ua: "user_data",
            mt: "user_data_from_automatic",
            nt: "user_data_from_automatic_getter",
            Rm: "user_data_from_code",
            aq: "user_data_from_manual",
            Sm: "user_data_mode",
            hg: "user_id_updated"
        }
    };
    var hp = new yb,
        ip = {},
        jp = {},
        mp = {
            name: D(19),
            set: function(a, b) {
                td(Ob(a, b), ip);
                kp()
            },
            get: function(a) {
                return lp(a, 2)
            },
            reset: function() {
                hp = new yb;
                ip = {};
                kp()
            }
        };

    function lp(a, b) {
        return b != 2 ? hp.get(a) : np(a)
    }

    function np(a, b) {
        var c = a.split(".");
        b = b || [];
        for (var d = ip, e = 0; e < c.length; e++) {
            if (d === null) return !1;
            if (d === void 0) break;
            d = d[c[e]];
            if (b.indexOf(d) !== -1) return
        }
        return d
    }

    function op(a, b) {
        jp.hasOwnProperty(a) || (hp.set(a, b), td(Ob(a, b), ip), kp())
    }

    function pp() {
        for (var a = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], b = 0; b < a.length; b++) {
            var c = a[b],
                d = lp(c, 1);
            if (Array.isArray(d) || sd(d)) d = td(d, null);
            jp[c] = d
        }
    }

    function kp(a) {
        zb(jp, function(b, c) {
            hp.set(b, c);
            td(Ob(b), ip);
            td(Ob(b, c), ip);
            a && delete jp[b]
        })
    }

    function qp(a, b) {
        var c, d = (b === void 0 ? 2 : b) !== 1 ? np(a) : hp.get(a);
        qd(d) === "array" || qd(d) === "object" ? c = td(d, null) : c = d;
        return c
    };
    var rp = {
        UA: 1,
        AW: 2,
        DC: 3,
        G: 4,
        GF: 5,
        GT: 12,
        GTM: 14,
        HA: 6,
        MC: 7
    };

    function sp(a) {
        a = a === void 0 ? {} : a;
        var b = D(5).split("-")[0].toUpperCase(),
            c, d = {
                ctid: D(5),
                Bn: lg(15),
                Gn: D(14),
                zr: kg(7) ? 2 : 1,
                ks: a.In,
                canonicalId: D(6),
                Ur: (c = Uj()) == null ? void 0 : c.canonicalContainerId,
                ls: a.Wd === void 0 ? void 0 : a.Wd ? 10 : 12
            };
        d.canonicalId !== a.Ra && (d.Ra = a.Ra);
        var e = Rj();
        d.Gr = e ? e.canonicalContainerId : void 0;
        Zi ? (d.Th = rp[b], d.Th || (d.Th = 0)) : d.Th = $i ? 13 : 10;
        kg(47) ? (d.yj = 0, d.qq = 2) : kg(50) ? d.yj = 1 : d.yj = 3;
        var f = a,
            g = {
                6: !1
            };
        lg(54) === 2 ? g[7] = !0 : lg(54) === 1 && (g[2] = !0);
        if (Ec) {
            var h = jj(pj(Ec), "host");
            h && (g[8] = h.match(/^(www\.)?googletagmanager\.com$/) ===
                null)
        }
        if (P(417)) {
            var l;
            g[9] = (l = f.mc) != null ? l : !1
        }
        if (P(420)) {
            var n = Zj(),
                p;
            g[10] = (p = n == null ? void 0 : n.fromContainerExecution) != null ? p : !1
        }
        d.xq = g;
        return pf(d, a.Gh)
    };
    var tp = {
            Pn: pg(3, 0)
        },
        up = [],
        vp = !1;

    function wp(a) {
        up.push(a)
    }
    var xp = void 0,
        yp = {},
        zp = void 0,
        Ap = new function() {
            var a = 5;
            tp.Pn > 0 && (a = tp.Pn);
            this.H = a;
            this.C = 0;
            this.P = []
        },
        Bp = 1E3;

    function Cp(a, b) {
        var c = xp;
        if (c === void 0)
            if (b) c = fo();
            else return "";
        for (var d = [Aj("https://" + D(21)), "/a", "?id=" + D(5)], e = m(up), f = e.next(); !f.done; f = e.next())
            for (var g = f.value, h = g({
                    eventId: c,
                    Yd: !!a
                }), l = m(h), n = l.next(); !n.done; n = l.next()) {
                var p = m(n.value),
                    q = p.next().value,
                    r = p.next().value;
                d.push("&" + q + "=" + r)
            }
        d.push("&z=0");
        return d.join("")
    }

    function Dp() {
        if (Ri.H && (zp && (w.clearTimeout(zp), zp = void 0), xp !== void 0 && Ep)) {
            var a = fm(Gl.aa.Qc);
            if (bm(a)) vp || (vp = !0, dm(a, Dp));
            else {
                var b;
                if (!(b = yp[xp])) {
                    var c = Ap;
                    b = c.C < c.H ? !1 : Gb() - c.P[c.C % c.H] < 1E3
                }
                if (b || Bp-- <= 0) M(1), yp[xp] = !0;
                else {
                    var d = Ap,
                        e = d.C++ % d.H;
                    d.P[e] = Gb();
                    var f = Cp(!0);
                    Al({
                        destinationId: D(5),
                        endpoint: 56,
                        eventId: xp
                    }, f);
                    vp = Ep = !1
                }
            }
        }
    }

    function Fp() {
        if (Lk && Ri.H) {
            var a = Cp(!0, !0);
            Al({
                destinationId: D(5),
                endpoint: 56,
                eventId: xp
            }, a)
        }
    }
    var Ep = !1;

    function Gp(a) {
        yp[a] || (a !== xp && (Dp(), xp = a), Ep = !0, zp || (zp = w.setTimeout(Dp, 500)), Cp().length >= 2022 && Dp())
    }
    var Hp = wb();

    function Ip() {
        Hp = wb()
    }

    function Jp() {
        var a = [
                ["v", "3"],
                ["t", "t"],
                ["pid", String(Hp)]
            ],
            b = sp();
        b && a.push(["gtm", b]);
        return a
    };
    var Kp = {};

    function Lp(a, b, c) {
        Lk && a !== void 0 && (Kp[a] = Kp[a] || [], Kp[a].push(c + b), Gp(a))
    }

    function Mp(a) {
        var b = a.eventId,
            c = a.Yd,
            d = [],
            e = Kp[b] || [];
        e.length && d.push(["epr", e.join(".")]);
        c && delete Kp[b];
        return d
    };
    var Np = !1;

    function Op(a, b, c, d) {
        var e = lo(c, d.isGtmEvent);
        e && (Np && (d.deferrable = !0), Pp.push("event", [b, a], e, d))
    }

    function Qp(a, b, c, d) {
        var e = lo(c, d.isGtmEvent);
        e && Pp.push("get", [a, b], e, d)
    }

    function Rp(a) {
        var b = lo(a, !0),
            c;
        b ? c = Sp(Pp, b).T : c = {};
        return c
    }
    var Tp = function() {
            this.C = {};
            this.T = {};
            this.V = {};
            this.la = null;
            this.P = {};
            this.H = !1;
            this.status = 1
        },
        Up = function(a, b, c, d) {
            this.H = Gb();
            this.C = b;
            this.args = c;
            this.messageContext = d;
            this.type = a
        };

    function Vp(a) {
        var b = {};
        zb(a, function(c, d) {
            td(Ob(c, d), b)
        });
        return b
    }
    var Wp = function() {
            this.destinations = {};
            this.C = {};
            this.commands = []
        },
        Sp = function(a, b) {
            return a.destinations[b.destinationId] = a.destinations[b.destinationId] || new Tp
        },
        Xp = function(a, b, c, d) {
            if (d.C) {
                var e = Sp(a, d.C),
                    f = e.la;
                if (f) {
                    var g = td(c, null),
                        h = td(e.C[d.C.destinationId], null),
                        l = td(e.P, null),
                        n = td(e.T, null),
                        p = td(a.C, null),
                        q = {};
                    if (Lk) try {
                        q = td(ip, null)
                    } catch (x) {
                        M(72)
                    }
                    var r = d.C.prefix,
                        u = function(x) {
                            Lp(d.messageContext.eventId, r, x)
                        },
                        t = gp(fp(ep(dp(So(Qo(Po(Ro(Oo(No(Mo(new Lo(d.messageContext.eventId, d.messageContext.priorityId),
                            g), h), l), n), p), q), d.messageContext.eventMetadata), function() {
                            if (u) {
                                var x = u;
                                u = void 0;
                                x("2");
                                if (d.messageContext.onSuccess) d.messageContext.onSuccess()
                            }
                        }), function() {
                            if (u) {
                                var x = u;
                                u = void 0;
                                x("3");
                                if (d.messageContext.onFailure) d.messageContext.onFailure()
                            }
                        }), !!d.messageContext.isGtmEvent)),
                        v = function() {
                            try {
                                Lp(d.messageContext.eventId, r, "1");
                                var x = d.type,
                                    y = d.C.id;
                                if (Nk && x === "config") {
                                    var A, C = (A = lo(y)) == null ? void 0 : A.ids;
                                    if (!(C && C.length > 1)) {
                                        var E, H = Fc("google_tag_data", {});
                                        H.td || (H.td = {});
                                        E = H.td;
                                        var J =
                                            td(t.T);
                                        td(t.C, J);
                                        var O = [],
                                            ba;
                                        for (ba in E) E.hasOwnProperty(ba) && yo(E[ba], J).length && O.push(ba);
                                        O.length && (wo(y, O), kb("TAGGING", so[z.readyState] || 14));
                                        E[y] = J
                                    }
                                }
                                f(d.C.id, b, d.H, t)
                            } catch (W) {
                                Lp(d.messageContext.eventId, r, "4")
                            }
                        };
                    b === "gtag.get" ? v() : dm(e.sa, v)
                }
            }
        },
        Yp = function(a, b) {
            if (b.type !== "require")
                if (b.C)
                    for (var c = Sp(a, b.C).V[b.type] || [], d = 0; d < c.length; d++) c[d]();
                else
                    for (var e in a.destinations)
                        if (a.destinations.hasOwnProperty(e)) {
                            var f = a.destinations[e];
                            if (f && f.V)
                                for (var g = f.V[b.type] || [], h = 0; h < g.length; h++) g[h]()
                        }
        };
    Wp.prototype.register = function(a, b, c, d) {
        var e = Sp(this, a);
        e.status !== 3 && (e.la = b, e.status = 3, e.sa = fm(c), Zp(this, a, d || {}), this.flush())
    };
    Wp.prototype.push = function(a, b, c, d) {
        c !== void 0 && (Sp(this, c).status === 1 && (Sp(this, c).status = 2, this.push("require", [{}], c, {})), Sp(this, c).H && (d.deferrable = !1), d.eventMetadata || (d.eventMetadata = {}), d.eventMetadata[Q.A.fg] || (d.eventMetadata[Q.A.fg] = [c.destinationId]), d.eventMetadata[Q.A.Pi] || (d.eventMetadata[Q.A.Pi] = [c.id]));
        this.commands.push(new Up(a, c, b, d));
        d.deferrable || this.flush()
    };
    Wp.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1; this.commands.length;) {
            var e = this.commands[0],
                f = e.C;
            if (e.messageContext.deferrable) !f || Sp(this, f).H ? (e.messageContext.deferrable = !1, this.commands.push(e)) : c.push(e), this.commands.shift();
            else {
                switch (e.type) {
                    case "require":
                        if (Sp(this, f).status !== 3 && !a) {
                            this.commands.push.apply(this.commands, c);
                            return
                        }
                        break;
                    case "set":
                        var g = e.args[0];
                        zb(g, function(A, C) {
                            td(Ob(A, C), b.C)
                        });
                        Go(g, !0);
                        break;
                    case "config":
                        var h = Sp(this, f),
                            l = Vp(e.args[0]),
                            n = !!l[K.m.xd];
                        delete l[K.m.xd];
                        var p = f.destinationId === f.id;
                        Go(l, !0);
                        n || (p ? h.P = {} : h.C[f.id] = {});
                        h.H && n || Xp(this, K.m.ma, l, e);
                        h.H = !0;
                        p ? td(l, h.P) : (td(l, h.C[f.id]), M(70));
                        d = !0;
                        break;
                    case "event":
                        var q = Vp(e.args[0]);
                        Go(q);
                        Xp(this, e.args[1], q, e);
                        break;
                    case "get":
                        var r = {},
                            u = (r[K.m.Df] = e.args[0], r[K.m.Cf] = e.args[1], r);
                        Xp(this, K.m.Db, u, e);
                        break;
                    case "container_config":
                        var t = Sp(this, f),
                            v = Vp(e.args[0]);
                        Go(v, !0);
                        t.H = !0;
                        t.P = v;
                        d = !0;
                        break;
                    case "destination_config":
                        var x = Sp(this, f),
                            y = Vp(e.args[0]);
                        Go(y, !0);
                        x.C[f.id] || (x.C[f.id] = {});
                        x.H = !0;
                        x.C[f.id] = y;
                        d = !0;
                        break;
                    case "reset_container_config":
                        Sp(this, f).P = {};
                        break;
                    case "reset_target_config":
                        Sp(this, f).C[f.id] = {}
                }
                this.commands.shift();
                Yp(this, e)
            }
        }
        this.commands.push.apply(this.commands, c);
        d && this.flush()
    };
    var Zp = function(a, b, c) {
            var d = td(c, null);
            td(Sp(a, b).T, d);
            Sp(a, b).T = d
        },
        Pp = new Wp;

    function $p(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            xr: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        var e = a.location.ancestorOrigins;
        if (e) {
            var f = e[e.length - 1],
                g;
            f && ((g = b) == null ? void 0 : g.indexOf(f)) === -1 && (c = !1, b = f)
        }
        return {
            url: b,
            xr: c
        }
    }

    function aq(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    ll(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function bq() {
        for (var a = w, b = a; a && a != a.parent;) a = a.parent, aq(a) && (b = a);
        return b
    };
    var cq = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        dq = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };

    function eq(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    var fq = function(a, b) {
            for (var c = a, d = 0; d < 50; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (h) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (h) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        gq = function(a) {
            var b = w;
            if (b.top == b) return 0;
            if (a === void 0 ? 0 : a) {
                var c = b.location.ancestorOrigins;
                if (c) return c[c.length - 1] == b.location.origin ? 1 : 2
            }
            return aq(b.top) ? 1 : 2
        },
        hq = function(a) {
            a = a === void 0 ? document : a;
            return a.createElement("img")
        };

    function iq(a, b, c) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, !1), !0) : !1
    }

    function jq(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function kq(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = hq(a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = yc(g, e);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                jq(e, "load", f);
                jq(e, "error", f)
            };
            iq(e, "load", f);
            iq(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function lq(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
        eq(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        mq(c, b)
    }

    function mq(a, b) {
        var c = window,
            d;
        b = b === void 0 ? !1 : b;
        d = d === void 0 ? !1 : d;
        if (c.fetch) {
            var e = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            };
            d && (e.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? e.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : e.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            });
            c.fetch(a, e)
        } else kq(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };
    var nq = function() {
        this.la = this.la;
        this.T = this.T
    };
    nq.prototype.la = !1;
    nq.prototype.dispose = function() {
        this.la || (this.la = !0, this.P())
    };
    nq.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    nq.prototype.addOnDisposeCallback = function(a, b) {
        this.la ? b !== void 0 ? a.call(b) : a() : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a))
    };
    nq.prototype.P = function() {
        if (this.T)
            for (; this.T.length;) this.T.shift()()
    };

    function oq(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }
    var pq = function(a, b) {
        b = b === void 0 ? {} : b;
        nq.call(this);
        this.C = null;
        this.sa = {};
        this.Rc = 0;
        this.V = null;
        this.H = a;
        var c;
        this.yb = (c = b.timeoutMs) != null ? c : 500;
        var d;
        this.nb = (d = b.wt) != null ? d : !1
    };
    wa(pq, nq);
    pq.prototype.P = function() {
        this.sa = {};
        this.V && (jq(this.H, "message", this.V), delete this.V);
        delete this.sa;
        delete this.H;
        delete this.C;
        nq.prototype.P.call(this)
    };
    var rq = function(a) {
        return typeof a.H.__tcfapi === "function" || qq(a) != null
    };
    pq.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.nb
            },
            d = dq(function() {
                return a(c)
            }),
            e = 0;
        this.yb !== -1 && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.yb));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = oq(c), c.internalBlockOnErrors = b.nb, h && c.internalErrorState === 0 || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            sq(this, "addEventListener", f)
        } catch (g) {
            c.tcString =
                "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    pq.prototype.removeEventListener = function(a) {
        a && a.listenerId && sq(this, "removeEventListener", null, a.listenerId)
    };
    var uq = function(a, b, c) {
            var d;
            d = d === void 0 ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (f !== void 0) {
                        e = f[d === void 0 ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (g === 0) return !1;
            var h = c;
            c === 2 ? (h = 0, g === 2 && (h = 1)) : c === 3 && (h = 1, g === 1 && (h = 0));
            var l;
            if (h === 0)
                if (a.purpose && a.vendor) {
                    var n = tq(a.vendor.consents, d === void 0 ? "755" : d);
                    l = n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : n && tq(a.purpose.consents, b)
                } else l = !0;
            else l = h === 1 ? a.purpose && a.vendor ? tq(a.purpose.legitimateInterests,
                b) && tq(a.vendor.legitimateInterests, d === void 0 ? "755" : d) : !0 : !0;
            return l
        },
        tq = function(a, b) {
            return !(!a || !a[b])
        },
        sq = function(a, b, c, d) {
            c || (c = function() {});
            var e = a.H;
            if (typeof e.__tcfapi === "function") {
                var f = e.__tcfapi;
                f(b, 2, c, d)
            } else if (qq(a)) {
                vq(a);
                var g = ++a.Rc;
                a.sa[g] = c;
                if (a.C) {
                    var h = {};
                    a.C.postMessage((h.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: g,
                        parameter: d
                    }, h), "*")
                }
            } else c({}, !1)
        },
        qq = function(a) {
            if (a.C) return a.C;
            a.C = fq(a.H, "__tcfapiLocator");
            return a.C
        },
        vq = function(a) {
            if (!a.V) {
                var b = function(c) {
                    try {
                        var d;
                        d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                        a.sa[d.callId](d.returnValue, d.success)
                    } catch (e) {}
                };
                a.V = b;
                iq(a.H, "message", b)
            }
        },
        wq = function(a) {
            if (a.gdprApplies === !1) return !0;
            a.internalErrorState === void 0 && (a.internalErrorState = oq(a));
            return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (lq({
                e: String(a.internalErrorState)
            }), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
        };
    var xq = {
        1: 0,
        3: 0,
        4: 0,
        7: 3,
        9: 3,
        10: 3
    };
    pg(32, 500);

    function yq() {
        return $n("tcf", function() {
            return {}
        })
    }
    var zq = function() {
        return new pq(w, {
            timeoutMs: -1
        })
    };

    function Aq() {
        var a = yq(),
            b = zq();
        rq(b) && !Bq() && !Cq() && M(124);
        if (!a.active && rq(b)) {
            Bq() && (a.active = !0, a.purposes = {}, a.cmpId = 0, a.tcfPolicyVersion = 0, Hl().active = !0, a.tcString = "tcunavailable");
            Vn();
            try {
                b.addEventListener(function(c) {
                    if (c.internalErrorState !== 0) Dq(a), Wn([K.m.W, K.m.Na, K.m.X]), Hl().active = !0;
                    else if (a.gdprApplies = c.gdprApplies, a.cmpId = c.cmpId, a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode, Cq() && (a.active = !0), !Eq(c) || Bq() || Cq()) {
                        a.tcfPolicyVersion = c.tcfPolicyVersion;
                        var d;
                        if (c.gdprApplies ===
                            !1) {
                            var e = {},
                                f;
                            for (f in xq) xq.hasOwnProperty(f) && (e[f] = !0);
                            d = e;
                            b.removeEventListener(c)
                        } else if (Eq(c)) {
                            var g = {},
                                h;
                            for (h in xq)
                                if (xq.hasOwnProperty(h))
                                    if (h === "1") {
                                        var l, n = c,
                                            p = {
                                                Rq: !0
                                            };
                                        p = p === void 0 ? {} : p;
                                        l = wq(n) ? n.gdprApplies === !1 ? !0 : n.tcString === "tcunavailable" ? !p.idpcApplies : (p.idpcApplies || n.gdprApplies !== void 0 || p.Rq) && (p.idpcApplies || typeof n.tcString === "string" && n.tcString.length) ? uq(n, "1", 0) : !0 : !1;
                                        g["1"] = l
                                    } else g[h] = uq(c, h, xq[h]);
                            d = g
                        }
                        if (d) {
                            a.tcString = c.tcString || "tcempty";
                            a.purposes = d;
                            var q = {},
                                r = (q[K.m.W] = a.purposes["1"] ? "granted" : "denied", q);
                            a.gdprApplies !== !0 ? (Wn([K.m.W, K.m.Na, K.m.X]), Hl().active = !0) : (r[K.m.Na] = a.purposes["3"] && a.purposes["4"] ? "granted" : "denied", typeof a.tcfPolicyVersion === "number" && a.tcfPolicyVersion >= 4 ? r[K.m.X] = a.purposes["1"] && a.purposes["7"] ? "granted" : "denied" : Wn([K.m.X]), Pn(r, {
                                eventId: 0
                            }, {
                                gdprApplies: a ? a.gdprApplies : void 0,
                                tcString: Fq() || ""
                            }))
                        }
                    } else Wn([K.m.W, K.m.Na, K.m.X])
                })
            } catch (c) {
                Dq(a), Wn([K.m.W, K.m.Na, K.m.X]), Hl().active = !0
            }
        }
    }

    function Dq(a) {
        a.type = "e";
        a.tcString = "tcunavailable"
    }

    function Eq(a) {
        return a.eventStatus === "tcloaded" || a.eventStatus === "useractioncomplete" || a.eventStatus === "cmpuishown"
    }

    function Bq() {
        return w.gtag_enable_tcf_support === !0
    }

    function Cq() {
        return yq().enableAdvertiserConsentMode === !0
    }

    function Fq() {
        var a = yq();
        if (a.active) return a.tcString
    }

    function Gq() {
        var a = yq();
        if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0"
    }

    function Hq(a) {
        if (!xq.hasOwnProperty(String(a))) return !0;
        var b = yq();
        return b.active && b.purposes ? !!b.purposes[String(a)] : !0
    };
    var Iq = [K.m.W, K.m.ja, K.m.X, K.m.Na],
        Jq = {},
        Kq = (Jq[K.m.W] = 1, Jq[K.m.ja] = 2, Jq);

    function Lq(a) {
        if (a === void 0) return 0;
        switch (L(a, K.m.Tb)) {
            case void 0:
                return 1;
            case !1:
                return 3;
            default:
                return 2
        }
    }

    function Mq() {
        return (P(183) ? ng(16).split("~") : ng(17).split("~")).indexOf(Pm()) !== -1 && Bc.globalPrivacyControl === !0
    }

    function Nq(a) {
        if (Mq()) return !1;
        var b = Lq(a);
        if (b === 3) return !1;
        switch (Ql(K.m.Na)) {
            case 1:
            case 3:
                return !0;
            case 2:
                return !1;
            case 4:
                return b === 2;
            case 0:
                return !0;
            default:
                return !1
        }
    }

    function Oq() {
        return Sl() || !Pl(K.m.W) || !Pl(K.m.ja)
    }

    function Pq() {
        var a = {},
            b;
        for (b in Kq) Kq.hasOwnProperty(b) && (a[Kq[b]] = Ql(b));
        return "G1" + mf(a[1] || 0) + mf(a[2] || 0)
    }
    var Qq = {},
        Rq = (Qq[K.m.W] = 0, Qq[K.m.ja] = 1, Qq[K.m.X] = 2, Qq[K.m.Na] = 3, Qq);

    function Sq(a) {
        switch (a) {
            case void 0:
                return 1;
            case !0:
                return 3;
            case !1:
                return 2;
            default:
                return 0
        }
    }

    function Tq(a) {
        for (var b = "1", c = 0; c < Iq.length; c++) {
            var d = b,
                e, f = Iq[c],
                g = Ol.delegatedConsentTypes[f];
            e = g === void 0 ? 0 : Rq.hasOwnProperty(g) ? 12 | Rq[g] : 8;
            var h = Hl();
            h.accessedAny = !0;
            var l = h.entries[f] || {};
            e = e << 2 | Sq(l.implicit);
            b = d + ("" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [Sq(l.declare) << 4 | Sq(l.default) << 2 | Sq(l.update)])
        }
        var n = b,
            p = (Mq() ? 1 : 0) << 3,
            q = (Sl() ? 1 : 0) << 2,
            r = Lq(a);
        b = n + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [p |
            q | r
        ];
        return b += "" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [Ol.containerScopedDefaults.ad_storage << 4 | Ol.containerScopedDefaults.analytics_storage << 2 | Ol.containerScopedDefaults.ad_user_data] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [(Ol.usedContainerScopedDefaults ? 1 : 0) << 2 | Ol.containerScopedDefaults.ad_personalization]
    }

    function Uq() {
        if (!Pl(K.m.X)) return "-";
        if (P(170)) return "a";
        for (var a = Object.keys(gn), b = {}, c = m(a), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            b[e] = Ol.corePlatformServices[e] !== !1
        }
        for (var f = "", g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            b[l] && (f += gn[l])
        }(Ol.usedCorePlatformServices ? Ol.selectedAllCorePlatformServices : 1) && (f += "o");
        return f || "-"
    }

    function Vq() {
        return Rm() || (Bq() || Cq()) && Gq() === "1" ? "1" : "0"
    }

    function Wq() {
        return (Rm() ? !0 : !(!Bq() && !Cq()) && Gq() === "1") || !Pl(K.m.X)
    }

    function Xq() {
        var a = "0",
            b = "0",
            c;
        var d = yq();
        c = d.active ? d.cmpId : void 0;
        typeof c === "number" && c >= 0 && c <= 4095 && (a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c >> 6 & 63], b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c & 63]);
        var e = "0",
            f;
        var g = yq();
        f = g.active ? g.tcfPolicyVersion : void 0;
        typeof f === "number" && f >= 0 && f <= 63 && (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f]);
        var h = 0;
        Rm() && (h |= 1);
        Gq() === "1" && (h |= 2);
        Bq() && (h |= 4);
        var l;
        var n = yq();
        l = n.enableAdvertiserConsentMode !==
            void 0 ? n.enableAdvertiserConsentMode ? "1" : "0" : void 0;
        l === "1" && (h |= 8);
        Hl().waitPeriodTimedOut && (h |= 16);
        return "1" + a + b + e + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [h]
    }

    function Yq() {
        return Pm() === "US-CO"
    };

    function Zq(a, b, c, d) {
        var e, f = Number(a.Xc != null ? a.Xc : void 0);
        f !== 0 && (e = new Date((b || Gb()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            yc: d
        }
    };
    var $q = ["ad_storage", "ad_user_data"];

    function ar(a, b) {
        if (!a) return kb("TAGGING", 32), 10;
        if (b === null || b === void 0 || b === "") return kb("TAGGING", 33), 11;
        var c = br(!1);
        if (c.error !== 0) return kb("TAGGING", 34), c.error;
        if (!c.value) return kb("TAGGING", 35), 2;
        c.value[a] = b;
        var d = cr(c);
        d !== 0 && kb("TAGGING", 36);
        return d
    }

    function dr(a) {
        if (!a) return kb("TAGGING", 27), {
            error: 10
        };
        var b = br();
        if (b.error !== 0) return kb("TAGGING", 29), b;
        if (!b.value) return kb("TAGGING", 30), {
            error: 2
        };
        if (!(a in b.value)) return kb("TAGGING", 31), {
            value: void 0,
            error: 15
        };
        var c = b.value[a];
        return c === null || c === void 0 || c === "" ? (kb("TAGGING", 28), {
            value: void 0,
            error: 11
        }) : {
            value: c,
            error: 0
        }
    }

    function br(a) {
        a = a === void 0 ? !0 : a;
        if (!Pl($q)) return kb("TAGGING", 43), {
            error: 3
        };
        try {
            if (!w.localStorage) return kb("TAGGING", 44), {
                error: 1
            }
        } catch (f) {
            return kb("TAGGING", 45), {
                error: 14
            }
        }
        var b = {
                schema: "gcl",
                version: 1
            },
            c = void 0;
        try {
            c = w.localStorage.getItem("_gcl_ls")
        } catch (f) {
            return kb("TAGGING", 46), {
                error: 13
            }
        }
        try {
            if (c) {
                var d = JSON.parse(c);
                if (d && typeof d === "object") b = d;
                else return kb("TAGGING", 47), {
                    error: 12
                }
            }
        } catch (f) {
            return kb("TAGGING", 48), {
                error: 8
            }
        }
        if (b.schema !== "gcl") return kb("TAGGING", 49), {
            error: 4
        };
        if (b.version !== 1) return kb("TAGGING", 50), {
            error: 5
        };
        try {
            var e = er(b);
            a && e && cr({
                value: b,
                error: 0
            })
        } catch (f) {
            return kb("TAGGING", 48), {
                error: 8
            }
        }
        return {
            value: b,
            error: 0
        }
    }

    function er(a) {
        if (!a || typeof a !== "object") return !1;
        if ("expires" in a && "value" in a) {
            var b;
            typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
            if (isNaN(b) || !(Date.now() <= b)) return a.value = null, a.error = 9, kb("TAGGING", 54), !0
        } else {
            for (var c = !1, d = m(Object.keys(a)), e = d.next(); !e.done; e = d.next()) c = er(a[e.value]) || c;
            return c
        }
        return !1
    }

    function cr(a) {
        if (a.error) return a.error;
        if (!a.value) return kb("TAGGING", 42), 2;
        var b = a.value,
            c;
        try {
            c = JSON.stringify(b)
        } catch (d) {
            return kb("TAGGING", 52), 6
        }
        try {
            w.localStorage.setItem("_gcl_ls", c)
        } catch (d) {
            return kb("TAGGING", 53), 7
        }
        return 0
    };
    var fr = {
            zg: "value",
            fb: "conversionCount",
            Ag: 1
        },
        gr = {
            Nh: 8,
            Sh: 9,
            zg: "timeouts",
            fb: "timeouts",
            Ag: 0
        },
        hr = {
            Nh: 10,
            Sh: 11,
            zg: "errors",
            fb: "errors",
            Ag: 0
        },
        ir = [fr, gr, hr, {
            Nh: 12,
            Sh: 13,
            zg: "eopCount",
            fb: "endOfPageCount",
            Ag: 0
        }];

    function jr(a) {
        var b;
        b = b === void 0 ? 1 : b;
        if (!kr(a)) return {};
        var c = lr(ir),
            d = c[a.fb];
        if (d === void 0 || d === -1) return c;
        var e = {},
            f = na(Object, "assign").call(Object, {}, c, (e[a.fb] = d + b, e));
        return mr(f) ? f : c
    }

    function lr(a) {
        var b;
        a: {
            var c = dr("gcl_ctr");
            if (c.error === 0 && c.value && typeof c.value === "object") {
                var d = c.value;
                try {
                    b = "value" in d && typeof d.value === "object" ? d.value : void 0;
                    break a
                } catch (p) {}
            }
            b = void 0
        }
        for (var e = b, f = {}, g = m(a), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            if (e && kr(l)) {
                var n = e[l.zg];
                n === void 0 || Number.isNaN(n) ? f[l.fb] = -1 : f[l.fb] = Number(n)
            } else f[l.fb] = -1
        }
        return f
    }

    function mr(a, b) {
        b = b || {};
        for (var c = Gb(), d = Zq(b, c, !0), e = {}, f = m(ir), g = f.next(); !g.done; g = f.next()) {
            var h = g.value,
                l = a[h.fb];
            l !== void 0 && l !== -1 && (e[h.zg] = l)
        }
        e.creationTimeMs = c;
        return ar("gcl_ctr", {
            value: e,
            expires: Number(d.expires)
        }) === 0 ? !0 : !1
    }

    function kr(a) {
        return Pl(["ad_storage", "ad_user_data"]) ? !a.Sh || Wa(a.Sh) : !1
    }

    function nr(a) {
        return Pl(["ad_storage", "ad_user_data"]) ? !a.Nh || Wa(a.Nh) : !1
    };
    var or = {
        O: {
            Tp: 0,
            Uj: 1,
            Jg: 2,
            jk: 3,
            Xh: 4,
            hk: 5,
            ik: 6,
            kk: 7,
            Yh: 8,
            Dl: 9,
            Cl: 10,
            yi: 11,
            El: 12,
            oh: 13,
            Nl: 14,
            dg: 15,
            Rp: 16,
            Ke: 17,
            Ui: 18,
            Vi: 19,
            Wi: 20,
            Mm: 21,
            Xi: 22,
            ai: 23,
            uk: 24
        }
    };
    or.O[or.O.Tp] = "RESERVED_ZERO";
    or.O[or.O.Uj] = "ADS_CONVERSION_HIT";
    or.O[or.O.Jg] = "CONTAINER_EXECUTE_START";
    or.O[or.O.jk] = "CONTAINER_SETUP_END";
    or.O[or.O.Xh] = "CONTAINER_SETUP_START";
    or.O[or.O.hk] = "CONTAINER_BLOCKING_END";
    or.O[or.O.ik] = "CONTAINER_EXECUTE_END";
    or.O[or.O.kk] = "CONTAINER_YIELD_END";
    or.O[or.O.Yh] = "CONTAINER_YIELD_START";
    or.O[or.O.Dl] = "EVENT_EXECUTE_END";
    or.O[or.O.Cl] = "EVENT_EVALUATION_END";
    or.O[or.O.yi] = "EVENT_EVALUATION_START";
    or.O[or.O.El] = "EVENT_SETUP_END";
    or.O[or.O.oh] = "EVENT_SETUP_START";
    or.O[or.O.Nl] = "GA4_CONVERSION_HIT";
    or.O[or.O.dg] = "PAGE_LOAD";
    or.O[or.O.Rp] = "PAGEVIEW";
    or.O[or.O.Ke] = "SNIPPET_LOAD";
    or.O[or.O.Ui] = "TAG_CALLBACK_ERROR";
    or.O[or.O.Vi] = "TAG_CALLBACK_FAILURE";
    or.O[or.O.Wi] = "TAG_CALLBACK_SUCCESS";
    or.O[or.O.Mm] = "TAG_EXECUTE_END";
    or.O[or.O.Xi] = "TAG_EXECUTE_START";
    or.O[or.O.ai] = "CUSTOM_PERFORMANCE_START";
    or.O[or.O.uk] = "CUSTOM_PERFORMANCE_END";
    var pr = [],
        qr = {},
        rr = {};

    function sr(a) {
        if (Wa(20) && pr.includes(a)) {
            var b;
            (b = hd()) == null || b.mark(a + "-" + or.O.ai + "-" + (rr[a] || 0))
        }
    }

    function tr(a) {
        if (Wa(20) && pr.includes(a)) {
            var b = a + "-" + or.O.uk + "-" + (rr[a] || 0),
                c = {
                    start: a + "-" + or.O.ai + "-" + (rr[a] || 0),
                    end: b
                },
                d;
            (d = hd()) == null || d.mark(b);
            var e, f, g = (f = (e = hd()) == null ? void 0 : e.measure(b, c)) == null ? void 0 : f.duration;
            g !== void 0 && (rr[a] = (rr[a] || 0) + 1, qr[a] = g + (qr[a] || 0))
        }
    };
    var ur = ["3", "4"];

    function vr(a) {
        return a.origin !== "null"
    };

    function wr(a, b, c, d) {
        try {
            sr("3");
            var e;
            return (e = xr(function(f) {
                return f === a
            }, b, c, d)[a]) != null ? e : []
        } finally {
            tr("3")
        }
    }

    function xr(a, b, c, d) {
        var e;
        if (yr(d)) {
            for (var f = {}, g = String(b || zr()).split(";"), h = 0; h < g.length; h++) {
                var l = g[h].split("="),
                    n = l[0].trim();
                if (n && a(n)) {
                    var p = l.slice(1).join("=").trim();
                    p && c && (p = decodeURIComponent(p));
                    var q = void 0,
                        r = void 0;
                    ((q = f)[r = n] || (q[r] = [])).push(p)
                }
            }
            e = f
        } else e = {};
        return e
    }

    function Ar(a, b, c, d, e) {
        if (yr(e)) {
            var f = Br(a, d, e);
            if (f.length === 1) return f[0];
            if (f.length !== 0) {
                f = Cr(f, function(g) {
                    return g.Hq
                }, b);
                if (f.length === 1) return f[0];
                f = Cr(f, function(g) {
                    return g.Ir
                }, c);
                return f[0]
            }
        }
    }

    function Dr(a, b, c, d) {
        var e = zr(),
            f = window;
        vr(f) && (f.document.cookie = a);
        var g = zr();
        return e !== g || c !== void 0 && wr(b, g, !1, d).indexOf(c) >= 0
    }

    function Er(a, b, c, d) {
        function e(x, y, A) {
            if (A == null) return delete h[y], x;
            h[y] = A;
            return x + "; " + y + "=" + A
        }

        function f(x, y) {
            if (y == null) return x;
            h[y] = !0;
            return x + "; " + y
        }
        if (!yr(c.yc)) return 2;
        var g;
        b == null ? g = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = Fr(b), g = a + "=" + b);
        var h = {};
        g = e(g, "path", c.path);
        var l;
        c.expires instanceof Date ? l = c.expires.toUTCString() : c.expires != null && (l = "" + c.expires);
        g = e(g, "expires", l);
        g = e(g, "max-age", c.Cr);
        g = e(g, "samesite", c.Wr);
        c.secure &&
            (g = f(g, "secure"));
        var n = c.domain;
        if (n && n.toLowerCase() === "auto") {
            for (var p = Gr(), q = void 0, r = !1, u = 0; u < p.length; ++u) {
                var t = p[u] !== "none" ? p[u] : void 0,
                    v = e(g, "domain", t);
                v = f(v, c.flags);
                try {
                    d && d(a, h)
                } catch (x) {
                    q = x;
                    continue
                }
                r = !0;
                if (!Hr(t, c.path) && Dr(v, a, b, c.yc)) return 0
            }
            if (q && !r) throw q;
            return 1
        }
        n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
        g = f(g, c.flags);
        d && d(a, h);
        return Hr(n, c.path) ? 1 : Dr(g, a, b, c.yc) ? 0 : 1
    }

    function Ir(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        sr("2");
        var d = Er(a, b, c);
        tr("2");
        return d
    }

    function Cr(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                l = b(h);
            l === c ? d.push(h) : f === void 0 || l < f ? (e = [h], f = l) : l === f && e.push(h)
        }
        return d.length > 0 ? d : e
    }

    function Br(a, b, c) {
        for (var d = [], e = wr(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                h = g.shift();
            if (!b || !h || b.indexOf(h) !== -1) {
                var l = g.shift();
                if (l) {
                    var n = l.split("-");
                    d.push({
                        zq: e[f],
                        Aq: g.join("."),
                        Hq: Number(n[0]) || 1,
                        Ir: Number(n[1]) || 1
                    })
                }
            }
        }
        return d
    }

    function Fr(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var Jr = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Kr = /(^|\.)doubleclick\.net$/i;

    function Hr(a, b) {
        return a !== void 0 && (Kr.test(window.document.location.hostname) || b === "/" && Jr.test(a))
    }

    function Lr(a) {
        if (!a) return 1;
        var b = a;
        Wa(5) && a === "none" && (b = window.document.location.hostname);
        b = b.indexOf(".") === 0 ? b.substring(1) : b;
        return b.split(".").length
    }

    function Mr(a) {
        if (!a || a === "/") return 1;
        a[0] !== "/" && (a = "/" + a);
        a[a.length - 1] !== "/" && (a += "/");
        return a.split("/").length - 1
    }

    function Nr(a, b) {
        var c = "" + Lr(a),
            d = Mr(b);
        d > 1 && (c += "-" + d);
        return c
    }
    var zr = function() {
            return vr(window) ? window.document.cookie : ""
        },
        yr = function(a) {
            return a && Wa(6) ? (Array.isArray(a) ? a : [a]).every(function(b) {
                return Rl(b) && Pl(b)
            }) : !0
        },
        Gr = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (b.length === 4) {
                var c = b[b.length - 1];
                if (Number(c).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Kr.test(e) || Jr.test(e) || a.push("none");
            return a
        };

    function Or(a) {
        var b = Math.round(Math.random() * 2147483647);
        return a ? String(b ^ bi(a) & 2147483647) : String(b)
    }

    function Pr(a) {
        return [Or(a), Math.round(Gb() / 1E3)].join(".")
    }

    function Qr(a, b, c, d, e) {
        var f = Lr(b),
            g;
        return (g = Ar(a, f, Mr(c), d, e)) == null ? void 0 : g.Aq
    };
    var Rr;

    function Sr() {
        function a(g) {
            c(g.target || g.srcElement || {})
        }

        function b(g) {
            d(g.target || g.srcElement || {})
        }
        var c = Tr,
            d = Ur,
            e = Vr();
        if (!e.init) {
            Sc(z, "mousedown", a);
            Sc(z, "keyup", a);
            Sc(z, "submit", b);
            var f = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                d(this);
                f.call(this)
            };
            e.init = !0
        }
    }

    function Wr(a, b, c, d, e) {
        var f = {
            callback: a,
            domains: b,
            fragment: c === 2,
            placement: c,
            forms: d,
            sameHost: e
        };
        Vr().decorators.push(f)
    }

    function Xr(a, b, c) {
        for (var d = Vr().decorators, e = {}, f = 0; f < d.length; ++f) {
            var g = d[f],
                h;
            if (h = !c || g.forms) a: {
                var l = g.domains,
                    n = a,
                    p = !!g.sameHost;
                if (l && (p || n !== z.location.hostname))
                    for (var q = 0; q < l.length; q++)
                        if (l[q] instanceof RegExp) {
                            if (l[q].test(n)) {
                                h = !0;
                                break a
                            }
                        } else if (n.indexOf(l[q]) >= 0 || p && l[q].indexOf(n) >= 0) {
                    h = !0;
                    break a
                }
                h = !1
            }
            if (h) {
                var r = g.placement;
                r === void 0 && (r = g.fragment ? 2 : 1);
                r === b && Jb(e, g.callback())
            }
        }
        return e
    }

    function Vr() {
        var a = Fc("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var Yr = /(.*?)\*(.*?)\*(.*)/,
        Zr = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        $r = /^(?:www\.|m\.|amp\.)+/,
        as = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function bs(a) {
        var b = as.exec(a);
        if (b) return {
            Fj: b[1],
            query: b[2],
            fragment: b[3]
        }
    }

    function cs(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }

    function ds(a, b) {
        var c = [Bc.userAgent, (new Date).getTimezoneOffset(), Bc.userLanguage || Bc.language, Math.floor(Gb() / 60 / 1E3) - (b === void 0 ? 0 : b), a].join("*"),
            d;
        if (!(d = Rr)) {
            for (var e = Array(256), f = 0; f < 256; f++) {
                for (var g = f, h = 0; h < 8; h++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                e[f] = g
            }
            d = e
        }
        Rr = d;
        for (var l = 4294967295, n = 0; n < c.length; n++) l = l >>> 8 ^ Rr[(l ^ c.charCodeAt(n)) & 255];
        return ((l ^ -1) >>> 0).toString(36)
    }

    function es(a) {
        return function(b) {
            var c = pj(w.location.href),
                d = c.search.replace("?", ""),
                e = gj(d, "_gl", !1, !0) || "";
            b.query = fs(e) || {};
            var f = jj(c, "fragment"),
                g;
            var h = -1;
            if (Lb(f, "_gl=")) h = 4;
            else {
                var l = f.indexOf("&_gl=");
                l > 0 && (h = l + 3 + 2)
            }
            if (h < 0) g = void 0;
            else {
                var n = f.indexOf("&", h);
                g = n < 0 ? f.substring(h) : f.substring(h, n)
            }
            b.fragment = fs(g || "") || {};
            a && gs(c, d, f)
        }
    }

    function hs(a, b) {
        var c = cs(a).exec(b),
            d = b;
        if (c) {
            var e = c[2],
                f = c[4];
            d = c[1];
            f && (d = d + e + f)
        }
        return d
    }

    function gs(a, b, c) {
        function d(g, h) {
            var l = hs("_gl", g);
            l.length && (l = h + l);
            return l
        }
        if (Ac && Ac.replaceState) {
            var e = cs("_gl");
            if (e.test(b) || e.test(c)) {
                var f = jj(a, "path");
                b = d(b, "?");
                c = d(c, "#");
                Ac.replaceState({}, "", "" + f + b + c)
            }
        }
    }

    function is(a, b) {
        var c = es(!!b),
            d = Vr();
        d.data || (d.data = {
            query: {},
            fragment: {}
        }, c(d.data));
        var e = {},
            f = d.data;
        f && (Jb(e, f.query), a && Jb(e, f.fragment));
        return e
    }
    var fs = function(a) {
        try {
            var b = js(a, 3);
            if (b !== void 0) {
                for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                    var f = d[e],
                        g = ib(d[e + 1]);
                    c[f] = g
                }
                kb("TAGGING", 6);
                return c
            }
        } catch (h) {
            kb("TAGGING", 8)
        }
    };

    function js(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; e < 3; ++e) {
                    var f = Yr.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = ij(d) || ""
                }
                c = void 0
            }
            var g = c;
            if (g && g[1] === "1") {
                var h = g[3],
                    l;
                a: {
                    for (var n = g[2], p = 0; p < b; ++p)
                        if (n === ds(h, p)) {
                            l = !0;
                            break a
                        }
                    l = !1
                }
                if (l) return h;
                kb("TAGGING", 7)
            }
        }
    }

    function ks(a, b, c, d, e) {
        function f(p) {
            p = hs(a, p);
            var q = p.charAt(p.length - 1);
            p && q !== "&" && (p += "&");
            return p + n
        }
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var g = bs(c);
        if (!g) return "";
        var h = g.query || "",
            l = g.fragment || "",
            n = a + "=" + b;
        d ? l.substring(1).length !== 0 && e || (l = "#" + f(l.substring(1))) : h = "?" + f(h.substring(1));
        return "" + g.Fj + h + l
    }

    function ls(a, b) {
        function c(n, p, q) {
            var r;
            a: {
                for (var u in n)
                    if (n.hasOwnProperty(u)) {
                        r = !0;
                        break a
                    }
                r = !1
            }
            if (r) {
                var t, v = [],
                    x;
                for (x in n)
                    if (n.hasOwnProperty(x)) {
                        var y = n[x];
                        y !== void 0 && y === y && y !== null && y.toString() !== "[object Object]" && (v.push(x), v.push(hb(String(y))))
                    }
                var A = v.join("*");
                t = ["1", ds(A), A].join("*");
                d ? (Wa(3) || Wa(1) || !p) && ms("_gl", t, a, p, q) : ns("_gl", t, a, p, q)
            }
        }
        var d = (a.tagName || "").toUpperCase() === "FORM",
            e = Xr(b, 1, d),
            f = Xr(b, 2, d),
            g = Xr(b, 4, d),
            h = Xr(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        Wa(1) && c(g, !0, !0);
        for (var l in h) h.hasOwnProperty(l) &&
            os(l, h[l], a)
    }

    function os(a, b, c) {
        c.tagName.toLowerCase() === "a" ? ns(a, b, c) : c.tagName.toLowerCase() === "form" && ms(a, b, c)
    }

    function ns(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var f;
        if (f = c.href) {
            var g;
            if (!(g = !Wa(4) || d)) {
                var h = w.location.href,
                    l = bs(c.href),
                    n = bs(h);
                g = !(l && n && l.Fj === n.Fj && l.query === n.query && l.fragment)
            }
            f = g
        }
        if (f) {
            var p = ks(a, b, c.href, d, e);
            qc.test(p) && (c.href = p)
        }
    }

    function ms(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        if (c) {
            var f = c.getAttribute("action") || "";
            if (f) {
                var g = (c.method || "").toLowerCase();
                if (g !== "get" || d) {
                    if (g === "get" || g === "post") {
                        var h = ks(a, b, f, d, e);
                        qc.test(h) && (c.action = h)
                    }
                } else {
                    for (var l = c.childNodes || [], n = !1, p = 0; p < l.length; p++) {
                        var q = l[p];
                        if (q.name === a) {
                            q.setAttribute("value", b);
                            n = !0;
                            break
                        }
                    }
                    if (!n) {
                        var r = z.createElement("input");
                        r.setAttribute("type", "hidden");
                        r.setAttribute("name", a);
                        r.setAttribute("value", b);
                        c.appendChild(r)
                    }
                }
            }
        }
    }

    function Tr(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && d > 0;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                f !== "http:" && f !== "https:" || ls(e, e.hostname)
            }
        } catch (g) {}
    }

    function Ur(a) {
        try {
            var b = a.getAttribute("action");
            if (b) {
                var c = jj(pj(b), "host");
                ls(a, c)
            }
        } catch (d) {}
    }

    function ps(a, b, c, d) {
        Sr();
        var e = c === "fragment" ? 2 : 1;
        d = !!d;
        Wr(a, b, e, d, !1);
        e === 2 && kb("TAGGING", 23);
        d && kb("TAGGING", 24)
    }

    function qs(a, b) {
        Sr();
        Wr(a, [lj(w.location, "host", !0)], b, !0, !0)
    }

    function rs() {
        var a = z.location.hostname,
            b = Zr.exec(z.referrer);
        if (!b) return !1;
        var c = b[2],
            d = b[1],
            e = "";
        if (c) {
            var f = c.split("/"),
                g = f[1];
            e = g === "s" ? ij(f[2]) || "" : ij(g) || ""
        } else if (d) {
            if (d.indexOf("xn--") === 0) return !1;
            e = d.replace(/-/g, ".").replace(/\.\./g, "-")
        }
        var h = a.replace($r, ""),
            l = e.replace($r, "");
        return h === l || Mb(h, "." + l)
    }

    function ss(a, b) {
        return a === !1 ? !1 : a || b || rs()
    };
    var ts = ["1"],
        us = {},
        vs = {};

    function ws(a, b) {
        b = b === void 0 ? !0 : b;
        var c = xs(a.prefix);
        if (us[c]) ys(a);
        else if (zs(c, a.path, a.domain)) {
            var d = vs[xs(a.prefix)] || {
                id: void 0,
                Ph: void 0
            };
            b && As(a, d.id, d.Ph);
            ys(a)
        } else {
            var e = rj("auiddc");
            if (e) kb("TAGGING", 17), us[c] = e;
            else if (b) {
                var f = xs(a.prefix),
                    g = Pr();
                Bs(f, g, a);
                zs(c, a.path, a.domain);
                ys(a, !0)
            }
        }
    }

    function ys(a, b) {
        if ((b === void 0 ? 0 : b) && kr(fr)) {
            var c = br(!1);
            c.error !== 0 ? kb("TAGGING", 38) : c.value ? "gcl_ctr" in c.value ? (delete c.value.gcl_ctr, cr(c) !== 0 && kb("TAGGING", 41)) : kb("TAGGING", 40) : kb("TAGGING", 39)
        }
        if (nr(fr) && lr([fr])[fr.fb] === -1) {
            for (var d = {}, e = (d[fr.fb] = 0, d), f = m(ir), g = f.next(); !g.done; g = f.next()) {
                var h = g.value;
                h !== fr && nr(h) && (e[h.fb] = 0)
            }
            mr(e, a)
        }
    }

    function As(a, b, c) {
        var d = xs(a.prefix),
            e = us[d];
        if (e) {
            var f = e.split(".");
            if (f.length === 2) {
                var g = Number(f[1]) || 0;
                if (g) {
                    var h = e;
                    b && (h = e + "." + b + "." + (c ? c : Math.floor(Gb() / 1E3)));
                    Bs(d, h, a, g * 1E3)
                }
            }
        }
    }

    function Bs(a, b, c, d) {
        var e;
        e = ["1", Nr(c.domain, c.path), b].join(".");
        var f = Zq(c, d);
        f.yc = Cs();
        Ir(a, e, f)
    }

    function zs(a, b, c) {
        var d = Qr(a, b, c, ts, Cs());
        if (!d) return !1;
        Ds(a, d);
        return !0
    }

    function Ds(a, b) {
        var c = b.split(".");
        c.length === 5 ? (us[a] = c.slice(0, 2).join("."), vs[a] = {
            id: c.slice(2, 4).join("."),
            Ph: Number(c[4]) || 0
        }) : c.length === 3 ? vs[a] = {
            id: c.slice(0, 2).join("."),
            Ph: Number(c[2]) || 0
        } : us[a] = b
    }

    function xs(a) {
        return (a || "_gcl") + "_au"
    }

    function Es(a) {
        function b() {
            Pl(c) && a()
        }
        var c = Cs();
        Vl(function() {
            b();
            Pl(c) || Wl(b, c)
        }, c)
    }

    function Fs(a) {
        var b = is(!0),
            c = xs(a.prefix);
        Es(function() {
            var d = b[c];
            if (d) {
                Ds(c, d);
                var e = Number(us[c].split(".")[1]) * 1E3;
                if (e) {
                    kb("TAGGING", 16);
                    var f = Zq(a, e);
                    f.yc = Cs();
                    var g = ["1", Nr(a.domain, a.path), d].join(".");
                    Ir(c, g, f)
                }
            }
        })
    }

    function Gs(a, b, c, d, e) {
        e = e || {};
        var f = function() {
            var g = {},
                h = Qr(a, e.path, e.domain, ts, Cs());
            h && (g[a] = h);
            return g
        };
        Es(function() {
            ps(f, b, c, d)
        })
    }

    function Cs() {
        return ["ad_storage", "ad_user_data"]
    };

    function Hs(a) {
        for (var b = [], c = z.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                Xd: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return b
    }

    function Is(a, b) {
        var c = Hs(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!(f[0] !== "1" || b && f.length < 3 || !b && f.length !== 3) && Number(f[1])) {
                d[c[e].Xd] || (d[c[e].Xd] = []);
                var g = {
                    version: f[0],
                    timestamp: Number(f[1]) * 1E3,
                    gclid: f[2]
                };
                b && f.length > 3 && (g.labels = f.slice(3));
                d[c[e].Xd].push(g)
            }
        }
        return d
    };
    var Js = {},
        Ks = (Js.k = {
            fa: /^[\w-]+$/
        }, Js.b = {
            fa: /^[\w-]+$/,
            Ij: !0
        }, Js.i = {
            fa: /^[1-9]\d*$/
        }, Js.h = {
            fa: /^\d+$/
        }, Js.t = {
            fa: /^[1-9]\d*$/
        }, Js.d = {
            fa: /^[A-Za-z0-9_-]+$/
        }, Js.j = {
            fa: /^\d+$/
        }, Js.u = {
            fa: /^[1-9]\d*$/
        }, Js.l = {
            fa: /^[01]$/
        }, Js.o = {
            fa: /^[1-9]\d*$/
        }, Js.g = {
            fa: /^[01]$/
        }, Js.s = {
            fa: /^.+$/
        }, Js);
    var Ls = {},
        Ps = (Ls[5] = {
            Uh: {
                2: Ms
            },
            xj: "2",
            Hh: ["k", "i", "b", "u"]
        }, Ls[4] = {
            Uh: {
                2: Ms,
                GCL: Ns
            },
            xj: "2",
            Hh: ["k", "i", "b"]
        }, Ls[2] = {
            Uh: {
                GS2: Ms,
                GS1: Os
            },
            xj: "GS2",
            Hh: "sogtjlhd".split("")
        }, Ls);

    function Qs(a, b, c) {
        var d = Ps[b];
        if (d) {
            var e = a.split(".")[0];
            c == null || c(e);
            if (e) {
                var f = d.Uh[e];
                if (f) return f(a, b)
            }
        }
    }

    function Ms(a, b) {
        var c = a.split(".");
        if (c.length === 3) {
            var d = c[2];
            if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1) try {
                d = decodeURIComponent(d)
            } catch (u) {}
            var e = {},
                f = Ps[b];
            if (f) {
                for (var g = f.Hh, h = m(d.split("$")), l = h.next(); !l.done; l = h.next()) {
                    var n = l.value,
                        p = n[0];
                    if (g.indexOf(p) !== -1) try {
                        var q = decodeURIComponent(n.substring(1)),
                            r = Ks[p];
                        r && (r.Ij ? (e[p] = e[p] || [], e[p].push(q)) : e[p] = q)
                    } catch (u) {}
                }
                return e
            }
        }
    }

    function Rs(a, b, c) {
        var d = Ps[b];
        if (d) return [d.xj, c || "1", Ss(a, b)].join(".")
    }

    function Ss(a, b) {
        var c = Ps[b];
        if (c) {
            for (var d = [], e = m(c.Hh), f = e.next(); !f.done; f = e.next()) {
                var g = f.value,
                    h = Ks[g];
                if (h) {
                    var l = a[g];
                    if (l !== void 0)
                        if (h.Ij && Array.isArray(l))
                            for (var n = m(l), p = n.next(); !p.done; p = n.next()) d.push(encodeURIComponent("" + g + p.value));
                        else d.push(encodeURIComponent("" + g + l))
                }
            }
            return d.join("$")
        }
    }

    function Ns(a) {
        var b = a.split(".");
        b.shift();
        var c = b.shift(),
            d = b.shift(),
            e = {};
        return e.k = d, e.i = c, e.b = b, e
    }

    function Os(a) {
        var b = a.split(".").slice(2);
        if (!(b.length < 5 || b.length > 7)) {
            var c = {};
            return c.s = b[0], c.o = b[1], c.g = b[2], c.t = b[3], c.j = b[4], c.l = b[5], c.h = b[6], c
        }
    };
    var Ts = new Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]],
        [2, "analytics_storage"]
    ]);

    function Us(a, b, c) {
        if (Ps[b]) {
            for (var d = [], e = wr(a, void 0, void 0, Ts.get(b)), f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = Qs(g.value, b, c);
                h && d.push(Vs(h))
            }
            return d
        }
    }

    function Ws(a) {
        var b = Xs;
        if (Ps[2]) {
            for (var c = {}, d = xr(a, void 0, void 0, Ts.get(2)), e = Object.keys(d).sort(), f = m(e), g = f.next(); !g.done; g = f.next())
                for (var h = g.value, l = m(d[h]), n = l.next(); !n.done; n = l.next()) {
                    var p = Qs(n.value, 2, b);
                    p && (c[h] || (c[h] = []), c[h].push(Vs(p)))
                }
            return c
        }
    }

    function Ys(a, b, c, d, e) {
        d = d || {};
        var f = Nr(d.domain, d.path),
            g = Rs(b, c, f);
        if (!g) return 1;
        var h = Zq(d, e, void 0, Ts.get(c));
        return Ir(a, g, h)
    }

    function Zs(a, b) {
        var c = b.fa;
        return typeof c === "function" ? c(a) : c.test(a)
    }

    function Vs(a) {
        for (var b = m(Object.keys(a)), c = b.next(), d = {}; !c.done; d = {
                kg: void 0
            }, c = b.next()) {
            var e = c.value,
                f = a[e];
            d.kg = Ks[e];
            d.kg ? d.kg.Ij ? a[e] = Array.isArray(f) ? f.filter(function(g) {
                return function(h) {
                    return Zs(h, g.kg)
                }
            }(d)) : void 0 : typeof f === "string" && Zs(f, d.kg) || (a[e] = void 0) : a[e] = void 0
        }
        return a
    };
    var $s = function() {
        this.value = 0
    };
    $s.prototype.set = function(a) {
        return this.value |= 1 << a
    };
    var at = function(a, b) {
        b <= 0 || (a.value |= 1 << b - 1)
    };
    $s.prototype.get = function() {
        return this.value
    };
    $s.prototype.clear = function(a) {
        this.value &= ~(1 << a)
    };
    $s.prototype.clearAll = function() {
        this.value = 0
    };
    $s.prototype.equals = function(a) {
        return this.value === a.value
    };

    function bt(a) {
        if (a) try {
            return new Uint8Array(atob(a.replace(/-/g, "+").replace(/_/g, "/")).split("").map(function(b) {
                return b.charCodeAt(0)
            }))
        } catch (b) {}
    }

    function ct(a, b) {
        var c = 0,
            d = 0,
            e, f = b;
        do {
            if (f >= a.length) return;
            e = a[f++];
            c |= (e & 127) << d;
            d += 7
        } while (e & 128);
        return [c, f]
    };

    function dt() {
        var a = String,
            b = w.location.hostname,
            c = w.location.pathname,
            d = b = Xb(b);
        d.split(".").length > 2 && (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
        b = d;
        c = Xb(c);
        var e = c.split(";")[0];
        e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
        return a(bi(("" + b + e).toLowerCase()))
    };
    var et = {},
        ft = (et.gclid = !0, et.dclid = !0, et.gbraid = !0, et.wbraid = !0, et),
        gt = /^\w+$/,
        ht = /^[\w-]+$/,
        it = {},
        jt = (it.aw = "_aw", it.dc = "_dc", it.gf = "_gf", it.gp = "_gp", it.gs = "_gs", it.ha = "_ha", it.ag = "_ag", it.gb = "_gb", it),
        kt = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
        lt = /^www\.googleadservices\.com$/;

    function mt() {
        return ["ad_storage", "ad_user_data"]
    }

    function nt(a) {
        return !Wa(6) || Pl(a)
    }

    function ot(a, b) {
        function c() {
            var d = nt(b);
            d && a();
            return d
        }
        Vl(function() {
            c() || Wl(c, b)
        }, b)
    }

    function pt(a) {
        return qt(a).map(function(b) {
            return b.gclid
        })
    }

    function rt(a) {
        return st(a).filter(function(b) {
            return b.gclid
        }).map(function(b) {
            return b.gclid
        })
    }

    function st(a) {
        var b = tt(a.prefix),
            c = ut("gb", b),
            d = ut("ag", b);
        if (!d || !c) return [];
        var e = function(h) {
                return function(l) {
                    l.type = h;
                    return l
                }
            },
            f = qt(c).map(e("gb")),
            g = vt(d).map(e("ag"));
        return f.concat(g).sort(function(h, l) {
            return l.timestamp - h.timestamp
        })
    }

    function wt(a, b, c, d, e) {
        var f = vb(a, function(g) {
            return g.gclid === b
        });
        f ? (f.timestamp < c && (f.timestamp = c, f.Wc = e), f.labels = xt(f.labels || [], d || [])) : a.push({
            version: "2",
            gclid: b,
            timestamp: c,
            labels: d,
            Wc: e
        })
    }

    function vt(a) {
        for (var b = Us(a, 5) || [], c = [], d = m(b), e = d.next(); !e.done; e = d.next()) {
            var f = e.value,
                g = f,
                h = zt(f);
            h && wt(c, g.k, h, g.b || [], f.u)
        }
        return c.sort(function(l, n) {
            return n.timestamp - l.timestamp
        })
    }

    function qt(a) {
        for (var b = [], c = wr(a, z.cookie, void 0, mt()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = At(e.value);
            f != null && (f.Wc = void 0, f.za = new $s, f.Za = [1], Bt(b, f))
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return Ct(b)
    }

    function Dt(a, b) {
        for (var c = [], d = m(a), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) || c.push(f)
        }
        for (var g = m(b), h = g.next(); !h.done; h = g.next()) {
            var l = h.value;
            c.includes(l) || c.push(l)
        }
        return c
    }

    function Bt(a, b, c) {
        c = c === void 0 ? !1 : c;
        for (var d, e, f = m(a), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            if (h.gclid === b.gclid) {
                d = h;
                break
            }
            h.za && b.za && h.za.equals(b.za) && (e = h)
        }
        if (d) {
            var l, n, p = (l = d.za) != null ? l : new $s,
                q = (n = b.za) != null ? n : new $s;
            p.value |= q.value;
            d.za = p;
            d.timestamp < b.timestamp && (d.timestamp = b.timestamp, d.Wc = b.Wc);
            d.labels = Dt(d.labels || [], b.labels || []);
            d.Za = Dt(d.Za || [], b.Za || [])
        } else c && e ? na(Object, "assign").call(Object, e, b) : a.push(b)
    }

    function Et(a) {
        if (!a) return new $s;
        var b = new $s;
        if (a === 1) return at(b, 2), at(b, 3), b;
        at(b, a);
        return b
    }

    function Ft() {
        var a = dr("gclid");
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        var b = a.value;
        try {
            if (!("value" in b && b.value) || typeof b.value !== "object") return null;
            var c = b.value,
                d = c.value;
            if (!d || !d.match(ht)) return null;
            var e = c.linkDecorationSource,
                f = c.linkDecorationSources,
                g = new $s;
            typeof e === "number" ? g = Et(e) : typeof f === "number" && (g.value = f);
            return {
                version: "",
                gclid: d,
                timestamp: Number(c.creationTimeMs) || 0,
                labels: [],
                za: g,
                Za: [2]
            }
        } catch (h) {
            return null
        }
    }

    function Gt() {
        var a = dr("gcl_aw");
        if (a.error !== 0) return null;
        try {
            return a.value.reduce(function(b, c) {
                if (!c.value || typeof c.value !== "object") return b;
                var d = c.value,
                    e = d.value;
                if (!e || !e.match(ht)) return b;
                var f = new $s,
                    g = d.linkDecorationSources;
                typeof g === "number" && (f.value = g);
                b.push({
                    version: "",
                    gclid: e,
                    timestamp: Number(d.creationTimeMs) || 0,
                    expires: Number(c.expires) || 0,
                    labels: [],
                    za: f,
                    Za: [2]
                });
                return b
            }, [])
        } catch (b) {
            return null
        }
    }

    function Ht(a) {
        for (var b = [], c = wr(a, z.cookie, void 0, mt()), d = m(c), e = d.next(); !e.done; e = d.next()) {
            var f = At(e.value);
            f != null && (f.Wc = void 0, f.za = new $s, f.Za = [1], Bt(b, f))
        }
        var g = Ft();
        g && (g.Wc = void 0, g.Za = g.Za || [2], Bt(b, g));
        if (Wa(15)) {
            var h = Gt();
            if (h)
                for (var l = m(h), n = l.next(); !n.done; n = l.next()) {
                    var p = n.value;
                    p.Wc = void 0;
                    p.Za = p.Za || [2];
                    Bt(b, p)
                }
        }
        b.sort(function(q, r) {
            return r.timestamp - q.timestamp
        });
        return Ct(b)
    }

    function xt(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function tt(a) {
        return a && typeof a === "string" && a.match(gt) ? a : "_gcl"
    }

    function It(a, b) {
        if (a) {
            var c = {
                value: a,
                za: new $s
            };
            at(c.za, b);
            return c
        }
    }

    function Jt(a, b, c) {
        var d = pj(a),
            e = jj(d, "query", !1, void 0, "gclsrc"),
            f = It(jj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
        if (b && (!f || !e)) {
            var g = d.hash.replace("#", "");
            f || (f = It(gj(g, "gclid", !1), 3));
            e || (e = gj(g, "gclsrc", !1))
        }
        return f && (e === void 0 || e === "aw" || e === "aw.ds" || Wa(19) && e === "aw.dv") ? [f] : []
    }

    function Kt(a, b) {
        var c = pj(a),
            d = jj(c, "query", !1, void 0, "gclid"),
            e = jj(c, "query", !1, void 0, "gclsrc"),
            f = jj(c, "query", !1, void 0, "wbraid");
        f = Vb(f);
        var g = jj(c, "query", !1, void 0, "gbraid"),
            h = jj(c, "query", !1, void 0, "gad_source"),
            l = jj(c, "query", !1, void 0, "dclid");
        if (b && !(d && e && f && g)) {
            var n = c.hash.replace("#", "");
            d = d || gj(n, "gclid", !1);
            e = e || gj(n, "gclsrc", !1);
            f = f || gj(n, "wbraid", !1);
            g = g || gj(n, "gbraid", !1);
            h = h || gj(n, "gad_source", !1)
        }
        return Lt(d, e, l, f, g, h)
    }

    function Mt() {
        return Kt(w.location.href, !0)
    }

    function Lt(a, b, c, d, e, f) {
        var g = {},
            h = function(l, n) {
                g[n] || (g[n] = []);
                g[n].push(l)
            };
        g.gclid = a;
        g.gclsrc = b;
        g.dclid = c;
        if (a !== void 0 && a.match(ht)) switch (b) {
            case void 0:
                h(a, "aw");
                break;
            case "aw.ds":
                h(a, "aw");
                h(a, "dc");
                break;
            case "aw.dv":
                Wa(19) && (h(a, "aw"), h(a, "dc"));
                break;
            case "ds":
                h(a, "dc");
                break;
            case "3p.ds":
                h(a, "dc");
                break;
            case "gf":
                h(a, "gf");
                break;
            case "ha":
                h(a, "ha")
        }
        c && h(c, "dc");
        d !== void 0 && ht.test(d) && (g.wbraid = d, h(d, "gb"));
        e !== void 0 && ht.test(e) && (g.gbraid = e, h(e, "ag"));
        f !== void 0 && ht.test(f) && (g.gad_source =
            f, h(f, "gs"));
        return g
    }

    function Nt(a) {
        for (var b = Mt(), c = !0, d = m(Object.keys(b)), e = d.next(); !e.done; e = d.next())
            if (b[e.value] !== void 0) {
                c = !1;
                break
            }
        c && (b = Kt(w.document.referrer, !1), b.gad_source = void 0);
        Ot(b, !1, a)
    }

    function Pt(a) {
        Nt(a);
        var b = Jt(w.location.href, !0, !1);
        b.length || (b = Jt(w.document.referrer, !1, !0));
        a = a || {};
        Qt(a);
        if (b.length) {
            var c = b[0],
                d = Gb(),
                e = Zq(a, d, !0),
                f = mt(),
                g = function() {
                    nt(f) && e.expires !== void 0 && ar("gclid", {
                        value: {
                            value: c.value,
                            creationTimeMs: d,
                            linkDecorationSources: c.za.get()
                        },
                        expires: Number(e.expires)
                    })
                };
            Vl(function() {
                g();
                nt(f) || Wl(g, f)
            }, f)
        }
    }

    function Qt(a) {
        var b;
        if (b = Wa(16)) {
            var c = Rt();
            b = kt.test(c) || lt.test(c) || St()
        }
        if (b) {
            var d;
            a: {
                for (var e = pj(w.location.href), f = hj(jj(e, "query")), g = m(Object.keys(f)), h = g.next(); !h.done; h = g.next()) {
                    var l = h.value;
                    if (!ft[l]) {
                        var n = f[l][0] || "",
                            p;
                        if (!n || n.length < 50 || n.length > 200) p = !1;
                        else {
                            var q = bt(n),
                                r;
                            if (q) c: {
                                var u = q;
                                if (u && u.length !== 0) {
                                    var t = 0;
                                    try {
                                        for (var v = 10; t < u.length && !(v-- <= 0);) {
                                            var x = ct(u, t);
                                            if (x === void 0) break;
                                            var y = m(x),
                                                A = y.next().value,
                                                C = y.next().value,
                                                E = A,
                                                H = C,
                                                J = E & 7;
                                            if (E >> 3 === 16382) {
                                                if (J !== 0) break;
                                                var O = ct(u, H);
                                                if (O === void 0) break;
                                                r = m(O).next().value === 1;
                                                break c
                                            }
                                            var ba;
                                            d: {
                                                var W = void 0,
                                                    N = u,
                                                    S = H;
                                                switch (J) {
                                                    case 0:
                                                        ba = (W = ct(N, S)) == null ? void 0 : W[1];
                                                        break d;
                                                    case 1:
                                                        ba = S + 8;
                                                        break d;
                                                    case 2:
                                                        var la = ct(N, S);
                                                        if (la === void 0) break;
                                                        var ja = m(la),
                                                            V = ja.next().value;
                                                        ba = ja.next().value + V;
                                                        break d;
                                                    case 5:
                                                        ba = S + 4;
                                                        break d
                                                }
                                                ba = void 0
                                            }
                                            if (ba === void 0 || ba > u.length || ba <= t) break;
                                            t = ba
                                        }
                                    } catch (ha) {}
                                }
                                r = !1
                            }
                            else r = !1;
                            p = r
                        }
                        if (p) {
                            d = n;
                            break a
                        }
                    }
                }
                d = void 0
            }
            var U = d;
            U && Tt(U, 7, a)
        }
    }

    function Tt(a, b, c) {
        c = c || {};
        var d = Gb(),
            e = Zq(c, d, !0),
            f = mt(),
            g = function() {
                if (nt(f) && e.expires !== void 0) {
                    var h = Gt() || [];
                    Bt(h, {
                        version: "",
                        gclid: a,
                        timestamp: d,
                        expires: Number(e.expires),
                        za: Et(b)
                    }, !0);
                    ar("gcl_aw", h.map(function(l) {
                        return {
                            value: {
                                value: l.gclid,
                                creationTimeMs: l.timestamp,
                                linkDecorationSources: l.za ? l.za.get() : 0
                            },
                            expires: Number(l.expires)
                        }
                    }))
                }
            };
        Vl(function() {
            nt(f) ? g() : Wl(g, f)
        }, f)
    }

    function Ot(a, b, c, d, e) {
        c = c || {};
        e = e || [];
        var f = tt(c.prefix),
            g = d || Gb(),
            h = Math.round(g / 1E3),
            l = mt(),
            n = !1,
            p = !1,
            q = Wa(21),
            r = function() {
                if (nt(l)) {
                    var u = Zq(c, g, !0);
                    u.yc = l;
                    for (var t = function(W, N) {
                            var S = ut(W, f);
                            S && (Ir(S, N, u), W !== "gb" && (n = !0))
                        }, v = function(W) {
                            var N = ["GCL", h, W];
                            e.length > 0 && N.push(e.join("."));
                            return N.join(".")
                        }, x = m(["aw", "dc", "gf", "ha", "gp"]), y = x.next(); !y.done; y = x.next()) {
                        var A = y.value;
                        a[A] && t(A, v(a[A][0]))
                    }
                    if ((!n || q) && a.gb) {
                        var C = a.gb[0],
                            E = ut("gb", f);
                        !b && qt(E).some(function(W) {
                            return W.gclid ===
                                C && W.labels && W.labels.length > 0
                        }) || t("gb", v(C))
                    }
                }
                if (!p && a.gbraid && nt("ad_storage") && (p = !0, !n || q)) {
                    var H = a.gbraid,
                        J = ut("ag", f);
                    if (b || !vt(J).some(function(W) {
                            return W.gclid === H && W.labels && W.labels.length > 0
                        })) {
                        var O = {},
                            ba = (O.k = H, O.i = "" + h, O.b = e, O);
                        Ys(J, ba, 5, c, g)
                    }
                }
                Ut(a, f, g, c)
            };
        Vl(function() {
            r();
            nt(l) || Wl(r, l)
        }, l)
    }

    function Ut(a, b, c, d) {
        if (a.gad_source !== void 0 && nt("ad_storage")) {
            var e = gd();
            if (e !== "r" && e !== "h") {
                var f = a.gad_source,
                    g = ut("gs", b);
                if (g) {
                    var h = Math.floor((Gb() - (fd() || 0)) / 1E3),
                        l, n = dt(),
                        p = {};
                    l = (p.k = f, p.i = "" + h, p.u = n, p);
                    Ys(g, l, 5, d, c)
                }
            }
        }
    }

    function Vt(a, b) {
        var c = is(!0);
        ot(function() {
            for (var d = tt(b.prefix), e = 0; e < a.length; ++e) {
                var f = a[e];
                if (jt[f] !== void 0) {
                    var g = ut(f, d),
                        h = c[g];
                    if (h) {
                        var l = Math.min(Wt(h), Gb()),
                            n;
                        b: {
                            for (var p = l, q = wr(g, z.cookie, void 0, mt()), r = 0; r < q.length; ++r)
                                if (Wt(q[r]) > p) {
                                    n = !0;
                                    break b
                                }
                            n = !1
                        }
                        if (!n) {
                            var u = Zq(b, l, !0);
                            u.yc = mt();
                            Ir(g, h, u)
                        }
                    }
                }
            }
            Ot(Lt(c.gclid, c.gclsrc), !1, b)
        }, mt())
    }

    function Xt(a) {
        var b = ["ag"],
            c = is(!0),
            d = tt(a.prefix);
        ot(function() {
            for (var e = 0; e < b.length; ++e) {
                var f = ut(b[e], d);
                if (f) {
                    var g = c[f];
                    if (g) {
                        var h = Qs(g, 5);
                        if (h) {
                            var l = zt(h);
                            l || (l = Gb());
                            var n;
                            a: {
                                for (var p = l, q = Us(f, 5), r = 0; r < q.length; ++r)
                                    if (zt(q[r]) > p) {
                                        n = !0;
                                        break a
                                    }
                                n = !1
                            }
                            if (n) break;
                            h.i = "" + Math.round(l / 1E3);
                            Ys(f, h, 5, a, l)
                        }
                    }
                }
            }
        }, ["ad_storage"])
    }

    function ut(a, b) {
        var c = jt[a];
        if (c !== void 0) return b + c
    }

    function Wt(a) {
        return Yt(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function zt(a) {
        return a ? (Number(a.i) || 0) * 1E3 : 0
    }

    function At(a) {
        var b = Yt(a.split("."));
        return b.length === 0 ? null : {
            version: b[0],
            gclid: b[2],
            timestamp: (Number(b[1]) || 0) * 1E3,
            labels: b.slice(3)
        }
    }

    function Yt(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !ht.test(a[2]) ? [] : a
    }

    function Zt(a, b, c, d, e) {
        if (Array.isArray(b) && vr(w)) {
            var f = tt(e),
                g = function() {
                    for (var h = {}, l = 0; l < a.length; ++l) {
                        var n = ut(a[l], f);
                        if (n) {
                            var p = wr(n, z.cookie, void 0, mt());
                            p.length && (h[n] = p.sort()[p.length - 1])
                        }
                    }
                    return h
                };
            ot(function() {
                ps(g, b, c, d)
            }, mt())
        }
    }

    function $t(a, b, c, d) {
        if (Array.isArray(a) && vr(w)) {
            var e = ["ag"],
                f = tt(d),
                g = function() {
                    for (var h = {}, l = 0; l < e.length; ++l) {
                        var n = ut(e[l], f);
                        if (!n) return {};
                        var p = Us(n, 5);
                        if (p.length) {
                            var q = p.sort(function(r, u) {
                                return zt(u) - zt(r)
                            })[0];
                            h[n] = Rs(q, 5)
                        }
                    }
                    return h
                };
            ot(function() {
                ps(g, a, b, c)
            }, ["ad_storage"])
        }
    }

    function Ct(a) {
        return a.filter(function(b) {
            return ht.test(b.gclid)
        })
    }

    function au(a, b) {
        if (vr(w)) {
            for (var c = tt(b.prefix), d = {}, e = 0; e < a.length; e++) jt[a[e]] && (d[a[e]] = jt[a[e]]);
            ot(function() {
                zb(d, function(f, g) {
                    var h = wr(c + g, z.cookie, void 0, mt());
                    h.sort(function(u, t) {
                        return Wt(t) - Wt(u)
                    });
                    if (h.length) {
                        var l = h[0],
                            n = Wt(l),
                            p = Yt(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
                            q = {},
                            r;
                        r = Yt(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
                        q[f] = [r];
                        Ot(q, !0, b, n, p)
                    }
                })
            }, mt())
        }
    }

    function bu(a) {
        var b = ["ag"],
            c = ["gbraid"];
        ot(function() {
            for (var d = tt(a.prefix), e = 0; e < b.length; ++e) {
                var f = ut(b[e], d);
                if (!f) break;
                var g = Us(f, 5);
                if (g.length) {
                    var h = g.sort(function(q, r) {
                            return zt(r) - zt(q)
                        })[0],
                        l = zt(h),
                        n = h.b,
                        p = {};
                    p[c[e]] = h.k;
                    Ot(p, !0, a, l, n)
                }
            }
        }, ["ad_storage"])
    }

    function cu(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }

    function du(a) {
        function b(h, l, n) {
            n && (h[l] = n)
        }
        if (Sl()) {
            var c = Mt(),
                d;
            a.includes("gad_source") && (d = c.gad_source !== void 0 ? c.gad_source : is(!1)._gs);
            if (cu(c, a) || d) {
                var e = {};
                b(e, "gclid", c.gclid);
                b(e, "dclid", c.dclid);
                b(e, "gclsrc", c.gclsrc);
                b(e, "wbraid", c.wbraid);
                b(e, "gbraid", c.gbraid);
                qs(function() {
                    return e
                }, 3);
                var f = {},
                    g = (f._up = "1", f);
                b(g, "_gs", d);
                qs(function() {
                    return g
                }, 1)
            }
        }
    }

    function St() {
        var a = pj(w.location.href);
        return jj(a, "query", !1, void 0, "gad_source")
    }

    function eu(a) {
        if (!Wa(1)) return null;
        var b = is(!0).gad_source;
        if (b != null) return w.location.hash = "", b;
        if (Wa(2)) {
            b = St();
            if (b != null) return b;
            var c = Mt();
            if (cu(c, a)) return "0"
        }
        return null
    }

    function fu(a) {
        var b = eu(a);
        b != null && qs(function() {
            var c = {};
            return c.gad_source = b, c
        }, 4)
    }

    function gu(a, b, c) {
        var d = [];
        if (b.length === 0) return d;
        for (var e = {}, f = 0; f < b.length; f++) {
            var g = b[f],
                h = g.type ? g.type : "gcl";
            (g.labels || []).indexOf(c) === -1 ? (a.push(0), e[h] || d.push(g)) : a.push(1);
            e[h] = !0
        }
        return d
    }

    function hu(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!nt(mt())) return e;
        var f = qt(a),
            g = gu(e, f, b);
        if (g.length && !d)
            for (var h = m(g), l = h.next(); !l.done; l = h.next()) {
                var n = l.value,
                    p = n.timestamp,
                    q = [n.version, Math.round(p / 1E3), n.gclid].concat(n.labels || [], [b]).join("."),
                    r = Zq(c, p, !0);
                r.yc = mt();
                Ir(a, q, r)
            }
        return e
    }

    function iu(a, b) {
        var c = [];
        b = b || {};
        var d = st(b),
            e = gu(c, d, a);
        if (e.length)
            for (var f = m(e), g = f.next(); !g.done; g = f.next()) {
                var h = g.value,
                    l = tt(b.prefix),
                    n = ut(h.type, l);
                if (!n) break;
                var p = h,
                    q = p.version,
                    r = p.gclid,
                    u = p.labels,
                    t = p.timestamp,
                    v = Math.round(t / 1E3);
                if (h.type === "ag") {
                    var x = {},
                        y = (x.k = r, x.i = "" + v, x.b = (u || []).concat([a]), x);
                    Ys(n, y, 5, b, t)
                } else if (h.type === "gb") {
                    var A = [q, v, r].concat(u || [], [a]).join("."),
                        C = Zq(b, t, !0);
                    C.yc = mt();
                    Ir(n, A, C)
                }
            }
        return c
    }

    function ju(a, b) {
        var c = tt(b),
            d = ut(a, c);
        if (!d) return 0;
        var e;
        e = a === "ag" ? vt(d) : qt(d);
        for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function ku(a) {
        for (var b = 0, c = m(Object.keys(a)), d = c.next(); !d.done; d = c.next())
            for (var e = a[d.value], f = 0; f < e.length; f++) b = Math.max(b, Number(e[f].timestamp));
        return b
    }

    function lu(a) {
        var b = Math.max(ju("aw", a), ku(nt(mt()) ? Is() : {})),
            c = Math.max(ju("gb", a), ku(nt(mt()) ? Is("_gac_gb", !0) : {}));
        c = Math.max(c, ju("ag", a));
        return c > b
    }

    function Rt() {
        return z.referrer ? jj(pj(z.referrer), "host") : ""
    };

    function xu(a) {
        var b = window,
            c = b.webkit;
        delete b.webkit;
        a(b.webkit);
        b.webkit = c
    }

    function yu(a) {
        var b = {
            action: "gcl_setup"
        };
        if ("CWVWebViewMessage" in a.messageHandlers) return a.messageHandlers.CWVWebViewMessage.postMessage({
            command: "awb",
            payload: b
        }), !0;
        var c = a.messageHandlers.awb;
        return c ? (c.postMessage(b), !0) : !1
    };

    function zu() {
        return ["ad_storage", "ad_user_data"]
    }

    function Au(a) {
        if (P(38) && !km(gm.Z.rm) && "webkit" in window && window.webkit.messageHandlers) {
            var b = function() {
                try {
                    xu(function(c) {
                        c && ("CWVWebViewMessage" in c.messageHandlers || "awb" in c.messageHandlers) && (jm(gm.Z.rm, function(d) {
                            d.gclid && Tt(d.gclid, 5, a)
                        }), yu(c) || M(178))
                    })
                } catch (c) {
                    M(177)
                }
            };
            Vl(function() {
                nt(zu()) ? b() : Wl(b, zu())
            }, zu())
        }
    };
    var Bu = ["https://www.google.com", "https://www.youtube.com", "https://m.youtube.com"];

    function Cu(a) {
        return a.data.action !== "gcl_transfer" ? (M(173), !0) : a.data.gadSource ? a.data.gclid ? !1 : (M(181), !0) : (M(180), !0)
    }

    function Du(a, b) {
        if (P(a)) {
            if (km(gm.Z.He)) return M(176), gm.Z.He;
            if (km(gm.Z.vm)) return M(170), gm.Z.He;
            var c = bq();
            if (!c) M(171);
            else if (c.opener) {
                var d = function(g) {
                    if (!Bu.includes(g.origin)) M(172);
                    else if (!Cu(g)) {
                        var h = {
                            gadSource: g.data.gadSource
                        };
                        P(229) && (h.gclid = g.data.gclid);
                        jm(gm.Z.He, h);
                        a === 200 && g.data.gclid && Tt(String(g.data.gclid), 6, b);
                        var l;
                        (l = g.stopImmediatePropagation) == null || l.call(g);
                        jq(c, "message", d)
                    }
                };
                if (iq(c, "message", d)) {
                    jm(gm.Z.vm, !0);
                    for (var e = m(Bu), f = e.next(); !f.done; f = e.next()) c.opener.postMessage({
                            action: "gcl_setup"
                        },
                        f.value);
                    M(174);
                    return gm.Z.He
                }
                M(175)
            }
        }
    };
    var Nu = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Ou = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Pu = /^\d+\.fls\.doubleclick\.net$/,
        Qu = /;gac=([^;?]+)/,
        Ru = /;gacgb=([^;?]+)/;

    function Su(a, b) {
        if (Pu.test(z.location.host)) {
            var c = z.location.href.match(b);
            return c && c.length === 2 && c[1].match(Nu) ? ij(c[1]) || "" : ""
        }
        for (var d = [], e = m(Object.keys(a)), f = e.next(); !f.done; f = e.next()) {
            for (var g = f.value, h = [], l = a[g], n = 0; n < l.length; n++) h.push(l[n].gclid);
            d.push(g + ":" + h.join(","))
        }
        return d.length > 0 ? d.join(";") : ""
    }

    function Tu(a, b, c) {
        for (var d = nt(mt()) ? Is("_gac_gb", !0) : {}, e = [], f = !1, g = m(Object.keys(d)), h = g.next(); !h.done; h = g.next()) {
            var l = h.value,
                n = hu("_gac_gb_" + l, a, b, c);
            f = f || n.length !== 0 && n.some(function(p) {
                return p === 1
            });
            e.push(l + ":" + n.join(","))
        }
        return {
            Pq: f ? e.join(";") : "",
            Oq: Su(d, Ru)
        }
    }

    function Uu(a) {
        var b = z.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
        return b && b.length === 2 && b[1].match(Ou) ? b[1] : void 0
    }

    function Vu(a) {
        var b = {},
            c, d, e;
        Pu.test(z.location.host) && (c = Uu("gclgs"), d = Uu("gclst"), e = Uu("gcllp"));
        if (c && d && e) b.og = c, b.Kh = d, b.Jh = e;
        else {
            var f = Gb(),
                g = vt((a || "_gcl") + "_gs"),
                h = g.map(function(p) {
                    return p.gclid
                }),
                l = g.map(function(p) {
                    return f - p.timestamp
                }),
                n = g.map(function(p) {
                    return p.Wc
                });
            h.length > 0 && l.length > 0 && n.length > 0 && (b.og = h.join("."), b.Kh = l.join("."), b.Jh = n.join("."))
        }
        return b
    }

    function Wu(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (Pu.test(z.location.host)) {
            var e = Uu(c);
            if (e) {
                if (d) {
                    var f = new $s;
                    at(f, 2);
                    at(f, 3);
                    return e.split(".").map(function(h) {
                        return {
                            gclid: h,
                            za: f,
                            Za: [1]
                        }
                    })
                }
                return e.split(".").map(function(h) {
                    return {
                        gclid: h,
                        za: new $s,
                        Za: [1]
                    }
                })
            }
        } else {
            if (b === "gclid") {
                var g = (a || "_gcl") + "_aw";
                return d ? Ht(g) : qt(g)
            }
            if (b === "wbraid") return qt((a || "_gcl") + "_gb");
            if (b === "braids") return st({
                prefix: a
            })
        }
        return []
    }

    function Xu(a) {
        return Pu.test(z.location.host) ? !(Uu("gclaw") || Uu("gac")) : lu(a)
    }

    function Yu(a, b, c) {
        var d;
        d = c ? iu(a, b) : hu((b && b.prefix || "_gcl") + "_gb", a, b);
        return d.length === 0 || d.every(function(e) {
            return e === 0
        }) ? "" : d.join(".")
    };
    var dv = function(a) {
            this.C = 1;
            this.C > 0 || (this.C = 1);
            this.onSuccess = a.D.onSuccess
        },
        ev = function(a, b) {
            return Ub(function() {
                a.C--;
                if (rb(a.onSuccess) && a.C === 0) a.onSuccess()
            }, b > 0 ? b : 1)
        };

    function hv(a, b) {
        var c = !!uj();
        switch (a) {
            case 45:
                return "https://www.google.com/ccm/collect";
            case 46:
                return c ? vj() + "/gs/ccm/collect" : "https://pagead2.googlesyndication.com/ccm/collect";
            case 51:
                return "https://www.google.com/travel/flights/click/conversion";
            case 9:
                return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
            case 17:
                return c ? Sm() ? fv() : "" + vj() + "/ag/g/c" : fv();
            case 16:
                return c ? Sm() ? gv() : "" + vj() + "/ga/g/c" : gv();
            case 67:
                return Sm() ? "" : "https://www.google.com/g/collect";
            case 1:
                return "https://ad.doubleclick.net/activity;";
            case 2:
                return c ? vj() + "/ddm/activity/" : "https://ade.googlesyndication.com/ddm/activity/";
            case 33:
                return "https://ad.doubleclick.net/activity;register_conversion=1;";
            case 11:
                return c ? vj() + "/d/pagead/form-data" : P(141) ? "https://www.google.com/pagead/form-data" : "https://google.com/pagead/form-data";
            case 3:
                return "https://" + b.mq + ".fls.doubleclick.net/activityi;";
            case 5:
                return "https://www.googleadservices.com/pagead/conversion";
            case 6:
                return c ? vj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 66:
                return "https://www.google.com/pagead/uconversion";
            case 8:
                return "https://www.google.com/pagead/1p-conversion";
            case 63:
                return "https://www.googleadservices.com/pagead/conversion";
            case 64:
                return c ? vj() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 65:
                return "https://www.google.com/pagead/1p-conversion";
            case 22:
                return c ? vj() + "/as/d/ccm/conversion" : "https://www.googleadservices.com/ccm/conversion";
            case 60:
                return c ? vj() + "/gs/ccm/conversion" : "https://pagead2.googlesyndication.com/ccm/conversion";
            case 23:
                return c ? vj() + "/g/d/ccm/conversion" : "https://www.google.com/ccm/conversion";
            case 55:
                return c ? vj() + "/gs/measurement/conversion" : "https://pagead2.googlesyndication.com/measurement/conversion";
            case 54:
                return P(205) ? "https://www.google.com/measurement/conversion" : c ? vj() + "/g/measurement/conversion" : "https://www.google.com/measurement/conversion";
            case 21:
                return c ? vj() + "/d/ccm/form-data" : P(141) ? "https://www.google.com/ccm/form-data" : "https://google.com/ccm/form-data";
            case 7:
            case 52:
            case 53:
            case 39:
            case 38:
            case 40:
            case 37:
            case 49:
            case 48:
            case 14:
            case 24:
            case 19:
            case 27:
            case 30:
            case 36:
            case 62:
            case 26:
            case 29:
            case 32:
            case 35:
            case 57:
            case 58:
            case 50:
            case 12:
            case 13:
            case 20:
            case 18:
            case 59:
            case 47:
            case 15:
            case 0:
            case 61:
            case 56:
            case 25:
            case 28:
            case 31:
            case 34:
                throw Error("Unsupported endpoint");
            default:
                tc(a, "Unknown endpoint")
        }
    };

    function jv(a) {
        switch (a) {
            case 0:
                break;
            case 9:
                return "e4";
            case 6:
                return "e5";
            case 14:
                return "e6";
            default:
                return "e7"
        }
    };
    var kv = "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(" "),
        lv = "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(" ");

    function mv(a, b) {
        if (!b._tag_metadata) {
            for (var c = {}, d = 0, e = 0; e < a.length; e++) d += nv(a[e], b, c) ? 1 : 0;
            d > 0 && (b._tag_metadata = c)
        }
    }

    function nv(a, b, c) {
        var d = b[a];
        if (d === void 0 || d === null) return !1;
        c[a] = Array.isArray(d) ? d.map(function() {
            return {
                mode: "c"
            }
        }) : {
            mode: "c"
        };
        return !0
    }

    function ov(a) {
        if (P(178) && a) {
            mv(kv, a);
            for (var b = ub(a.address), c = 0; c < b.length; c++) {
                var d = b[c];
                d && mv(lv, d)
            }
            var e = a.home_address;
            e && mv(lv, e)
        }
    }

    function pv(a, b, c) {
        function d(f, g) {
            g = String(g).substring(0, 100);
            e.push("" + f + encodeURIComponent(g))
        }
        if (!c) return "";
        var e = [];
        d("i", String(a));
        d("f", b);
        c.mode && d("m", c.mode);
        c.isPreHashed && d("p", "1");
        c.rawLength && d("r", String(c.rawLength));
        c.normalizedLength && d("n", String(c.normalizedLength));
        c.location && d("l", c.location);
        c.selector && d("s", c.selector);
        return e.join(".")
    };

    function qv() {
        this.blockSize = -1
    };

    function rv(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.P = Ea.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.T = this.H = 0;
        this.C = [];
        this.la = a;
        this.V = b;
        this.sa = Ea.Int32Array ? new Int32Array(64) : Array(64);
        sv === void 0 && (Ea.Int32Array ? sv = new Int32Array(tv) : sv = tv);
        this.reset()
    }
    Fa(rv, qv);
    for (var uv = [], vv = 0; vv < 63; vv++) uv[vv] = 0;
    var wv = [].concat(128, uv);
    rv.prototype.reset = function() {
        this.T = this.H = 0;
        var a;
        if (Ea.Int32Array) a = new Int32Array(this.V);
        else {
            var b = this.V,
                c = b.length;
            if (c > 0) {
                for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
                a = d
            } else a = []
        }
        this.C = a
    };
    var xv = function(a) {
        for (var b = a.P, c = a.sa, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (var f = 16; f < 64; f++) {
            var g = c[f - 15] | 0,
                h = c[f - 2] | 0;
            c[f] = ((c[f - 16] | 0) + ((g >>> 7 | g << 25) ^ (g >>> 18 | g << 14) ^ g >>> 3) | 0) + ((c[f - 7] | 0) + ((h >>> 17 | h << 15) ^ (h >>> 19 | h << 13) ^ h >>> 10) | 0) | 0
        }
        for (var l = a.C[0] | 0, n = a.C[1] | 0, p = a.C[2] | 0, q = a.C[3] | 0, r = a.C[4] | 0, u = a.C[5] | 0, t = a.C[6] | 0, v = a.C[7] | 0, x = 0; x < 64; x++) {
            var y = ((l >>> 2 | l << 30) ^ (l >>> 13 | l << 19) ^ (l >>> 22 | l << 10)) + (l & n ^ l & p ^ n & p) | 0,
                A = (v + ((r >>> 6 | r << 26) ^ (r >>> 11 | r << 21) ^ (r >>> 25 | r << 7)) |
                    0) + (((r & u ^ ~r & t) + (sv[x] | 0) | 0) + (c[x] | 0) | 0) | 0;
            v = t;
            t = u;
            u = r;
            r = q + A | 0;
            q = p;
            p = n;
            n = l;
            l = A + y | 0
        }
        a.C[0] = a.C[0] + l | 0;
        a.C[1] = a.C[1] + n | 0;
        a.C[2] = a.C[2] + p | 0;
        a.C[3] = a.C[3] + q | 0;
        a.C[4] = a.C[4] + r | 0;
        a.C[5] = a.C[5] + u | 0;
        a.C[6] = a.C[6] + t | 0;
        a.C[7] = a.C[7] + v | 0
    };
    rv.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.H;
        if (typeof a === "string")
            for (; c < b;) this.P[d++] = a.charCodeAt(c++), d == this.blockSize && (xv(this), d = 0);
        else {
            var e, f = typeof a;
            e = f != "object" ? f : a ? Array.isArray(a) ? "array" : f : "null";
            if (e == "array" || e == "object" && typeof a.length == "number")
                for (; c < b;) {
                    var g = a[c++];
                    if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0))) throw Error("message must be a byte array");
                    this.P[d++] = g;
                    d == this.blockSize && (xv(this), d = 0)
                } else throw Error("message must be string or array");
        }
        this.H = d;
        this.T += b
    };
    rv.prototype.digest = function() {
        var a = [],
            b = this.T * 8;
        this.H < 56 ? this.update(wv, 56 - this.H) : this.update(wv, this.blockSize - (this.H - 56));
        for (var c = 63; c >= 56; c--) this.P[c] = b & 255, b /= 256;
        xv(this);
        for (var d = 0, e = 0; e < this.la; e++)
            for (var f = 24; f >= 0; f -= 8) a[d++] = this.C[e] >> f & 255;
        return a
    };
    var tv = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        sv;

    function yv() {
        rv.call(this, 8, zv)
    }
    Fa(yv, rv);
    var zv = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var Av = /^[0-9A-Fa-f]{64}$/;

    function Bv(a) {
        try {
            return (new TextEncoder).encode(a)
        } catch (b) {
            return Tb(a)
        }
    }

    function Cv(a) {
        var b = w;
        if (a === "" || a === "e0") return Promise.resolve(a);
        var c;
        if ((c = b.crypto) == null ? 0 : c.subtle) {
            if (Av.test(a)) return Promise.resolve(a);
            try {
                var d = Bv(a);
                return b.crypto.subtle.digest("SHA-256", d).then(function(e) {
                    return Dv(e, b)
                }).catch(function() {
                    return "e2"
                })
            } catch (e) {
                return Promise.resolve("e2")
            }
        } else return Promise.resolve("e1")
    }

    function Dv(a, b) {
        var c = Array.from(new Uint8Array(a)).map(function(d) {
            return String.fromCharCode(d)
        }).join("");
        return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    };

    function lw() {
        var a = [],
            b = Number('') || 0,
            c = Number('') || 0;
        c || (c = b / 100);
        var d = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 21,
            studyId: 21,
            experimentId: 105102050,
            controlId: 105102051,
            controlId2: 105102052,
            probability: c,
            active: d,
            ka: 0
        });
        var e =
            Number('') || 0,
            f = Number('') || 0;
        f || (f = e / 100);
        var g = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 265,
            studyId: 265,
            experimentId: 115691063,
            controlId: 115691064,
            controlId2: 115691065,
            probability: f,
            active: g,
            ka: 0
        });
        var h = Number('') || 0,
            l = Number('') || 0;
        l || (l = h / 100);
        var n = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 228,
            studyId: 228,
            experimentId: 105177154,
            controlId: 105177155,
            controlId2: 105255245,
            probability: l,
            active: n,
            ka: 0
        });
        var p = Number('') ||
            0,
            q = Number('') || 0;
        q || (q = p / 100);
        var r = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 287,
            studyId: 287,
            experimentId: 116133312,
            controlId: 116133313,
            controlId2: 116133314,
            probability: q,
            active: r,
            ka: 0
        });
        var u = Number('') ||
            0,
            t = Number('') || 0;
        t || (t = u / 100);
        var v = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 288,
            studyId: 288,
            experimentId: 116133315,
            controlId: 116133316,
            controlId2: 116133317,
            probability: t,
            active: v,
            ka: 0
        });
        var x =
            Number('') || 0,
            y = Number('0.01') || 0;
        y || (y = x / 100);
        var A = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 285,
            studyId: 285,
            experimentId: 115495938,
            controlId: 115495939,
            controlId2: 115495940,
            probability: y,
            active: A,
            ka: 0
        });
        var C = Number('') || 0,
            E = Number('') || 0;
        E || (E = C / 100);
        var H = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 286,
            studyId: 286,
            experimentId: 115495941,
            controlId: 115495942,
            controlId2: 115495943,
            probability: E,
            active: H,
            ka: 0
        });
        var J = Number('') || 0,
            O = Number('') || 0;
        O || (O = J / 100);
        var ba = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 219,
            studyId: 219,
            experimentId: 104948811,
            controlId: 104948812,
            controlId2: 0,
            probability: O,
            active: ba,
            ka: 0
        });
        var W = Number('') || 0,
            N = Number('') || 0;
        N || (N = W / 100);
        var S = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 220,
            studyId: 220,
            experimentId: 104948813,
            controlId: 104948814,
            controlId2: 0,
            probability: N,
            active: S,
            ka: 0
        });
        var la = Number('') || 0,
            ja = Number('0.5') || 0;
        ja || (ja = la / 100);
        var V = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 255,
            studyId: 255,
            experimentId: 105391252,
            controlId: 105391253,
            controlId2: 105446120,
            probability: ja,
            active: V,
            ka: 0
        });
        var U = Number('') || 0,
            ha = Number('') || 0;
        ha || (ha = U / 100);
        var ta = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 235,
            studyId: 235,
            experimentId: 105357150,
            controlId: 105357151,
            controlId2: 0,
            probability: ha,
            active: ta,
            ka: 1
        });
        var pa = Number('') || 0,
            Ma = Number('0') || 0;
        Ma || (Ma = pa / 100);
        var Sa = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 170,
            studyId: 170,
            experimentId: 116024733,
            controlId: 116024734,
            controlId2: 116024735,
            probability: Ma,
            active: Sa,
            ka: 0
        });
        var mb = Number('') || 0,
            cb = Number('') || 0;
        cb || (cb = mb / 100);
        var Ya = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 203,
            studyId: 203,
            experimentId: 115480710,
            controlId: 115480709,
            controlId2: 115489982,
            probability: cb,
            active: Ya,
            ka: 0
        });
        var Pb = Number('') || 0,
            Qb = Number('') || 0;
        Qb || (Qb = Pb / 100);
        var ke = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 178,
            studyId: 178,
            experimentId: 115958700,
            controlId: 115958701,
            controlId2: 115958702,
            probability: Qb,
            active: ke,
            ka: 0
        });
        var Ig = Number('') || 0,
            le = Number('') || 0;
        le || (le = Ig / 100);
        var Qe = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 197,
            studyId: 197,
            experimentId: 105113532,
            controlId: 105113531,
            controlId2: 0,
            probability: le,
            active: Qe,
            ka: 0
        });
        var Xk = Number('') ||
            0,
            vi = Number('0.2') || 0;
        vi || (vi = Xk / 100);
        var Yk = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 243,
            studyId: 243,
            experimentId: 115616985,
            controlId: 115616986,
            controlId2: 0,
            probability: vi,
            active: Yk,
            ka: 0
        });
        var To = Number('') || 0,
            wi = Number('') ||
            0;
        wi || (wi = To / 100);
        var Zk = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 277,
            studyId: 277,
            experimentId: 116130039,
            controlId: 116130040,
            controlId2: 0,
            probability: wi,
            active: Zk,
            ka: 0
        });
        var Uo = Number('') || 0,
            xi = Number('1') ||
            0;
        xi || (xi = Uo / 100);
        var Vo = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 254,
            studyId: 254,
            experimentId: 115583767,
            controlId: 115583768,
            controlId2: 115583769,
            probability: xi,
            active: Vo,
            ka: 0
        });
        var $k = Number('') || 0,
            yi = Number('') ||
            0;
        yi || (yi = $k / 100);
        var Wo = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 253,
            studyId: 253,
            experimentId: 115583770,
            controlId: 115583771,
            controlId2: 115583772,
            probability: yi,
            active: Wo,
            ka: 0
        });
        var HJ = Number('') || 0,
            Xo = Number('') ||
            0;
        Xo || (Xo = HJ / 100);
        var IJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 266,
            studyId: 266,
            experimentId: 115718529,
            controlId: 115718530,
            controlId2: 115718531,
            probability: Xo,
            active: IJ,
            ka: 0
        });
        var JJ = Number('') || 0,
            Yo = Number('') ||
            0;
        Yo || (Yo = JJ / 100);
        var KJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 267,
            studyId: 267,
            experimentId: 115718526,
            controlId: 115718527,
            controlId2: 115718528,
            probability: Yo,
            active: KJ,
            ka: 0
        });
        var LJ = Number('') || 0,
            Zo = Number('') ||
            0;
        Zo || (Zo = LJ / 100);
        var MJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 259,
            studyId: 259,
            experimentId: 105322302,
            controlId: 105322303,
            controlId2: 105322304,
            probability: Zo,
            active: MJ,
            ka: 0
        });
        var NJ = Number('') || 0,
            $o = Number('') || 0;
        $o || ($o = NJ / 100);
        var OJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 249,
            studyId: 249,
            experimentId: 105440521,
            controlId: 105440522,
            controlId2: 0,
            focused: !0,
            probability: $o,
            active: OJ,
            ka: 0
        });
        var PJ = Number('') || 0,
            ap = Number('0.5') || 0;
        ap || (ap = PJ / 100);
        var QJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 195,
            studyId: 195,
            experimentId: 104527906,
            controlId: 104527907,
            controlId2: 104898015,
            probability: ap,
            active: QJ,
            ka: 1
        });
        var RJ = Number('') || 0,
            bp = Number('0.5') || 0;
        bp || (bp = RJ / 100);
        var SJ = function() {
            var ma = !1;
            return ma
        }();
        a.push({
            na: 196,
            studyId: 196,
            experimentId: 104528500,
            controlId: 104528501,
            controlId2: 104898016,
            probability: bp,
            active: SJ,
            ka: 0
        });
        var TJ = Number('') || 0,
            cp = Number('') || 0;
        cp || (cp = TJ / 100);
        var UJ = function() {
            var ma = !1;
            ma = !0;
            return ma
        }();
        a.push({
            na: 229,
            studyId: 229,
            experimentId: 105359938,
            controlId: 105359937,
            controlId2: 105359936,
            probability: cp,
            active: UJ,
            ka: 0
        });
        return a
    };
    var mw = {};

    function nw(a) {
        var b = a,
            c = a = ow[b.studyId] ? na(Object, "assign").call(Object, {}, b, {
                active: !0
            }) : b;
        c.controlId2 && c.probability <= .25 || (c = na(Object, "assign").call(Object, {}, c, {
            controlId2: 0
        }));
        Ii[c.studyId] = c;
        a.focused && (mw[a.studyId] = !0);
        if (a.ka === 1) {
            var d = a.studyId;
            pw(lm(gm.Z.Mi, {}), d);
            qw(d) && sk(d)
        } else if (a.ka === 0) {
            var e = a.studyId;
            pw(rw, e);
            qw(e) && sk(e)
        }
    }

    function pw(a, b) {
        if (Ii[b]) {
            var c = Ii[b],
                d = c.experimentId,
                e = c.probability;
            if (!(a.studies || {})[b]) {
                var f = a.studies || {};
                f[b] = !0;
                a.studies = f;
                Ii[b].active || (Ii[b].probability > .5 ? Mi(a, d, b) : e <= 0 || e > 1 || Li.Xr(a, b))
            }
        }
        if (!mw[b]) {
            var g = Oi(a, b);
            g && Ri.C.H.add(g)
        }
    }
    var rw = {};

    function qw(a) {
        return Ni(lm(gm.Z.Mi, {}), a) || Ni(rw, a)
    }

    function sw(a) {
        var b = R(a, Q.A.zi) || [];
        return ok(b)
    }
    var ow = {};

    function tw() {
        var a = !1;
        if (a) {
            var b, c, d = ((b = w) == null ? void 0 : (c = b.location) == null ? void 0 : c.hash) || "";
            if (d[0] === "#" && d[1] === "_" && d[2] === "t" && d[3] === "e" && d[4] === "=") {
                var e = d.substring(5);
                if (e)
                    for (var f = m(e.split("~")), g = f.next(); !g.done; g = f.next()) {
                        var h = Number(g.value);
                        h && (ow[h] = !0, sk(h))
                    }
            }
        }
        for (var l = m(lw()), n = l.next(); !n.done; n = l.next()) nw(n.value);
        for (var p = [], q =
                m(og(56) || []), r = q.next(); !r.done; r = q.next()) {
            var u = r.value,
                t = {
                    studyId: u[1],
                    active: !!u[2],
                    probability: u[3] || 0,
                    experimentId: u[4] || 0,
                    controlId: u[5] || 0,
                    controlId2: u[6] || 0
                },
                v = 0;
            switch (u[7]) {
                case 2:
                    v = 1;
                    break;
                case 1:
                case 0:
                    v = 0
            }
            var x;
            a: switch (t.studyId) {
                case 249:
                    x = !0;
                    break a;
                default:
                    x = !1
            }
            var y = na(Object, "assign").call(Object, {}, t, {
                ka: v,
                focused: x
            });
            (y.active || y.experimentId && y.controlId) && p.push(y)
        }
        for (var A = m(p), C = A.next(); !C.done; C = A.next()) nw(C.value)
    };

    function uw(a, b) {
        b && zb(b, function(c, d) {
            typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d))
        })
    };

    function vw(a, b) {
        var c = Hu(a, K.m.Gc);
        if (c && typeof c === "object")
            for (var d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value,
                    g = c[f];
                g !== void 0 && (g === null && (g = ""), b["gap." + f] = String(g))
            }
    };

    function ww(a, b, c, d) {
        if (vn()) {
            var e = b.D;
            Cn({
                targetId: d || [b.target.destinationId],
                request: {
                    url: a,
                    parameterEncoding: 2,
                    endpoint: c
                },
                hb: {
                    eventId: e.eventId,
                    priorityId: e.priorityId
                },
                bj: {
                    eventId: R(b, Q.A.Ye),
                    priorityId: R(b, Q.A.Ze)
                }
            })
        }
    };
    var Kw = {};
    Kw.O = or.O;
    var Lw = {
            Xs: "L",
            Vp: "S",
            ot: "Y",
            Bs: "B",
            Ps: "E",
            Ts: "I",
            kt: "TC",
            Ss: "HTC"
        },
        Mw = {
            Vp: "S",
            Os: "V",
            Es: "E",
            jt: "tag"
        },
        Nw = {},
        Ow = (Nw[Kw.O.Vi] = "6", Nw[Kw.O.Wi] = "5", Nw[Kw.O.Ui] = "7", Nw);

    function Pw() {
        function a(c, d) {
            var e = pb(jb[d] || []);
            e && b.push([c, e])
        }
        var b = [];
        a("u", "GTM");
        a("ut", "TAGGING");
        a("h", "HEALTH");
        return b
    };
    var Qw = !1;

    function ix(a) {}

    function jx(a) {}

    function kx() {}

    function lx(a) {}

    function mx(a) {}

    function nx(a) {}

    function ox() {}

    function px(a, b) {}

    function qx(a, b, c) {}

    function rx() {};
    var sx = Object.freeze({
        cache: "no-store",
        credentials: "include",
        method: "GET",
        keepalive: !0,
        redirect: "follow"
    });

    function tx(a, b, c, d, e, f, g, h) {
        var l = na(Object, "assign").call(Object, {}, sx);
        c && (l.body = c, l.method = "POST");
        na(Object, "assign").call(Object, l, e);
        h == null || wl(h);
        w.fetch(b, l).then(function(n) {
            h == null || xl(h);
            if (!n.ok) g == null || g();
            else if (n.body) {
                var p = n.body.getReader(),
                    q = new TextDecoder;
                return new Promise(function(r) {
                    function u() {
                        p.read().then(function(t) {
                            var v;
                            v = t.done;
                            var x = q.decode(t.value, {
                                stream: !v
                            });
                            ux(d, x);
                            v ? (f == null || f(), r()) : u()
                        }).catch(function() {
                            r()
                        })
                    }
                    u()
                })
            }
        }).catch(function() {
            h == null || xl(h);
            g ? g() : P(128) && (b += "&_z=retryFetch", c ? zl(a, b, c) : yl(a, b))
        })
    };
    var vx = function(a) {
            this.P = a;
            this.C = ""
        },
        wx = function(a, b) {
            a.H = b;
            return a
        },
        ux = function(a, b) {
            b = a.C + b;
            for (var c = b.indexOf("\n\n"); c !== -1;) {
                var d = a,
                    e;
                a: {
                    var f = m(b.substring(0, c).split("\n")),
                        g = f.next().value,
                        h = f.next().value;
                    if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0) try {
                        e = JSON.parse(h.substring(h.indexOf(":") + 1));
                        break a
                    } catch (l) {}
                    e = void 0
                }
                xx(d, e);
                b = b.substring(c + 2);
                c = b.indexOf("\n\n")
            }
            a.C = b
        },
        yx = function(a, b) {
            return function() {
                if (b.fallback_url && b.fallback_url_method) {
                    var c = {};
                    xx(a, (c[b.fallback_url_method] = [b.fallback_url], c.options = {}, c))
                }
            }
        },
        xx = function(a, b) {
            b && (zx(b.send_pixel, b.options, a.P), zx(b.create_iframe, b.options, a.T), zx(b.fetch, b.options, a.H))
        };

    function Ax(a) {
        var b = a.search;
        return a.protocol + "//" + a.hostname + a.pathname + (b ? b + "&richsstsse" : "?richsstsse")
    }

    function zx(a, b, c) {
        if (a && c) {
            var d = a || [];
            if (Array.isArray(d))
                for (var e = sd(b) ? b : {}, f = m(d), g = f.next(); !g.done; g = f.next()) c(g.value, e)
        }
    };
    var zg;

    function Bx() {
        var a = data.permissions || {};
        zg = new Fg(D(5), a)
    }

    function Cx(a, b) {
        Ag(a, b)
    };
    var Dx = pg(57, 5),
        Ex = pg(58, 50),
        Fx = wb();
    var Hx = function(a, b) {
            a && (Gx("sid", a.targetId, b), Gx("cc", a.clientCount, b), Gx("tl", a.totalLifeMs, b), Gx("hc", a.heartbeatCount, b), Gx("cl", a.clientLifeMs, b))
        },
        Gx = function(a, b, c) {
            b != null && c.push(a + "=" + b)
        },
        Ix = function() {
            var a = z.referrer;
            if (a) {
                var b;
                return jj(pj(a), "host") === ((b = w.location) == null ? void 0 : b.host) ? 1 : 2
            }
            return 0
        },
        Jx = "https://" + D(21) + "/a?",
        Lx = function() {
            this.V = Kx;
            this.P = 0
        };
    Lx.prototype.H = function(a, b, c, d) {
        var e = Ix(),
            f, g = [];
        f = w === w.top && e !== 0 && b ?
            (b == null ? void 0 : b.clientCount) > 1 ? e === 2 ? 1 : 2 : e === 2 ? 0 : 3 : 4;
        a && Gx("si", a.wg, g);
        Gx("m", 0, g);
        Gx("iss", f, g);
        Gx("if", c, g);
        Hx(b, g);
        d && Gx("fm", encodeURIComponent(d.substring(0, Ex)), g);
        this.T(g);
    };
    Lx.prototype.C = function(a, b, c, d, e) {
        var f = [];
        Gx("m", 1, f);
        Gx("s", a, f);
        Gx("po", Ix(), f);
        b && (Gx("st", b.state, f), Gx("si", b.wg, f), Gx("sm", b.Eg, f));
        Hx(c, f);
        Gx("c", d, f);
        e && Gx("fm", encodeURIComponent(e.substring(0, Ex)), f);
        this.T(f);
    };
    Lx.prototype.T = function(a) {
        a = a === void 0 ? [] : a;
        !Lk || this.P >= Dx || (Gx("pid", Fx, a), Gx("bc", ++this.P, a), a.unshift("ctid=" + D(5) + "&t=s"), this.V("" + Jx + a.join("&")))
    };

    function Mx(a) {
        return a.performance && a.performance.now() || Date.now()
    }
    var Ox = function(a, b) {
        var c = w,
            d = Nx,
            e;
        var f = function(g, h, l) {
            l = l === void 0 ? {
                rn: function() {},
                sn: function() {},
                qn: function() {},
                onFailure: function() {}
            } : l;
            this.fq = g;
            this.C = h;
            this.P = l;
            this.la = this.sa = this.heartbeatCount = this.cq = 0;
            this.Bh = !1;
            this.H = {};
            this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
            this.state = 0;
            this.wg = Mx(this.C);
            this.Eg = Mx(this.C);
            this.V = 10
        };
        f.prototype.init = function() {
            this.T(1);
            this.nb()
        };
        f.prototype.getState = function() {
            return {
                state: this.state,
                wg: Math.round(Mx(this.C) - this.wg),
                Eg: Math.round(Mx(this.C) - this.Eg)
            }
        };
        f.prototype.T = function(g) {
            this.state !== g && (this.state = g, this.Eg = Mx(this.C))
        };
        f.prototype.Lm = function() {
            return String(this.cq++)
        };
        f.prototype.nb = function() {
            var g = this;
            this.heartbeatCount++;
            this.yb({
                type: 0,
                clientId: this.id,
                requestId: this.Lm(),
                maxDelay: this.Ch()
            }, function(h) {
                if (h.type === 0) {
                    var l;
                    if (((l = h.failure) == null ? void 0 : l.failureType) != null)
                        if (h.stats && (g.stats = h.stats), g.la++, h.isDead || g.la > d.om) {
                            var n = h.isDead && h.failure.failureType;
                            g.V = n || 10;
                            g.T(4);
                            g.bq();
                            var p, q;
                            (q = (p = g.P).qn) == null || q.call(p, {
                                failureType: n || 10,
                                data: h.failure.data
                            })
                        } else g.T(3), g.Qm();
                    else {
                        if (g.heartbeatCount > h.stats.heartbeatCount + d.om) {
                            g.heartbeatCount = h.stats.heartbeatCount;
                            var r, u;
                            (u = (r = g.P).onFailure) == null || u.call(r, {
                                failureType: 13
                            })
                        }
                        g.stats = h.stats;
                        var t = g.state;
                        g.T(2);
                        if (t !== 2)
                            if (g.Bh) {
                                var v, x;
                                (x = (v = g.P).sn) == null || x.call(v)
                            } else {
                                g.Bh = !0;
                                var y, A;
                                (A = (y = g.P).rn) == null || A.call(y)
                            }
                        g.la = 0;
                        g.gq();
                        g.Qm()
                    }
                }
            })
        };
        f.prototype.Ch = function() {
            return this.state ===
                2 ? d.Fp : d.Zp
        };
        f.prototype.Qm = function() {
            var g = this;
            this.C.setTimeout(function() {
                g.nb()
            }, Math.max(0, this.Ch() - (Mx(this.C) - this.sa)))
        };
        f.prototype.kq = function(g, h, l) {
            var n = this;
            this.yb({
                type: 1,
                clientId: this.id,
                requestId: this.Lm(),
                command: g
            }, function(p) {
                if (p.type === 1)
                    if (p.result) h(p.result);
                    else {
                        var q, r, u, t = {
                                failureType: (u = (q = p.failure) == null ? void 0 : q.failureType) != null ? u : 12,
                                data: (r = p.failure) == null ? void 0 : r.data
                            },
                            v, x;
                        (x = (v = n.P).onFailure) == null || x.call(v, t);
                        l(t)
                    }
            })
        };
        f.prototype.yb = function(g, h) {
            var l =
                this;
            if (this.state === 4) g.failure = {
                failureType: this.V
            }, h(g);
            else {
                var n = this.state !== 2 && g.type !== 0,
                    p = g.requestId,
                    q, r = this.C.setTimeout(function() {
                        var t = l.H[p];
                        t && (Hm(6), l.cg(t, 7))
                    }, (q = g.maxDelay) != null ? q : d.lo),
                    u = {
                        request: g,
                        En: h,
                        yn: n,
                        Br: r
                    };
                this.H[p] = u;
                n || this.sendRequest(u)
            }
        };
        f.prototype.sendRequest = function(g) {
            this.sa = Mx(this.C);
            g.yn = !1;
            this.fq(g.request)
        };
        f.prototype.gq = function() {
            for (var g = m(Object.keys(this.H)), h = g.next(); !h.done; h = g.next()) {
                var l = this.H[h.value];
                l.yn && this.sendRequest(l)
            }
        };
        f.prototype.bq =
            function() {
                for (var g = m(Object.keys(this.H)), h = g.next(); !h.done; h = g.next()) this.cg(this.H[h.value], this.V)
            };
        f.prototype.cg = function(g, h) {
            this.Rc(g);
            var l = g.request;
            l.failure = {
                failureType: h
            };
            g.En(l)
        };
        f.prototype.Rc = function(g) {
            delete this.H[g.request.requestId];
            this.C.clearTimeout(g.Br)
        };
        f.prototype.ar = function(g) {
            this.sa = Mx(this.C);
            var h = this.H[g.requestId];
            if (h) this.Rc(h), h.En(g);
            else {
                var l, n;
                (n = (l = this.P).onFailure) == null || n.call(l, {
                    failureType: 14
                })
            }
        };
        e = new f(a, c, b);
        return e
    };
    var Px;
    var Qx = function() {
            Px || (Px = new Lx);
            return Px
        },
        Kx = function(a) {
            dm(fm(Gl.aa.Qc), function() {
                Rc(a)
            })
        },
        Rx = function(a) {
            var b = a.substring(0, a.indexOf("/_/service_worker"));
            return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "")
        },
        Sx = function(a) {
            var b = a,
                c, d = ng(11);
            d = ng(10);
            c = d;
            b ? (b.charAt(b.length - 1) !== "/" && (b += "/"), a = b + c) : a = "https://www.googletagmanager.com/static/service_worker/" + c + "/";
            var e;
            try {
                e = new URL(a)
            } catch (f) {
                return null
            }
            return e.protocol !==
                "https:" ? null : e
        },
        Tx = function(a) {
            var b = w.location.origin;
            if (!b) return null;
            (P(432) ? uj() : uj() && !a) && (a = "" + b + vj() + "/_/service_worker");
            return Sx(a)
        },
        Ux = function(a) {
            var b = km(gm.Z.Am);
            return b && b[a]
        },
        Nx = {
            Zp: pg(53, 500),
            Fp: pg(54, 5E3),
            om: pg(8, 20),
            lo: pg(55, 5E3)
        },
        Vx = function(a, b, c) {
            var d = this;
            this.H = b;
            this.V = this.T = !1;
            this.la = null;
            this.initTime = Math.round(Gb());
            this.C = 15;
            this.P = this.Cq(a);
            w.setTimeout(function() {
                d.initialize()
            }, 1E3);
            Uc(function() {
                d.qr(a, c)
            })
        };
    k = Vx.prototype;
    k.delegate = function(a, b, c) {
        this.getState() !==
            2 ? (this.H.C(this.C, {
                state: this.getState(),
                wg: this.initTime,
                Eg: Math.round(Gb()) - this.initTime
            }, void 0, a.commandType), c({
                failureType: this.C
            })) : this.P.kq(a, b, c)
    };
    k.getState = function() {
        return this.P.getState().state
    };
    k.qr = function(a, b) {
        var c = w.location.origin,
            d = this,
            e = Pc();
        try {
            var f = e.contentDocument.createElement("iframe"),
                g = a.pathname,
                h = g[g.length - 1] === "/" ? a.toString() : a.toString() + "/",
                l = a.origin !== "https://www.googletagmanager.com" ? Rx(g) : "",
                n;
            P(133) && (n = {
                sandbox: "allow-same-origin allow-scripts"
            });
            Pc(h + "sw_iframe.html?origin=" + encodeURIComponent(c) + l + (b ? "&e=1" : ""), void 0, n, void 0, f);
            var p = function() {
                e.contentDocument.body.appendChild(f);
                f.addEventListener("load", function() {
                    d.la = f.contentWindow;
                    e.contentWindow.addEventListener("message", function(q) {
                        q.origin === a.origin && d.P.ar(q.data)
                    });
                    d.initialize()
                })
            };
            e.contentDocument.readyState === "complete" ? p() : e.contentWindow.addEventListener("load", function() {
                p()
            })
        } catch (q) {
            e.parentElement.removeChild(e), this.C = 11, this.H.H(void 0, void 0, this.C, q.toString())
        }
    };
    k.Cq = function(a) {
        var b = this,
            c = Ox(function(d) {
                var e;
                (e = b.la) == null || e.postMessage(d, a.origin)
            }, {
                rn: function() {
                    b.T = !0;
                    b.H.H(c.getState(), c.stats)
                },
                sn: function() {},
                qn: function(d) {
                    b.T ? (b.C = (d == null ? void 0 : d.failureType) || 10, b.H.C(b.C, c.getState(), c.stats, void 0, d == null ? void 0 : d.data)) : (b.C = (d == null ? void 0 : d.failureType) || 4, b.H.H(c.getState(), c.stats, b.C, d == null ? void 0 : d.data))
                },
                onFailure: function(d) {
                    b.C = d.failureType;
                    b.H.C(b.C, c.getState(), c.stats, d.command, d.data)
                }
            });
        return c
    };
    k.initialize = function() {
        this.V ||
            this.P.init();
        this.V = !0
    };

    function Wx() {
        var a = Cg(zg.C, "", function() {
            return {}
        });
        try {
            return a("internal_sw_allowed"), !0
        } catch (b) {
            return !1
        }
    }

    function Xx(a) {
        var b, c, d = a === void 0 ? {} : a;
        b = d.Vr;
        c = d.Ln === void 0 ? !1 : d.Ln;
        var e = Tx(b);
        if (e === null || !Wx() || P(168) || Ux(e.origin)) return;
        if (!Cc()) {
            Qx().H(void 0, void 0, 6);
            return
        }
        var f = new Vx(e, Qx(), c);
        lm(gm.Z.Am, {})[e.origin] = f;
    }
    var Yx = function(a, b, c, d) {
        var e;
        if ((e = Ux(a)) == null || !e.delegate) {
            var f = Cc() ? 16 : 6;
            Qx().C(f, void 0, void 0, b.commandType);
            d({
                failureType: f
            });
            return
        }
        Ux(a).delegate(b, c, d);
    };

    function Zx(a, b, c, d, e) {
        var f = P(277) ? Tx() : Sx();
        if (f === null) {
            d(Cc() ? 16 : 6);
            return
        }
        var g, h = (g = Ux(f.origin)) == null ? void 0 : g.initTime,
            l = Math.round(Gb()),
            n = {
                commandType: 0,
                params: {
                    url: a,
                    method: 0,
                    templates: b,
                    body: "",
                    processResponse: !1,
                    sinceInit: h ? l - h : void 0
                }
            };
        e && (n.params.encryptionKeyString = e);
        Yx(f.origin, n, function(p) {
            c(p)
        }, function(p) {
            d(p.failureType)
        });
    }

    function $x(a, b, c, d) {
        var e = Tx(a);
        if (e === null) {
            d("_is_sw=f" + (Cc() ? 16 : 6) + "te");
            return
        }
        var f = b ? 1 : 0,
            g = Math.round(Gb()),
            h, l = (h = Ux(e.origin)) == null ? void 0 : h.initTime,
            n = l ? g - l : void 0;
        Yx(e.origin, {
            commandType: 0,
            params: {
                url: a,
                method: f,
                templates: c,
                body: b || "",
                processResponse: !0,
                reportEarlySuccess: P(412),
                sinceInit: n,
                attributionReporting: !0,
                referer: w.location.href
            }
        }, function() {}, function(p) {
            var q = "_is_sw=f" + p.failureType,
                r, u = (r = Ux(e.origin)) == null ? void 0 : r.getState();
            u !== void 0 && (q += "s" + u);
            d(n ? q + ("t" + n) : q + "te")
        });
    };
    var ay = function(a, b) {
            this.Fr = a;
            this.timeoutMs = b;
            this.Wa = void 0
        },
        wl = function(a) {
            a.Wa || (a.Wa = setTimeout(function() {
                a.Fr();
                a.Wa = void 0
            }, a.timeoutMs))
        },
        xl = function(a) {
            a.Wa && (clearTimeout(a.Wa), a.Wa = void 0)
        };

    function Cy() {
        return $n("dedupe_gclid", function() {
            return Pr()
        })
    };
    var Hy = {
        Li: {
            Yn: "1",
            rp: "2",
            Sp: "3"
        }
    };

    function My(a, b, c, d) {
        var e = Oc(),
            f;
        if (e === 1) a: {
            var g = D(3);g = g.toLowerCase();
            for (var h = "https://" + g, l = "http://" + g, n = 1, p = z.getElementsByTagName("script"), q = 0; q < p.length && q < 100; q++) {
                var r = p[q].src;
                if (r) {
                    r = r.toLowerCase();
                    if (r.indexOf(l) === 0) {
                        f = 3;
                        break a
                    }
                    n === 1 && r.indexOf(h) === 0 && (n = 2)
                }
            }
            f = n
        }
        else f = e;
        return (f === 2 || d || "http:" !== w.location.protocol ? a : b) + c
    };

    function Ny(a, b, c, d, e) {
        if (!Yj(a)) {
            d.loadExperiments = Ti();
            bk(a, d, e);
            var f = Oy(a),
                g = function() {
                    Ij().container[a] && (Ij().container[a].state = 3);
                    Py()
                },
                h = {
                    destinationId: a,
                    endpoint: 0
                };
            if (uj()) Cl(h, vj() + "/" + Qy(f), void 0, g);
            else {
                var l = Lb(a, "GTM-"),
                    n = yj(),
                    p = c ? "/gtag/js" : "/gtm.js",
                    q = Ry(b, p + f);
                if (!q) {
                    var r = D(3) + p;
                    n && Ec && l && (r = Ec.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
                    q = My("https://", "http://", r + f)
                }
                Cl(h, q, void 0, g)
            }
        }
    }

    function Py() {
        ck() || zb(dk(), function(a, b) {
            Sy(a, b.transportUrl, b.context);
            M(92)
        })
    }

    function Sy(a, b, c, d) {
        if (!ak(a))
            if (c.loadExperiments || (c.loadExperiments = Ti()), ck()) {
                var e = Ij(),
                    f = Hj(a);
                f ? f.state = 0 : (f = {
                    state: 0,
                    transportUrl: b,
                    context: c,
                    parent: Tj()
                }, e.destinationArray[a] = [f]);
                Jj({
                    ctid: a,
                    isDestination: !0
                }, d);
                M(91)
            } else {
                var g = Ij(),
                    h = Hj(a);
                h ? h.state = 1 : (h = {
                    context: c,
                    state: 1,
                    parent: Tj()
                }, g.destinationArray[a] = [h]);
                Jj({
                    ctid: a,
                    isDestination: !0
                }, d);
                var l = {
                    destinationId: a,
                    endpoint: 0
                };
                if (uj()) {
                    var n = "gtd" + Oy(a, !0);
                    Cl(l, vj() + "/" + Qy(n))
                } else {
                    var p = "/gtag/destination" + Oy(a, !0),
                        q = Ry(b, p);
                    q || (q =
                        My("https://", "http://", D(3) + p));
                    Cl(l, q)
                }
            }
    }

    function Oy(a, b) {
        b = b === void 0 ? !1 : b;
        var c = "?id=" + encodeURIComponent(a),
            d = D(19);
        d !== "dataLayer" && (c += "&l=" + d);
        if (!Lb(a, "GTM-") || b) c = P(130) ? c + (uj() ? "&sc=1" : "&cx=c") : c + "&cx=c";
        var e = c,
            f, g = {
                Bn: lg(15),
                Gn: D(14)
            };
        f = pf(g);
        c = e + ("&gtm=" + f);
        yj() && (c += "&sign=" + Vi.Si);
        var h = c,
            l = lg(54);
        if (l === 1) {
            if (h += "&fps=fc", P(429)) {
                var n = D(60);
                n && (h += "&gdev=" + n)
            }
        } else l === 2 && (h += "&fps=fe");
        return h
    }

    function Qy(a) {
        if (!P(413)) return a;
        var b = D(58);
        if (!b) return M(182), a;
        try {
            return rf(a, b)
        } catch (c) {
            return M(183), a
        }
    }

    function Ry(a, b) {
        if (!P(419)) return xj(a, b);
        if ((uj() || kg(50)) && a) {
            var c = D(58),
                d = D(18);
            if (c && d) try {
                b = d + "/" + rf(b, c)
            } catch (e) {
                M(183)
            }
            return wj(a, b)
        }
    };
    var Ty = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        Uy = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        Vy = {
            cl: ["ecl"],
            customPixels: ["customScripts",
                "html"
            ],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        Wy = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");

    function Xy() {
        var a = lp("gtm.allowlist") || lp("gtm.whitelist");
        a && M(9);
        Zi && (P(212) ? a = void 0 : a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"]);
        Ty.test(w.location && w.location.hostname) && (Zi ? M(116) : (M(117), kg(48) && (a = [], window.console && window.console.log && window.console.log("GTM blocked. See go/13687728."))));
        var b = a && Kb(Db(a), Uy),
            c = lp("gtm.blocklist") || lp("gtm.blacklist");
        c || (c = lp("tagTypeBlacklist")) && M(3);
        c ? M(8) : c = [];
        Ty.test(w.location && w.location.hostname) && (c = Db(c), c.push("nonGooglePixels", "nonGoogleScripts",
            "sandboxedScripts"));
        Db(c).indexOf("google") >= 0 && M(2);
        var d = c && Kb(Db(c), Vy),
            e = {};
        return function(f) {
            var g = f && f[tf.Ta];
            if (!g || typeof g !== "string") return !0;
            g = g.replace(/^_*/, "");
            if (e[g] !== void 0) return e[g];
            var h = cj[g] || [],
                l = !0;
            if (a) {
                var n;
                if (n = l) a: {
                    if (b.indexOf(g) < 0) {
                        if (Zi && h.indexOf("cmpPartners") >= 0) {
                            n = !0;
                            break a
                        }
                        if (h && h.length > 0)
                            for (var p = 0; p < h.length; p++) {
                                if (b.indexOf(h[p]) < 0) {
                                    M(11);
                                    n = !1;
                                    break a
                                }
                            } else {
                                n = !1;
                                break a
                            }
                    }
                    n = !0
                }
                l = n
            }
            var q = !1;
            if (c) {
                var r = d.indexOf(g) >= 0;
                if (r) q = r;
                else {
                    var u = xb(d, h || []);
                    u &&
                        M(10);
                    q = u
                }
            }
            var t = !l || q;
            !t && (h.indexOf("sandboxedScripts") === -1 ? 0 : Zi && h.indexOf("cmpPartners") >= 0 ? !Yy() : b && b.indexOf("sandboxedScripts") !== -1 ? 0 : xb(d, Wy)) && (t = !0);
            return e[g] = t
        }
    }

    function Yy() {
        var a = Cg(zg.C, D(5), function() {
            return {}
        });
        try {
            return a("inject_cmp_banner"), !0
        } catch (b) {
            return !1
        }
    };
    var Zy = function() {
        this.H = 0;
        this.C = {}
    };
    Zy.prototype.addListener = function(a, b, c) {
        var d = ++this.H;
        this.C[a] = this.C[a] || {};
        this.C[a][String(d)] = {
            listener: b,
            We: c
        };
        return d
    };
    Zy.prototype.removeListener = function(a, b) {
        var c = this.C[a],
            d = String(b);
        if (!c || !c[d]) return !1;
        delete c[d];
        return !0
    };
    var az = function(a, b) {
        var c = [];
        zb($y.C[a], function(d, e) {
            c.indexOf(e.listener) < 0 && (e.We === void 0 || b.indexOf(e.We) >= 0) && c.push(e.listener)
        });
        return c
    };

    function bz(a, b, c) {
        return {
            entityType: a,
            indexInOriginContainer: b,
            nameInOriginContainer: c,
            originContainerId: D(5),
            originCId: Pj()
        }
    };

    function cz(a, b) {
        if (data.entities) {
            var c = data.entities[a];
            if (c) return c[b]
        }
    };
    var ez = function(a, b) {
            this.C = !1;
            this.T = [];
            this.eventData = {
                tags: []
            };
            this.V = !1;
            this.H = this.P = 0;
            dz(this, a, b)
        },
        fz = function(a, b, c, d) {
            if (Xi.hasOwnProperty(b) || b === "__zone") return -1;
            var e = {};
            sd(d) && (e = td(d, e));
            e.id = c;
            e.status = "timeout";
            return a.eventData.tags.push(e) - 1
        },
        gz = function(a, b, c, d) {
            var e = a.eventData.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        hz = function(a) {
            if (!a.C) {
                for (var b = a.T, c = 0; c < b.length; c++) b[c]();
                a.C = !0;
                a.T.length = 0
            }
        },
        dz = function(a, b, c) {
            b !== void 0 && a.ig(b);
            c && w.setTimeout(function() {
                    hz(a)
                },
                Number(c))
        };
    ez.prototype.ig = function(a) {
        var b = this,
            c = Ib(function() {
                Uc(function() {
                    a(D(5), b.eventData)
                })
            });
        this.C ? c() : this.T.push(c)
    };
    var iz = function(a) {
            a.P++;
            return Ib(function() {
                a.H++;
                a.V && a.H >= a.P && hz(a)
            })
        },
        jz = function(a) {
            a.V = !0;
            a.H >= a.P && hz(a)
        };
    var kz = {};

    function lz() {
        return w[mz()]
    }

    function mz() {
        return w.GoogleAnalyticsObject || "ga"
    }

    function pz() {
        var a = D(5);
    }

    function qz(a, b) {
        return function() {
            var c = lz(),
                d = c && c.getByName && c.getByName(a);
            if (d) {
                var e = d.get("sendHitTask");
                d.set("sendHitTask", function(f) {
                    var g = f.get("hitPayload"),
                        h = f.get("hitCallback"),
                        l = g.indexOf("&tid=" + b) < 0;
                    l && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                    e(f);
                    l && (f.set("hitPayload", g, !0), f.set("hitCallback", h, !0), f.set("_x_19", void 0, !0), e(f))
                })
            }
        }
    };
    var wz = ["es", "1"],
        xz = {},
        yz = {};

    function zz(a, b) {
        if (Lk) {
            var c;
            c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
            xz[a] = [
                ["e", c],
                ["eid", a]
            ];
            Gp(a)
        }
    }

    function Az(a) {
        var b = a.eventId,
            c = a.Yd;
        if (!xz[b]) return [];
        var d = [];
        yz[b] || d.push(wz);
        d.push.apply(d, za(xz[b]));
        c && (yz[b] = !0);
        return d
    };
    var Bz = {},
        Cz = {},
        Dz = {};

    function Ez(a, b, c, d) {
        Lk && P(120) && ((d === void 0 ? 0 : d) ? (Dz[b] = Dz[b] || 0, ++Dz[b]) : c !== void 0 ? (Cz[a] = Cz[a] || {}, Cz[a][b] = Math.round(c)) : (Bz[a] = Bz[a] || {}, Bz[a][b] = (Bz[a][b] || 0) + 1))
    }

    function Fz(a) {
        var b = a.eventId,
            c = a.Yd,
            d = Bz[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete Bz[b];
        return e.length ? [
            ["md", e.join(".")]
        ] : []
    }

    function Gz(a) {
        var b = a.eventId,
            c = a.Yd,
            d = Cz[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete Cz[b];
        return e.length ? [
            ["mtd", e.join(".")]
        ] : []
    }

    function Hz() {
        for (var a = [], b = m(Object.keys(Dz)), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            a.push("" + d + Dz[d])
        }
        return a.length ? [
            ["mec", a.join(".")]
        ] : []
    };
    var Iz = {};

    function Jz(a, b, c) {
        Iz[a] != null || (Iz[a] = {});
        var d;
        (d = Iz[a])[c] != null || (d[c] = {});
        Iz[a][c][b] = (Iz[a][c][b] || 0) + 1
    };
    var Kz = {},
        Lz = {};

    function Mz(a, b, c) {
        if (Lk && b) {
            var d = Ik(b);
            Kz[a] = Kz[a] || [];
            Kz[a].push(c + d);
            var e = b[tf.Ta];
            if (!e) throw Error("Error: No function name given for function call.");
            var f = (Vf[e] ? "1" : "2") + d;
            Lz[a] = Lz[a] || [];
            Lz[a].push(f);
            Gp(a)
        }
    }

    function Nz(a) {
        var b = a.eventId,
            c = a.Yd,
            d = [],
            e = Kz[b] || [];
        e.length && d.push(["tr", e.join(".")]);
        var f = Lz[b] || [];
        f.length && d.push(["ti", f.join(".")]);
        c && (delete Kz[b], delete Lz[b]);
        return d
    };

    function Oz(a, b, c) {
        c = c === void 0 ? !1 : c;
        Pz().addRestriction(0, a, b, c)
    }

    function Qz(a, b, c) {
        c = c === void 0 ? !1 : c;
        Pz().addRestriction(1, a, b, c)
    }

    function Rz() {
        var a = Pj();
        return Pz().getRestrictions(1, a)
    }
    var Sz = function() {
            this.container = {};
            this.C = {}
        },
        Tz = function(a, b) {
            var c = a.container[b];
            c || (c = {
                _entity: {
                    internal: [],
                    external: []
                },
                _event: {
                    internal: [],
                    external: []
                }
            }, a.container[b] = c);
            return c
        };
    Sz.prototype.addRestriction = function(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (!d || !this.C[b]) {
            var e = Tz(this, b);
            a === 0 ? d ? e._entity.external.push(c) : e._entity.internal.push(c) : a === 1 && (d ? e._event.external.push(c) : e._event.internal.push(c))
        }
    };
    Sz.prototype.getRestrictions = function(a, b) {
        var c = Tz(this, b);
        if (a === 0) {
            var d, e;
            return [].concat(za((c == null ? void 0 : (d = c._entity) == null ? void 0 : d.internal) || []), za((c == null ? void 0 : (e = c._entity) == null ? void 0 : e.external) || []))
        }
        if (a === 1) {
            var f, g;
            return [].concat(za((c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) || []), za((c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) || []))
        }
        return []
    };
    Sz.prototype.getExternalRestrictions = function(a, b) {
        var c = Tz(this, b),
            d, e;
        return a === 0 ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) || [] : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) || []
    };
    Sz.prototype.removeExternalRestrictions = function(a) {
        var b = Tz(this, a);
        b._event && (b._event.external = []);
        b._entity && (b._entity.external = []);
        this.C[a] = !0
    };

    function Pz() {
        return $n("r", function() {
            return new Sz
        })
    };

    function Uz(a, b, c, d) {
        var e = Tf[a],
            f = Vz(a, b, c, d);
        if (!f) return null;
        var g = gg(e[tf.Bm], c, []);
        if (g && g.length) {
            var h = g[0];
            f = Uz(h.index, {
                onSuccess: f,
                onFailure: h.gn === 1 ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function Vz(a, b, c, d) {
        function e() {
            function x() {
                Hm(3);
                var O = Gb() - J;
                bz(1, a, Tf[a][tf.sh]);
                Mz(c.id, f, "7");
                gz(c.Uc, E, "exception", O);
                P(109) && qx(c, f, Kw.O.Ui);
                H || (H = !0, h())
            }
            if (f[tf.Np]) h();
            else {
                var y = fg(f, c, []),
                    A = y[tf.Zn];
                if (A != null)
                    for (var C = 0; C < A.length; C++)
                        if (!Rn(A[C])) {
                            h();
                            return
                        }
                var E = fz(c.Uc, String(f[tf.Ta]), Number(f[tf.Eh]), y[tf.METADATA]),
                    H = !1;
                y.vtp_gtmOnSuccess = function() {
                    if (!H) {
                        H = !0;
                        var O = Gb() - J;
                        Mz(c.id, Tf[a], "5");
                        gz(c.Uc, E, "success", O);
                        P(109) && qx(c, f, Kw.O.Wi);
                        g()
                    }
                };
                y.vtp_gtmOnFailure = function() {
                    if (!H) {
                        H = !0;
                        var O = Gb() - J;
                        Mz(c.id, Tf[a], "6");
                        gz(c.Uc, E, "failure", O);
                        P(109) && qx(c, f, Kw.O.Vi);
                        h()
                    }
                };
                y.vtp_gtmTagId = f.tag_id;
                y.vtp_gtmEventId = c.id;
                c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
                Mz(c.id, f, "1");
                P(109) && px(c, f);
                var J = Gb();
                try {
                    hg(y, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (O) {
                    x(O)
                }
                P(109) && qx(c, f, Kw.O.Mm)
            }
        }
        var f = Tf[a],
            g = b.onSuccess,
            h = b.onFailure,
            l = b.terminate;
        if (c.isBlocked(f)) return null;
        var n = gg(f[tf.Nm], c, []);
        if (n && n.length) {
            var p = n[0],
                q = Uz(p.index, {
                    onSuccess: g,
                    onFailure: h,
                    terminate: l
                }, c, d);
            if (!q) return null;
            g = q;
            h = p.gn === 2 ? l : q
        }
        if (f[tf.sm] || f[tf.Pp]) {
            var r = f[tf.sm] ? Uf : c.rs,
                u = g,
                t = h;
            if (!r[a]) {
                var v = Wz(a, r, Ib(e));
                g = v.onSuccess;
                h = v.onFailure
            }
            return function() {
                r[a](u, t)
            }
        }
        return e
    }

    function Wz(a, b, c) {
        var d = [],
            e = [];
        b[a] = Xz(d, e, c);
        return {
            onSuccess: function() {
                b[a] = Yz;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = Zz;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function Xz(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function Yz(a) {
        a()
    }

    function Zz(a, b) {
        b()
    };
    var bA = function(a, b) {
        for (var c = [], d = 0; d < Tf.length; d++)
            if (a[d]) {
                var e = Tf[d];
                var f = iz(b.Uc);
                try {
                    var g = Uz(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var h = e[tf.Ta];
                        if (!h) throw Error("Error: No function name given for function call.");
                        var l = Vf[h];
                        c.push({
                            Mn: d,
                            priorityOverride: (l ? l.priorityOverride || 0 : 0) || cz(e[tf.Ta], 1) || 0,
                            execute: g
                        })
                    } else $z(d, b), f()
                } catch (p) {
                    f()
                }
            }
        c.sort(aA);
        for (var n = 0; n < c.length; n++) c[n].execute();
        return c.length > 0
    };

    function cA(a, b) {
        if (!$y) return !1;
        var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
            d = az(a.event, c ? String(c).split(",") : []);
        if (!d.length) return !1;
        for (var e = 0; e < d.length; ++e) {
            var f = iz(b);
            try {
                d[e](a, f)
            } catch (g) {
                f()
            }
        }
        return !0
    }

    function aA(a, b) {
        var c, d = b.priorityOverride,
            e = a.priorityOverride;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (c !== 0) f = c;
        else {
            var g = a.Mn,
                h = b.Mn;
            f = g > h ? 1 : g < h ? -1 : 0
        }
        return f
    }

    function $z(a, b) {
        if (Lk) {
            var c = function(d) {
                var e = b.isBlocked(Tf[d]) ? "3" : "4",
                    f = gg(Tf[d][tf.Bm], b, []);
                f && f.length && c(f[0].index);
                Mz(b.id, Tf[d], e);
                var g = gg(Tf[d][tf.Nm], b, []);
                g && g.length && c(g[0].index)
            };
            c(a)
        }
    }
    var dA = !1,
        $y;

    function eA() {
        $y || ($y = new Zy);
        return $y
    }

    function fA(a) {
        var b = a["gtm.uniqueEventId"],
            c = a["gtm.priorityId"],
            d = a.event;
        if (P(109)) {}
        if (d === "gtm.js") {
            if (dA) return !1;
            dA = !0
        }
        var e = !1,
            f = Rz(),
            g = td(a, null);
        if (!f.every(function(u) {
                return u({
                    originalEventData: g
                })
            })) {
            if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent") return !1;
            e = !0
        }
        zz(b, d);
        var h = a.eventCallback,
            l =
            a.eventTimeout,
            n = {
                id: b,
                priorityId: c,
                name: d,
                isBlocked: gA(g, e),
                rs: [],
                logMacroError: function(u, t, v) {
                    M(6);
                    Hm(4);
                    bz(2, t, v)
                },
                cachedModelValues: hA(),
                Uc: new ez(function() {
                    if (P(109)) {}
                    h && h.apply(h, Array.prototype.slice.call(arguments,
                        0))
                }, l),
                originalEventData: g
            };
        P(120) && Lk && (n.reportMacroDiscrepancy = Ez);
        P(109) && mx(n.id);
        var p = ug(n);
        P(109) && nx(n.id);
        e && (p = iA(p));
        P(109) && lx(b);
        var q = bA(p, n),
            r = cA(a, n.Uc);
        jz(n.Uc);
        d !== "gtm.js" && d !== "gtm.sync" || pz();
        return jA(p, q) || r
    }

    function hA() {
        var a = {};
        a.event = qp("event", 1);
        a.ecommerce = qp("ecommerce", 1);
        a.gtm = qp("gtm");
        a.eventModel = qp("eventModel");
        return a
    }

    function gA(a, b) {
        var c = Xy();
        return function(d) {
            var e = c(d);
            if ((!Zi || !P(407)) && e) return !0;
            var f = d && d[tf.Ta];
            if (!f || typeof f !== "string") return !0;
            f = f.replace(/^_*/, "");
            e && Zi && P(407) && Lk && Jz(Number(a["gtm.uniqueEventId"]), f, "bl");
            var g, h = Pj();
            g = Pz().getRestrictions(0, h);
            var l = a;
            b && (l = td(a, null), l["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER);
            for (var n = !1, p = cj[f] || [], q = m(g), r = q.next(); !r.done; r = q.next()) {
                var u = r.value;
                try {
                    u({
                        entityId: f,
                        securityGroups: p,
                        originalEventData: l
                    }) || (n = !0)
                } catch (t) {
                    n = !0
                }
            }
            return n ||
                e
        }
    }

    function iA(a) {
        for (var b = [], c = 0; c < a.length; c++)
            if (a[c]) {
                var d = String(Tf[c][tf.Ta]);
                if (Wi[d] || Tf[c][tf.Qp] !== void 0 || cz(d, 2)) b[c] = !0
            }
        return b
    }

    function jA(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Tf[c] && !Xi[String(Tf[c][tf.Ta])]) return !0;
        return !1
    };

    function kA() {
        eA().addListener("gtm.init", function(a, b) {
            Ri.H = !0;
            sm();
            b()
        })
    };

    function lA() {
        if (Zn.pscdl !== void 0) km(gm.Z.Zh) === void 0 && jm(gm.Z.Zh, Zn.pscdl);
        else {
            var a = function(c) {
                    Zn.pscdl = c;
                    jm(gm.Z.Zh, c)
                },
                b = function() {
                    a("error")
                };
            try {
                Bc.cookieDeprecationLabel ? (a("pending"), Bc.cookieDeprecationLabel.getValue().then(a).catch(b)) : a("noapi")
            } catch (c) {
                b(c)
            }
        }
    };
    var mA = !1,
        nA = 0,
        oA = [];

    function pA(a) {
        if (!mA) {
            var b = z.createEventObject,
                c = z.readyState === "complete",
                d = z.readyState === "interactive";
            if (!a || a.type !== "readystatechange" || c || !b && d) {
                mA = !0;
                for (var e = 0; e < oA.length; e++) Uc(oA[e])
            }
            oA.push = function() {
                for (var f = Da.apply(0, arguments), g = 0; g < f.length; g++) Uc(f[g]);
                return 0
            }
        }
    }

    function qA() {
        if (!mA && nA < 140) {
            nA++;
            try {
                var a, b;
                (b = (a = z.documentElement).doScroll) == null || b.call(a, "left");
                pA()
            } catch (c) {
                w.setTimeout(qA, 50)
            }
        }
    }

    function rA() {
        var a = w;
        mA = !1;
        nA = 0;
        if (z.readyState === "interactive" && !z.createEventObject || z.readyState === "complete") pA();
        else {
            Sc(z, "DOMContentLoaded", pA);
            Sc(z, "readystatechange", pA);
            if (z.createEventObject && z.documentElement.doScroll) {
                var b = !0;
                try {
                    b = !a.frameElement
                } catch (c) {}
                b && qA()
            }
            Sc(a, "load", pA)
        }
    }

    function sA(a) {
        mA ? a() : oA.push(a)
    };

    function tA(a, b) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: fo()
        });
        b.eventId = a["gtm.uniqueEventId"];
        b.priorityId = a["gtm.priorityId"];
        return {
            eventId: b.eventId,
            priorityId: b.priorityId
        }
    }

    function uA(a) {
        for (var b = m([K.m.vd, K.m.Oc]), c = b.next(); !c.done; c = b.next()) {
            var d = c.value,
                e = a && a[d] || Pp.C[d];
            if (e) return e
        }
    };
    var vA = !1;
    var wA = 0;

    function xA(a) {
        Nk && a === void 0 && wA === 0 && (lk("mcc", "1"), wA = 1)
    };

    function yA(a, b) {
        return arguments.length === 1 ? zA("set", a) : zA("set", a, b)
    }

    function AA(a, b) {
        return arguments.length === 1 ? zA("config", a) : zA("config", a, b)
    }

    function BA(a, b, c) {
        c = c || {};
        c[K.m.ud] = a;
        return zA("event", b, c)
    }

    function zA() {
        return arguments
    };
    var CA = function() {
        this.messages = [];
        this.C = []
    };
    CA.prototype.enqueue = function(a, b, c) {
        var d = this.messages.length + 1;
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        var e = na(Object, "assign").call(Object, {}, c, {
                eventId: b,
                priorityId: d,
                fromContainerExecution: !0
            }),
            f = {
                message: a,
                notBeforeEventId: b,
                priorityId: d,
                messageContext: e
            };
        this.messages.push(f);
        for (var g = 0; g < this.C.length; g++) try {
            this.C[g](f)
        } catch (h) {}
    };
    CA.prototype.listen = function(a) {
        this.C.push(a)
    };
    CA.prototype.get = function() {
        for (var a = {}, b = 0; b < this.messages.length; b++) {
            var c = this.messages[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    CA.prototype.prune = function(a) {
        for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
            var e = this.messages[d];
            e.notBeforeEventId === a ? b.push(e) : c.push(e)
        }
        this.messages = c;
        return b
    };

    function DA(a, b, c) {
        c.eventMetadata = c.eventMetadata || {};
        c.eventMetadata[Q.A.Pa] = D(6);
        EA().enqueue(a, b, c)
    }

    function FA() {
        var a = GA;
        EA().listen(a)
    }

    function EA() {
        return $n("mb", function() {
            return new CA
        })
    };
    var HA = 0,
        IA = 0,
        JA = {};
    var KA = {},
        LA = {};

    function MA(a, b) {
        for (var c = [], d = [], e = {}, f = 0; f < a.length; e = {
                Hj: void 0,
                mj: void 0
            }, f++) {
            var g = a[f];
            if (g.indexOf("-") >= 0) {
                if (e.Hj = lo(g, b), e.Hj) {
                    var h = Nj();
                    vb(h, function(r) {
                        return function(u) {
                            return r.Hj.destinationId === u
                        }
                    }(e)) ? c.push(g) : d.push(g)
                }
            } else {
                var l = KA[g] || [];
                e.mj = {};
                l.forEach(function(r) {
                    return function(u) {
                        r.mj[u] = !0
                    }
                }(e));
                for (var n = Qj(), p = 0; p < n.length; p++)
                    if (e.mj[n[p]]) {
                        c = c.concat(Nj());
                        break
                    }
                var q = LA[g] || [];
                q.length && (c = c.concat(q))
            }
        }
        return {
            Aj: c,
            Dr: d
        }
    }

    function NA(a) {
        zb(KA, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    }

    function OA(a) {
        zb(LA, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    };
    var PA = !1,
        QA = void 0,
        RA = void 0;

    function SA(a, b, c) {
        var d = td(a, null);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return b[f] !== void 0
        }) && M(136);
        var e = td(b, null);
        td(c, e);
        DA(AA(Qj()[0], e), a.eventId, d)
    };

    function TA(a, b) {
        var c = {},
            d = (c.event = a, c);
        b && (d.eventModel = td(b, null), b[K.m.zf] && (d.eventCallback = b[K.m.zf]), b[K.m.Yg] && (d.eventTimeout = b[K.m.Yg]));
        return d
    }

    function UA(a, b) {
        var c = a && a[K.m.ud];
        c === void 0 && (c = lp(K.m.ud, 2), c === void 0 && (c = "default"));
        if (sb(c) || Array.isArray(c)) {
            var d;
            d = b.isGtmEvent ? sb(c) ? [c] : c : c.toString().replace(/\s+/g, "").split(",");
            var e = MA(d, b.isGtmEvent),
                f = e.Aj,
                g = e.Dr;
            if (g.length)
                for (var h = uA(a), l = 0; l < g.length; l++) {
                    var n = lo(g[l], b.isGtmEvent);
                    if (n) {
                        var p = n.destinationId,
                            q = void 0;
                        ((q = Hj(n.destinationId)) == null ? void 0 : q.state) === 0 || Sy(p, h, {
                            source: 3,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            var r = f.concat(g);
            return {
                Aj: mo(f, b.isGtmEvent),
                nq: mo(r, b.isGtmEvent)
            }
        }
    }
    var VA = {
            config: function(a, b) {
                var c = tA(a, b);
                if (!(a.length < 2) && sb(a[1])) {
                    var d = {};
                    if (a.length > 2) {
                        if (a[2] !== void 0 && !sd(a[2]) || a.length > 3) return;
                        d = a[2]
                    }
                    var e = lo(a[1], b.isGtmEvent);
                    if (e) {
                        var f, g, h;
                        a: {
                            if (!kg(7)) {
                                var l = Sj(Tj());
                                if (ek(l)) {
                                    var n = l.parent,
                                        p = n.isDestination;
                                    h = {
                                        Hr: Sj(n),
                                        Ar: p
                                    };
                                    break a
                                }
                            }
                            h = void 0
                        }
                        var q = h;
                        q && (f = q.Hr, g = q.Ar);
                        zz(c.eventId, "gtag.config");
                        var r = e.destinationId,
                            u = e.id !== r;
                        if (u ? Nj().indexOf(r) === -1 : Qj().indexOf(r) === -1) {
                            if (!b.inheritParentConfig && !d[K.m.Ic]) {
                                var t = uA(d);
                                if (u) Sy(r, t, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                });
                                else if (f !== void 0 && f.containers.indexOf(r) !== -1) {
                                    var v = d;
                                    QA ? SA(b, v, QA) : RA || (RA = td(v, null))
                                } else Ny(r, t, !0, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        } else {
                            if (f && (M(128), g && M(130), b.inheritParentConfig)) {
                                var x;
                                var y = d;
                                RA ? (SA(b, RA, y), x = !1) : (!y[K.m.xd] && kg(11) && QA || (QA = td(y, null)), x = !0);
                                x && f.containers && f.containers.join(",");
                                return
                            }
                            Nk && (wA === 1 && (ik.mcc = !1), wA = 2);
                            if (kg(11) && !u && !d[K.m.xd]) {
                                var A = PA;
                                PA = !0;
                                var C = d,
                                    E = Object.keys(C).length >
                                    0 ? 2 : 1,
                                    H, J, O = (b == null ? void 0 : (J = b.originatingEntity) == null ? void 0 : J.originContainerId) || "";
                                H = O ? Lb(O, "GTM-") ? 3 : 2 : 1;
                                if (A) {
                                    if (M(184), IA === H || IA !== 3 && H !== 3 || M(185), HA !== 2 && E !== 2 || M(186), HA === 2 && E === 2) {
                                        var ba;
                                        a: {
                                            var W = JA,
                                                N = Object.keys(W),
                                                S = Object.keys(C);
                                            if (N.length !== S.length) ba = !0;
                                            else {
                                                for (var la = m(N), ja = la.next(); !ja.done; ja = la.next()) {
                                                    var V = ja.value;
                                                    if (!C.hasOwnProperty(V) || W[V] !== C[V]) {
                                                        ba = !0;
                                                        break a
                                                    }
                                                }
                                                ba = !1
                                            }
                                        }
                                        ba && M(189)
                                    }
                                } else HA = E, IA = H, JA = C;
                                if (A) return
                            }
                            vA || M(43);
                            if (!b.noTargetGroup)
                                if (u) {
                                    OA(e.id);
                                    var U =
                                        e.id,
                                        ha = d[K.m.fh] || "default";
                                    ha = String(ha).split(",");
                                    for (var ta = 0; ta < ha.length; ta++) {
                                        var pa = LA[ha[ta]] || [];
                                        LA[ha[ta]] = pa;
                                        pa.indexOf(U) < 0 && pa.push(U)
                                    }
                                } else {
                                    NA(e.id);
                                    var Ma = e.id,
                                        Sa = d[K.m.fh] || "default";
                                    Sa = Sa.toString().split(",");
                                    for (var mb = 0; mb < Sa.length; mb++) {
                                        var cb = KA[Sa[mb]] || [];
                                        KA[Sa[mb]] = cb;
                                        cb.indexOf(Ma) < 0 && cb.push(Ma)
                                    }
                                }
                            delete d[K.m.fh];
                            var Ya = b.eventMetadata || {};
                            Ya.hasOwnProperty(Q.A.Dd) || (Ya[Q.A.Dd] = !b.fromContainerExecution);
                            b.eventMetadata = Ya;
                            delete d[K.m.zf];
                            for (var Pb = u ? [e.id] : Nj(), Qb =
                                    0; Qb < Pb.length; Qb++) {
                                var ke = d,
                                    Ig = Pb[Qb],
                                    le = td(b, null),
                                    Qe = lo(Ig, le.isGtmEvent);
                                Qe && Pp.push("config", [ke], Qe, le)
                            }
                        }
                    }
                }
            },
            consent: function(a, b) {
                if (a.length === 3) {
                    M(39);
                    var c = tA(a, b),
                        d = a[1],
                        e = {},
                        f = hn(a[2]),
                        g;
                    for (g in f)
                        if (f.hasOwnProperty(g)) {
                            var h = f[g];
                            e[g] = g === K.m.Ig ? Array.isArray(h) ? NaN : Number(h) : g === K.m.oc ? (Array.isArray(h) ? h : [h]).map(jn) : kn(h)
                        }
                    b.fromContainerExecution || (e[K.m.X] && M(139), e[K.m.Na] && M(140));
                    d === "default" ? Nn(e) : d === "update" ? Pn(e, c) : d === "declare" && b.fromContainerExecution && Mn(e)
                }
            },
            container_config: function(a,
                b) {
                if (b.isGtmEvent && !(b.eventMetadata && b.eventMetadata[Q.A.eb] && b.eventMetadata[Q.A.Pa] !== Pj() || a.length !== 3) && sb(a[1]) && sd(a[2])) {
                    var c = a[2],
                        d = lo(a[1], !0);
                    if (d) {
                        var e = d.destinationId,
                            f = td(b, null),
                            g = lo(e, f.isGtmEvent);
                        g && Pp.push("container_config", [c], g, f)
                    }
                }
            },
            destination_config: function(a, b) {
                if (b.isGtmEvent && !(b.eventMetadata && b.eventMetadata[Q.A.eb] && b.eventMetadata[Q.A.Pa] !== Pj() || a.length !== 3) && sb(a[1]) && sd(a[2])) {
                    var c = a[2],
                        d = lo(a[1], !0);
                    if (d) {
                        var e = d.destinationId,
                            f = td(b, null),
                            g = lo(e, f.isGtmEvent);
                        g && Pp.push("destination_config", [c], g, f)
                    }
                }
            },
            event: function(a, b) {
                var c = a[1];
                if (!(a.length < 2) && sb(c)) {
                    var d = void 0;
                    if (a.length > 2) {
                        if (!sd(a[2]) && a[2] !== void 0 || a.length > 3) return;
                        d = a[2]
                    }
                    var e = TA(c, d),
                        f = tA(a, b),
                        g = f.eventId,
                        h = f.priorityId;
                    e["gtm.uniqueEventId"] = g;
                    h && (e["gtm.priorityId"] = h);
                    if (c === "optimize.callback") return e.eventModel = e.eventModel || {}, e;
                    var l = UA(d, b);
                    if (l) {
                        for (var n = l.Aj, p = l.nq, q = p.map(function(O) {
                                    return O.id
                                }), r = p.map(function(O) {
                                    return O.destinationId
                                }), u = n.map(function(O) {
                                    return O.id
                                }),
                                t = m(Nj()), v = t.next(); !v.done; v = t.next()) {
                            var x = v.value;
                            r.indexOf(x) < 0 && u.push(x)
                        }
                        zz(g, c);
                        for (var y = m(u), A = y.next(); !A.done; A = y.next()) {
                            var C = A.value,
                                E = td(b, null),
                                H = td(d, null);
                            delete H[K.m.zf];
                            var J = E.eventMetadata || {};
                            J.hasOwnProperty(Q.A.Dd) || (J[Q.A.Dd] = !E.fromContainerExecution);
                            J[Q.A.Pi] = q.slice();
                            J[Q.A.fg] = r.slice();
                            E.eventMetadata = J;
                            Op(c, H, C, E)
                        }
                        e.eventModel = e.eventModel || {};
                        q.length > 0 ? e.eventModel[K.m.ud] = q.join(",") : delete e.eventModel[K.m.ud];
                        vA || M(43);
                        b.noGtmEvent === void 0 && b.eventMetadata &&
                            b.eventMetadata[Q.A.Km] && (b.noGtmEvent = !0);
                        e.eventModel[K.m.Hc] && (b.noGtmEvent = !0);
                        return b.noGtmEvent ? void 0 : e
                    }
                }
            },
            get: function(a, b) {
                M(53);
                if (a.length === 4 && sb(a[1]) && sb(a[2]) && rb(a[3])) {
                    var c = lo(a[1], b.isGtmEvent),
                        d = String(a[2]),
                        e = a[3];
                    if (c) {
                        vA || M(43);
                        var f = uA();
                        if (vb(Nj(), function(h) {
                                return c.destinationId === h
                            })) {
                            tA(a, b);
                            var g = {};
                            td((g[K.m.Df] = d, g[K.m.Cf] = e, g), null);
                            Qp(d, function(h) {
                                Uc(function() {
                                    e(h)
                                })
                            }, c.id, b)
                        } else Sy(c.destinationId, f, {
                            source: 4,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            },
            js: function(a, b) {
                if (a.length === 2 && a[1].getTime) {
                    vA = !0;
                    var c = tA(a, b),
                        d = c.eventId,
                        e = c.priorityId,
                        f = {};
                    return f.event = "gtm.js", f["gtm.start"] = a[1].getTime(), f["gtm.uniqueEventId"] = d, f["gtm.priorityId"] = e, f
                }
            },
            policy: function(a) {
                if (a.length === 3 && sb(a[1]) && rb(a[2])) {
                    if (Ag(a[1], a[2]), M(74), a[1] === "all") {
                        M(75);
                        var b = !1;
                        try {
                            b = a[2](D(5), "unknown", {})
                        } catch (c) {}
                        b || M(76)
                    }
                } else M(73)
            },
            set: function(a, b) {
                var c = void 0;
                a.length === 2 && sd(a[1]) ? c = td(a[1], null) : a.length === 3 && sb(a[1]) && (c = {}, sd(a[2]) || Array.isArray(a[2]) ?
                    c[a[1]] = td(a[2], null) : c[a[1]] = a[2]);
                if (c) {
                    var d = tA(a, b),
                        e = d.eventId,
                        f = d.priorityId;
                    td(c, null);
                    D(5);
                    var g = td(c, null);
                    Pp.push("set", [g], void 0, b);
                    c["gtm.uniqueEventId"] = e;
                    f && (c["gtm.priorityId"] = f);
                    delete c.event;
                    b.overwriteModelFields = !0;
                    return c
                }
            }
        },
        WA = {
            policy: !0
        };
    var YA = function(a) {
        if (XA(a)) return a;
        this.value = a
    };
    YA.prototype.getUntrustedMessageValue = function() {
        return this.value
    };
    var XA = function(a) {
        return !a || qd(a) !== "object" || sd(a) ? !1 : "getUntrustedMessageValue" in a
    };
    YA.prototype.getUntrustedMessageValue = YA.prototype.getUntrustedMessageValue;
    var ZA = !1,
        $A = [];

    function aB() {
        if (!ZA) {
            ZA = !0;
            for (var a = 0; a < $A.length; a++) Uc($A[a])
        }
    }

    function bB(a) {
        ZA ? Uc(a) : $A.push(a)
    };
    var cB = 0,
        dB = {},
        eB = [],
        fB = [],
        gB = !1,
        hB = !1;

    function iB(a, b) {
        return a.messageContext.eventId - b.messageContext.eventId || a.messageContext.priorityId - b.messageContext.priorityId
    }

    function jB(a, b, c) {
        a.eventCallback = b;
        c && (a.eventTimeout = c);
        return kB(a)
    }

    function lB(a, b) {
        if (!tb(b) || b < 0) b = 0;
        var c = eo(),
            d = 0,
            e = !1,
            f = void 0;
        f = w.setTimeout(function() {
            e || (e = !0, a());
            f = void 0
        }, b);
        return function() {
            var g = c ? c.subscribers : 1;
            ++d === g && (f && (w.clearTimeout(f), f = void 0), e || (a(), e = !0))
        }
    }

    function mB(a) {
        if (a == null || typeof a !== "object") return !1;
        if (a.event) return !0;
        if (Ab(a)) {
            var b = a[0];
            if (b === "config" || b === "event" || b === "js" || b === "get") return !0
        }
        return !1
    }

    function nB() {
        var a;
        if (fB.length) a = fB.shift();
        else if (eB.length) a = eB.shift();
        else return;
        var b;
        var c = a;
        if (gB || !mB(c.message)) b = c;
        else {
            gB = !0;
            var d = c.message["gtm.uniqueEventId"],
                e, f;
            typeof d === "number" ? (e = d - 2, f = d - 1) : (e = fo(), f = fo(), c.message["gtm.uniqueEventId"] = fo());
            var g = {},
                h = {
                    message: (g.event = "gtm.init_consent", g["gtm.uniqueEventId"] = e, g),
                    messageContext: {
                        eventId: e
                    }
                },
                l = {},
                n = {
                    message: (l.event = "gtm.init", l["gtm.uniqueEventId"] = f, l),
                    messageContext: {
                        eventId: f
                    }
                };
            eB.unshift(n, c);
            b = h
        }
        return b
    }

    function oB() {
        for (var a = !1, b; !hB && (b = nB());) {
            hB = !0;
            delete ip.eventModel;
            kp();
            var c = b,
                d = c.message,
                e = c.messageContext;
            if (d == null) hB = !1;
            else {
                e.fromContainerExecution && pp();
                try {
                    if (rb(d)) try {
                        d.call(mp)
                    } catch (H) {} else if (Array.isArray(d)) {
                        if (sb(d[0])) {
                            var f = d[0].split("."),
                                g = f.pop(),
                                h = d.slice(1),
                                l = lp(f.join("."), 2);
                            if (l != null) try {
                                l[g].apply(l, h)
                            } catch (H) {}
                        }
                    } else {
                        var n = void 0;
                        if (Ab(d)) a: {
                            if (d.length && sb(d[0])) {
                                var p = VA[d[0]];
                                if (p && (!e.fromContainerExecution || !WA[d[0]])) {
                                    n = p(d, e);
                                    break a
                                }
                            }
                            n = void 0
                        }
                        else n =
                            d;
                        if (n) {
                            var q;
                            for (var r = n, u = r._clear || e.overwriteModelFields, t = m(Object.keys(r)), v = t.next(); !v.done; v = t.next()) {
                                var x = v.value;
                                x !== "_clear" && (u && op(x), op(x, r[x]))
                            }
                            bj || (bj = r["gtm.start"]);
                            var y = r["gtm.uniqueEventId"];
                            r.event ? (typeof y !== "number" && (y = fo(), r["gtm.uniqueEventId"] = y, op("gtm.uniqueEventId", y)), q = fA(r)) : q = !1;
                            a = q || a
                        }
                    }
                } finally {
                    e.fromContainerExecution && kp(!0);
                    var A = d["gtm.uniqueEventId"];
                    if (typeof A === "number") {
                        for (var C = dB[String(A)] || [], E = 0; E < C.length; E++) fB.push(pB(C[E]));
                        C.length && fB.sort(iB);
                        delete dB[String(A)];
                        A > cB && (cB = A)
                    }
                    hB = !1
                }
            }
        }
        return !a
    }

    function qB() {
        if (P(109)) {
            var a = !kg(51);
        }
        var c = oB();
        if (P(109)) {}
        try {
            var e = w[D(19)],
                f = D(5),
                g = e.hide;
            if (g && g[f] !== void 0 &&
                g.end) {
                g[f] = !1;
                var h = !0,
                    l;
                for (l in g)
                    if (g.hasOwnProperty(l) && g[l] === !0) {
                        h = !1;
                        break
                    }
                h && (g.end(), g.end = null)
            }
        } catch (n) {
            D(5)
        }
        return c
    }

    function GA(a) {
        if (cB < a.notBeforeEventId) {
            var b = String(a.notBeforeEventId);
            dB[b] = dB[b] || [];
            dB[b].push(a)
        } else fB.push(pB(a)), fB.sort(iB), Uc(function() {
            hB || oB()
        })
    }

    function pB(a) {
        return {
            message: a.message,
            messageContext: a.messageContext
        }
    }

    function rB() {
        function a(f) {
            var g = {};
            if (XA(f)) {
                var h = f;
                f = XA(h) ? h.getUntrustedMessageValue() : void 0;
                g.fromContainerExecution = !0
            }
            return {
                message: f,
                messageContext: g
            }
        }
        var b = Fc(D(19), []),
            c = co();
        c.pruned === !0 && M(83);
        dB = EA().get();
        FA();
        sA(function() {
            if (!c.gtmDom) {
                c.gtmDom = !0;
                var f = {};
                b.push((f.event = "gtm.dom", f))
            }
        });
        bB(function() {
            if (!c.gtmLoad) {
                c.gtmLoad = !0;
                var f = {};
                b.push((f.event = "gtm.load", f))
            }
        });
        c.subscribers = (c.subscribers || 0) + 1;
        var d = b.push;
        b.push = function() {
            var f;
            if (Zn.SANDBOXED_JS_SEMAPHORE > 0) {
                f = [];
                for (var g = 0; g < arguments.length; g++) f[g] = new YA(arguments[g])
            } else f = [].slice.call(arguments, 0);
            var h = f.map(function(q) {
                return a(q)
            });
            eB.push.apply(eB, h);
            var l = d.apply(b, f),
                n = Math.max(100, pg(1, 300));
            if (this.length > n)
                for (M(4), c.pruned = !0; this.length > n;) this.shift();
            var p = typeof l !== "boolean" || l;
            return oB() && p
        };
        var e = b.slice(0).map(function(f) {
            return a(f)
        });
        eB.push.apply(eB, e);
        if (!kg(51)) {
            if (P(109)) {}
            Uc(qB)
        }
    }
    var kB = function(a) {
        return w[D(19)].push(a)
    };

    function sB(a) {
        kB(a)
    };

    function tB() {
        var a, b = pj(w.location.href);
        (a = b.hostname + b.pathname) && lk("dl", encodeURIComponent(a));
        var c;
        var d = D(5);
        if (d) {
            var e = kg(7) ? 1 : 0,
                f = Zj(),
                g = f && f.fromContainerExecution ? 1 : 0,
                h = f && f.source || 0,
                l = D(6);
            c = d + ";" + l + ";" + g + ";" + h + ";" + e
        } else c = void 0;
        var n = c;
        n && lk("tdp", n);
        var p = gq(!0);
        p !== void 0 && lk("frm", String(p))
    };
    var uB = wk(),
        vB = void 0;

    function wB(a) {
        return yk(a, function(b) {
            return b.jb > 0 ? String(b.jb) : void 0
        })
    }

    function xB() {
        if (vn() || Nk) lk("csp", function() {
            var a = wB(uB);
            zk(uB);
            return a
        }, !1), lk("mde", function() {
            var a = wB(Bk);
            zk(Bk);
            return a
        }, !1), w.addEventListener("securitypolicyviolation", yB)
    }

    function yB(a) {
        if (a.disposition === "enforce") {
            M(179);
            var b = Hk(a.effectiveDirective);
            if (b) {
                var c;
                var d = Fk(b, a.blockedURI);
                c = d ? Dk[b][d] : void 0;
                if (c) {
                    var e;
                    a: {
                        try {
                            var f = new URL(a.blockedURI),
                                g = f.pathname.indexOf(";");
                            e = g >= 0 ? f.origin + f.pathname.substring(0, g) : f.origin + f.pathname;
                            break a
                        } catch (v) {}
                        e = void 0
                    }
                    var h = e;
                    if (h) {
                        for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
                            var p = n.value;
                            if (!p.Cn) {
                                p.Cn = !0;
                                var q = {
                                    eventId: p.eventId,
                                    priorityId: p.priorityId
                                };
                                if (vn()) {
                                    var r = q,
                                        u = {
                                            type: 1,
                                            blockedUrl: h,
                                            endpoint: p.endpoint,
                                            violation: a.effectiveDirective
                                        };
                                    if (vn()) {
                                        var t = Bn("TAG_DIAGNOSTICS", {
                                            eventId: r == null ? void 0 : r.eventId,
                                            priorityId: r == null ? void 0 : r.priorityId
                                        });
                                        t.tagDiagnostics = u;
                                        un(t)
                                    }
                                }
                                zB(p.destinationId, p.endpoint)
                            }
                        }
                        Gk(b, a.blockedURI)
                    }
                }
            }
        }
    }

    function zB(a, b) {
        Ak(uB, a, b);
        mk("csp", !0);
        mk("mde", !0);
        b !== 61 && b !== 56 && vB === void 0 && (vB = w.setTimeout(function() {
            uB.jb > 0 && sm(!1);
            vB = void 0
        }, 500))
    };
    var AB = void 0;

    function BB() {
        P(236) && w.addEventListener("pageshow", function(a) {
            a && (lk("bfc", function() {
                return AB ? "1" : "0"
            }), a.persisted ? (AB = !0, mk("bfc", !0), sm()) : AB = !1)
        })
    };

    function CB() {
        var a;
        var b = Rj();
        if (b)
            if (b.canonicalContainerId) a = b.canonicalContainerId;
            else {
                var c, d = b.scriptContainerId || ((c = b.destinations) == null ? void 0 : c[0]);
                a = d ? "_" + d : void 0
            }
        else a = void 0;
        var e = a;
        e && lk("pcid", e)
    };
    var DB = {},
        EB = (DB[1] = function() {
            return w.fetch
        }, DB[2] = function() {
            return Math.random
        }, DB[3] = function() {
            return Bc.sendBeacon
        }, DB[4] = function() {
            return w.XMLHttpRequest
        }, DB);

    function FB() {
        if (P(409)) {
            for (var a = [], b = m(Object.keys(EB)), c = b.next(); !c.done; c = b.next()) {
                var d = c.value,
                    e = EB[d](),
                    f;
                if (!(f = typeof e !== "function")) {
                    var g = Function.prototype.toString.call(e);
                    f = Mb(g, "{ [native code] }") || Mb(g, "{\n    [native code]\n}")
                }
                f || a.push(d)
            }
            a.length > 0 && lk("jsp", a.join("~"))
        }
    };
    var GB = /^(https?:)?\/\//;

    function HB() {
        var a = Uj();
        if (a) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    var e;
                    try {
                        var f;
                        e = (f = hd()) == null ? void 0 : f.getEntriesByType("resource")
                    } catch (q) {}
                    if (e) {
                        for (var g = -1, h = m(e), l = h.next(); !l.done; l = h.next()) {
                            var n = l.value;
                            if (n.initiatorType === "script" && (g += 1, n.name.replace(GB, "") === d.replace(GB, ""))) {
                                b = g;
                                break a
                            }
                        }
                        M(146)
                    } else M(145)
                }
                b = void 0
            }
            var p = b;
            p !== void 0 && (a.canonicalContainerId && lk("rtg", String(a.canonicalContainerId)), lk("slo", String(p)), lk("hlo", a.htmlLoadOrder || "-1"),
                lk("lst", String(a.loadScriptType || "0")))
        } else M(144)
    };

    function bC() {};
    var cC = function() {};
    cC.prototype.toString = function() {
        return "undefined"
    };
    var dC = new cC;
    var fC = function() {
            $n("rm", function() {
                return {}
            })[Pj()] = function(a) {
                if (eC.hasOwnProperty(a)) return eC[a]
            }
        },
        iC = function(a, b, c) {
            if (a instanceof gC) {
                var d = a,
                    e = d.resolve,
                    f = b,
                    g = String(fo());
                hC[g] = [f, c];
                a = e.call(d, g);
                b = qb
            }
            return {
                lr: a,
                onSuccess: b
            }
        },
        jC = function(a) {
            var b = a ? 0 : 1;
            return function(c) {
                M(a ? 134 : 135);
                var d = hC[c];
                if (d && typeof d[b] === "function") d[b]();
                hC[c] = void 0
            }
        },
        gC = function(a) {
            this.valueOf = this.toString;
            this.resolve = function(b) {
                for (var c = [], d = 0; d < a.length; d++) c.push(a[d] === dC ? b : a[d]);
                return c.join("")
            }
        };
    gC.prototype.toString = function() {
        return this.resolve("undefined")
    };
    var eC = {},
        hC = {};
    var kC = {};

    function lC(a) {
        Lk && (kC[a] = (kC[a] || 0) + 1)
    }

    function mC() {
        var a = [];
        kC[1] && a.push("1." + kC[1]);
        kC[2] && a.push("2." + kC[2]);
        kC[3] && a.push("3." + kC[3]);
        return a.length ? [
            ["odp", a.join("~")]
        ] : []
    };

    function nC() {
        (P(212) || P(405)) && D(5).indexOf("GTM-") !== 0 && (Cx("detect_link_click_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.waitForTags) === !0 && lC(1), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Cx("detect_form_submit_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.waitForTags) === !0 && lC(2), !0) : (d == null ? void 0 : d.waitForTags) !== !0
        }), Cx("detect_youtube_activity_events", function(a, b, c) {
            var d = c.options;
            return P(405) ? ((d == null ? void 0 : d.fixMissingApi) ===
                !0 && lC(3), !0) : (d == null ? void 0 : d.fixMissingApi) !== !0
        }));
        (P(212) || P(407)) && Zi && Oz(Pj(), function(a) {
            var b, c, d;
            b = a.entityId;
            c = a.securityGroups;
            d = a.originalEventData;
            var e = "__" + b,
                f = cz(e, 5) || !(!Vf[e] || !Vf[e][5]) || c.includes("cmpPartners");
            return P(407) ? (f || Lk && Jz(Number(d["gtm.uniqueEventId"]), b, "r"), !0) : f
        })
    };

    function oC(a, b) {
        function c(g) {
            var h = pj(g),
                l = jj(h, "protocol"),
                n = jj(h, "host", !0),
                p = jj(h, "port"),
                q = jj(h, "path").toLowerCase().replace(/\/$/, "");
            if (l === void 0 || l === "http" && p === "80" || l === "https" && p === "443") l = "web", p = "default";
            return [l, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function pC(a) {
        return qC(a) ? 1 : 0
    }

    function qC(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = td(a, {});
                td({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (pC(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return gh(b, c);
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var g = 0; g < bh.length; g++) {
                            var h = bh[g];
                            if (b[h] != null) {
                                f = b[h](c);
                                break a
                            }
                        }
                    } catch (l) {}
                    f = !1
                }
                return f;
            case "_ew":
                return ch(b, c);
            case "_eq":
                return hh(b, c);
            case "_ge":
                return ih(b, c);
            case "_gt":
                return kh(b, c);
            case "_lc":
                return dh(b, c);
            case "_le":
                return jh(b,
                    c);
            case "_lt":
                return lh(b, c);
            case "_re":
                return fh(b, c, a.ignore_case);
            case "_sw":
                return mh(b, c);
            case "_um":
                return oC(b, c)
        }
        return !1
    };
    var rC = function() {
        this.C = this.gppString = void 0
    };
    rC.prototype.reset = function() {
        this.C = this.gppString = void 0
    };
    var sC = new rC;
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    var tC = function(a, b, c, d) {
        nq.call(this);
        this.Bh = b;
        this.cg = c;
        this.Rc = d;
        this.yb = new Map;
        this.Ch = 0;
        this.sa = new Map;
        this.nb = new Map;
        this.V = void 0;
        this.H = a
    };
    wa(tC, nq);
    tC.prototype.P = function() {
        delete this.C;
        this.yb.clear();
        this.sa.clear();
        this.nb.clear();
        this.V && (jq(this.H, "message", this.V), delete this.V);
        delete this.H;
        delete this.Rc;
        nq.prototype.P.call(this)
    };
    var uC = function(a) {
            if (a.C) return a.C;
            a.cg && a.cg(a.H) ? a.C = a.H : a.C = fq(a.H, a.Bh);
            var b;
            return (b = a.C) != null ? b : null
        },
        wC = function(a, b, c) {
            if (uC(a))
                if (a.C === a.H) {
                    var d = a.yb.get(b);
                    d && d(a.C, c)
                } else {
                    var e = a.sa.get(b);
                    if (e && e.zj) {
                        vC(a);
                        var f = ++a.Ch;
                        a.nb.set(f, {
                            Rh: e.Rh,
                            Gq: e.on(c),
                            persistent: b === "addEventListener"
                        });
                        a.C.postMessage(e.zj(c, f), "*")
                    }
                }
        },
        vC = function(a) {
            a.V || (a.V = function(b) {
                try {
                    var c;
                    c = a.Rc ? a.Rc(b) : void 0;
                    if (c) {
                        var d = c.Kr,
                            e = a.nb.get(d);
                        if (e) {
                            e.persistent || a.nb.delete(d);
                            var f;
                            (f = e.Rh) == null || f.call(e,
                                e.Gq, c.payload)
                        }
                    }
                } catch (g) {}
            }, iq(a.H, "message", a.V))
        };
    var xC = function(a, b) {
            var c = b.listener,
                d = (0, a.__gpp)("addEventListener", c);
            d && c(d, !0)
        },
        yC = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        zC = {
            on: function(a) {
                return a.listener
            },
            zj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, c
            },
            Rh: function(a, b) {
                var c = b.__gppReturn;
                a(c.returnValue, c.success)
            }
        },
        AC = {
            on: function(a) {
                return a.listener
            },
            zj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            Rh: function(a, b) {
                var c = b.__gppReturn,
                    d = c.returnValue.data;
                a == null || a(d, c.success)
            }
        };

    function BC(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Kr: b.__gppReturn.callId
        }
    }
    var CC = function(a, b) {
        var c;
        c = (b === void 0 ? {} : b).timeoutMs;
        nq.call(this);
        this.caller = new tC(a, "__gppLocator", function(d) {
            return typeof d.__gpp === "function"
        }, BC);
        this.caller.yb.set("addEventListener", xC);
        this.caller.sa.set("addEventListener", zC);
        this.caller.yb.set("removeEventListener", yC);
        this.caller.sa.set("removeEventListener", AC);
        this.timeoutMs = c != null ? c : 500
    };
    wa(CC, nq);
    CC.prototype.P = function() {
        this.caller.dispose();
        nq.prototype.P.call(this)
    };
    CC.prototype.addEventListener = function(a) {
        var b = this,
            c = dq(function() {
                a(DC, !0)
            }),
            d = this.timeoutMs === -1 ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        wC(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    var h;
                    ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 || e.pingData.gppVersion === "1" || e.pingData.gppVersion === "1.0" ? (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 1,
                            gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                            applicableSections: [-1]
                        }
                    }) : Array.isArray(e.pingData.applicableSections) ? g = e : (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(g, f)
                } catch (l) {
                    if (e == null ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (n) {
                        a(EC, !0);
                        return
                    }
                    a(FC, !0)
                }
            }
        })
    };
    CC.prototype.removeEventListener = function(a) {
        wC(this.caller, "removeEventListener", {
            listener: function() {},
            listenerId: a
        })
    };
    var FC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        DC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        EC = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function GC(a) {
        var b;
        if (!(b = a.pingData.signalStatus === "ready")) {
            var c = a.pingData.applicableSections;
            b = !c || c.length === 1 && c[0] === -1
        }
        if (b) {
            sC.gppString = a.pingData.gppString;
            var d = a.pingData.applicableSections.join(",");
            sC.C = d
        }
    }

    function HC() {
        try {
            var a = new CC(w, {
                timeoutMs: -1
            });
            uC(a.caller) && a.addEventListener(GC)
        } catch (b) {}
    };

    function IC() {
        var a = [
                ["cv", D(1)],
                ["rv", D(14)],
                ["tc", Tf.filter(function(c) {
                    return c
                }).length]
            ],
            b = lg(15);
        b && a.push(["x", b]);
        ok() && a.push(["tag_exp", ok()]);
        return a
    };
    var JC = {},
        KC = {};

    function LC(a) {
        var b = a.eventId,
            c = a.Yd,
            d = [],
            e = JC[b] || [];
        e.length && d.push(["hf", e.join(".")]);
        var f = KC[b] || [];
        f.length && d.push(["ht", f.join(".")]);
        c && (delete JC[b], delete KC[b]);
        return d
    };

    function MC() {
        return !1
    }

    function NC() {
        var a = {};
        return function(b, c, d) {}
    };

    function OC() {
        var a = PC;
        return function(b, c, d) {
            var e = d && d.event;
            QC(c);
            var f = Sh(b) ? void 0 : 1,
                g = new bb;
            zb(c, function(r, u) {
                var t = Id(u, void 0, f);
                t === void 0 && u !== void 0 && M(44);
                g.set(r, t)
            });
            a.Rb(sg());
            var h = {
                Ym: Gg(b),
                eventId: e == null ? void 0 : e.id,
                priorityId: e !== void 0 ? e.priorityId : void 0,
                ig: e !== void 0 ? function(r) {
                    e.Uc.ig(r)
                } : void 0,
                Ob: function() {
                    return b
                },
                log: function() {},
                Mq: {
                    index: d == null ? void 0 : d.index,
                    type: d == null ? void 0 : d.type,
                    name: d == null ? void 0 : d.name
                },
                Sr: !!cz(b, 3),
                originalEventData: e == null ? void 0 : e.originalEventData
            };
            e && e.cachedModelValues && (h.cachedModelValues = {
                gtm: e.cachedModelValues.gtm,
                ecommerce: e.cachedModelValues.ecommerce
            });
            if (MC()) {
                var l = NC(),
                    n, p;
                h.sb = {
                    Oj: [],
                    jg: {},
                    jc: function(r, u, t) {
                        u === 1 && (n = r);
                        u === 7 && (p = t);
                        l(r, u, t)
                    },
                    Qh: li()
                };
                h.log = function(r) {
                    var u = Da.apply(1, arguments);
                    n && l(n, 4, {
                        level: r,
                        source: p,
                        message: u
                    })
                }
            }
            var q = gf(a, h, [b, g]);
            a.Rb();
            q instanceof Ga && (q.type === "return" ? q = q.data : q = void 0);
            return B(q, void 0, f)
        }
    }

    function QC(a) {
        var b = a.gtmOnSuccess,
            c = a.gtmOnFailure;
        rb(b) && (a.gtmOnSuccess = function() {
            Uc(b)
        });
        rb(c) && (a.gtmOnFailure = function() {
            Uc(c)
        })
    };

    function RC(a) {}
    RC.J = "internal.addAdsClickIds";

    function SC(a, b) {
        var c = this;
    }
    SC.publicName = "addConsentListener";
    var TC = !1;

    function UC(a) {
        for (var b = 0; b < a.length; ++b)
            if (TC) try {
                a[b]()
            } catch (c) {
                M(77)
            } else a[b]()
    }

    function VC(a, b, c) {
        var d = this,
            e;
        return e
    }
    VC.J = "internal.addDataLayerEventListener";

    function WC(a, b, c) {}
    WC.publicName = "addDocumentEventListener";

    function XC(a, b, c, d) {}
    XC.publicName = "addElementEventListener";

    function YC(a) {
        return a.K.qb()
    };

    function ZC(a) {}
    ZC.publicName = "addEventCallback";

    function nD(a) {}
    nD.J = "internal.addFormAbandonmentListener";

    function oD(a, b, c, d) {}
    oD.J = "internal.addFormData";
    var pD = {},
        qD = [],
        rD = {},
        sD = 0,
        tD = 0;

    function AD(a, b) {}
    AD.J = "internal.addFormInteractionListener";

    function HD(a, b) {}
    HD.J = "internal.addFormSubmitListener";

    function MD(a) {}
    MD.J = "internal.addGaSendListener";

    function ND(a) {
        if (!a) return {};
        var b = a.Mq;
        return bz(b.type, b.index, b.name)
    }

    function OD(a) {
        return a ? {
            originatingEntity: ND(a)
        } : {}
    };

    function WD(a) {
        var b = Zn.zones;
        return b ? b.getIsAllowedFn(Qj(), a) : function() {
            return !0
        }
    }

    function XD() {
        var a = Zn.zones;
        a && a.unregisterChild(Qj())
    }

    function YD() {
        Qz(Pj(), function(a) {
            var b = a.originalEventData["gtm.uniqueEventId"],
                c = Zn.zones;
            return c ? c.isActive(Qj(), b) : !0
        });
        Oz(Pj(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            return WD(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c)
        })
    };
    var ZD = function(a, b) {
        this.tagId = a;
        this.canonicalId = b
    };

    function $D(a, b) {
        var c = this;
        return a
    }
    $D.J = "internal.loadGoogleTag";

    function aE(a) {
        return new Ad("", function(b) {
            var c = this.evaluate(b);
            if (c instanceof Ad) return new Ad("", function() {
                var d = Da.apply(0, arguments),
                    e = this,
                    f = td(YC(this), null);
                f.eventId = a.eventId;
                f.priorityId = a.priorityId;
                f.originalEventData = a.originalEventData;
                var g = d.map(function(l) {
                        return e.evaluate(l)
                    }),
                    h = this.K.ob();
                h.Ud(f);
                return c.Pb.apply(c, [h].concat(za(g)))
            })
        })
    };

    function bE(a, b, c) {
        var d = this;
    }
    bE.J = "internal.addGoogleTagRestriction";
    var cE = {},
        dE = [];

    function kE(a, b) {}
    kE.J = "internal.addHistoryChangeListener";

    function lE(a, b, c) {}
    lE.publicName = "addWindowEventListener";

    function mE(a, b) {
        return !0
    }
    mE.publicName = "aliasInWindow";

    function nE(a, b, c) {}
    nE.J = "internal.appendRemoteConfigParameter";

    function oE(a) {
        var b;
        return b
    }
    oE.publicName = "callInWindow";

    function pE(a) {}
    pE.publicName = "callLater";

    function qE(a) {}
    qE.J = "callOnDomReady";

    function rE(a) {}
    rE.J = "callOnWindowLoad";

    function sE(a, b) {
        var c;
        return c
    }
    sE.J = "internal.computeGtmParameter";

    function tE(a, b) {
        var c = this;
    }
    tE.J = "internal.consentScheduleFirstTry";

    function uE(a, b) {
        var c = this;
    }
    uE.J = "internal.consentScheduleRetry";

    function vE(a) {
        var b;
        return b
    }
    vE.J = "internal.copyFromCrossContainerData";

    function wE(a, b) {
        var c;
        if (!Dh(a) || !Ih(b) && b !== null && !yh(b)) throw G(this.getName(), ["string", "number|undefined"], arguments);
        I(this, "read_data_layer", a);
        c = (b || 2) !== 2 ? lp(a, 1) : np(a, [w, z]);
        var d = Id(c, this.K, Sh(YC(this).Ob()) ? 2 : 1);
        d === void 0 && c !== void 0 && M(45);
        return d
    }
    wE.publicName = "copyFromDataLayer";

    function xE(a) {
        var b = void 0;
        return b
    }
    xE.J = "internal.copyFromDataLayerCache";

    function yE(a) {
        var b;
        return b
    }
    yE.publicName = "copyFromWindow";

    function zE(a) {
        var b = void 0;
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        I(this, "unsafe_access_globals", a);
        var c = a.split(".");
        b = w[c.shift()];
        for (var d = 0; d < c.length; d++) b = b && b[c[d]];
        return Id(b, this.K, 1)
    }
    zE.J = "internal.copyKeyFromWindow";
    var AE = function(a) {
        return a === Gl.aa.Sa && Yl[a] === Fl.Ma.Fe && !Rn(K.m.W)
    };
    var BE = function() {
            return "0"
        },
        CE = function(a) {
            if (typeof a !== "string") return "";
            var b = ["gclid", "dclid", "wbraid", "_gl"];
            P(102) && b.push("gbraid");
            return qj(a, b, "0")
        };
    var DE = {},
        EE = {},
        FE = {},
        GE = {},
        HE = {},
        IE = {},
        JE = {},
        KE = {},
        LE = {},
        ME = {},
        NE = {},
        OE = {},
        PE = {},
        QE = {},
        RE = {},
        SE = {},
        TE = {},
        UE = {},
        VE = {},
        WE = {},
        XE = {},
        YE = {},
        ZE = {},
        $E = {},
        aF = {},
        bF = {},
        cF = (bF[K.m.Oa] = (DE[2] = [AE], DE), bF[K.m.Jf] = (EE[2] = [AE], EE), bF[K.m.Bf] = (FE[2] = [AE], FE), bF[K.m.sl] = (GE[2] = [AE], GE), bF[K.m.tl] = (HE[2] = [AE], HE), bF[K.m.vl] = (IE[2] = [AE], IE), bF[K.m.wl] = (JE[2] = [AE], JE), bF[K.m.xl] = (KE[2] = [AE], KE), bF[K.m.Jb] = (LE[2] = [AE], LE), bF[K.m.Kf] = (ME[2] = [AE], ME), bF[K.m.Lf] = (NE[2] = [AE], NE), bF[K.m.Mf] = (OE[2] = [AE], OE), bF[K.m.Nf] = (PE[2] = [AE], PE), bF[K.m.Of] = (QE[2] = [AE], QE), bF[K.m.Pf] = (RE[2] = [AE], RE), bF[K.m.Qf] = (SE[2] = [AE], SE), bF[K.m.Rf] = (TE[2] = [AE], TE), bF[K.m.tb] = (UE[1] = [AE], UE), bF[K.m.hd] = (VE[1] = [AE], VE), bF[K.m.md] = (WE[1] = [AE], WE), bF[K.m.oe] = (XE[1] = [AE], XE), bF[K.m.ff] = (YE[1] = [function(a) {
            return P(102) && AE(a)
        }], YE), bF[K.m.Cc] = (ZE[1] = [AE], ZE), bF[K.m.xa] = ($E[1] = [AE], $E), bF[K.m.Ya] = (aF[1] = [AE], aF), bF),
        dF = {},
        eF = (dF[K.m.tb] = BE, dF[K.m.hd] = BE, dF[K.m.md] = BE, dF[K.m.oe] = BE, dF[K.m.ff] = BE, dF[K.m.Cc] = function(a) {
            if (!sd(a)) return {};
            var b = td(a,
                null);
            delete b.match_id;
            return b
        }, dF[K.m.xa] = CE, dF[K.m.Ya] = CE, dF),
        fF = {},
        gF = {},
        hF = (gF[Q.A.Ua] = (fF[2] = [AE], fF), gF),
        iF = {};
    var jF = function(a, b, c, d) {
        this.C = a;
        this.P = b;
        this.T = c;
        this.V = d
    };
    jF.prototype.getValue = function(a) {
        a = a === void 0 ? Gl.aa.Sc : a;
        if (!this.P.some(function(b) {
                return b(a)
            })) return this.T.some(function(b) {
            return b(a)
        }) ? this.V(this.C) : this.C
    };
    jF.prototype.H = function() {
        return qd(this.C) === "array" || sd(this.C) ? td(this.C, null) : this.C
    };
    var kF = function() {},
        lF = function(a, b) {
            this.conditions = a;
            this.C = b
        },
        mF = function(a, b, c) {
            var d, e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
                f, g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
            return new jF(c, e, g, a.C[b] || kF)
        },
        nF, oF;
    var pF, qF = !1;

    function rF() {
        qF = !0;
        kg(52) && (pF = productSettings, productSettings = void 0);
        pF = pF || {}
    }

    function sF(a) {
        qF || rF();
        return pF[a]
    };
    var tF = function(a, b, c) {
            this.eventName = b;
            this.D = c;
            this.C = {};
            this.isAborted = !1;
            this.target = a;
            this.metadata = {};
            for (var d = c.eventMetadata || {}, e = m(Object.keys(d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                T(this, g, d[g])
            }
        },
        Hu = function(a, b) {
            var c, d;
            return (c = a.C[b]) == null ? void 0 : (d = c.getValue) == null ? void 0 : d.call(c, R(a, Q.A.gg))
        },
        X = function(a, b, c) {
            var d = a.C,
                e;
            c === void 0 ? e = void 0 : (nF != null || (nF = new lF(cF, eF)), e = mF(nF, b, c));
            d[b] = e
        };
    tF.prototype.mergeHitDataForKey = function(a, b) {
        var c, d, e;
        c = (d = this.C[a]) == null ? void 0 : (e = d.H) == null ? void 0 : e.call(d);
        if (!c) return X(this, a, b), !0;
        if (!sd(c)) return !1;
        X(this, a, na(Object, "assign").call(Object, c, b));
        return !0
    };
    var uF = function(a, b) {
        b = b === void 0 ? {} : b;
        for (var c = m(Object.keys(a.C)), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = void 0,
                g = void 0,
                h = void 0;
            b[e] = (f = a.C[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 : h.call(g)
        }
        return b
    };
    tF.prototype.copyToHitData = function(a, b, c) {
        var d = L(this.D, a);
        d === void 0 && (d = b);
        if (sb(d) && c !== void 0) try {
            d = c(d)
        } catch (e) {}
        d !== void 0 && X(this, a, d)
    };
    var R = function(a, b) {
            var c = a.metadata[b];
            if (b === Q.A.gg) {
                var d;
                return c == null ? void 0 : (d = c.H) == null ? void 0 : d.call(c)
            }
            var e;
            return c == null ? void 0 : (e = c.getValue) == null ? void 0 : e.call(c, R(a, Q.A.gg))
        },
        T = function(a, b, c) {
            var d = a.metadata,
                e;
            c === void 0 ? e = c : (oF != null || (oF = new lF(hF, iF)), e = mF(oF, b, c));
            d[b] = e
        },
        vF = function(a, b) {
            b = b === void 0 ? {} : b;
            for (var c = m(Object.keys(a.metadata)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value,
                    f = void 0,
                    g = void 0,
                    h = void 0;
                b[e] = (f = a.metadata[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 :
                    h.call(g)
            }
            return b
        },
        wF = function(a, b, c) {
            var d = sF(a.target.destinationId);
            return d && d[b] !== void 0 ? d[b] : c
        },
        xF = function(a) {
            for (var b = new tF(a.target, a.eventName, a.D), c = uF(a), d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
                var f = e.value;
                X(b, f, c[f])
            }
            for (var g = vF(a), h = m(Object.keys(g)), l = h.next(); !l.done; l = h.next()) {
                var n = l.value;
                T(b, n, g[n])
            }
            b.isAborted = a.isAborted;
            return b
        },
        yF = function(a) {
            var b = a.D,
                c = b.eventId,
                d = b.priorityId;
            return d ? c + "_" + d : String(c)
        };
    tF.prototype.accept = function() {
        var a = lm(gm.Z.xi, {}),
            b = yF(this),
            c = this.target.destinationId;
        a[b] || (a[b] = {});
        a[b][c] = Pj();
        var d = gm.Z.xi;
        if (hm(d)) {
            var e;
            (e = im(d)) == null || e.notify()
        }
    };
    tF.prototype.canBeAccepted = function(a) {
        var b = km(gm.Z.xi);
        if (!b) return !0;
        var c = b[yF(this)];
        if (!c) return !0;
        var d = c[a != null ? a : this.target.destinationId];
        return d === void 0 || d === Pj()
    };

    function zF(a) {
        return {
            getDestinationId: function() {
                return a.target.destinationId
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                a.eventName = b
            },
            getHitData: function(b) {
                return Hu(a, b)
            },
            setHitData: function(b, c) {
                X(a, b, c)
            },
            setHitDataIfNotDefined: function(b, c) {
                Hu(a, b) === void 0 && X(a, b, c)
            },
            copyToHitData: function(b, c) {
                a.copyToHitData(b, c)
            },
            getMetadata: function(b) {
                return R(a, b)
            },
            setMetadata: function(b, c) {
                T(a, b, c)
            },
            isAborted: function() {
                return a.isAborted
            },
            abort: function() {
                a.isAborted = !0
            },
            getFromEventContext: function(b) {
                return L(a.D, b)
            },
            pb: function() {
                return a
            },
            getHitKeys: function() {
                return Object.keys(a.C)
            },
            getMergedValues: function(b) {
                return a.D.getMergedValues(b, 3)
            },
            mergeHitDataForKey: function(b, c) {
                return sd(c) ? a.mergeHitDataForKey(b, c) : !1
            },
            accept: function() {
                a.accept()
            },
            canBeAccepted: function(b) {
                return a.canBeAccepted(b)
            }
        }
    };

    function AF(a, b) {
        var c;
        return c
    }
    AF.J = "internal.copyPreHit";

    function BF(a, b) {
        var c = null;
        return Id(c, this.K, 2)
    }
    BF.publicName = "createArgumentsQueue";

    function CF(a) {
        return Id(function(c) {
            var d = lz();
            if (typeof c === "function") d(function() {
                c(function(f, g, h) {
                    var l =
                        lz(),
                        n = l && l.getByName && l.getByName(f);
                    return (new w.gaplugins.Linker(n)).decorate(g, h)
                })
            });
            else if (Array.isArray(c)) {
                var e = String(c[0]).split(".");
                b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c)
            } else if (c === "isLoaded") return !!d.loaded
        }, this.K, 1)
    }
    CF.J = "internal.createGaCommandQueue";

    function DF(a) {
        return Id(function() {
                if (!rb(e.push)) throw Error("Object at " + a + " in window is not an array.");
                e.push.apply(e, Array.prototype.slice.call(arguments, 0))
            }, this.K,
            Sh(YC(this).Ob()) ? 2 : 1)
    }
    DF.publicName = "createQueue";

    function EF(a, b) {
        var c = null;
        if (!Dh(a) || !Eh(b)) throw G(this.getName(), ["string", "string|undefined"], arguments);
        try {
            var d = (b || "").split("").filter(function(e) {
                return "ig".indexOf(e) >= 0
            }).join("");
            c = new Fd(new RegExp(a, d))
        } catch (e) {}
        return c
    }
    EF.J = "internal.createRegex";

    function FF(a) {}
    FF.J = "internal.declareConsentState";

    function GF(a) {
        var b = "";
        return b
    }
    GF.J = "internal.decodeUrlHtmlEntities";

    function HF(a, b, c) {
        var d;
        return d
    }
    HF.J = "internal.decorateUrlWithGaCookies";

    function IF() {}
    IF.J = "internal.deferCustomEvents";

    function JF(a) {
        return P(423) || KF ? z.querySelector(a) : null
    }

    function LF(a) {
        return P(423) || KF ? z.querySelectorAll(a) : null
    }

    function MF(a, b) {
        if (P(423)) try {
            return a.closest(b)
        } catch (e) {
            return null
        } else {
            if (!KF) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!z.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (d !== null && d.nodeType ===
                1);
            return null
        }
    }
    var NF = !1;
    if (z.querySelectorAll) try {
        var OF = z.querySelectorAll(":root");
        OF && OF.length == 1 && OF[0] == z.documentElement && (NF = !0)
    } catch (a) {}
    var KF = NF;

    function PF() {
        var a = w.screen;
        return {
            width: a ? a.width : 0,
            height: a ? a.height : 0
        }
    }

    function QF(a) {
        if (z.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top === b.bottom || b.left === b.right || !w.getComputedStyle) return !0;
        var c = w.getComputedStyle(a, null);
        if (c.visibility === "hidden") return !0;
        for (var d = a, e = c; d;) {
            if (e.display === "none") return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var h = g.indexOf("opacity(");
                h >= 0 && (g = g.substring(h + 8, g.indexOf(")", h)), g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)), f = String(Math.min(Number(g), Number(f))))
            }
            if (f !== void 0 && Number(f) <= 0) return !0;
            (d = d.parentElement) &&
            (e = w.getComputedStyle(d, null))
        }
        return !1
    }

    function VG(a) {
        var b;
        return b
    }
    VG.J = "internal.detectUserProvidedData";

    function $G(a, b) {
        return f
    }
    $G.J = "internal.enableAutoEventOnClick";

    function hH(a, b) {
        return p
    }
    hH.J = "internal.enableAutoEventOnElementVisibility";

    function iH() {}
    iH.J = "internal.enableAutoEventOnError";
    var jH = {},
        kH = [],
        lH = {},
        mH = 0,
        nH = 0;

    function tH(a, b) {
        var c = this;
        return d
    }
    tH.J = "internal.enableAutoEventOnFormInteraction";

    function yH(a, b) {
        var c = this;
        return f
    }
    yH.J = "internal.enableAutoEventOnFormSubmit";

    function DH() {
        var a = this;
    }
    DH.J = "internal.enableAutoEventOnGaSend";
    var EH = {},
        FH = [];

    function MH(a, b) {
        var c = this;
        return f
    }
    MH.J = "internal.enableAutoEventOnHistoryChange";
    var NH = ["http://", "https://", "javascript:", "file://"];

    function RH(a, b) {
        var c = this;
        return h
    }
    RH.J = "internal.enableAutoEventOnLinkClick";
    var SH, TH;

    function dI(a, b) {
        var c = this;
        return d
    }
    dI.J = "internal.enableAutoEventOnScroll";

    function eI(a) {
        return function() {
            if (a.limit && a.Cj >= a.limit) a.Oh && w.clearInterval(a.Oh);
            else {
                a.Cj++;
                var b = Gb();
                kB({
                    event: a.eventName,
                    "gtm.timerId": a.Oh,
                    "gtm.timerEventNumber": a.Cj,
                    "gtm.timerInterval": a.interval,
                    "gtm.timerLimit": a.limit,
                    "gtm.timerStartTime": a.Kn,
                    "gtm.timerCurrentTime": b,
                    "gtm.timerElapsedTime": b - a.Kn,
                    "gtm.triggers": a.ys
                })
            }
        }
    }

    function fI(a, b) {
        return f
    }
    fI.J = "internal.enableAutoEventOnTimer";
    var vc = Ba(["data-gtm-yt-inspected-"]),
        hI = ["www.youtube.com", "www.youtube-nocookie.com"],
        iI, jI = !1;

    function tI(a, b) {
        var c = this;
        return e
    }
    tI.J = "internal.enableAutoEventOnYouTubeActivity";
    jI = !1;

    function uI(a, b) {
        if (!Dh(a) || !xh(b)) throw G(this.getName(), ["string", "Object|undefined"], arguments);
        var c = b ? B(b) : {},
            d = a,
            e = !1;
        return e
    }
    uI.J = "internal.evaluateBooleanExpression";
    var vI;

    function wI(a) {
        var b = !1;
        return b
    }
    wI.J = "internal.evaluateMatchingRules";
    var yI = [K.m.W, K.m.X];

    function JI(a) {
        if (P(10)) return;
        var b = uj() || kg(50) || !!zj(a.D);
        P(431) && (b = kg(50) || !!zj(a.D));
        if (b || P(168)) return;
        Xx({
            Ln: P(131)
        });
    };

    function OI() {
        var a;
        a = a === void 0 ? document : a;
        var b;
        return !((b = a.featurePolicy) == null || !b.allowedFeatures().includes("attribution-reporting"))
    };
    var lJ = {};
    var nJ = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function oJ(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function pJ(a) {
        var b = a.google_tag_data,
            c;
        if (b != null && b.uach) {
            var d = b.uach,
                e = na(Object, "assign").call(Object, {}, d);
            d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
            c = e
        } else c = null;
        return c
    }

    function qJ(a) {
        var b, c;
        return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) != null ? c : null
    }

    function rJ(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function sJ(a) {
        if (!rJ(a)) return null;
        var b = oJ(a);
        if (b.uach_promise) return b.uach_promise;
        var c = a.navigator.userAgentData.getHighEntropyValues(nJ).then(function(d) {
            b.uach != null || (b.uach = d);
            return d
        });
        return b.uach_promise = c
    };

    function yJ(a, b) {
        b = b === void 0 ? !1 : b;
        var c = R(a, Q.A.fg),
            d = wF(a, "custom_event_accept_rules", !1) && !b;
        if (c) {
            var e = c.indexOf(a.target.destinationId) >= 0,
                f = !0;
            R(a, Q.A.eb) && (f = R(a, Q.A.Pa) === Pj());
            e && f ? T(a, Q.A.Vh, !0) : (T(a, Q.A.Vh, !1), d || (a.isAborted = !0));
            if (a.canBeAccepted()) {
                var g = Oj().indexOf(a.target.destinationId) >= 0,
                    h = !1;
                if (!g) {
                    var l, n = (l = Hj(a.target.destinationId)) == null ? void 0 : l.canonicalContainerId;
                    n && (h = Pj() === n)
                }
                g || h ? R(a, Q.A.Vh) && a.accept() : a.isAborted = !0
            } else a.isAborted = !0
        }
    };
    var EJ = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        FJ = /^www.googleadservices.com$/;

    function GJ(a) {
        a || (a = VJ());
        return a.zs ? !1 : a.gr || a.hr || a.jr || a.ir || a.Ne || a.Ih || a.Qq || a.fc === "aw.ds" || P(235) && a.fc === "aw.dv" || a.Uq ? !0 : !1
    }

    function VJ() {
        var a = {},
            b = is(!0);
        a.zs = !!b._up;
        var c = Mt(),
            d = ou();
        a.gr = c.aw !== void 0;
        a.hr = c.dc !== void 0;
        a.jr = c.wbraid !== void 0;
        a.ir = c.gbraid !== void 0;
        a.fc = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
        a.Ne = d.Ne;
        a.Ih = d.Ih;
        var e = z.referrer ? jj(pj(z.referrer), "host") : "";
        a.Uq = EJ.test(e);
        a.Qq = FJ.test(e);
        return a
    };

    function WJ() {
        var a = w.__uspapi;
        if (rb(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    if (d && c) {
                        var e = c.uspString;
                        e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e)
                    }
                })
            } catch (c) {}
            return b
        }
    };

    function ZJ(a) {
        Nk && (Am = !0, a.eventName === K.m.ma ? Gm(a.D, a.target.id) : (R(a, Q.A.de) || (Dm[a.target.id] = !0), xA(R(a, Q.A.Pa))))
    };
    var eK = {
        Tf: {
            ao: "cd",
            bo: "ce",
            co: "cf",
            eo: "cpf",
            fo: "cu"
        }
    };

    function hK(a, b) {
        b = b === void 0 ? !0 : b;
        var c = pb(jb.GTAG_EVENT_FEATURE_CHANNEL || []);
        c && (X(a, K.m.Ff, c), b && nb())
    };

    function tK(a) {};

    function VK() {
        return Hq(7) && Hq(9) && Hq(10)
    };

    function PL(a, b, c, d) {}
    PL.J = "internal.executeEventProcessor";

    function QL(a) {
        var b;
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        I(this, "unsafe_run_arbitrary_javascript");
        try {
            var c = w.google_tag_manager;
            c && typeof c.e === "function" && (b = c.e(a))
        } catch (d) {}
        return Id(b, this.K, 1)
    }
    QL.J = "internal.executeJavascriptString";

    function RL(a) {
        var b;
        return b
    };

    function SL(a) {
        var b = "";
        return b
    }
    SL.J = "internal.generateClientId";

    function TL(a) {
        var b = {};
        return Id(b)
    }
    TL.J = "internal.getAdsCookieWritingOptions";

    function UL(a, b) {
        var c = !1;
        return c
    }
    UL.J = "internal.getAllowAdPersonalization";

    function VL() {
        var a;
        return a
    }
    VL.J = "internal.getAndResetEventUsage";

    function WL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    WL.J = "internal.getAuid";

    function XL() {
        var a = new bb;
        return a
    }
    XL.publicName = "getContainerVersion";

    function YL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        if (!Dh(a) || !Hh(b)) throw G(this.getName(), ["string", "boolean|undefined"], arguments);
        I(this, "get_cookies", a);
        c = Id(wr(a, void 0, !!b), this.K);
        return c
    }
    YL.publicName = "getCookieValues";

    function ZL() {
        var a = "";
        return a
    }
    ZL.J = "internal.getCorePlatformServicesParam";

    function $L() {
        return Om()
    }
    $L.J = "internal.getCountryCode";

    function aM() {
        var a = [];
        return Id(a)
    }
    aM.J = "internal.getDestinationIds";

    function bM(a) {
        var b = new bb;
        return b
    }
    bM.J = "internal.getDeveloperIds";

    function cM(a) {
        var b;
        return b
    }
    cM.J = "internal.getEcsidCookieValue";

    function dM(a, b) {
        var c = null;
        return c
    }
    dM.J = "internal.getElementAttribute";

    function eM(a) {
        var b = null;
        return b
    }
    eM.J = "internal.getElementById";

    function fM(a) {
        var b = "";
        return b
    }
    fM.J = "internal.getElementInnerText";

    function gM(a) {
        var b = null;
        return b
    }
    gM.J = "internal.getElementParent";

    function hM(a) {
        var b = null;
        return b
    }
    hM.J = "internal.getElementPreviousSibling";

    function iM(a, b) {
        var c = null;
        return Id(c)
    }
    iM.J = "internal.getElementProperty";

    function jM(a) {
        var b;
        return b
    }
    jM.J = "internal.getElementValue";

    function kM(a) {
        var b = 0;
        return b
    }
    kM.J = "internal.getElementVisibilityRatio";

    function lM(a) {
        var b = null;
        return b
    }
    lM.J = "internal.getElementsByCssSelector";

    function mM(a) {
        var b;
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        I(this, "read_event_data", a);
        var c;
        a: {
            var d = a,
                e = YC(this).originalEventData;
            if (e) {
                for (var f = e, g = {}, h = {}, l = {}, n = [], p = d.split("\\\\"), q = 0; q < p.length; q++) {
                    for (var r = p[q].split("\\."), u = 0; u < r.length; u++) {
                        for (var t = r[u].split("."), v = 0; v < t.length; v++) n.push(t[v]), v !== t.length - 1 && n.push(l);
                        u !== r.length - 1 && n.push(h)
                    }
                    q !== p.length - 1 && n.push(g)
                }
                for (var x = [], y = "", A = m(n), C = A.next(); !C.done; C =
                    A.next()) {
                    var E = C.value;
                    E === l ? (x.push(y), y = "") : y = E === g ? y + "\\" : E === h ? y + "." : y + E
                }
                y && x.push(y);
                for (var H = m(x), J = H.next(); !J.done; J = H.next()) {
                    if (f == null) {
                        c = void 0;
                        break a
                    }
                    f = f[J.value]
                }
                c = f
            } else c = void 0
        }
        b = Id(c, this.K, 1);
        return b
    }
    mM.J = "internal.getEventData";

    function nM(a) {
        var b = null;
        return b
    }
    nM.J = "internal.getFirstElementByCssSelector";
    var oM = {};
    oM.disableUserDataWithoutCcd = P(223);

    function pM() {
        return Id(oM)
    }
    pM.J = "internal.getFlags";

    function qM() {
        return Im["8"] || ""
    }
    qM.J = "internal.getGeoCurrencyCode";

    function rM() {
        var a;
        return a
    }
    rM.J = "internal.getGsaExperimentId";

    function sM() {
        return new Fd(dC)
    }
    sM.J = "internal.getHtmlId";

    function tM(a) {
        var b;
        return b
    }
    tM.J = "internal.getIframingState";

    function uM(a, b) {
        var c = {};
        return Id(c)
    }
    uM.J = "internal.getLinkerValueFromLocation";

    function vM() {
        var a = new bb;
        return a
    }
    vM.J = "internal.getPrivacyStrings";

    function wM(a, b) {
        var c;
        return c
    }
    wM.J = "internal.getProductSettingsParameter";

    function xM(a, b) {
        var c;
        return c
    }
    xM.publicName = "getQueryParameters";

    function yM(a, b) {
        var c;
        return c
    }
    yM.publicName = "getReferrerQueryParameters";

    function zM(a) {
        var b = "";
        if (!Eh(a)) throw G(this.getName(), ["string|undefined"], arguments);
        I(this, "get_referrer", a);
        b = lj(pj(z.referrer), a);
        return b
    }
    zM.publicName = "getReferrerUrl";

    function AM() {
        return Pm()
    }
    AM.J = "internal.getRegionCode";

    function BM(a, b) {
        var c;
        return c
    }
    BM.J = "internal.getRemoteConfigParameter";

    function CM(a, b) {
        var c = null;
        return c
    }
    CM.J = "internal.getScopedElementsByCssSelector";

    function DM() {
        var a = new bb;
        a.set("width", 0);
        a.set("height", 0);
        return a
    }
    DM.J = "internal.getScreenDimensions";

    function EM() {
        var a = "";
        return a
    }
    EM.J = "internal.getTopSameDomainUrl";

    function FM() {
        var a = "";
        return a
    }
    FM.J = "internal.getTopWindowUrl";

    function GM(a) {
        var b = "";
        if (!Eh(a)) throw G(this.getName(), ["string|undefined"], arguments);
        I(this, "get_url", a);
        b = jj(pj(w.location.href), a);
        return b
    }
    GM.publicName = "getUrl";

    function HM() {
        I(this, "get_user_agent");
        return Bc.userAgent
    }
    HM.J = "internal.getUserAgent";

    function IM() {
        var a;
        return a ? Id(tJ(a)) : a
    }
    IM.J = "internal.getUserAgentClientHints";

    function LM() {
        var a = w;
        return a.gaGlobal = a.gaGlobal || {}
    }

    function MM(a, b) {
        var c = LM();
        if (c.vid === void 0 || b && !c.from_cookie) c.vid = a, c.from_cookie = b
    };

    function nN(a) {
        (HI(a) || uj()) && X(a, K.m.zl, Pm() || Om());
        !HI(a) && uj() && X(a, K.m.Ei, "::")
    }

    function oN(a) {
        if (uj() && !HI(a) && (Sm() || X(a, K.m.al, !0), P(78))) {
            gK(a);
            fK(a, eK.Tf.eo, ln(L(a.D, K.m.Xa)));
            var b = eK.Tf.fo;
            var c = L(a.D, K.m.Ac);
            fK(a, b, c === !0 ? 1 : c === !1 ? 0 : void 0);
            fK(a, eK.Tf.co, ln(L(a.D, K.m.Fb)));
            fK(a, eK.Tf.ao, Nr(kn(L(a.D, K.m.wb)), kn(L(a.D, K.m.Wb))))
        }
    };
    var JN = {
        AW: gm.Z.Rn,
        G: gm.Z.Bp,
        DC: gm.Z.up
    };

    function KN(a) {
        var b = Hv(a);
        return "" + bi(b.map(function(c) {
            return c.value
        }).join("!"))
    }

    function LN(a) {
        var b = lo(a);
        return b && JN[b.prefix]
    }

    function MN(a, b) {
        var c = a[b];
        c && (c.clearTimerId && w.clearTimeout(c.clearTimerId), c.clearTimerId = w.setTimeout(function() {
            delete a[b]
        }, 36E5))
    };
    var wO = function(a) {
        for (var b = {}, c = String(vO.cookie).split(";"), d = 0; d < c.length; d++) {
            var e = c[d].split("="),
                f = e[0].trim();
            if (f && a(f)) {
                var g = e.slice(1).join("=").trim();
                g && (g = decodeURIComponent(g));
                var h = void 0,
                    l = void 0;
                ((h = b)[l = f] || (h[l] = [])).push(g)
            }
        }
        return b
    };
    var xO = window,
        vO = document,
        yO = function(a) {
            var b = xO._gaUserPrefs;
            if (b && b.ioo && b.ioo() || vO.documentElement.hasAttribute("data-google-analytics-opt-out") || a && xO["ga-disable-" + a] === !0) return !0;
            try {
                var c = xO.external;
                if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0
            } catch (f) {}
            for (var d = wO(function(f) {
                    return f === "AMP_TOKEN"
                }).AMP_TOKEN || [], e = 0; e < d.length; e++)
                if (d[e] == "$OPT_OUT") return !0;
            return vO.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var zO = "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(" ");

    function AO() {
        var a = z.location,
            b, c = a == null ? void 0 : (b = a.search) == null ? void 0 : b.replace("?", ""),
            d;
        if (c) {
            for (var e = [], f = hj(c, !0), g = m(zO), h = g.next(); !h.done; h = g.next()) {
                var l = h.value,
                    n = f[l];
                if (n)
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        q !== void 0 && e.push({
                            name: l,
                            value: q
                        })
                    }
            }
            d = e
        } else d = [];
        return d
    };

    function LO(a) {
        zb(a, function(c) {
            c.charAt(0) === "_" && delete a[c]
        });
        var b = a[K.m.yd] || {};
        zb(b, function(c) {
            c.charAt(0) === "_" && delete b[c]
        })
    };

    function pP(a) {}

    function qP(a) {
        var b = function() {};
        return b
    }

    function rP(a, b) {}
    var sP = F.M.xk,
        tP = F.M.yk;

    function uP(a, b) {
        var c = Nj();
        c && c.indexOf(b) > -1 && (a[Q.A.eb] = !0)
    }

    function wP(a, b, c) {
        var d = this;
    }
    wP.J = "internal.gtagConfig";

    function xP(a, b, c) {
        var d = this;
    }
    xP.J = "internal.gtagDestinationConfig";

    function zP(a, b) {}
    zP.publicName = "gtagSet";

    function AP() {
        var a = {};
        return a
    };

    function BP(a) {}
    BP.J = "internal.initializeServiceWorker";

    function CP(a, b) {}
    CP.publicName = "injectHiddenIframe";
    var DP = function() {
        var a = 0;
        return function(b) {
            switch (b) {
                case 1:
                    a |= 1;
                    break;
                case 2:
                    a |= 2;
                    break;
                case 3:
                    a |= 4
            }
            return a
        }
    }();

    function EP(a, b, c, d, e) {}
    EP.J = "internal.injectHtml";
    var IP = {};

    function KP(a, b, c, d) {}
    var LP = {
            dl: 1,
            id: 1
        },
        MP = {};

    function NP(a, b, c, d) {}
    P(160) ? NP.publicName = "injectScript" : KP.publicName = "injectScript";
    NP.J = "internal.injectScript";

    function OP() {
        var a = !1;
        return a
    }
    OP.J = "internal.isAutoPiiEligible";

    function PP(a) {
        var b = !0;
        return b
    }
    PP.publicName = "isConsentGranted";

    function QP(a) {
        var b = !1;
        return b
    }
    QP.J = "internal.isDebugMode";

    function RP() {
        return Rm()
    }
    RP.J = "internal.isDmaRegion";

    function SP() {
        return mA
    }
    SP.J = "internal.isDomReady";

    function TP(a) {
        var b = !1;
        return b
    }
    TP.J = "internal.isEntityInfrastructure";

    function UP(a) {
        var b = !1;
        return b
    }
    UP.J = "internal.isFeatureEnabled";

    function VP() {
        var a = !1;
        return a
    }
    VP.J = "internal.isFpfe";

    function WP() {
        var a = !1;
        return a
    }
    WP.J = "internal.isGcpConversion";

    function XP() {
        var a = !1;
        return a
    }
    XP.J = "internal.isLandingPage";

    function YP() {
        var a = !1;
        return a
    }
    YP.J = "internal.isOgt";

    function ZP() {
        var a;
        return a
    }
    ZP.J = "internal.isSafariPcmEligibleBrowser";

    function $P() {
        var a = gi(function(b) {
            YC(this).log("error", b)
        });
        a.publicName = "JSON";
        return a
    };

    function aQ(a) {
        var b = void 0;
        if (!Dh(a)) throw G(this.getName(), ["string"], arguments);
        b = pj(a);
        return Id(b)
    }
    aQ.J = "internal.legacyParseUrl";

    function bQ() {
        return !1
    }
    var cQ = {
        getItem: function(a) {
            var b = null;
            return b
        },
        setItem: function(a, b) {
            return !1
        },
        removeItem: function(a) {}
    };

    function dQ() {}
    dQ.publicName = "logToConsole";

    function eQ(a, b) {}
    eQ.J = "internal.mergeRemoteConfig";

    function fQ(a, b, c) {
        c = c === void 0 ? !0 : c;
        var d = [];
        if (!Dh(a) || !Dh(b) || !Gh(c)) throw G(this.getName(), ["string", "string", "boolean|undefined"], arguments);
        d = wr(b, a, !!c);
        return Id(d)
    }
    fQ.J = "internal.parseCookieValuesFromString";

    function gQ(a) {
        var b = void 0;
        if (typeof a !== "string") return;
        a && Lb(a, "//") && (a = z.location.protocol + a);
        if (typeof URL === "function") {
            var c;
            a: {
                var d;
                try {
                    d = new URL(a)
                } catch (x) {
                    c = void 0;
                    break a
                }
                for (var e = {}, f = Array.from(d.searchParams), g = 0; g < f.length; g++) {
                    var h = f[g][0],
                        l = f[g][1];
                    e.hasOwnProperty(h) ? typeof e[h] === "string" ? e[h] = [e[h], l] : e[h].push(l) : e[h] = l
                }
                c = Id({
                    href: d.href,
                    origin: d.origin,
                    protocol: d.protocol,
                    username: d.username,
                    password: d.password,
                    host: d.host,
                    hostname: d.hostname,
                    port: d.port,
                    pathname: d.pathname,
                    search: d.search,
                    searchParams: e,
                    hash: d.hash
                })
            }
            return c
        }
        var n;
        try {
            n = pj(a)
        } catch (x) {
            return
        }
        if (!n.protocol || !n.host) return;
        var p = {};
        if (n.search)
            for (var q = n.search.replace("?", "").split("&"), r = 0; r < q.length; r++) {
                var u = q[r].split("="),
                    t = u[0],
                    v = ij(u.splice(1).join("=")) || "";
                v = v.replace(/\+/g, " ");
                p.hasOwnProperty(t) ? typeof p[t] === "string" ? p[t] = [p[t], v] : p[t].push(v) : p[t] = v
            }
        n.searchParams = p;
        n.origin = n.protocol + "//" + n.host;
        n.username = "";
        n.password = "";
        b = Id(n);
        return b
    }
    gQ.publicName = "parseUrl";

    function hQ(a) {}
    hQ.J = "internal.processAsNewEvent";

    function iQ(a, b, c) {
        var d;
        return d
    }
    iQ.J = "internal.pushToDataLayer";

    function jQ(a) {
        var b = Da.apply(1, arguments),
            c = !1;
        return c
    }
    jQ.publicName = "queryPermission";

    function kQ(a) {
        var b = this;
    }
    kQ.J = "internal.queueAdsTransmission";

    function lQ(a) {
        var b = void 0;
        return b
    }
    lQ.publicName = "readAnalyticsStorage";

    function mQ() {
        var a = "";
        return a
    }
    mQ.publicName = "readCharacterSet";

    function nQ() {
        return D(19)
    }
    nQ.J = "internal.readDataLayerName";

    function oQ() {
        var a = "";
        return a
    }
    oQ.publicName = "readTitle";

    function pQ(a, b) {
        var c = this;
    }
    pQ.J = "internal.registerCcdCallback";

    function qQ(a, b) {
        return !0
    }
    qQ.J = "internal.registerDestination";
    var rQ = ["config", "event", "get", "set"];

    function sQ(a, b, c) {}
    sQ.J = "internal.registerGtagCommandListener";

    function tQ(a, b) {
        var c = !1;
        return c
    }
    tQ.J = "internal.removeDataLayerEventListener";

    function uQ(a, b) {}
    uQ.J = "internal.removeFormData";

    function vQ() {}
    vQ.publicName = "resetDataLayer";

    function wQ(a, b, c) {
        var d = void 0;
        return d
    }
    wQ.J = "internal.scrubUrlParams";

    function xQ(a) {}
    xQ.J = "internal.sendAdsHit";

    function yQ(a, b, c, d) {}
    yQ.J = "internal.sendGtagEvent";

    function zQ(a, b, c) {}
    zQ.publicName = "sendPixel";

    function AQ(a, b) {}
    AQ.J = "internal.setAnchorHref";

    function BQ(a) {}
    BQ.J = "internal.setContainerConsentDefaults";

    function CQ(a, b, c, d) {
        var e = this;
        d = d === void 0 ? !0 : d;
        var f = !1;
        return f
    }
    CQ.publicName = "setCookie";

    function DQ(a) {}
    DQ.J = "internal.setCorePlatformServices";

    function EQ(a, b) {}
    EQ.J = "internal.setDataLayerValue";

    function FQ(a) {}
    FQ.publicName = "setDefaultConsentState";

    function GQ(a, b) {}
    GQ.J = "internal.setDelegatedConsentType";

    function HQ(a, b) {}
    HQ.J = "internal.setFormAction";

    function IQ(a, b, c) {
        c = c === void 0 ? !1 : c;
    }
    IQ.J = "internal.setInCrossContainerData";

    function JQ(a, b, c) {
        return !1
    }
    JQ.publicName = "setInWindow";

    function KQ(a, b, c) {}
    KQ.J = "internal.setProductSettingsParameter";

    function LQ(a, b, c) {}
    LQ.J = "internal.setRemoteConfigParameter";

    function MQ(a, b) {}
    MQ.J = "internal.setTransmissionMode";

    function NQ(a, b, c, d) {
        var e = this;
    }
    NQ.publicName = "sha256";

    function OQ(a, b, c) {}
    OQ.J = "internal.sortRemoteConfigParameters";

    function PQ(a) {}
    PQ.J = "internal.storeAdsBraidLabels";

    function QQ(a, b) {
        var c = void 0;
        return c
    }
    QQ.J = "internal.subscribeToCrossContainerData";

    function RQ(a) {}
    RQ.J = "internal.taskSendAdsHits";
    var SQ = {},
        TQ = {};
    SQ.getItem = function(a) {
        var b = null;
        return b
    };
    SQ.setItem = function(a, b) {};
    SQ.removeItem = function(a) {};
    SQ.clear = function() {};
    SQ.publicName = "templateStorage";
    SQ.resetForTest = function() {
        for (var a = m(Object.keys(TQ)), b = a.next(); !b.done; b = a.next()) delete TQ[b.value]
    };

    function UQ(a, b) {
        var c = !1;
        if (!Ch(a) || !Dh(b)) throw G(this.getName(), ["OpaqueValue", "string"], arguments);
        var d = a.getValue();
        if (!(d instanceof RegExp)) return !1;
        c = d.test(b);
        return c
    }
    UQ.J = "internal.testRegex";

    function VQ(a) {
        var b;
        return b
    };

    function WQ(a, b) {}
    WQ.J = "internal.trackUsage";

    function XQ(a, b) {
        var c;
        return c
    }
    XQ.J = "internal.unsubscribeFromCrossContainerData";

    function YQ(a) {}
    YQ.publicName = "updateConsentState";

    function ZQ(a) {
        var b = !1;
        return b
    }
    ZQ.J = "internal.userDataNeedsEncryption";
    var $Q;

    function aR(a, b, c) {
        $Q = $Q || new ri;
        $Q.add(a, b, c)
    }

    function bR(a, b) {
        var c = $Q = $Q || new ri;
        if (c.C.hasOwnProperty(a)) throw Error("Attempting to add a private function which already exists: " + a + ".");
        if (c.contains(a)) throw Error("Attempting to add a private function with an existing API name: " + a + ".");
        c.C[a] = rb(b) ? Lh(a, b) : Mh(a, b)
    }

    function cR() {
        return function(a) {
            var b;
            var c = $Q;
            if (c.contains(a)) b = c.get(a, this);
            else {
                var d;
                if (d = c.C.hasOwnProperty(a)) {
                    var e = this.K.qb();
                    if (e) {
                        var f = !1,
                            g = e.Ob();
                        if (g) {
                            Sh(g) || (f = !0);
                        }
                        d = f
                    } else d = !0
                }
                if (d) {
                    var h = c.C.hasOwnProperty(a) ? c.C[a] : void 0;
                    b = h
                } else throw Error(a + " is not a valid API name.");
            }
            return b
        }
    };

    function dR() {
        var a = function(c) {
                return void bR(c.J, c)
            },
            b = function(c) {
                return void aR(c.publicName, c)
            };
        b(SC);
        b(ZC);
        b(mE);
        b(oE);
        b(pE);
        b(wE);
        b(yE);
        b(BF);
        b($P());
        b(DF);
        b(XL);
        b(YL);
        b(xM);
        b(yM);
        b(zM);
        b(GM);
        b(zP);
        b(CP);
        b(PP);
        b(dQ);
        b(gQ);
        b(jQ);
        b(lQ);
        b(mQ);
        b(oQ);
        b(zQ);
        b(CQ);
        b(FQ);
        b(JQ);
        b(NQ);
        b(SQ);
        b(YQ);
        aR("Math", Qh());
        aR("Object", pi);
        aR("TestHelper", ti());
        aR("assertApi", Nh);
        aR("assertThat", Oh);
        aR("decodeUri", Th);
        aR("decodeUriComponent", Uh);
        aR("encodeUri", Vh);
        aR("encodeUriComponent", Wh);
        aR("fail", ai);
        aR("generateRandom",
            di);
        aR("getTimestamp", ei);
        aR("getTimestampMillis", ei);
        aR("getType", fi);
        aR("makeInteger", hi);
        aR("makeNumber", ii);
        aR("makeString", ji);
        aR("makeTableMap", ki);
        aR("mock", ni);
        aR("mockObject", oi);
        aR("fromBase64", RL, !("atob" in w));
        aR("localStorage", cQ, !bQ());
        aR("toBase64", VQ, !("btoa" in w));
        a(RC);
        a(VC);
        a(oD);
        a(AD);
        a(HD);
        a(MD);
        a(bE);
        a(kE);
        a(nE);
        a(qE);
        a(rE);
        a(sE);
        a(tE);
        a(uE);
        a(vE);
        a(xE);
        a(zE);
        a(AF);
        a(CF);
        a(EF);
        a(FF);
        a(GF);
        a(HF);
        a(IF);
        a(VG);
        a($G);
        a(hH);
        a(iH);
        a(tH);
        a(yH);
        a(DH);
        a(MH);
        a(RH);
        a(dI);
        a(fI);
        a(tI);
        a(uI);
        a(wI);
        a(PL);
        a(QL);
        a(SL);
        a(TL);
        a(UL);
        a(VL);
        a(WL);
        a(ZL);
        a($L);
        a(aM);
        a(bM);
        a(cM);
        a(dM);
        a(eM);
        a(fM);
        a(gM);
        a(hM);
        a(iM);
        a(jM);
        a(kM);
        a(lM);
        a(mM);
        a(nM);
        a(pM);
        a(qM);
        a(rM);
        a(sM);
        a(tM);
        a(uM);
        a(vM);
        a(wM);
        a(AM);
        a(BM);
        a(CM);
        a(DM);
        a(EM);
        a(FM);
        a(IM);
        a(wP);
        a(xP);
        a(BP);
        a(EP);
        a(NP);
        a(OP);
        a(QP);
        a(RP);
        a(SP);
        a(TP);
        a(UP);
        a(VP);
        a(WP);
        a(XP);
        a(YP);
        a(ZP);
        a(aQ);
        a($D);
        a(eQ);
        a(fQ);
        a(hQ);
        a(iQ);
        a(kQ);
        a(nQ);
        a(pQ);
        a(qQ);
        a(sQ);
        a(tQ);
        a(uQ);
        a(wQ);
        a(xQ);
        a(yQ);
        a(AQ);
        a(BQ);
        a(DQ);
        a(EQ);
        a(GQ);
        a(HQ);
        a(IQ);
        a(KQ);
        a(LQ);
        a(MQ);
        a(OQ);
        a(PQ);
        a(QQ);
        a(RQ);
        a(UQ);
        a(WQ);
        a(XQ);
        a(ZQ);
        bR("internal.IframingStateSchema", AP());
        bR("internal.quickHash", ci);
        P(160) ? b(NP) : b(KP);
        return cR()
    };
    var PC;

    function eR() {
        var a = data.sandboxed_scripts,
            b = data.security_groups;
        a: {
            var c = data.runtime || [],
                d = data.runtime_lines;PC = new ef;fR();Pf = OC();
            var e = PC,
                f = dR(),
                g = new Bd("require", f);g.Va();e.C.C.set("require", g);Xa.set("require", g);
            for (var h = [], l = 0; l < c.length; l++) {
                var n = c[l];
                if (!Array.isArray(n) || n.length < 3) {
                    if (n.length === 0) continue;
                    break a
                }
                d && d[l] && d[l].length && rg(n, d[l]);
                try {
                    PC.execute(n), P(120) && Lk && n[0] === 50 && h.push(n[1])
                } catch (r) {}
            }
            P(120) && (bg = h)
        }
        if (a && a.length)
            for (var p = 0; p < a.length; p++) {
                var q = a[p].replace(/^_*/,
                    "");
                cj[q] = ["sandboxedScripts"]
            }
        gR(b)
    }

    function fR() {
        PC.Zc(function(a, b, c) {
            Zn.SANDBOXED_JS_SEMAPHORE = Zn.SANDBOXED_JS_SEMAPHORE || 0;
            Zn.SANDBOXED_JS_SEMAPHORE++;
            try {
                return a.apply(b, c)
            } finally {
                Zn.SANDBOXED_JS_SEMAPHORE--
            }
        })
    }

    function gR(a) {
        a && zb(a, function(b, c) {
            for (var d = 0; d < c.length; d++) {
                var e = c[d].replace(/^_*/, "");
                cj[e] = cj[e] || [];
                cj[e].push(b)
            }
        })
    };

    function hR(a) {
        DA(yA("developer_id." + a, !0), 0, {})
    };
    var iR = Array.isArray;

    function jR(a, b) {
        return td(a, b || null)
    }

    function Y(a) {
        return window.encodeURIComponent(a)
    }

    function kR(a, b, c) {
        Rc(a, b, c)
    }

    function lR(a) {
        var b = ["veinteractive.com", "ve-interactive.cn"];
        if (!a) return !1;
        var c = jj(pj(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                f > 0 && e.charAt(0) !== "." && (f--, e = "." + e);
                if (f >= 0 && c.indexOf(e, f) === f) return !0
            }
        }
        return !1
    }

    function mR(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    }

    function nR(a, b) {
        var c = {};
        if (a)
            for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
        if (b) {
            var e = mR(b, "parameter", "parameterValue");
            e && (c = jR(e, c))
        }
        return c
    }

    function oR(a, b, c) {
        return a === void 0 || a === c ? b : a
    }
    var pR = {
        La: {
            Tj: 1,
            Im: 2,
            Tm: 3,
            Um: 4,
            Vm: 5,
            Fm: 6
        }
    };
    pR.La[pR.La.Tj] = "ADOBE_COMMERCE";
    pR.La[pR.La.Im] = "SQUARESPACE";
    pR.La[pR.La.Tm] = "WOO_COMMERCE";
    pR.La[pR.La.Um] = "WOO_COMMERCE_LEGACY";
    pR.La[pR.La.Vm] = "WORD_PRESS";
    pR.La[pR.La.Fm] = "SHOPIFY";

    function qR() {
        try {
            if (!P(243)) return [];
            var a = P(430);
            if (a) {
                var b = km(gm.Z.tm);
                if (Array.isArray(b)) return b
            }
            sr("4");
            var c = [],
                d;
            a: {
                try {
                    d = !!JF('script[data-requiremodule^="mage/"]');
                    break a
                } catch (u) {}
                d = !1
            }
            d && c.push(pR.La.Tj);
            var e;
            a: {
                try {
                    e = !!JF('script[src^="//assets.squarespace.com/"]');
                    break a
                } catch (u) {}
                e = !1
            }
            e && c.push(pR.La.Im);
            var f;
            a: {
                if (P(425)) try {
                    f = !!JF('script[src*="cdn.shopify.com"],meta[property="og:image"][content*="cdn.shopify.com"],link[rel="preconnect"][href*="cdn.shopify.com"],link[rel="preconnect"][href*="fonts.shopifycdn.com"],link[rel="preconnect"][href*="iterable-shopify"],link[rel="preconnect"][href*="v.shopify.com"]');
                    break a
                } catch (u) {}
                f = !1
            }
            f && c.push(pR.La.Fm);
            var g;
            a: {
                try {
                    g = !!JF('script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]');
                    break a
                } catch (u) {}
                g = !1
            }
            g && c.push(pR.La.Um);
            var h;
            a: {
                try {
                    var l, n = ((l = z.location) == null ? void 0 : l.hostname) || "",
                        p, q = ((p = z.location) == null ? void 0 : p.origin) || "";
                    h = Mb(n, ".wordpress.com") || !!JF('[src^="' + q + '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="//s.w.org"]');
                    break a
                } catch (u) {}
                h = !1
            }
            h && c.push(pR.La.Vm);
            var r;
            a: {
                try {
                    r = !!JF('[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]');
                    break a
                } catch (u) {}
                r = !1
            }
            r && c.push(pR.La.Tm);
            tr("4");
            mA && a && jm(gm.Z.tm, c);
            return c
        } catch (u) {}
        return []
    };

    function rR(a, b, c) {
        return Nc(a, b, c, void 0)
    }

    function sR(a, b) {
        return lp(a, b || 2)
    }

    function tR(a, b) {
        w[a] = b
    }

    function uR(a, b, c) {
        var d = w;
        b && (d[a] === void 0 || c && !d[a]) && (d[a] = b);
        return d[a]
    }
    var vR = {},
        wR = Pi.N;
    var Z = {
        securityGroups: {}
    };

    Z.securityGroups.access_globals = ["google"],
        function() {
            function a(b, c, d) {
                var e = {
                    key: d,
                    read: !1,
                    write: !1,
                    execute: !1
                };
                switch (c) {
                    case "read":
                        e.read = !0;
                        break;
                    case "write":
                        e.write = !0;
                        break;
                    case "readwrite":
                        e.read = e.write = !0;
                        break;
                    case "execute":
                        e.execute = !0;
                        break;
                    default:
                        throw Error("Invalid " + b + " request " + c);
                }
                return e
            }(function(b) {
                Z.__access_globals = b;
                Z.__access_globals.F = "access_globals";
                Z.__access_globals.isVendorTemplate = !0;
                Z.__access_globals.priorityOverride = 0;
                Z.__access_globals.isInfrastructure = !1;
                Z.__access_globals["5"] = !1
            })(function(b) {
                for (var c = b.vtp_keys || [], d = b.vtp_createPermissionError, e = [], f = [], g = [], h = 0; h < c.length; h++) {
                    var l = c[h],
                        n = l.key;
                    l.read && e.push(n);
                    l.write && f.push(n);
                    l.execute && g.push(n)
                }
                return {
                    assert: function(p, q, r) {
                        if (!sb(r)) throw d(p, {}, "Key must be a string.");
                        if (q === "read") {
                            if (e.indexOf(r) > -1) return
                        } else if (q === "write") {
                            if (f.indexOf(r) > -1) return
                        } else if (q === "readwrite") {
                            if (f.indexOf(r) > -1 && e.indexOf(r) > -1) return
                        } else if (q === "execute") {
                            if (g.indexOf(r) > -1) return
                        } else throw d(p, {}, "Operation must be either 'read', 'write', or 'execute', was " + q);
                        throw d(p, {}, "Prohibited " + q + " on global variable: " + r + ".");
                    },
                    U: a
                }
            })
        }();
    Z.securityGroups.get_referrer = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Z.__get_referrer = b;
                Z.__get_referrer.F = "get_referrer";
                Z.__get_referrer.isVendorTemplate = !0;
                Z.__get_referrer.priorityOverride = 0;
                Z.__get_referrer.isInfrastructure = !1;
                Z.__get_referrer["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"),
                    b.vtp_query && c.push("query"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!sb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!sb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " +
                                    h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    U: a
                }
            })
        }();
    Z.securityGroups.read_event_data = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Z.__read_event_data = b;
                Z.__read_event_data.F = "read_event_data";
                Z.__read_event_data.isVendorTemplate = !0;
                Z.__read_event_data.priorityOverride = 0;
                Z.__read_event_data.isInfrastructure = !1;
                Z.__read_event_data["5"] = !1
            })(function(b) {
                var c = b.vtp_eventDataAccess,
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (g != null && !sb(g)) throw e(f, {
                            key: g
                        }, "Key must be a string.");
                        if (c !== "any") {
                            try {
                                if (c ===
                                    "specific" && g != null && ah(g, d)) return
                            } catch (h) {
                                throw e(f, {
                                    key: g
                                }, "Invalid key filter.");
                            }
                            throw e(f, {
                                key: g
                            }, "Prohibited read from event data.");
                        }
                    },
                    U: a
                }
            })
        }();

    Z.securityGroups.read_data_layer = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Z.__read_data_layer = b;
                Z.__read_data_layer.F = "read_data_layer";
                Z.__read_data_layer.isVendorTemplate = !0;
                Z.__read_data_layer.priorityOverride = 0;
                Z.__read_data_layer.isInfrastructure = !1;
                Z.__read_data_layer["5"] = !1
            })(function(b) {
                var c = b.vtp_allowedKeys || "specific",
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (!sb(g)) throw e(f, {}, "Keys must be strings.");
                        if (c !== "any") {
                            try {
                                if (ah(g,
                                        d)) return
                            } catch (h) {
                                throw e(f, {}, "Invalid key filter.");
                            }
                            throw e(f, {}, "Prohibited read from data layer variable: " + g + ".");
                        }
                    },
                    U: a
                }
            })
        }();
    Z.securityGroups.unsafe_access_globals = ["google"],
        function() {
            function a(c, d) {
                c("access_globals", "readwrite", d)
            }

            function b(c, d) {
                return {
                    key: d
                }
            }(function(c) {
                Z.__unsafe_access_globals = c;
                Z.__unsafe_access_globals.F = "unsafe_access_globals";
                Z.__unsafe_access_globals.isVendorTemplate = !0;
                Z.__unsafe_access_globals.priorityOverride = 0;
                Z.__unsafe_access_globals.isInfrastructure = !1;
                Z.__unsafe_access_globals["5"] = !1
            })(function(c) {
                var d = c.vtp_createPermissionError;
                return {
                    assert: function(e, f) {
                        if (!sb(f)) throw d(e, {}, "Wrong key type. Must be string.");
                    },
                    U: b,
                    Xm: a
                }
            })
        }();








    Z.securityGroups.get_url = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Z.__get_url = b;
                Z.__get_url.F = "get_url";
                Z.__get_url.isVendorTemplate = !0;
                Z.__get_url.priorityOverride = 0;
                Z.__get_url.isInfrastructure = !1;
                Z.__get_url["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"), b.vtp_query && c.push("query"), b.vtp_fragment &&
                    c.push("fragment"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!sb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!sb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " + h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    U: a
                }
            })
        }();

    Z.securityGroups.unsafe_run_arbitrary_javascript = ["google"],
        function() {
            function a() {
                return {}
            }(function(b) {
                Z.__unsafe_run_arbitrary_javascript = b;
                Z.__unsafe_run_arbitrary_javascript.F = "unsafe_run_arbitrary_javascript";
                Z.__unsafe_run_arbitrary_javascript.isVendorTemplate = !0;
                Z.__unsafe_run_arbitrary_javascript.priorityOverride = 0;
                Z.__unsafe_run_arbitrary_javascript.isInfrastructure = !1;
                Z.__unsafe_run_arbitrary_javascript["5"] = !1
            })(function() {
                return {
                    assert: function() {},
                    U: a
                }
            })
        }();











    Z.securityGroups.get_cookies = ["google"],
        function() {
            function a(b, c) {
                return {
                    name: c
                }
            }(function(b) {
                Z.__get_cookies = b;
                Z.__get_cookies.F = "get_cookies";
                Z.__get_cookies.isVendorTemplate = !0;
                Z.__get_cookies.priorityOverride = 0;
                Z.__get_cookies.isInfrastructure = !1;
                Z.__get_cookies["5"] = !1
            })(function(b) {
                var c = b.vtp_cookieAccess || "specific",
                    d = b.vtp_cookieNames || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (!sb(g)) throw e(f, {}, "Cookie name must be a string.");
                        if (c !== "any" && !(c === "specific" && d.indexOf(g) >=
                                0)) throw e(f, {}, 'Access to cookie "' + g + '" is prohibited.');
                    },
                    U: a
                }
            })
        }();
    var xR = {},
        bo = {
            dataLayer: mp,
            callback: function(a) {
                xR.hasOwnProperty(a) && rb(xR[a]) && xR[a]();
                delete xR[a]
            },
            bootstrap: 0
        };
    bo.onHtmlSuccess = jC(!0), bo.onHtmlFailure = jC(!1);

    function yR() {
        ao();
        Wj();
        Py();
        Jb(cj, Z.securityGroups);
        var a = Sj(Tj()),
            b, c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
        An(c, a == null ? void 0 : a.parent);
        c !== 2 && c !== 4 && c !== 3 || M(142);
        fC(), Yf({
            vr: function(d) {
                return d === dC
            },
            Dq: function(d) {
                return new gC(d)
            },
            wr: function(d) {
                for (var e = !1, f = !1, g = 2; g < d.length; g++) e = e || d[g] === 8, f = f || d[g] === 16;
                return e && f
            },
            Mr: function(d) {
                var e;
                if (d === dC) e = d;
                else {
                    var f = fo();
                    eC[f] = d;
                    e = 'google_tag_manager["rm"]["' + Pj() + '"](' + f + ")"
                }
                return e
            }
        });
        ag = {
            yq: xg
        }
    }

    function zR() {
        var a = D(60);
        a && a && (lJ[a] = !0)
    }

    function Lm() {
        try {
            if (kg(47) || !fk()) {
                Ui();
                if (P(109)) {}
                Va[6] = !0;
                var a = $n("debugGroupId", function() {
                    return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
                });
                In(a);
                io();
                HC();
                Aq();
                lA();
                if (Xj()) {
                    D(5);
                    XD();
                    Pz().removeExternalRestrictions(Pj());
                } else {
                    tw();
                    Zf();
                    Vf = Z;
                    Wf = pC;
                    Bx();
                    eR();
                    yR();
                    nC();
                    Jm || (Im = Nm(), Im["0"] && lm(gm.Z.De, JSON.stringify(Im)));
                    Xn();
                    rB();
                    rA();
                    ZA = !1;
                    z.readyState === "complete" ? aB() : Sc(w, "load", aB);
                    kA();
                    Lk && (wp(Jp), w.setInterval(Ip, 864E5), wp(IC), wp(Az), wp(Pw), wp(Mp), wp(LC), wp(Nz), P(120) && (wp(Fz), wp(Gz), wp(Hz)), kC = {}, wp(mC));
                    Nk && (xm(), zo(), tB(), HB(), CB(), lk("bt", String(kg(47) ? 2 : kg(50) ? 1 : 0)), lk("ct", String(kg(47) ?
                        0 : kg(50) ? 1 : 3)), xB(), BB(), FB());
                    bC();
                    Hm(1);
                    YD();
                    bo.bootstrap = Gb();
                    kg(51) && qB();
                    P(109) && kx();
                    typeof w.name === "string" && Lb(w.name, "web-pixel-sandbox-CUSTOM") && id() ? hR("dMDg0Yz") : w.Shopify && (hR("dN2ZkMj"), id() && hR("dNTU0Yz"));
                    zR()
                }
            }
        } catch (b) {
            Hm(5), Fp()
        }
    }
    (function(a) {
        function b() {
            n = z.documentElement.getAttribute("data-tag-assistant-present");
            nn(n) && (l = h.Gl)
        }

        function c() {
            l && Ec ? g(l) : a()
        }
        if (!w[D(37)]) {
            var d = !1;
            if (z.referrer) {
                var e = pj(z.referrer);
                d = lj(e, "host") === D(38)
            }
            if (!d) {
                var f = wr(D(39));
                d = !(!f.length || !f[0].length)
            }
            d && (w[D(37)] = !0, Nc(D(40)))
        }
        var g = function(t) {
                var v = "GTM",
                    x = "GTM";
                Zi && (v = "OGT", x = "GTAG");
                var y = D(23),
                    A = w[y];
                A || (A = [], w[y] = A, Nc("https://" + D(3) + "/debug/bootstrap?id=" + D(5) + "&src=" + x + "&cond=" + String(t) + "&gtm=" + sp()));
                var C = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: Ec,
                        containerProduct: v,
                        debug: !1,
                        id: D(5),
                        targetRef: {
                            ctid: D(5),
                            isDestination: Mj(),
                            canonicalId: D(6)
                        },
                        aliases: Qj(),
                        destinations: Nj()
                    }
                };
                C.data.resume = function() {
                    a()
                };
                kg(2) && (C.data.initialPublish = !0);
                A.push(C)
            },
            h = {
                Ep: 1,
                Vl: 2,
                xm: 3,
                rk: 4,
                Gl: 5
            };
        h[h.Ep] = "GTM_DEBUG_LEGACY_PARAM";
        h[h.Vl] = "GTM_DEBUG_PARAM";
        h[h.xm] = "REFERRER";
        h[h.rk] = "COOKIE";
        h[h.Gl] = "EXTENSION_PARAM";
        var l = void 0,
            n = void 0,
            p = jj(w.location, "query", !1, void 0, "gtm_debug");
        nn(p) && (l = h.Vl);
        if (!l && z.referrer) {
            var q = pj(z.referrer);
            lj(q,
                "host") === D(24) && (l = h.xm)
        }
        if (!l) {
            var r = wr("__TAG_ASSISTANT");
            r.length && r[0].length && (l = h.rk)
        }
        l || b();
        if (!l && mn(n)) {
            var u = !1;
            Sc(z, "TADebugSignal", function() {
                u || (u = !0, b(), c())
            }, !1);
            w.setTimeout(function() {
                u || (u = !0, b(), c())
            }, 200)
        } else c()
    })(function() {
        !kg(47) || Nm()["0"] ? Lm() : Km()
    });

})()